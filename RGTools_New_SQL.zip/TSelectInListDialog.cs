using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace RGTools_New
{
    using ListModuleType = List<TListModule>;
    
    public partial class TSelectInListDialog : Form
    {
        public TSelectInListDialog()
        {
            InitializeComponent();

        }

        private void TSelectInListDialog_Load(object sender, EventArgs e)
        {
            textBox2.SelectionLength = 0;
            for (int i = 0; i < lstMasterModule.Items.Count; i++)
            {
                lstMasterModule.SelectedItems.Add(lstMasterModule.Items[i]);
            }

            textBox2.SelectionStart = 0;
            lstMasterModule.SelectedIndex = -1;

            btnOK.Focus();
        }
        ListModuleType _ListModule = null;
        internal void AddList(ListModuleType ListModule)
        {
            _ListModule = ListModule;

            foreach (TListModule lstModule in ListModule)
            {
                lstMasterModule.Items.Add(lstModule);
            }
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (_ListModule != null)
            {
                _ListModule.Clear();
                for (int i = 0; i < lstMasterModule.SelectedItems.Count; i++)
                {
                    _ListModule.Add((TListModule)lstMasterModule.SelectedItems[i]);
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (_ListModule != null)
            {
                _ListModule.Clear();
            }
        }

        private void lstMasterModule_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void lstMasterModule_DoubleClick(object sender, EventArgs e)
        {
            lstMasterModule.SelectedIndex = -1;
        }

     
     
    }
}