namespace RGTools_New
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tbPgBuildREM = new System.Windows.Forms.TabPage();
            this.btnBuildREMCancel = new System.Windows.Forms.Button();
            this.lblMsg = new System.Windows.Forms.Label();
            this.btnBuildREMSel = new System.Windows.Forms.Button();
            this.btnBuildREMProcess = new System.Windows.Forms.Button();
            this.txtBuildREMOutput = new System.Windows.Forms.TextBox();
            this.btnBuildREMBrowse = new System.Windows.Forms.Button();
            this.txtBuildREMDir = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.chkBuildREMCalculate = new System.Windows.Forms.CheckBox();
            this.tbPgBuildMODULE = new System.Windows.Forms.TabPage();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.cmdFixAirREM = new System.Windows.Forms.Button();
            this.btnModuleRemoveAll = new System.Windows.Forms.Button();
            this.btnModuleAddAll = new System.Windows.Forms.Button();
            this.btnModuleDBBrowse = new System.Windows.Forms.Button();
            this.btnModuleStart = new System.Windows.Forms.Button();
            this.btnModuleCancel = new System.Windows.Forms.Button();
            this.txtModuleDB = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.lblModuleMsg = new System.Windows.Forms.Label();
            this.lstModuleSel = new System.Windows.Forms.ListBox();
            this.lstModuleAval = new System.Windows.Forms.ListBox();
            this.btnModuleAdd = new System.Windows.Forms.Button();
            this.btnModuleRemove = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.btnModuleBrowse = new System.Windows.Forms.Button();
            this.txtModuleDir = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtModuleOut = new System.Windows.Forms.TextBox();
            this.tbPgModuleDel = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.lblDelModuleMsg = new System.Windows.Forms.Label();
            this.btnDelModBrowse = new System.Windows.Forms.Button();
            this.btnDelModOpen = new System.Windows.Forms.Button();
            this.txtDelModVer = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtDelModName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnDelModCancel = new System.Windows.Forms.Button();
            this.btnDelModRemAll = new System.Windows.Forms.Button();
            this.btnDelModAddAll = new System.Windows.Forms.Button();
            this.lstDelModSel = new System.Windows.Forms.ListBox();
            this.lstDelModAvail = new System.Windows.Forms.ListBox();
            this.btnDelModProcess = new System.Windows.Forms.Button();
            this.btnDelModAdd = new System.Windows.Forms.Button();
            this.btnDelModRemove = new System.Windows.Forms.Button();
            this.txtDelModOut = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbPgRGTC = new System.Windows.Forms.TabPage();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.lblRgtimeMsg = new System.Windows.Forms.Label();
            this.btbRunTimeCreationBrowse = new System.Windows.Forms.Button();
            this.btbRunTimeCreationOpen = new System.Windows.Forms.Button();
            this.txtRunTimeCreationVer = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtRunTimeCreationDB = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnRunTimeCreationCancel = new System.Windows.Forms.Button();
            this.txtRunTimeCreationOut = new System.Windows.Forms.TextBox();
            this.btnRunTimeCreationProcess = new System.Windows.Forms.Button();
            this.tbPgDelState = new System.Windows.Forms.TabPage();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.lblDelStMsg = new System.Windows.Forms.Label();
            this.btnDelStBrowse = new System.Windows.Forms.Button();
            this.btnDelStOpen = new System.Windows.Forms.Button();
            this.txtDelStVer = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtDelStDB = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btnDelStCancel = new System.Windows.Forms.Button();
            this.txtDelStOut = new System.Windows.Forms.TextBox();
            this.btnDelStProcess = new System.Windows.Forms.Button();
            this.tbPgUpload = new System.Windows.Forms.TabPage();
            this.splitContainer5 = new System.Windows.Forms.SplitContainer();
            this.lblLoadMsg = new System.Windows.Forms.Label();
            this.btnLdBrowse = new System.Windows.Forms.Button();
            this.btnLdOpen = new System.Windows.Forms.Button();
            this.txtLdVer = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtLoadDB = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.btnLdCancel = new System.Windows.Forms.Button();
            this.txtLdOut = new System.Windows.Forms.TextBox();
            this.btnLdProcess = new System.Windows.Forms.Button();
            this.tbPgMergSt = new System.Windows.Forms.TabPage();
            this.splitContainer8 = new System.Windows.Forms.SplitContainer();
            this.lblMergeStMsg = new System.Windows.Forms.Label();
            this.btnMergeSTBrowse = new System.Windows.Forms.Button();
            this.btnMergeSTOpen = new System.Windows.Forms.Button();
            this.txtMergeSTVer = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.txtMergeStDB = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.chkMergeSynCheck = new System.Windows.Forms.CheckBox();
            this.btnMergeSTCancel = new System.Windows.Forms.Button();
            this.txtMergeSTOut = new System.Windows.Forms.TextBox();
            this.btnMergeSTProcess = new System.Windows.Forms.Button();
            this.txtMergeSTVerName = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.txtMergeSTDate = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.btnMergeSTRemoveAll = new System.Windows.Forms.Button();
            this.btnMergeSTAddAll = new System.Windows.Forms.Button();
            this.lstMergeSTStates = new System.Windows.Forms.ListBox();
            this.lstMergeSTAvaiSt = new System.Windows.Forms.ListBox();
            this.btnMergeSTAdd = new System.Windows.Forms.Button();
            this.btnMergeSTRemove = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.txtMergeSTModuleRoot = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.txtMergeSTSateRoot = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.tbPgMergFederal = new System.Windows.Forms.TabPage();
            this.splitContainer7 = new System.Windows.Forms.SplitContainer();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.lblMergeFModuleMsg = new System.Windows.Forms.Label();
            this.txtMergeFMasterVer = new System.Windows.Forms.TextBox();
            this.btnMergeFModuleBrowse = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.btnMergeFModuleOpen = new System.Windows.Forms.Button();
            this.txtMergeFMasterDB = new System.Windows.Forms.TextBox();
            this.txtMergeFModuleVer = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.btnMergeFMasterOpen = new System.Windows.Forms.Button();
            this.txtMergeFModuleDB = new System.Windows.Forms.TextBox();
            this.btnMergeFMasterBrowse = new System.Windows.Forms.Button();
            this.label32 = new System.Windows.Forms.Label();
            this.lblMergeFMasterMsg = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.btnMergeFProcess = new System.Windows.Forms.Button();
            this.btnMergeFCancel = new System.Windows.Forms.Button();
            this.txtDateSC = new System.Windows.Forms.TextBox();
            this.txtDateDA = new System.Windows.Forms.TextBox();
            this.txtVNameSC = new System.Windows.Forms.TextBox();
            this.txtVNameDA = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.txtMergeFdOut = new System.Windows.Forms.TextBox();
            this.tbPgBlobsCreat = new System.Windows.Forms.TabPage();
            this.splitContainer6 = new System.Windows.Forms.SplitContainer();
            this.lblBlobsMsg = new System.Windows.Forms.Label();
            this.btnBlobsBrowse = new System.Windows.Forms.Button();
            this.btnBlobsOpen = new System.Windows.Forms.Button();
            this.txtBlobsVer = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtBlobsDB = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.btnBlobsProcess = new System.Windows.Forms.Button();
            this.btnBlobsCancel = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.optMissingBlobs = new System.Windows.Forms.RadioButton();
            this.optAllTheBlobs = new System.Windows.Forms.RadioButton();
            this.txtBlobsOut = new System.Windows.Forms.TextBox();
            this.tbPgLog = new System.Windows.Forms.TabPage();
            this.btnLogDel = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.dtpLog = new System.Windows.Forms.DateTimePicker();
            this.cboLogPageType = new System.Windows.Forms.ComboBox();
            this.btnLogRefresh = new System.Windows.Forms.Button();
            this.txtLogOut = new System.Windows.Forms.TextBox();
            this.btnLogExport = new System.Windows.Forms.Button();
            this.tbPgAuto = new System.Windows.Forms.TabPage();
            this.btnAutoBrowseDB = new System.Windows.Forms.Button();
            this.txtAutoDB = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.btnAutoCancel = new System.Windows.Forms.Button();
            this.lblAutoMsg = new System.Windows.Forms.Label();
            this.btnAutoSelDir = new System.Windows.Forms.Button();
            this.btnAutoProcess = new System.Windows.Forms.Button();
            this.txtAutoOut = new System.Windows.Forms.TextBox();
            this.btnAutoBrowseDir = new System.Windows.Forms.Button();
            this.txtAutoDir = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.chkAutoCalc = new System.Windows.Forms.CheckBox();
            this.tbPgCheck = new System.Windows.Forms.TabPage();
            this.spDBCheck = new System.Windows.Forms.SplitContainer();
            this.lblDBCheckMsg = new System.Windows.Forms.Label();
            this.btnDBCheckBrowse = new System.Windows.Forms.Button();
            this.btnDBCheckOpen = new System.Windows.Forms.Button();
            this.txtDBCheckVer = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.txtDBCheckDB = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.btnDBCheckProcess = new System.Windows.Forms.Button();
            this.txtDBCheckOut = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rdoLookForDuplicateQuestionLinkText = new System.Windows.Forms.RadioButton();
            this.rdoMissingLink = new System.Windows.Forms.RadioButton();
            this.rdoFix_av_collision = new System.Windows.Forms.RadioButton();
            this.rdoduplicateappsn = new System.Windows.Forms.RadioButton();
            this.rdoDup_state_domainsn = new System.Windows.Forms.RadioButton();
            this.rdoApplicabilityRangeMap2 = new System.Windows.Forms.RadioButton();
            this.tabControl.SuspendLayout();
            this.tbPgBuildREM.SuspendLayout();
            this.tbPgBuildMODULE.SuspendLayout();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            this.tbPgModuleDel.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tbPgRGTC.SuspendLayout();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.tbPgDelState.SuspendLayout();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.tbPgUpload.SuspendLayout();
            this.splitContainer5.Panel1.SuspendLayout();
            this.splitContainer5.Panel2.SuspendLayout();
            this.splitContainer5.SuspendLayout();
            this.tbPgMergSt.SuspendLayout();
            this.splitContainer8.Panel1.SuspendLayout();
            this.splitContainer8.Panel2.SuspendLayout();
            this.splitContainer8.SuspendLayout();
            this.tbPgMergFederal.SuspendLayout();
            this.splitContainer7.Panel1.SuspendLayout();
            this.splitContainer7.Panel2.SuspendLayout();
            this.splitContainer7.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tbPgBlobsCreat.SuspendLayout();
            this.splitContainer6.Panel1.SuspendLayout();
            this.splitContainer6.Panel2.SuspendLayout();
            this.splitContainer6.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tbPgLog.SuspendLayout();
            this.tbPgAuto.SuspendLayout();
            this.tbPgCheck.SuspendLayout();
            this.spDBCheck.Panel1.SuspendLayout();
            this.spDBCheck.Panel2.SuspendLayout();
            this.spDBCheck.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tbPgBuildREM);
            this.tabControl.Controls.Add(this.tbPgBuildMODULE);
            this.tabControl.Controls.Add(this.tbPgModuleDel);
            this.tabControl.Controls.Add(this.tbPgRGTC);
            this.tabControl.Controls.Add(this.tbPgDelState);
            this.tabControl.Controls.Add(this.tbPgUpload);
            this.tabControl.Controls.Add(this.tbPgMergSt);
            this.tabControl.Controls.Add(this.tbPgMergFederal);
            this.tabControl.Controls.Add(this.tbPgBlobsCreat);
            this.tabControl.Controls.Add(this.tbPgLog);
            this.tabControl.Controls.Add(this.tbPgAuto);
            this.tabControl.Controls.Add(this.tbPgCheck);
            this.tabControl.Location = new System.Drawing.Point(2, 1);
            this.tabControl.Multiline = true;
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(588, 532);
            this.tabControl.TabIndex = 1;
            // 
            // tbPgBuildREM
            // 
            this.tbPgBuildREM.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tbPgBuildREM.Controls.Add(this.btnBuildREMCancel);
            this.tbPgBuildREM.Controls.Add(this.lblMsg);
            this.tbPgBuildREM.Controls.Add(this.btnBuildREMSel);
            this.tbPgBuildREM.Controls.Add(this.btnBuildREMProcess);
            this.tbPgBuildREM.Controls.Add(this.txtBuildREMOutput);
            this.tbPgBuildREM.Controls.Add(this.btnBuildREMBrowse);
            this.tbPgBuildREM.Controls.Add(this.txtBuildREMDir);
            this.tbPgBuildREM.Controls.Add(this.label1);
            this.tbPgBuildREM.Controls.Add(this.chkBuildREMCalculate);
            this.tbPgBuildREM.Location = new System.Drawing.Point(4, 40);
            this.tbPgBuildREM.Name = "tbPgBuildREM";
            this.tbPgBuildREM.Padding = new System.Windows.Forms.Padding(3);
            this.tbPgBuildREM.Size = new System.Drawing.Size(580, 488);
            this.tbPgBuildREM.TabIndex = 0;
            this.tbPgBuildREM.Text = "Build REM Files";
            // 
            // btnBuildREMCancel
            // 
            this.btnBuildREMCancel.Location = new System.Drawing.Point(479, 58);
            this.btnBuildREMCancel.Name = "btnBuildREMCancel";
            this.btnBuildREMCancel.Size = new System.Drawing.Size(85, 23);
            this.btnBuildREMCancel.TabIndex = 8;
            this.btnBuildREMCancel.Text = "&Cancel";
            this.btnBuildREMCancel.UseVisualStyleBackColor = true;
            this.btnBuildREMCancel.Visible = false;
            // 
            // lblMsg
            // 
            this.lblMsg.AutoSize = true;
            this.lblMsg.ForeColor = System.Drawing.Color.Red;
            this.lblMsg.Location = new System.Drawing.Point(144, 10);
            this.lblMsg.Name = "lblMsg";
            this.lblMsg.Size = new System.Drawing.Size(0, 13);
            this.lblMsg.TabIndex = 7;
            // 
            // btnBuildREMSel
            // 
            this.btnBuildREMSel.Location = new System.Drawing.Point(351, 58);
            this.btnBuildREMSel.Name = "btnBuildREMSel";
            this.btnBuildREMSel.Size = new System.Drawing.Size(98, 23);
            this.btnBuildREMSel.TabIndex = 6;
            this.btnBuildREMSel.Text = "Select &Directories";
            this.btnBuildREMSel.UseVisualStyleBackColor = true;
            // 
            // btnBuildREMProcess
            // 
            this.btnBuildREMProcess.Location = new System.Drawing.Point(479, 58);
            this.btnBuildREMProcess.Name = "btnBuildREMProcess";
            this.btnBuildREMProcess.Size = new System.Drawing.Size(85, 23);
            this.btnBuildREMProcess.TabIndex = 5;
            this.btnBuildREMProcess.Text = "&Start Process";
            this.btnBuildREMProcess.UseVisualStyleBackColor = true;
            // 
            // txtBuildREMOutput
            // 
            this.txtBuildREMOutput.Location = new System.Drawing.Point(19, 103);
            this.txtBuildREMOutput.Multiline = true;
            this.txtBuildREMOutput.Name = "txtBuildREMOutput";
            this.txtBuildREMOutput.ReadOnly = true;
            this.txtBuildREMOutput.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtBuildREMOutput.Size = new System.Drawing.Size(545, 378);
            this.txtBuildREMOutput.TabIndex = 4;
            // 
            // btnBuildREMBrowse
            // 
            this.btnBuildREMBrowse.Location = new System.Drawing.Point(479, 27);
            this.btnBuildREMBrowse.Name = "btnBuildREMBrowse";
            this.btnBuildREMBrowse.Size = new System.Drawing.Size(85, 23);
            this.btnBuildREMBrowse.TabIndex = 3;
            this.btnBuildREMBrowse.Text = "&Browse";
            this.btnBuildREMBrowse.UseVisualStyleBackColor = true;
            // 
            // txtBuildREMDir
            // 
            this.txtBuildREMDir.Location = new System.Drawing.Point(15, 27);
            this.txtBuildREMDir.Name = "txtBuildREMDir";
            this.txtBuildREMDir.Size = new System.Drawing.Size(430, 20);
            this.txtBuildREMDir.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Source Text Directory";
            // 
            // chkBuildREMCalculate
            // 
            this.chkBuildREMCalculate.AutoSize = true;
            this.chkBuildREMCalculate.Location = new System.Drawing.Point(19, 58);
            this.chkBuildREMCalculate.Name = "chkBuildREMCalculate";
            this.chkBuildREMCalculate.Size = new System.Drawing.Size(201, 17);
            this.chkBuildREMCalculate.TabIndex = 0;
            this.chkBuildREMCalculate.Text = "Calculate Domain/Question Changes";
            this.chkBuildREMCalculate.UseVisualStyleBackColor = true;
            // 
            // tbPgBuildMODULE
            // 
            this.tbPgBuildMODULE.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tbPgBuildMODULE.Controls.Add(this.splitContainer4);
            this.tbPgBuildMODULE.Location = new System.Drawing.Point(4, 40);
            this.tbPgBuildMODULE.Name = "tbPgBuildMODULE";
            this.tbPgBuildMODULE.Padding = new System.Windows.Forms.Padding(3);
            this.tbPgBuildMODULE.Size = new System.Drawing.Size(580, 488);
            this.tbPgBuildMODULE.TabIndex = 6;
            this.tbPgBuildMODULE.Text = "Build MODULE.DB";
            // 
            // splitContainer4
            // 
            this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer4.Location = new System.Drawing.Point(3, 3);
            this.splitContainer4.Name = "splitContainer4";
            this.splitContainer4.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.cmdFixAirREM);
            this.splitContainer4.Panel1.Controls.Add(this.btnModuleRemoveAll);
            this.splitContainer4.Panel1.Controls.Add(this.btnModuleAddAll);
            this.splitContainer4.Panel1.Controls.Add(this.btnModuleDBBrowse);
            this.splitContainer4.Panel1.Controls.Add(this.btnModuleStart);
            this.splitContainer4.Panel1.Controls.Add(this.btnModuleCancel);
            this.splitContainer4.Panel1.Controls.Add(this.txtModuleDB);
            this.splitContainer4.Panel1.Controls.Add(this.label10);
            this.splitContainer4.Panel1.Controls.Add(this.lblModuleMsg);
            this.splitContainer4.Panel1.Controls.Add(this.lstModuleSel);
            this.splitContainer4.Panel1.Controls.Add(this.lstModuleAval);
            this.splitContainer4.Panel1.Controls.Add(this.btnModuleAdd);
            this.splitContainer4.Panel1.Controls.Add(this.btnModuleRemove);
            this.splitContainer4.Panel1.Controls.Add(this.label12);
            this.splitContainer4.Panel1.Controls.Add(this.label13);
            this.splitContainer4.Panel1.Controls.Add(this.btnModuleBrowse);
            this.splitContainer4.Panel1.Controls.Add(this.txtModuleDir);
            this.splitContainer4.Panel1.Controls.Add(this.label11);
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.txtModuleOut);
            this.splitContainer4.Size = new System.Drawing.Size(574, 482);
            this.splitContainer4.SplitterDistance = 304;
            this.splitContainer4.TabIndex = 0;
            // 
            // cmdFixAirREM
            // 
            this.cmdFixAirREM.Enabled = false;
            this.cmdFixAirREM.Location = new System.Drawing.Point(474, 63);
            this.cmdFixAirREM.Name = "cmdFixAirREM";
            this.cmdFixAirREM.Size = new System.Drawing.Size(85, 23);
            this.cmdFixAirREM.TabIndex = 38;
            this.cmdFixAirREM.Text = "&Fix Air REMs";
            this.cmdFixAirREM.UseVisualStyleBackColor = true;
            // 
            // btnModuleRemoveAll
            // 
            this.btnModuleRemoveAll.Location = new System.Drawing.Point(249, 170);
            this.btnModuleRemoveAll.Name = "btnModuleRemoveAll";
            this.btnModuleRemoveAll.Size = new System.Drawing.Size(80, 30);
            this.btnModuleRemoveAll.TabIndex = 37;
            this.btnModuleRemoveAll.Text = "<-R&emove All";
            this.btnModuleRemoveAll.UseVisualStyleBackColor = true;
            // 
            // btnModuleAddAll
            // 
            this.btnModuleAddAll.Location = new System.Drawing.Point(250, 205);
            this.btnModuleAddAll.Name = "btnModuleAddAll";
            this.btnModuleAddAll.Size = new System.Drawing.Size(80, 30);
            this.btnModuleAddAll.TabIndex = 36;
            this.btnModuleAddAll.Text = "A&dd All ->";
            this.btnModuleAddAll.UseVisualStyleBackColor = true;
            // 
            // btnModuleDBBrowse
            // 
            this.btnModuleDBBrowse.Location = new System.Drawing.Point(484, 262);
            this.btnModuleDBBrowse.Name = "btnModuleDBBrowse";
            this.btnModuleDBBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnModuleDBBrowse.TabIndex = 35;
            this.btnModuleDBBrowse.Text = "&Browse";
            this.btnModuleDBBrowse.UseVisualStyleBackColor = true;
            // 
            // btnModuleStart
            // 
            this.btnModuleStart.Location = new System.Drawing.Point(474, 29);
            this.btnModuleStart.Name = "btnModuleStart";
            this.btnModuleStart.Size = new System.Drawing.Size(85, 23);
            this.btnModuleStart.TabIndex = 34;
            this.btnModuleStart.Text = "&Start Process";
            this.btnModuleStart.UseVisualStyleBackColor = true;
            // 
            // btnModuleCancel
            // 
            this.btnModuleCancel.Location = new System.Drawing.Point(474, 29);
            this.btnModuleCancel.Name = "btnModuleCancel";
            this.btnModuleCancel.Size = new System.Drawing.Size(85, 23);
            this.btnModuleCancel.TabIndex = 33;
            this.btnModuleCancel.Text = "&Cancel";
            this.btnModuleCancel.UseVisualStyleBackColor = true;
            this.btnModuleCancel.Visible = false;
            // 
            // txtModuleDB
            // 
            this.txtModuleDB.Location = new System.Drawing.Point(212, 265);
            this.txtModuleDB.Name = "txtModuleDB";
            this.txtModuleDB.Size = new System.Drawing.Size(256, 20);
            this.txtModuleDB.TabIndex = 31;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(13, 268);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(193, 13);
            this.label10.TabIndex = 30;
            this.label10.Text = "Name of the Module Database to Build:";
            // 
            // lblModuleMsg
            // 
            this.lblModuleMsg.AutoSize = true;
            this.lblModuleMsg.ForeColor = System.Drawing.Color.Red;
            this.lblModuleMsg.Location = new System.Drawing.Point(13, 14);
            this.lblModuleMsg.Name = "lblModuleMsg";
            this.lblModuleMsg.Size = new System.Drawing.Size(0, 13);
            this.lblModuleMsg.TabIndex = 29;
            // 
            // lstModuleSel
            // 
            this.lstModuleSel.FormattingEnabled = true;
            this.lstModuleSel.Location = new System.Drawing.Point(363, 98);
            this.lstModuleSel.Name = "lstModuleSel";
            this.lstModuleSel.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstModuleSel.Size = new System.Drawing.Size(200, 147);
            this.lstModuleSel.TabIndex = 28;
            // 
            // lstModuleAval
            // 
            this.lstModuleAval.FormattingEnabled = true;
            this.lstModuleAval.Location = new System.Drawing.Point(16, 98);
            this.lstModuleAval.Name = "lstModuleAval";
            this.lstModuleAval.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstModuleAval.Size = new System.Drawing.Size(200, 147);
            this.lstModuleAval.TabIndex = 27;
            // 
            // btnModuleAdd
            // 
            this.btnModuleAdd.Enabled = false;
            this.btnModuleAdd.Location = new System.Drawing.Point(250, 98);
            this.btnModuleAdd.Name = "btnModuleAdd";
            this.btnModuleAdd.Size = new System.Drawing.Size(80, 30);
            this.btnModuleAdd.TabIndex = 26;
            this.btnModuleAdd.Text = "&Add ->";
            this.btnModuleAdd.UseVisualStyleBackColor = true;
            // 
            // btnModuleRemove
            // 
            this.btnModuleRemove.Enabled = false;
            this.btnModuleRemove.Location = new System.Drawing.Point(250, 134);
            this.btnModuleRemove.Name = "btnModuleRemove";
            this.btnModuleRemove.Size = new System.Drawing.Size(80, 30);
            this.btnModuleRemove.TabIndex = 25;
            this.btnModuleRemove.Text = "<- &Remove";
            this.btnModuleRemove.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(360, 73);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(85, 13);
            this.label12.TabIndex = 19;
            this.label12.Text = "Modules to Build";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(13, 73);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(91, 13);
            this.label13.TabIndex = 18;
            this.label13.Text = "Available Module:";
            // 
            // btnModuleBrowse
            // 
            this.btnModuleBrowse.Location = new System.Drawing.Point(393, 28);
            this.btnModuleBrowse.Name = "btnModuleBrowse";
            this.btnModuleBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnModuleBrowse.TabIndex = 17;
            this.btnModuleBrowse.Text = "&Browse";
            this.btnModuleBrowse.UseVisualStyleBackColor = true;
            // 
            // txtModuleDir
            // 
            this.txtModuleDir.Location = new System.Drawing.Point(135, 31);
            this.txtModuleDir.Name = "txtModuleDir";
            this.txtModuleDir.Size = new System.Drawing.Size(244, 20);
            this.txtModuleDir.TabIndex = 13;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(13, 36);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(116, 13);
            this.label11.TabIndex = 12;
            this.label11.Text = "Module Root Directory:";
            // 
            // txtModuleOut
            // 
            this.txtModuleOut.Location = new System.Drawing.Point(16, 3);
            this.txtModuleOut.Multiline = true;
            this.txtModuleOut.Name = "txtModuleOut";
            this.txtModuleOut.ReadOnly = true;
            this.txtModuleOut.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtModuleOut.Size = new System.Drawing.Size(547, 167);
            this.txtModuleOut.TabIndex = 12;
            // 
            // tbPgModuleDel
            // 
            this.tbPgModuleDel.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tbPgModuleDel.Controls.Add(this.splitContainer1);
            this.tbPgModuleDel.Location = new System.Drawing.Point(4, 40);
            this.tbPgModuleDel.Name = "tbPgModuleDel";
            this.tbPgModuleDel.Padding = new System.Windows.Forms.Padding(3);
            this.tbPgModuleDel.Size = new System.Drawing.Size(580, 488);
            this.tbPgModuleDel.TabIndex = 1;
            this.tbPgModuleDel.Text = "Module Deletion";
            // 
            // splitContainer1
            // 
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer1.Location = new System.Drawing.Point(3, 6);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.lblDelModuleMsg);
            this.splitContainer1.Panel1.Controls.Add(this.btnDelModBrowse);
            this.splitContainer1.Panel1.Controls.Add(this.btnDelModOpen);
            this.splitContainer1.Panel1.Controls.Add(this.txtDelModVer);
            this.splitContainer1.Panel1.Controls.Add(this.label3);
            this.splitContainer1.Panel1.Controls.Add(this.txtDelModName);
            this.splitContainer1.Panel1.Controls.Add(this.label2);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.btnDelModCancel);
            this.splitContainer1.Panel2.Controls.Add(this.btnDelModRemAll);
            this.splitContainer1.Panel2.Controls.Add(this.btnDelModAddAll);
            this.splitContainer1.Panel2.Controls.Add(this.lstDelModSel);
            this.splitContainer1.Panel2.Controls.Add(this.lstDelModAvail);
            this.splitContainer1.Panel2.Controls.Add(this.btnDelModProcess);
            this.splitContainer1.Panel2.Controls.Add(this.btnDelModAdd);
            this.splitContainer1.Panel2.Controls.Add(this.btnDelModRemove);
            this.splitContainer1.Panel2.Controls.Add(this.txtDelModOut);
            this.splitContainer1.Panel2.Controls.Add(this.label5);
            this.splitContainer1.Panel2.Controls.Add(this.label4);
            this.splitContainer1.Size = new System.Drawing.Size(577, 486);
            this.splitContainer1.SplitterDistance = 101;
            this.splitContainer1.TabIndex = 6;
            // 
            // lblDelModuleMsg
            // 
            this.lblDelModuleMsg.AutoSize = true;
            this.lblDelModuleMsg.ForeColor = System.Drawing.Color.Red;
            this.lblDelModuleMsg.Location = new System.Drawing.Point(161, 13);
            this.lblDelModuleMsg.Name = "lblDelModuleMsg";
            this.lblDelModuleMsg.Size = new System.Drawing.Size(0, 13);
            this.lblDelModuleMsg.TabIndex = 12;
            // 
            // btnDelModBrowse
            // 
            this.btnDelModBrowse.Location = new System.Drawing.Point(487, 27);
            this.btnDelModBrowse.Name = "btnDelModBrowse";
            this.btnDelModBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnDelModBrowse.TabIndex = 11;
            this.btnDelModBrowse.Text = "&Browse";
            this.btnDelModBrowse.UseVisualStyleBackColor = true;
            // 
            // btnDelModOpen
            // 
            this.btnDelModOpen.Location = new System.Drawing.Point(487, 58);
            this.btnDelModOpen.Name = "btnDelModOpen";
            this.btnDelModOpen.Size = new System.Drawing.Size(75, 23);
            this.btnDelModOpen.TabIndex = 10;
            this.btnDelModOpen.Text = "&Open";
            this.btnDelModOpen.UseVisualStyleBackColor = true;
            // 
            // txtDelModVer
            // 
            this.txtDelModVer.Location = new System.Drawing.Point(63, 60);
            this.txtDelModVer.Name = "txtDelModVer";
            this.txtDelModVer.ReadOnly = true;
            this.txtDelModVer.Size = new System.Drawing.Size(180, 20);
            this.txtDelModVer.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Version:";
            // 
            // txtDelModName
            // 
            this.txtDelModName.Location = new System.Drawing.Point(15, 27);
            this.txtDelModName.Name = "txtDelModName";
            this.txtDelModName.Size = new System.Drawing.Size(452, 20);
            this.txtDelModName.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Module Database Name:";
            // 
            // btnDelModCancel
            // 
            this.btnDelModCancel.Location = new System.Drawing.Point(248, 23);
            this.btnDelModCancel.Name = "btnDelModCancel";
            this.btnDelModCancel.Size = new System.Drawing.Size(80, 30);
            this.btnDelModCancel.TabIndex = 40;
            this.btnDelModCancel.Text = "&Cancel";
            this.btnDelModCancel.UseVisualStyleBackColor = true;
            this.btnDelModCancel.Visible = false;
            // 
            // btnDelModRemAll
            // 
            this.btnDelModRemAll.Location = new System.Drawing.Point(248, 192);
            this.btnDelModRemAll.Name = "btnDelModRemAll";
            this.btnDelModRemAll.Size = new System.Drawing.Size(80, 30);
            this.btnDelModRemAll.TabIndex = 39;
            this.btnDelModRemAll.Text = "<-R&emove All";
            this.btnDelModRemAll.UseVisualStyleBackColor = true;
            // 
            // btnDelModAddAll
            // 
            this.btnDelModAddAll.Location = new System.Drawing.Point(248, 156);
            this.btnDelModAddAll.Name = "btnDelModAddAll";
            this.btnDelModAddAll.Size = new System.Drawing.Size(80, 30);
            this.btnDelModAddAll.TabIndex = 38;
            this.btnDelModAddAll.Text = "A&dd All ->";
            this.btnDelModAddAll.UseVisualStyleBackColor = true;
            // 
            // lstDelModSel
            // 
            this.lstDelModSel.FormattingEnabled = true;
            this.lstDelModSel.Location = new System.Drawing.Point(362, 51);
            this.lstDelModSel.Name = "lstDelModSel";
            this.lstDelModSel.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstDelModSel.Size = new System.Drawing.Size(200, 173);
            this.lstDelModSel.TabIndex = 29;
            // 
            // lstDelModAvail
            // 
            this.lstDelModAvail.FormattingEnabled = true;
            this.lstDelModAvail.Location = new System.Drawing.Point(15, 51);
            this.lstDelModAvail.Name = "lstDelModAvail";
            this.lstDelModAvail.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstDelModAvail.Size = new System.Drawing.Size(200, 173);
            this.lstDelModAvail.TabIndex = 28;
            // 
            // btnDelModProcess
            // 
            this.btnDelModProcess.Location = new System.Drawing.Point(248, 23);
            this.btnDelModProcess.Name = "btnDelModProcess";
            this.btnDelModProcess.Size = new System.Drawing.Size(80, 30);
            this.btnDelModProcess.TabIndex = 14;
            this.btnDelModProcess.Text = "&Start Process";
            this.btnDelModProcess.UseVisualStyleBackColor = true;
            // 
            // btnDelModAdd
            // 
            this.btnDelModAdd.Enabled = false;
            this.btnDelModAdd.Location = new System.Drawing.Point(248, 84);
            this.btnDelModAdd.Name = "btnDelModAdd";
            this.btnDelModAdd.Size = new System.Drawing.Size(80, 30);
            this.btnDelModAdd.TabIndex = 13;
            this.btnDelModAdd.Text = "&Add ->";
            this.btnDelModAdd.UseVisualStyleBackColor = true;
            // 
            // btnDelModRemove
            // 
            this.btnDelModRemove.Enabled = false;
            this.btnDelModRemove.Location = new System.Drawing.Point(248, 120);
            this.btnDelModRemove.Name = "btnDelModRemove";
            this.btnDelModRemove.Size = new System.Drawing.Size(80, 30);
            this.btnDelModRemove.TabIndex = 12;
            this.btnDelModRemove.Text = "<- &Remove";
            this.btnDelModRemove.UseVisualStyleBackColor = true;
            // 
            // txtDelModOut
            // 
            this.txtDelModOut.Location = new System.Drawing.Point(15, 238);
            this.txtDelModOut.Multiline = true;
            this.txtDelModOut.Name = "txtDelModOut";
            this.txtDelModOut.ReadOnly = true;
            this.txtDelModOut.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtDelModOut.Size = new System.Drawing.Size(547, 132);
            this.txtDelModOut.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(371, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(96, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Modules to Delete:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Available Module:";
            // 
            // tbPgRGTC
            // 
            this.tbPgRGTC.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tbPgRGTC.Controls.Add(this.splitContainer2);
            this.tbPgRGTC.Location = new System.Drawing.Point(4, 40);
            this.tbPgRGTC.Name = "tbPgRGTC";
            this.tbPgRGTC.Padding = new System.Windows.Forms.Padding(3);
            this.tbPgRGTC.Size = new System.Drawing.Size(580, 488);
            this.tbPgRGTC.TabIndex = 2;
            this.tbPgRGTC.Text = "Run-Time Creation";
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(3, 3);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.lblRgtimeMsg);
            this.splitContainer2.Panel1.Controls.Add(this.btbRunTimeCreationBrowse);
            this.splitContainer2.Panel1.Controls.Add(this.btbRunTimeCreationOpen);
            this.splitContainer2.Panel1.Controls.Add(this.txtRunTimeCreationVer);
            this.splitContainer2.Panel1.Controls.Add(this.label6);
            this.splitContainer2.Panel1.Controls.Add(this.txtRunTimeCreationDB);
            this.splitContainer2.Panel1.Controls.Add(this.label7);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.btnRunTimeCreationCancel);
            this.splitContainer2.Panel2.Controls.Add(this.txtRunTimeCreationOut);
            this.splitContainer2.Panel2.Controls.Add(this.btnRunTimeCreationProcess);
            this.splitContainer2.Size = new System.Drawing.Size(574, 482);
            this.splitContainer2.SplitterDistance = 107;
            this.splitContainer2.TabIndex = 0;
            // 
            // lblRgtimeMsg
            // 
            this.lblRgtimeMsg.AutoSize = true;
            this.lblRgtimeMsg.ForeColor = System.Drawing.Color.Red;
            this.lblRgtimeMsg.Location = new System.Drawing.Point(143, 13);
            this.lblRgtimeMsg.Name = "lblRgtimeMsg";
            this.lblRgtimeMsg.Size = new System.Drawing.Size(0, 13);
            this.lblRgtimeMsg.TabIndex = 30;
            // 
            // btbRunTimeCreationBrowse
            // 
            this.btbRunTimeCreationBrowse.Location = new System.Drawing.Point(487, 27);
            this.btbRunTimeCreationBrowse.Name = "btbRunTimeCreationBrowse";
            this.btbRunTimeCreationBrowse.Size = new System.Drawing.Size(75, 23);
            this.btbRunTimeCreationBrowse.TabIndex = 17;
            this.btbRunTimeCreationBrowse.Text = "&Browse";
            this.btbRunTimeCreationBrowse.UseVisualStyleBackColor = true;
            // 
            // btbRunTimeCreationOpen
            // 
            this.btbRunTimeCreationOpen.Location = new System.Drawing.Point(487, 58);
            this.btbRunTimeCreationOpen.Name = "btbRunTimeCreationOpen";
            this.btbRunTimeCreationOpen.Size = new System.Drawing.Size(75, 23);
            this.btbRunTimeCreationOpen.TabIndex = 16;
            this.btbRunTimeCreationOpen.Text = "&Open";
            this.btbRunTimeCreationOpen.UseVisualStyleBackColor = true;
            // 
            // txtRunTimeCreationVer
            // 
            this.txtRunTimeCreationVer.Location = new System.Drawing.Point(63, 60);
            this.txtRunTimeCreationVer.Name = "txtRunTimeCreationVer";
            this.txtRunTimeCreationVer.ReadOnly = true;
            this.txtRunTimeCreationVer.Size = new System.Drawing.Size(180, 20);
            this.txtRunTimeCreationVer.TabIndex = 15;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 63);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "Version:";
            // 
            // txtRunTimeCreationDB
            // 
            this.txtRunTimeCreationDB.Location = new System.Drawing.Point(15, 27);
            this.txtRunTimeCreationDB.Name = "txtRunTimeCreationDB";
            this.txtRunTimeCreationDB.Size = new System.Drawing.Size(452, 20);
            this.txtRunTimeCreationDB.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 11);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(125, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Module Database Name:";
            // 
            // btnRunTimeCreationCancel
            // 
            this.btnRunTimeCreationCancel.Location = new System.Drawing.Point(468, 3);
            this.btnRunTimeCreationCancel.Name = "btnRunTimeCreationCancel";
            this.btnRunTimeCreationCancel.Size = new System.Drawing.Size(94, 30);
            this.btnRunTimeCreationCancel.TabIndex = 41;
            this.btnRunTimeCreationCancel.Text = "&Cancel";
            this.btnRunTimeCreationCancel.UseVisualStyleBackColor = true;
            this.btnRunTimeCreationCancel.Visible = false;
            // 
            // txtRunTimeCreationOut
            // 
            this.txtRunTimeCreationOut.Location = new System.Drawing.Point(15, 39);
            this.txtRunTimeCreationOut.Multiline = true;
            this.txtRunTimeCreationOut.Name = "txtRunTimeCreationOut";
            this.txtRunTimeCreationOut.ReadOnly = true;
            this.txtRunTimeCreationOut.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtRunTimeCreationOut.Size = new System.Drawing.Size(547, 328);
            this.txtRunTimeCreationOut.TabIndex = 16;
            // 
            // btnRunTimeCreationProcess
            // 
            this.btnRunTimeCreationProcess.Enabled = false;
            this.btnRunTimeCreationProcess.Location = new System.Drawing.Point(468, 4);
            this.btnRunTimeCreationProcess.Name = "btnRunTimeCreationProcess";
            this.btnRunTimeCreationProcess.Size = new System.Drawing.Size(94, 29);
            this.btnRunTimeCreationProcess.TabIndex = 15;
            this.btnRunTimeCreationProcess.Text = "&Start Process";
            this.btnRunTimeCreationProcess.UseVisualStyleBackColor = true;
            // 
            // tbPgDelState
            // 
            this.tbPgDelState.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tbPgDelState.Controls.Add(this.splitContainer3);
            this.tbPgDelState.Location = new System.Drawing.Point(4, 40);
            this.tbPgDelState.Name = "tbPgDelState";
            this.tbPgDelState.Padding = new System.Windows.Forms.Padding(3);
            this.tbPgDelState.Size = new System.Drawing.Size(580, 488);
            this.tbPgDelState.TabIndex = 3;
            this.tbPgDelState.Text = "Delete State";
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(3, 3);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.lblDelStMsg);
            this.splitContainer3.Panel1.Controls.Add(this.btnDelStBrowse);
            this.splitContainer3.Panel1.Controls.Add(this.btnDelStOpen);
            this.splitContainer3.Panel1.Controls.Add(this.txtDelStVer);
            this.splitContainer3.Panel1.Controls.Add(this.label8);
            this.splitContainer3.Panel1.Controls.Add(this.txtDelStDB);
            this.splitContainer3.Panel1.Controls.Add(this.label9);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.btnDelStCancel);
            this.splitContainer3.Panel2.Controls.Add(this.txtDelStOut);
            this.splitContainer3.Panel2.Controls.Add(this.btnDelStProcess);
            this.splitContainer3.Size = new System.Drawing.Size(574, 482);
            this.splitContainer3.SplitterDistance = 108;
            this.splitContainer3.TabIndex = 0;
            // 
            // lblDelStMsg
            // 
            this.lblDelStMsg.AutoSize = true;
            this.lblDelStMsg.ForeColor = System.Drawing.Color.Red;
            this.lblDelStMsg.Location = new System.Drawing.Point(143, 11);
            this.lblDelStMsg.Name = "lblDelStMsg";
            this.lblDelStMsg.Size = new System.Drawing.Size(0, 13);
            this.lblDelStMsg.TabIndex = 31;
            // 
            // btnDelStBrowse
            // 
            this.btnDelStBrowse.Location = new System.Drawing.Point(487, 27);
            this.btnDelStBrowse.Name = "btnDelStBrowse";
            this.btnDelStBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnDelStBrowse.TabIndex = 23;
            this.btnDelStBrowse.Text = "&Browse";
            this.btnDelStBrowse.UseVisualStyleBackColor = true;
            // 
            // btnDelStOpen
            // 
            this.btnDelStOpen.Location = new System.Drawing.Point(487, 58);
            this.btnDelStOpen.Name = "btnDelStOpen";
            this.btnDelStOpen.Size = new System.Drawing.Size(75, 23);
            this.btnDelStOpen.TabIndex = 22;
            this.btnDelStOpen.Text = "&Open";
            this.btnDelStOpen.UseVisualStyleBackColor = true;
            // 
            // txtDelStVer
            // 
            this.txtDelStVer.Location = new System.Drawing.Point(63, 60);
            this.txtDelStVer.Name = "txtDelStVer";
            this.txtDelStVer.ReadOnly = true;
            this.txtDelStVer.Size = new System.Drawing.Size(180, 20);
            this.txtDelStVer.TabIndex = 21;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 63);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(45, 13);
            this.label8.TabIndex = 20;
            this.label8.Text = "Version:";
            // 
            // txtDelStDB
            // 
            this.txtDelStDB.Location = new System.Drawing.Point(15, 27);
            this.txtDelStDB.Name = "txtDelStDB";
            this.txtDelStDB.Size = new System.Drawing.Size(452, 20);
            this.txtDelStDB.TabIndex = 19;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 11);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(125, 13);
            this.label9.TabIndex = 18;
            this.label9.Text = "Module Database Name:";
            // 
            // btnDelStCancel
            // 
            this.btnDelStCancel.Location = new System.Drawing.Point(468, 3);
            this.btnDelStCancel.Name = "btnDelStCancel";
            this.btnDelStCancel.Size = new System.Drawing.Size(94, 30);
            this.btnDelStCancel.TabIndex = 44;
            this.btnDelStCancel.Text = "&Cancel";
            this.btnDelStCancel.UseVisualStyleBackColor = true;
            this.btnDelStCancel.Visible = false;
            // 
            // txtDelStOut
            // 
            this.txtDelStOut.Location = new System.Drawing.Point(15, 39);
            this.txtDelStOut.Multiline = true;
            this.txtDelStOut.Name = "txtDelStOut";
            this.txtDelStOut.ReadOnly = true;
            this.txtDelStOut.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtDelStOut.Size = new System.Drawing.Size(547, 327);
            this.txtDelStOut.TabIndex = 43;
            // 
            // btnDelStProcess
            // 
            this.btnDelStProcess.Enabled = false;
            this.btnDelStProcess.Location = new System.Drawing.Point(468, 4);
            this.btnDelStProcess.Name = "btnDelStProcess";
            this.btnDelStProcess.Size = new System.Drawing.Size(94, 29);
            this.btnDelStProcess.TabIndex = 42;
            this.btnDelStProcess.Text = "&Start Process";
            this.btnDelStProcess.UseVisualStyleBackColor = true;
            // 
            // tbPgUpload
            // 
            this.tbPgUpload.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tbPgUpload.Controls.Add(this.splitContainer5);
            this.tbPgUpload.Location = new System.Drawing.Point(4, 40);
            this.tbPgUpload.Name = "tbPgUpload";
            this.tbPgUpload.Padding = new System.Windows.Forms.Padding(3);
            this.tbPgUpload.Size = new System.Drawing.Size(580, 488);
            this.tbPgUpload.TabIndex = 4;
            this.tbPgUpload.Text = "Unload / Reload";
            // 
            // splitContainer5
            // 
            this.splitContainer5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer5.Location = new System.Drawing.Point(3, 3);
            this.splitContainer5.Name = "splitContainer5";
            this.splitContainer5.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer5.Panel1
            // 
            this.splitContainer5.Panel1.Controls.Add(this.lblLoadMsg);
            this.splitContainer5.Panel1.Controls.Add(this.btnLdBrowse);
            this.splitContainer5.Panel1.Controls.Add(this.btnLdOpen);
            this.splitContainer5.Panel1.Controls.Add(this.txtLdVer);
            this.splitContainer5.Panel1.Controls.Add(this.label15);
            this.splitContainer5.Panel1.Controls.Add(this.txtLoadDB);
            this.splitContainer5.Panel1.Controls.Add(this.label16);
            // 
            // splitContainer5.Panel2
            // 
            this.splitContainer5.Panel2.Controls.Add(this.btnLdCancel);
            this.splitContainer5.Panel2.Controls.Add(this.txtLdOut);
            this.splitContainer5.Panel2.Controls.Add(this.btnLdProcess);
            this.splitContainer5.Size = new System.Drawing.Size(574, 482);
            this.splitContainer5.SplitterDistance = 109;
            this.splitContainer5.TabIndex = 0;
            // 
            // lblLoadMsg
            // 
            this.lblLoadMsg.AutoSize = true;
            this.lblLoadMsg.ForeColor = System.Drawing.Color.Red;
            this.lblLoadMsg.Location = new System.Drawing.Point(143, 11);
            this.lblLoadMsg.Name = "lblLoadMsg";
            this.lblLoadMsg.Size = new System.Drawing.Size(0, 13);
            this.lblLoadMsg.TabIndex = 38;
            // 
            // btnLdBrowse
            // 
            this.btnLdBrowse.Location = new System.Drawing.Point(487, 27);
            this.btnLdBrowse.Name = "btnLdBrowse";
            this.btnLdBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnLdBrowse.TabIndex = 37;
            this.btnLdBrowse.Text = "&Browse";
            this.btnLdBrowse.UseVisualStyleBackColor = true;
            // 
            // btnLdOpen
            // 
            this.btnLdOpen.Location = new System.Drawing.Point(487, 58);
            this.btnLdOpen.Name = "btnLdOpen";
            this.btnLdOpen.Size = new System.Drawing.Size(75, 23);
            this.btnLdOpen.TabIndex = 36;
            this.btnLdOpen.Text = "&Open";
            this.btnLdOpen.UseVisualStyleBackColor = true;
            // 
            // txtLdVer
            // 
            this.txtLdVer.Location = new System.Drawing.Point(63, 60);
            this.txtLdVer.Name = "txtLdVer";
            this.txtLdVer.ReadOnly = true;
            this.txtLdVer.Size = new System.Drawing.Size(180, 20);
            this.txtLdVer.TabIndex = 35;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(12, 63);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(45, 13);
            this.label15.TabIndex = 34;
            this.label15.Text = "Version:";
            // 
            // txtLoadDB
            // 
            this.txtLoadDB.Location = new System.Drawing.Point(15, 27);
            this.txtLoadDB.Name = "txtLoadDB";
            this.txtLoadDB.Size = new System.Drawing.Size(452, 20);
            this.txtLoadDB.TabIndex = 33;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(12, 11);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(125, 13);
            this.label16.TabIndex = 32;
            this.label16.Text = "Module Database Name:";
            // 
            // btnLdCancel
            // 
            this.btnLdCancel.Location = new System.Drawing.Point(468, 3);
            this.btnLdCancel.Name = "btnLdCancel";
            this.btnLdCancel.Size = new System.Drawing.Size(94, 30);
            this.btnLdCancel.TabIndex = 47;
            this.btnLdCancel.Text = "&Cancel";
            this.btnLdCancel.UseVisualStyleBackColor = true;
            this.btnLdCancel.Visible = false;
            // 
            // txtLdOut
            // 
            this.txtLdOut.Location = new System.Drawing.Point(15, 39);
            this.txtLdOut.Multiline = true;
            this.txtLdOut.Name = "txtLdOut";
            this.txtLdOut.ReadOnly = true;
            this.txtLdOut.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtLdOut.Size = new System.Drawing.Size(547, 326);
            this.txtLdOut.TabIndex = 46;
            // 
            // btnLdProcess
            // 
            this.btnLdProcess.Enabled = false;
            this.btnLdProcess.Location = new System.Drawing.Point(468, 4);
            this.btnLdProcess.Name = "btnLdProcess";
            this.btnLdProcess.Size = new System.Drawing.Size(94, 29);
            this.btnLdProcess.TabIndex = 45;
            this.btnLdProcess.Text = "&Start Process";
            this.btnLdProcess.UseVisualStyleBackColor = true;
            // 
            // tbPgMergSt
            // 
            this.tbPgMergSt.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tbPgMergSt.Controls.Add(this.splitContainer8);
            this.tbPgMergSt.Location = new System.Drawing.Point(4, 40);
            this.tbPgMergSt.Name = "tbPgMergSt";
            this.tbPgMergSt.Padding = new System.Windows.Forms.Padding(3);
            this.tbPgMergSt.Size = new System.Drawing.Size(580, 488);
            this.tbPgMergSt.TabIndex = 5;
            this.tbPgMergSt.Text = "Merge State";
            // 
            // splitContainer8
            // 
            this.splitContainer8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer8.Location = new System.Drawing.Point(3, 3);
            this.splitContainer8.Name = "splitContainer8";
            this.splitContainer8.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer8.Panel1
            // 
            this.splitContainer8.Panel1.Controls.Add(this.lblMergeStMsg);
            this.splitContainer8.Panel1.Controls.Add(this.btnMergeSTBrowse);
            this.splitContainer8.Panel1.Controls.Add(this.btnMergeSTOpen);
            this.splitContainer8.Panel1.Controls.Add(this.txtMergeSTVer);
            this.splitContainer8.Panel1.Controls.Add(this.label24);
            this.splitContainer8.Panel1.Controls.Add(this.txtMergeStDB);
            this.splitContainer8.Panel1.Controls.Add(this.label25);
            // 
            // splitContainer8.Panel2
            // 
            this.splitContainer8.Panel2.Controls.Add(this.chkMergeSynCheck);
            this.splitContainer8.Panel2.Controls.Add(this.btnMergeSTCancel);
            this.splitContainer8.Panel2.Controls.Add(this.txtMergeSTOut);
            this.splitContainer8.Panel2.Controls.Add(this.btnMergeSTProcess);
            this.splitContainer8.Panel2.Controls.Add(this.txtMergeSTVerName);
            this.splitContainer8.Panel2.Controls.Add(this.label30);
            this.splitContainer8.Panel2.Controls.Add(this.txtMergeSTDate);
            this.splitContainer8.Panel2.Controls.Add(this.label31);
            this.splitContainer8.Panel2.Controls.Add(this.btnMergeSTRemoveAll);
            this.splitContainer8.Panel2.Controls.Add(this.btnMergeSTAddAll);
            this.splitContainer8.Panel2.Controls.Add(this.lstMergeSTStates);
            this.splitContainer8.Panel2.Controls.Add(this.lstMergeSTAvaiSt);
            this.splitContainer8.Panel2.Controls.Add(this.btnMergeSTAdd);
            this.splitContainer8.Panel2.Controls.Add(this.btnMergeSTRemove);
            this.splitContainer8.Panel2.Controls.Add(this.label28);
            this.splitContainer8.Panel2.Controls.Add(this.label29);
            this.splitContainer8.Panel2.Controls.Add(this.txtMergeSTModuleRoot);
            this.splitContainer8.Panel2.Controls.Add(this.label27);
            this.splitContainer8.Panel2.Controls.Add(this.txtMergeSTSateRoot);
            this.splitContainer8.Panel2.Controls.Add(this.label26);
            this.splitContainer8.Size = new System.Drawing.Size(574, 482);
            this.splitContainer8.SplitterDistance = 91;
            this.splitContainer8.TabIndex = 0;
            // 
            // lblMergeStMsg
            // 
            this.lblMergeStMsg.AutoSize = true;
            this.lblMergeStMsg.ForeColor = System.Drawing.Color.Red;
            this.lblMergeStMsg.Location = new System.Drawing.Point(143, 11);
            this.lblMergeStMsg.Name = "lblMergeStMsg";
            this.lblMergeStMsg.Size = new System.Drawing.Size(0, 13);
            this.lblMergeStMsg.TabIndex = 45;
            // 
            // btnMergeSTBrowse
            // 
            this.btnMergeSTBrowse.Location = new System.Drawing.Point(487, 27);
            this.btnMergeSTBrowse.Name = "btnMergeSTBrowse";
            this.btnMergeSTBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnMergeSTBrowse.TabIndex = 44;
            this.btnMergeSTBrowse.Text = "&Browse";
            this.btnMergeSTBrowse.UseVisualStyleBackColor = true;
            // 
            // btnMergeSTOpen
            // 
            this.btnMergeSTOpen.Location = new System.Drawing.Point(487, 53);
            this.btnMergeSTOpen.Name = "btnMergeSTOpen";
            this.btnMergeSTOpen.Size = new System.Drawing.Size(75, 23);
            this.btnMergeSTOpen.TabIndex = 43;
            this.btnMergeSTOpen.Text = "&Open";
            this.btnMergeSTOpen.UseVisualStyleBackColor = true;
            // 
            // txtMergeSTVer
            // 
            this.txtMergeSTVer.Location = new System.Drawing.Point(63, 60);
            this.txtMergeSTVer.Name = "txtMergeSTVer";
            this.txtMergeSTVer.ReadOnly = true;
            this.txtMergeSTVer.Size = new System.Drawing.Size(180, 20);
            this.txtMergeSTVer.TabIndex = 42;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(12, 63);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(45, 13);
            this.label24.TabIndex = 41;
            this.label24.Text = "Version:";
            // 
            // txtMergeStDB
            // 
            this.txtMergeStDB.Location = new System.Drawing.Point(15, 27);
            this.txtMergeStDB.Name = "txtMergeStDB";
            this.txtMergeStDB.Size = new System.Drawing.Size(452, 20);
            this.txtMergeStDB.TabIndex = 40;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(12, 11);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(125, 13);
            this.label25.TabIndex = 39;
            this.label25.Text = "Module Database Name:";
            // 
            // chkMergeSynCheck
            // 
            this.chkMergeSynCheck.AutoSize = true;
            this.chkMergeSynCheck.Location = new System.Drawing.Point(15, 208);
            this.chkMergeSynCheck.Name = "chkMergeSynCheck";
            this.chkMergeSynCheck.Size = new System.Drawing.Size(130, 17);
            this.chkMergeSynCheck.TabIndex = 60;
            this.chkMergeSynCheck.Text = "Syntax Checking Only";
            this.chkMergeSynCheck.UseVisualStyleBackColor = true;
            // 
            // btnMergeSTCancel
            // 
            this.btnMergeSTCancel.Location = new System.Drawing.Point(468, 200);
            this.btnMergeSTCancel.Name = "btnMergeSTCancel";
            this.btnMergeSTCancel.Size = new System.Drawing.Size(94, 25);
            this.btnMergeSTCancel.TabIndex = 59;
            this.btnMergeSTCancel.Text = "&Cancel";
            this.btnMergeSTCancel.UseVisualStyleBackColor = true;
            this.btnMergeSTCancel.Visible = false;
            // 
            // txtMergeSTOut
            // 
            this.txtMergeSTOut.Location = new System.Drawing.Point(15, 231);
            this.txtMergeSTOut.Multiline = true;
            this.txtMergeSTOut.Name = "txtMergeSTOut";
            this.txtMergeSTOut.ReadOnly = true;
            this.txtMergeSTOut.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtMergeSTOut.Size = new System.Drawing.Size(547, 145);
            this.txtMergeSTOut.TabIndex = 58;
            // 
            // btnMergeSTProcess
            // 
            this.btnMergeSTProcess.Enabled = false;
            this.btnMergeSTProcess.Location = new System.Drawing.Point(468, 200);
            this.btnMergeSTProcess.Name = "btnMergeSTProcess";
            this.btnMergeSTProcess.Size = new System.Drawing.Size(94, 25);
            this.btnMergeSTProcess.TabIndex = 57;
            this.btnMergeSTProcess.Text = "&Start Process";
            this.btnMergeSTProcess.UseVisualStyleBackColor = true;
            // 
            // txtMergeSTVerName
            // 
            this.txtMergeSTVerName.Location = new System.Drawing.Point(302, 174);
            this.txtMergeSTVerName.Name = "txtMergeSTVerName";
            this.txtMergeSTVerName.Size = new System.Drawing.Size(260, 20);
            this.txtMergeSTVerName.TabIndex = 56;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(299, 158);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(152, 13);
            this.label30.TabIndex = 55;
            this.label30.Text = "State Version Name (Optional):";
            // 
            // txtMergeSTDate
            // 
            this.txtMergeSTDate.Location = new System.Drawing.Point(15, 174);
            this.txtMergeSTDate.Name = "txtMergeSTDate";
            this.txtMergeSTDate.Size = new System.Drawing.Size(260, 20);
            this.txtMergeSTDate.TabIndex = 54;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(12, 158);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(225, 13);
            this.label31.TabIndex = 53;
            this.label31.Text = "Research Date for new and modified sections:";
            // 
            // btnMergeSTRemoveAll
            // 
            this.btnMergeSTRemoveAll.Location = new System.Drawing.Point(248, 133);
            this.btnMergeSTRemoveAll.Name = "btnMergeSTRemoveAll";
            this.btnMergeSTRemoveAll.Size = new System.Drawing.Size(80, 22);
            this.btnMergeSTRemoveAll.TabIndex = 52;
            this.btnMergeSTRemoveAll.Text = "<-R&emove All";
            this.btnMergeSTRemoveAll.UseVisualStyleBackColor = true;
            // 
            // btnMergeSTAddAll
            // 
            this.btnMergeSTAddAll.Location = new System.Drawing.Point(248, 105);
            this.btnMergeSTAddAll.Name = "btnMergeSTAddAll";
            this.btnMergeSTAddAll.Size = new System.Drawing.Size(80, 22);
            this.btnMergeSTAddAll.TabIndex = 51;
            this.btnMergeSTAddAll.Text = "A&dd All ->";
            this.btnMergeSTAddAll.UseVisualStyleBackColor = true;
            // 
            // lstMergeSTStates
            // 
            this.lstMergeSTStates.FormattingEnabled = true;
            this.lstMergeSTStates.Location = new System.Drawing.Point(362, 60);
            this.lstMergeSTStates.Name = "lstMergeSTStates";
            this.lstMergeSTStates.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstMergeSTStates.Size = new System.Drawing.Size(200, 95);
            this.lstMergeSTStates.TabIndex = 50;
            // 
            // lstMergeSTAvaiSt
            // 
            this.lstMergeSTAvaiSt.FormattingEnabled = true;
            this.lstMergeSTAvaiSt.Location = new System.Drawing.Point(15, 60);
            this.lstMergeSTAvaiSt.Name = "lstMergeSTAvaiSt";
            this.lstMergeSTAvaiSt.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstMergeSTAvaiSt.Size = new System.Drawing.Size(200, 95);
            this.lstMergeSTAvaiSt.TabIndex = 49;
            // 
            // btnMergeSTAdd
            // 
            this.btnMergeSTAdd.Enabled = false;
            this.btnMergeSTAdd.Location = new System.Drawing.Point(248, 49);
            this.btnMergeSTAdd.Name = "btnMergeSTAdd";
            this.btnMergeSTAdd.Size = new System.Drawing.Size(80, 22);
            this.btnMergeSTAdd.TabIndex = 48;
            this.btnMergeSTAdd.Text = "&Add ->";
            this.btnMergeSTAdd.UseVisualStyleBackColor = true;
            // 
            // btnMergeSTRemove
            // 
            this.btnMergeSTRemove.Enabled = false;
            this.btnMergeSTRemove.Location = new System.Drawing.Point(248, 77);
            this.btnMergeSTRemove.Name = "btnMergeSTRemove";
            this.btnMergeSTRemove.Size = new System.Drawing.Size(80, 22);
            this.btnMergeSTRemove.TabIndex = 47;
            this.btnMergeSTRemove.Text = "<- &Remove";
            this.btnMergeSTRemove.UseVisualStyleBackColor = true;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(359, 44);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(85, 13);
            this.label28.TabIndex = 46;
            this.label28.Text = "States to Merge:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(12, 44);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(86, 13);
            this.label29.TabIndex = 45;
            this.label29.Text = "Available States:";
            // 
            // txtMergeSTModuleRoot
            // 
            this.txtMergeSTModuleRoot.Location = new System.Drawing.Point(302, 18);
            this.txtMergeSTModuleRoot.Name = "txtMergeSTModuleRoot";
            this.txtMergeSTModuleRoot.Size = new System.Drawing.Size(260, 20);
            this.txtMergeSTModuleRoot.TabIndex = 44;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(299, 2);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(116, 13);
            this.label27.TabIndex = 43;
            this.label27.Text = "Module Root Directory:";
            // 
            // txtMergeSTSateRoot
            // 
            this.txtMergeSTSateRoot.Location = new System.Drawing.Point(15, 18);
            this.txtMergeSTSateRoot.Name = "txtMergeSTSateRoot";
            this.txtMergeSTSateRoot.Size = new System.Drawing.Size(260, 20);
            this.txtMergeSTSateRoot.TabIndex = 42;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(12, 2);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(106, 13);
            this.label26.TabIndex = 41;
            this.label26.Text = "State Root Directory:";
            // 
            // tbPgMergFederal
            // 
            this.tbPgMergFederal.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tbPgMergFederal.Controls.Add(this.splitContainer7);
            this.tbPgMergFederal.Location = new System.Drawing.Point(4, 40);
            this.tbPgMergFederal.Name = "tbPgMergFederal";
            this.tbPgMergFederal.Padding = new System.Windows.Forms.Padding(3);
            this.tbPgMergFederal.Size = new System.Drawing.Size(580, 488);
            this.tbPgMergFederal.TabIndex = 7;
            this.tbPgMergFederal.Text = "Merge Federal";
            // 
            // splitContainer7
            // 
            this.splitContainer7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer7.Location = new System.Drawing.Point(3, 3);
            this.splitContainer7.Name = "splitContainer7";
            this.splitContainer7.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer7.Panel1
            // 
            this.splitContainer7.Panel1.Controls.Add(this.groupBox4);
            // 
            // splitContainer7.Panel2
            // 
            this.splitContainer7.Panel2.Controls.Add(this.textBox2);
            this.splitContainer7.Panel2.Controls.Add(this.btnMergeFProcess);
            this.splitContainer7.Panel2.Controls.Add(this.btnMergeFCancel);
            this.splitContainer7.Panel2.Controls.Add(this.txtDateSC);
            this.splitContainer7.Panel2.Controls.Add(this.txtDateDA);
            this.splitContainer7.Panel2.Controls.Add(this.txtVNameSC);
            this.splitContainer7.Panel2.Controls.Add(this.txtVNameDA);
            this.splitContainer7.Panel2.Controls.Add(this.textBox8);
            this.splitContainer7.Panel2.Controls.Add(this.textBox7);
            this.splitContainer7.Panel2.Controls.Add(this.textBox5);
            this.splitContainer7.Panel2.Controls.Add(this.textBox4);
            this.splitContainer7.Panel2.Controls.Add(this.txtMergeFdOut);
            this.splitContainer7.Size = new System.Drawing.Size(574, 482);
            this.splitContainer7.SplitterDistance = 171;
            this.splitContainer7.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.lblMergeFModuleMsg);
            this.groupBox4.Controls.Add(this.txtMergeFMasterVer);
            this.groupBox4.Controls.Add(this.btnMergeFModuleBrowse);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.btnMergeFModuleOpen);
            this.groupBox4.Controls.Add(this.txtMergeFMasterDB);
            this.groupBox4.Controls.Add(this.txtMergeFModuleVer);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Controls.Add(this.btnMergeFMasterOpen);
            this.groupBox4.Controls.Add(this.txtMergeFModuleDB);
            this.groupBox4.Controls.Add(this.btnMergeFMasterBrowse);
            this.groupBox4.Controls.Add(this.label32);
            this.groupBox4.Controls.Add(this.lblMergeFMasterMsg);
            this.groupBox4.Location = new System.Drawing.Point(9, 0);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(559, 168);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            // 
            // lblMergeFModuleMsg
            // 
            this.lblMergeFModuleMsg.AutoSize = true;
            this.lblMergeFModuleMsg.ForeColor = System.Drawing.Color.Red;
            this.lblMergeFModuleMsg.Location = new System.Drawing.Point(178, 92);
            this.lblMergeFModuleMsg.Name = "lblMergeFModuleMsg";
            this.lblMergeFModuleMsg.Size = new System.Drawing.Size(0, 13);
            this.lblMergeFModuleMsg.TabIndex = 52;
            // 
            // txtMergeFMasterVer
            // 
            this.txtMergeFMasterVer.Location = new System.Drawing.Point(54, 62);
            this.txtMergeFMasterVer.Name = "txtMergeFMasterVer";
            this.txtMergeFMasterVer.ReadOnly = true;
            this.txtMergeFMasterVer.Size = new System.Drawing.Size(180, 20);
            this.txtMergeFMasterVer.TabIndex = 42;
            // 
            // btnMergeFModuleBrowse
            // 
            this.btnMergeFModuleBrowse.Location = new System.Drawing.Point(478, 108);
            this.btnMergeFModuleBrowse.Name = "btnMergeFModuleBrowse";
            this.btnMergeFModuleBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnMergeFModuleBrowse.TabIndex = 51;
            this.btnMergeFModuleBrowse.Text = "&Browse";
            this.btnMergeFModuleBrowse.UseVisualStyleBackColor = true;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(3, 13);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(160, 13);
            this.label19.TabIndex = 39;
            this.label19.Text = "Master Module Database Name:";
            // 
            // btnMergeFModuleOpen
            // 
            this.btnMergeFModuleOpen.Location = new System.Drawing.Point(478, 139);
            this.btnMergeFModuleOpen.Name = "btnMergeFModuleOpen";
            this.btnMergeFModuleOpen.Size = new System.Drawing.Size(75, 23);
            this.btnMergeFModuleOpen.TabIndex = 50;
            this.btnMergeFModuleOpen.Text = "&Open";
            this.btnMergeFModuleOpen.UseVisualStyleBackColor = true;
            // 
            // txtMergeFMasterDB
            // 
            this.txtMergeFMasterDB.Location = new System.Drawing.Point(6, 29);
            this.txtMergeFMasterDB.Name = "txtMergeFMasterDB";
            this.txtMergeFMasterDB.Size = new System.Drawing.Size(452, 20);
            this.txtMergeFMasterDB.TabIndex = 40;
            // 
            // txtMergeFModuleVer
            // 
            this.txtMergeFModuleVer.Location = new System.Drawing.Point(54, 141);
            this.txtMergeFModuleVer.Name = "txtMergeFModuleVer";
            this.txtMergeFModuleVer.ReadOnly = true;
            this.txtMergeFModuleVer.Size = new System.Drawing.Size(180, 20);
            this.txtMergeFModuleVer.TabIndex = 49;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(3, 65);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(45, 13);
            this.label18.TabIndex = 41;
            this.label18.Text = "Version:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(3, 144);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(45, 13);
            this.label23.TabIndex = 48;
            this.label23.Text = "Version:";
            // 
            // btnMergeFMasterOpen
            // 
            this.btnMergeFMasterOpen.Location = new System.Drawing.Point(478, 60);
            this.btnMergeFMasterOpen.Name = "btnMergeFMasterOpen";
            this.btnMergeFMasterOpen.Size = new System.Drawing.Size(75, 23);
            this.btnMergeFMasterOpen.TabIndex = 43;
            this.btnMergeFMasterOpen.Text = "&Open";
            this.btnMergeFMasterOpen.UseVisualStyleBackColor = true;
            // 
            // txtMergeFModuleDB
            // 
            this.txtMergeFModuleDB.Location = new System.Drawing.Point(6, 108);
            this.txtMergeFModuleDB.Name = "txtMergeFModuleDB";
            this.txtMergeFModuleDB.Size = new System.Drawing.Size(452, 20);
            this.txtMergeFModuleDB.TabIndex = 47;
            // 
            // btnMergeFMasterBrowse
            // 
            this.btnMergeFMasterBrowse.Location = new System.Drawing.Point(478, 29);
            this.btnMergeFMasterBrowse.Name = "btnMergeFMasterBrowse";
            this.btnMergeFMasterBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnMergeFMasterBrowse.TabIndex = 44;
            this.btnMergeFMasterBrowse.Text = "&Browse";
            this.btnMergeFMasterBrowse.UseVisualStyleBackColor = true;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(3, 92);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(174, 13);
            this.label32.TabIndex = 46;
            this.label32.Text = "To Merge Module Database Name:";
            // 
            // lblMergeFMasterMsg
            // 
            this.lblMergeFMasterMsg.AutoSize = true;
            this.lblMergeFMasterMsg.ForeColor = System.Drawing.Color.Red;
            this.lblMergeFMasterMsg.Location = new System.Drawing.Point(178, 13);
            this.lblMergeFMasterMsg.Name = "lblMergeFMasterMsg";
            this.lblMergeFMasterMsg.Size = new System.Drawing.Size(0, 13);
            this.lblMergeFMasterMsg.TabIndex = 45;
            // 
            // textBox2
            // 
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Location = new System.Drawing.Point(15, 5);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(547, 36);
            this.textBox2.TabIndex = 71;
            this.textBox2.Text = "Enter here, the Version Names and Research Dates. Enter a Research Date to make t" +
                "he version name appear in the \\\"Select Reference Change Date\\\" dialog box in Dak" +
                "ot a Audit / Smart Cite.";
            // 
            // btnMergeFProcess
            // 
            this.btnMergeFProcess.Enabled = false;
            this.btnMergeFProcess.Location = new System.Drawing.Point(469, 94);
            this.btnMergeFProcess.Name = "btnMergeFProcess";
            this.btnMergeFProcess.Size = new System.Drawing.Size(94, 25);
            this.btnMergeFProcess.TabIndex = 70;
            this.btnMergeFProcess.Text = "&Start Process";
            this.btnMergeFProcess.UseVisualStyleBackColor = true;
            // 
            // btnMergeFCancel
            // 
            this.btnMergeFCancel.Location = new System.Drawing.Point(469, 94);
            this.btnMergeFCancel.Name = "btnMergeFCancel";
            this.btnMergeFCancel.Size = new System.Drawing.Size(94, 25);
            this.btnMergeFCancel.TabIndex = 69;
            this.btnMergeFCancel.Text = "&Cancel";
            this.btnMergeFCancel.UseVisualStyleBackColor = true;
            this.btnMergeFCancel.Visible = false;
            // 
            // txtDateSC
            // 
            this.txtDateSC.Location = new System.Drawing.Point(288, 97);
            this.txtDateSC.Name = "txtDateSC";
            this.txtDateSC.Size = new System.Drawing.Size(163, 20);
            this.txtDateSC.TabIndex = 67;
            // 
            // txtDateDA
            // 
            this.txtDateDA.Location = new System.Drawing.Point(287, 71);
            this.txtDateDA.Name = "txtDateDA";
            this.txtDateDA.Size = new System.Drawing.Size(163, 20);
            this.txtDateDA.TabIndex = 66;
            // 
            // txtVNameSC
            // 
            this.txtVNameSC.Location = new System.Drawing.Point(119, 97);
            this.txtVNameSC.Name = "txtVNameSC";
            this.txtVNameSC.Size = new System.Drawing.Size(163, 20);
            this.txtVNameSC.TabIndex = 65;
            // 
            // txtVNameDA
            // 
            this.txtVNameDA.Location = new System.Drawing.Point(119, 71);
            this.txtVNameDA.Name = "txtVNameDA";
            this.txtVNameDA.Size = new System.Drawing.Size(163, 20);
            this.txtVNameDA.TabIndex = 64;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(30, 97);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(83, 20);
            this.textBox8.TabIndex = 63;
            this.textBox8.Text = "Smart Cite:";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(30, 71);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(83, 20);
            this.textBox7.TabIndex = 62;
            this.textBox7.Text = "Dakota Auditor:";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(288, 45);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(162, 20);
            this.textBox5.TabIndex = 61;
            this.textBox5.Text = "Research Date";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(120, 45);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(162, 20);
            this.textBox4.TabIndex = 60;
            this.textBox4.Text = "Version Name";
            // 
            // txtMergeFdOut
            // 
            this.txtMergeFdOut.Location = new System.Drawing.Point(15, 125);
            this.txtMergeFdOut.Multiline = true;
            this.txtMergeFdOut.Name = "txtMergeFdOut";
            this.txtMergeFdOut.ReadOnly = true;
            this.txtMergeFdOut.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtMergeFdOut.Size = new System.Drawing.Size(547, 174);
            this.txtMergeFdOut.TabIndex = 59;
            // 
            // tbPgBlobsCreat
            // 
            this.tbPgBlobsCreat.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tbPgBlobsCreat.Controls.Add(this.splitContainer6);
            this.tbPgBlobsCreat.Location = new System.Drawing.Point(4, 40);
            this.tbPgBlobsCreat.Name = "tbPgBlobsCreat";
            this.tbPgBlobsCreat.Padding = new System.Windows.Forms.Padding(3);
            this.tbPgBlobsCreat.Size = new System.Drawing.Size(580, 488);
            this.tbPgBlobsCreat.TabIndex = 8;
            this.tbPgBlobsCreat.Text = "Blobs Creation";
            // 
            // splitContainer6
            // 
            this.splitContainer6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer6.Location = new System.Drawing.Point(3, 3);
            this.splitContainer6.Name = "splitContainer6";
            this.splitContainer6.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer6.Panel1
            // 
            this.splitContainer6.Panel1.Controls.Add(this.lblBlobsMsg);
            this.splitContainer6.Panel1.Controls.Add(this.btnBlobsBrowse);
            this.splitContainer6.Panel1.Controls.Add(this.btnBlobsOpen);
            this.splitContainer6.Panel1.Controls.Add(this.txtBlobsVer);
            this.splitContainer6.Panel1.Controls.Add(this.label21);
            this.splitContainer6.Panel1.Controls.Add(this.txtBlobsDB);
            this.splitContainer6.Panel1.Controls.Add(this.label22);
            // 
            // splitContainer6.Panel2
            // 
            this.splitContainer6.Panel2.Controls.Add(this.btnBlobsProcess);
            this.splitContainer6.Panel2.Controls.Add(this.btnBlobsCancel);
            this.splitContainer6.Panel2.Controls.Add(this.groupBox1);
            this.splitContainer6.Panel2.Controls.Add(this.txtBlobsOut);
            this.splitContainer6.Size = new System.Drawing.Size(574, 482);
            this.splitContainer6.SplitterDistance = 94;
            this.splitContainer6.TabIndex = 0;
            // 
            // lblBlobsMsg
            // 
            this.lblBlobsMsg.AutoSize = true;
            this.lblBlobsMsg.ForeColor = System.Drawing.Color.Red;
            this.lblBlobsMsg.Location = new System.Drawing.Point(143, 11);
            this.lblBlobsMsg.Name = "lblBlobsMsg";
            this.lblBlobsMsg.Size = new System.Drawing.Size(0, 13);
            this.lblBlobsMsg.TabIndex = 45;
            // 
            // btnBlobsBrowse
            // 
            this.btnBlobsBrowse.Location = new System.Drawing.Point(487, 27);
            this.btnBlobsBrowse.Name = "btnBlobsBrowse";
            this.btnBlobsBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnBlobsBrowse.TabIndex = 44;
            this.btnBlobsBrowse.Text = "&Browse";
            this.btnBlobsBrowse.UseVisualStyleBackColor = true;
            // 
            // btnBlobsOpen
            // 
            this.btnBlobsOpen.Location = new System.Drawing.Point(487, 58);
            this.btnBlobsOpen.Name = "btnBlobsOpen";
            this.btnBlobsOpen.Size = new System.Drawing.Size(75, 23);
            this.btnBlobsOpen.TabIndex = 43;
            this.btnBlobsOpen.Text = "&Open";
            this.btnBlobsOpen.UseVisualStyleBackColor = true;
            // 
            // txtBlobsVer
            // 
            this.txtBlobsVer.Location = new System.Drawing.Point(63, 60);
            this.txtBlobsVer.Name = "txtBlobsVer";
            this.txtBlobsVer.ReadOnly = true;
            this.txtBlobsVer.Size = new System.Drawing.Size(180, 20);
            this.txtBlobsVer.TabIndex = 42;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(12, 63);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(45, 13);
            this.label21.TabIndex = 41;
            this.label21.Text = "Version:";
            // 
            // txtBlobsDB
            // 
            this.txtBlobsDB.Location = new System.Drawing.Point(15, 27);
            this.txtBlobsDB.Name = "txtBlobsDB";
            this.txtBlobsDB.Size = new System.Drawing.Size(452, 20);
            this.txtBlobsDB.TabIndex = 40;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(12, 11);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(125, 13);
            this.label22.TabIndex = 39;
            this.label22.Text = "Module Database Name:";
            // 
            // btnBlobsProcess
            // 
            this.btnBlobsProcess.Enabled = false;
            this.btnBlobsProcess.Location = new System.Drawing.Point(468, 67);
            this.btnBlobsProcess.Name = "btnBlobsProcess";
            this.btnBlobsProcess.Size = new System.Drawing.Size(94, 25);
            this.btnBlobsProcess.TabIndex = 73;
            this.btnBlobsProcess.Text = "&Start Process";
            this.btnBlobsProcess.UseVisualStyleBackColor = true;
            // 
            // btnBlobsCancel
            // 
            this.btnBlobsCancel.Location = new System.Drawing.Point(468, 67);
            this.btnBlobsCancel.Name = "btnBlobsCancel";
            this.btnBlobsCancel.Size = new System.Drawing.Size(94, 25);
            this.btnBlobsCancel.TabIndex = 72;
            this.btnBlobsCancel.Text = "&Cancel";
            this.btnBlobsCancel.UseVisualStyleBackColor = true;
            this.btnBlobsCancel.Visible = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.optMissingBlobs);
            this.groupBox1.Controls.Add(this.optAllTheBlobs);
            this.groupBox1.Location = new System.Drawing.Point(15, 24);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(353, 83);
            this.groupBox1.TabIndex = 61;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Build";
            // 
            // optMissingBlobs
            // 
            this.optMissingBlobs.AutoSize = true;
            this.optMissingBlobs.Checked = true;
            this.optMissingBlobs.Location = new System.Drawing.Point(21, 28);
            this.optMissingBlobs.Name = "optMissingBlobs";
            this.optMissingBlobs.Size = new System.Drawing.Size(89, 17);
            this.optMissingBlobs.TabIndex = 1;
            this.optMissingBlobs.TabStop = true;
            this.optMissingBlobs.Text = "Missing Blobs";
            this.optMissingBlobs.UseVisualStyleBackColor = true;
            // 
            // optAllTheBlobs
            // 
            this.optAllTheBlobs.AutoSize = true;
            this.optAllTheBlobs.Location = new System.Drawing.Point(21, 51);
            this.optAllTheBlobs.Name = "optAllTheBlobs";
            this.optAllTheBlobs.Size = new System.Drawing.Size(87, 17);
            this.optAllTheBlobs.TabIndex = 0;
            this.optAllTheBlobs.TabStop = true;
            this.optAllTheBlobs.Text = "All The Blobs";
            this.optAllTheBlobs.UseVisualStyleBackColor = true;
            // 
            // txtBlobsOut
            // 
            this.txtBlobsOut.Location = new System.Drawing.Point(15, 128);
            this.txtBlobsOut.Multiline = true;
            this.txtBlobsOut.Name = "txtBlobsOut";
            this.txtBlobsOut.ReadOnly = true;
            this.txtBlobsOut.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtBlobsOut.Size = new System.Drawing.Size(547, 246);
            this.txtBlobsOut.TabIndex = 60;
            // 
            // tbPgLog
            // 
            this.tbPgLog.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tbPgLog.Controls.Add(this.btnLogDel);
            this.tbPgLog.Controls.Add(this.label17);
            this.tbPgLog.Controls.Add(this.label14);
            this.tbPgLog.Controls.Add(this.dtpLog);
            this.tbPgLog.Controls.Add(this.cboLogPageType);
            this.tbPgLog.Controls.Add(this.btnLogRefresh);
            this.tbPgLog.Controls.Add(this.txtLogOut);
            this.tbPgLog.Controls.Add(this.btnLogExport);
            this.tbPgLog.Location = new System.Drawing.Point(4, 40);
            this.tbPgLog.Name = "tbPgLog";
            this.tbPgLog.Padding = new System.Windows.Forms.Padding(3);
            this.tbPgLog.Size = new System.Drawing.Size(580, 488);
            this.tbPgLog.TabIndex = 9;
            this.tbPgLog.Text = "Log File";
            // 
            // btnLogDel
            // 
            this.btnLogDel.Location = new System.Drawing.Point(389, 37);
            this.btnLogDel.Name = "btnLogDel";
            this.btnLogDel.Size = new System.Drawing.Size(85, 23);
            this.btnLogDel.TabIndex = 42;
            this.btnLogDel.Text = "&Delete";
            this.btnLogDel.UseVisualStyleBackColor = true;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(189, 12);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(74, 13);
            this.label17.TabIndex = 41;
            this.label17.Text = "Process Date:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(17, 12);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(75, 13);
            this.label14.TabIndex = 40;
            this.label14.Text = "Process Type:";
            // 
            // dtpLog
            // 
            this.dtpLog.CustomFormat = "MM/dd/yyyy";
            this.dtpLog.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpLog.Location = new System.Drawing.Point(192, 37);
            this.dtpLog.Name = "dtpLog";
            this.dtpLog.Size = new System.Drawing.Size(95, 20);
            this.dtpLog.TabIndex = 16;
            this.dtpLog.Value = new System.DateTime(2009, 2, 19, 0, 0, 0, 0);
            // 
            // cboLogPageType
            // 
            this.cboLogPageType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLogPageType.FormattingEnabled = true;
            this.cboLogPageType.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.cboLogPageType.Items.AddRange(new object[] {
            "All",
            "BuildREM",
            "BuildMODULE",
            "BlobsCreation",
            "MergeFederal",
            "MergeState",
            "ModuleDeletion",
            "RunTimeCreation",
            "DeleteState",
            "UnloadReload",
            "DBCheck",
            "AutoProcess"});
            this.cboLogPageType.Location = new System.Drawing.Point(20, 36);
            this.cboLogPageType.Name = "cboLogPageType";
            this.cboLogPageType.Size = new System.Drawing.Size(150, 21);
            this.cboLogPageType.TabIndex = 15;
            // 
            // btnLogRefresh
            // 
            this.btnLogRefresh.Location = new System.Drawing.Point(298, 37);
            this.btnLogRefresh.Name = "btnLogRefresh";
            this.btnLogRefresh.Size = new System.Drawing.Size(85, 23);
            this.btnLogRefresh.TabIndex = 14;
            this.btnLogRefresh.Text = "&Refresh";
            this.btnLogRefresh.UseVisualStyleBackColor = true;
            // 
            // txtLogOut
            // 
            this.txtLogOut.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtLogOut.Location = new System.Drawing.Point(20, 85);
            this.txtLogOut.Multiline = true;
            this.txtLogOut.Name = "txtLogOut";
            this.txtLogOut.ReadOnly = true;
            this.txtLogOut.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtLogOut.Size = new System.Drawing.Size(545, 391);
            this.txtLogOut.TabIndex = 13;
            // 
            // btnLogExport
            // 
            this.btnLogExport.Location = new System.Drawing.Point(480, 37);
            this.btnLogExport.Name = "btnLogExport";
            this.btnLogExport.Size = new System.Drawing.Size(85, 23);
            this.btnLogExport.TabIndex = 12;
            this.btnLogExport.Text = "&Export";
            this.btnLogExport.UseVisualStyleBackColor = true;
            // 
            // tbPgAuto
            // 
            this.tbPgAuto.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tbPgAuto.Controls.Add(this.btnAutoBrowseDB);
            this.tbPgAuto.Controls.Add(this.txtAutoDB);
            this.tbPgAuto.Controls.Add(this.label34);
            this.tbPgAuto.Controls.Add(this.btnAutoCancel);
            this.tbPgAuto.Controls.Add(this.lblAutoMsg);
            this.tbPgAuto.Controls.Add(this.btnAutoSelDir);
            this.tbPgAuto.Controls.Add(this.btnAutoProcess);
            this.tbPgAuto.Controls.Add(this.txtAutoOut);
            this.tbPgAuto.Controls.Add(this.btnAutoBrowseDir);
            this.tbPgAuto.Controls.Add(this.txtAutoDir);
            this.tbPgAuto.Controls.Add(this.label33);
            this.tbPgAuto.Controls.Add(this.chkAutoCalc);
            this.tbPgAuto.Location = new System.Drawing.Point(4, 40);
            this.tbPgAuto.Name = "tbPgAuto";
            this.tbPgAuto.Padding = new System.Windows.Forms.Padding(3);
            this.tbPgAuto.Size = new System.Drawing.Size(580, 488);
            this.tbPgAuto.TabIndex = 10;
            this.tbPgAuto.Text = "Auto Process";
            // 
            // btnAutoBrowseDB
            // 
            this.btnAutoBrowseDB.Location = new System.Drawing.Point(480, 90);
            this.btnAutoBrowseDB.Name = "btnAutoBrowseDB";
            this.btnAutoBrowseDB.Size = new System.Drawing.Size(85, 23);
            this.btnAutoBrowseDB.TabIndex = 38;
            this.btnAutoBrowseDB.Text = "&Browse";
            this.btnAutoBrowseDB.UseVisualStyleBackColor = true;
            // 
            // txtAutoDB
            // 
            this.txtAutoDB.Location = new System.Drawing.Point(216, 93);
            this.txtAutoDB.Name = "txtAutoDB";
            this.txtAutoDB.Size = new System.Drawing.Size(229, 20);
            this.txtAutoDB.TabIndex = 37;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(17, 96);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(193, 13);
            this.label34.TabIndex = 36;
            this.label34.Text = "Name of the Module Database to Build:";
            // 
            // btnAutoCancel
            // 
            this.btnAutoCancel.Location = new System.Drawing.Point(479, 58);
            this.btnAutoCancel.Name = "btnAutoCancel";
            this.btnAutoCancel.Size = new System.Drawing.Size(85, 23);
            this.btnAutoCancel.TabIndex = 17;
            this.btnAutoCancel.Text = "&Cancel";
            this.btnAutoCancel.UseVisualStyleBackColor = true;
            this.btnAutoCancel.Visible = false;
            // 
            // lblAutoMsg
            // 
            this.lblAutoMsg.AutoSize = true;
            this.lblAutoMsg.ForeColor = System.Drawing.Color.Red;
            this.lblAutoMsg.Location = new System.Drawing.Point(144, 11);
            this.lblAutoMsg.Name = "lblAutoMsg";
            this.lblAutoMsg.Size = new System.Drawing.Size(0, 13);
            this.lblAutoMsg.TabIndex = 16;
            // 
            // btnAutoSelDir
            // 
            this.btnAutoSelDir.Location = new System.Drawing.Point(347, 58);
            this.btnAutoSelDir.Name = "btnAutoSelDir";
            this.btnAutoSelDir.Size = new System.Drawing.Size(98, 23);
            this.btnAutoSelDir.TabIndex = 15;
            this.btnAutoSelDir.Text = "Select &Directories";
            this.btnAutoSelDir.UseVisualStyleBackColor = true;
            // 
            // btnAutoProcess
            // 
            this.btnAutoProcess.Location = new System.Drawing.Point(479, 58);
            this.btnAutoProcess.Name = "btnAutoProcess";
            this.btnAutoProcess.Size = new System.Drawing.Size(85, 23);
            this.btnAutoProcess.TabIndex = 14;
            this.btnAutoProcess.Text = "&Start Process";
            this.btnAutoProcess.UseVisualStyleBackColor = true;
            // 
            // txtAutoOut
            // 
            this.txtAutoOut.Location = new System.Drawing.Point(15, 126);
            this.txtAutoOut.Multiline = true;
            this.txtAutoOut.Name = "txtAutoOut";
            this.txtAutoOut.ReadOnly = true;
            this.txtAutoOut.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtAutoOut.Size = new System.Drawing.Size(545, 352);
            this.txtAutoOut.TabIndex = 13;
            // 
            // btnAutoBrowseDir
            // 
            this.btnAutoBrowseDir.Location = new System.Drawing.Point(479, 27);
            this.btnAutoBrowseDir.Name = "btnAutoBrowseDir";
            this.btnAutoBrowseDir.Size = new System.Drawing.Size(85, 23);
            this.btnAutoBrowseDir.TabIndex = 12;
            this.btnAutoBrowseDir.Text = "&Browse";
            this.btnAutoBrowseDir.UseVisualStyleBackColor = true;
            // 
            // txtAutoDir
            // 
            this.txtAutoDir.Location = new System.Drawing.Point(15, 27);
            this.txtAutoDir.Name = "txtAutoDir";
            this.txtAutoDir.Size = new System.Drawing.Size(430, 20);
            this.txtAutoDir.TabIndex = 11;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(12, 11);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(110, 13);
            this.label33.TabIndex = 10;
            this.label33.Text = "Source Text Directory";
            // 
            // chkAutoCalc
            // 
            this.chkAutoCalc.AutoSize = true;
            this.chkAutoCalc.Location = new System.Drawing.Point(19, 58);
            this.chkAutoCalc.Name = "chkAutoCalc";
            this.chkAutoCalc.Size = new System.Drawing.Size(201, 17);
            this.chkAutoCalc.TabIndex = 9;
            this.chkAutoCalc.Text = "Calculate Domain/Question Changes";
            this.chkAutoCalc.UseVisualStyleBackColor = true;
            // 
            // tbPgCheck
            // 
            this.tbPgCheck.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tbPgCheck.Controls.Add(this.spDBCheck);
            this.tbPgCheck.Location = new System.Drawing.Point(4, 40);
            this.tbPgCheck.Name = "tbPgCheck";
            this.tbPgCheck.Padding = new System.Windows.Forms.Padding(3);
            this.tbPgCheck.Size = new System.Drawing.Size(580, 488);
            this.tbPgCheck.TabIndex = 11;
            this.tbPgCheck.Text = "DB Cheking";
            // 
            // spDBCheck
            // 
            this.spDBCheck.Dock = System.Windows.Forms.DockStyle.Fill;
            this.spDBCheck.Location = new System.Drawing.Point(3, 3);
            this.spDBCheck.Name = "spDBCheck";
            this.spDBCheck.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // spDBCheck.Panel1
            // 
            this.spDBCheck.Panel1.Controls.Add(this.lblDBCheckMsg);
            this.spDBCheck.Panel1.Controls.Add(this.btnDBCheckBrowse);
            this.spDBCheck.Panel1.Controls.Add(this.btnDBCheckOpen);
            this.spDBCheck.Panel1.Controls.Add(this.txtDBCheckVer);
            this.spDBCheck.Panel1.Controls.Add(this.label39);
            this.spDBCheck.Panel1.Controls.Add(this.txtDBCheckDB);
            this.spDBCheck.Panel1.Controls.Add(this.label40);
            // 
            // spDBCheck.Panel2
            // 
            this.spDBCheck.Panel2.Controls.Add(this.btnDBCheckProcess);
            this.spDBCheck.Panel2.Controls.Add(this.txtDBCheckOut);
            this.spDBCheck.Panel2.Controls.Add(this.groupBox2);
            this.spDBCheck.Size = new System.Drawing.Size(574, 482);
            this.spDBCheck.SplitterDistance = 109;
            this.spDBCheck.TabIndex = 0;
            // 
            // lblDBCheckMsg
            // 
            this.lblDBCheckMsg.AutoSize = true;
            this.lblDBCheckMsg.ForeColor = System.Drawing.Color.Red;
            this.lblDBCheckMsg.Location = new System.Drawing.Point(145, 10);
            this.lblDBCheckMsg.Name = "lblDBCheckMsg";
            this.lblDBCheckMsg.Size = new System.Drawing.Size(0, 13);
            this.lblDBCheckMsg.TabIndex = 52;
            // 
            // btnDBCheckBrowse
            // 
            this.btnDBCheckBrowse.Location = new System.Drawing.Point(487, 27);
            this.btnDBCheckBrowse.Name = "btnDBCheckBrowse";
            this.btnDBCheckBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnDBCheckBrowse.TabIndex = 51;
            this.btnDBCheckBrowse.Text = "&Browse";
            this.btnDBCheckBrowse.UseVisualStyleBackColor = true;
            // 
            // btnDBCheckOpen
            // 
            this.btnDBCheckOpen.Location = new System.Drawing.Point(487, 58);
            this.btnDBCheckOpen.Name = "btnDBCheckOpen";
            this.btnDBCheckOpen.Size = new System.Drawing.Size(75, 23);
            this.btnDBCheckOpen.TabIndex = 50;
            this.btnDBCheckOpen.Text = "&Open";
            this.btnDBCheckOpen.UseVisualStyleBackColor = true;
            // 
            // txtDBCheckVer
            // 
            this.txtDBCheckVer.Location = new System.Drawing.Point(63, 60);
            this.txtDBCheckVer.Name = "txtDBCheckVer";
            this.txtDBCheckVer.ReadOnly = true;
            this.txtDBCheckVer.Size = new System.Drawing.Size(180, 20);
            this.txtDBCheckVer.TabIndex = 49;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(12, 63);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(45, 13);
            this.label39.TabIndex = 48;
            this.label39.Text = "Version:";
            // 
            // txtDBCheckDB
            // 
            this.txtDBCheckDB.Location = new System.Drawing.Point(15, 27);
            this.txtDBCheckDB.Name = "txtDBCheckDB";
            this.txtDBCheckDB.Size = new System.Drawing.Size(452, 20);
            this.txtDBCheckDB.TabIndex = 47;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(12, 11);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(125, 13);
            this.label40.TabIndex = 46;
            this.label40.Text = "Module Database Name:";
            // 
            // btnDBCheckProcess
            // 
            this.btnDBCheckProcess.Enabled = false;
            this.btnDBCheckProcess.Location = new System.Drawing.Point(466, 64);
            this.btnDBCheckProcess.Name = "btnDBCheckProcess";
            this.btnDBCheckProcess.Size = new System.Drawing.Size(94, 25);
            this.btnDBCheckProcess.TabIndex = 74;
            this.btnDBCheckProcess.Text = "&Start Process";
            this.btnDBCheckProcess.UseVisualStyleBackColor = true;
            // 
            // txtDBCheckOut
            // 
            this.txtDBCheckOut.Location = new System.Drawing.Point(15, 115);
            this.txtDBCheckOut.Multiline = true;
            this.txtDBCheckOut.Name = "txtDBCheckOut";
            this.txtDBCheckOut.ReadOnly = true;
            this.txtDBCheckOut.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtDBCheckOut.Size = new System.Drawing.Size(545, 250);
            this.txtDBCheckOut.TabIndex = 14;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rdoLookForDuplicateQuestionLinkText);
            this.groupBox2.Controls.Add(this.rdoMissingLink);
            this.groupBox2.Controls.Add(this.rdoFix_av_collision);
            this.groupBox2.Controls.Add(this.rdoduplicateappsn);
            this.groupBox2.Controls.Add(this.rdoDup_state_domainsn);
            this.groupBox2.Controls.Add(this.rdoApplicabilityRangeMap2);
            this.groupBox2.Location = new System.Drawing.Point(15, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(445, 94);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Queries";
            // 
            // rdoLookForDuplicateQuestionLinkText
            // 
            this.rdoLookForDuplicateQuestionLinkText.AutoSize = true;
            this.rdoLookForDuplicateQuestionLinkText.Location = new System.Drawing.Point(227, 42);
            this.rdoLookForDuplicateQuestionLinkText.Name = "rdoLookForDuplicateQuestionLinkText";
            this.rdoLookForDuplicateQuestionLinkText.Size = new System.Drawing.Size(207, 17);
            this.rdoLookForDuplicateQuestionLinkText.TabIndex = 7;
            this.rdoLookForDuplicateQuestionLinkText.Text = "Look For Duplicate Question Link Text";
            this.rdoLookForDuplicateQuestionLinkText.UseVisualStyleBackColor = true;
            // 
            // rdoMissingLink
            // 
            this.rdoMissingLink.AutoSize = true;
            this.rdoMissingLink.Location = new System.Drawing.Point(227, 65);
            this.rdoMissingLink.Name = "rdoMissingLink";
            this.rdoMissingLink.Size = new System.Drawing.Size(88, 17);
            this.rdoMissingLink.TabIndex = 6;
            this.rdoMissingLink.Text = "Missing Links";
            this.rdoMissingLink.UseVisualStyleBackColor = true;
            // 
            // rdoFix_av_collision
            // 
            this.rdoFix_av_collision.AutoSize = true;
            this.rdoFix_av_collision.Checked = true;
            this.rdoFix_av_collision.Location = new System.Drawing.Point(15, 19);
            this.rdoFix_av_collision.Name = "rdoFix_av_collision";
            this.rdoFix_av_collision.Size = new System.Drawing.Size(177, 17);
            this.rdoFix_av_collision.TabIndex = 5;
            this.rdoFix_av_collision.TabStop = true;
            this.rdoFix_av_collision.Text = "Fix Applicability Variable Overlap";
            this.rdoFix_av_collision.UseVisualStyleBackColor = true;
            // 
            // rdoduplicateappsn
            // 
            this.rdoduplicateappsn.AutoSize = true;
            this.rdoduplicateappsn.Location = new System.Drawing.Point(15, 42);
            this.rdoduplicateappsn.Name = "rdoduplicateappsn";
            this.rdoduplicateappsn.Size = new System.Drawing.Size(192, 17);
            this.rdoduplicateappsn.TabIndex = 4;
            this.rdoduplicateappsn.Text = "Duplicate Application Serial number";
            this.rdoduplicateappsn.UseVisualStyleBackColor = true;
            // 
            // rdoDup_state_domainsn
            // 
            this.rdoDup_state_domainsn.AutoSize = true;
            this.rdoDup_state_domainsn.Location = new System.Drawing.Point(15, 65);
            this.rdoDup_state_domainsn.Name = "rdoDup_state_domainsn";
            this.rdoDup_state_domainsn.Size = new System.Drawing.Size(210, 17);
            this.rdoDup_state_domainsn.TabIndex = 3;
            this.rdoDup_state_domainsn.Text = "Dupplicate State Domain Serial number";
            this.rdoDup_state_domainsn.UseVisualStyleBackColor = true;
            // 
            // rdoApplicabilityRangeMap2
            // 
            this.rdoApplicabilityRangeMap2.AutoSize = true;
            this.rdoApplicabilityRangeMap2.Location = new System.Drawing.Point(227, 19);
            this.rdoApplicabilityRangeMap2.Name = "rdoApplicabilityRangeMap2";
            this.rdoApplicabilityRangeMap2.Size = new System.Drawing.Size(173, 17);
            this.rdoApplicabilityRangeMap2.TabIndex = 2;
            this.rdoApplicabilityRangeMap2.Text = "Range of Applicability Variables";
            this.rdoApplicabilityRangeMap2.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(594, 537);
            this.Controls.Add(this.tabControl);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl.ResumeLayout(false);
            this.tbPgBuildREM.ResumeLayout(false);
            this.tbPgBuildREM.PerformLayout();
            this.tbPgBuildMODULE.ResumeLayout(false);
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel1.PerformLayout();
            this.splitContainer4.Panel2.ResumeLayout(false);
            this.splitContainer4.Panel2.PerformLayout();
            this.splitContainer4.ResumeLayout(false);
            this.tbPgModuleDel.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            this.splitContainer1.ResumeLayout(false);
            this.tbPgRGTC.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.Panel2.PerformLayout();
            this.splitContainer2.ResumeLayout(false);
            this.tbPgDelState.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel1.PerformLayout();
            this.splitContainer3.Panel2.ResumeLayout(false);
            this.splitContainer3.Panel2.PerformLayout();
            this.splitContainer3.ResumeLayout(false);
            this.tbPgUpload.ResumeLayout(false);
            this.splitContainer5.Panel1.ResumeLayout(false);
            this.splitContainer5.Panel1.PerformLayout();
            this.splitContainer5.Panel2.ResumeLayout(false);
            this.splitContainer5.Panel2.PerformLayout();
            this.splitContainer5.ResumeLayout(false);
            this.tbPgMergSt.ResumeLayout(false);
            this.splitContainer8.Panel1.ResumeLayout(false);
            this.splitContainer8.Panel1.PerformLayout();
            this.splitContainer8.Panel2.ResumeLayout(false);
            this.splitContainer8.Panel2.PerformLayout();
            this.splitContainer8.ResumeLayout(false);
            this.tbPgMergFederal.ResumeLayout(false);
            this.splitContainer7.Panel1.ResumeLayout(false);
            this.splitContainer7.Panel2.ResumeLayout(false);
            this.splitContainer7.Panel2.PerformLayout();
            this.splitContainer7.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tbPgBlobsCreat.ResumeLayout(false);
            this.splitContainer6.Panel1.ResumeLayout(false);
            this.splitContainer6.Panel1.PerformLayout();
            this.splitContainer6.Panel2.ResumeLayout(false);
            this.splitContainer6.Panel2.PerformLayout();
            this.splitContainer6.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tbPgLog.ResumeLayout(false);
            this.tbPgLog.PerformLayout();
            this.tbPgAuto.ResumeLayout(false);
            this.tbPgAuto.PerformLayout();
            this.tbPgCheck.ResumeLayout(false);
            this.spDBCheck.Panel1.ResumeLayout(false);
            this.spDBCheck.Panel1.PerformLayout();
            this.spDBCheck.Panel2.ResumeLayout(false);
            this.spDBCheck.Panel2.PerformLayout();
            this.spDBCheck.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tbPgBuildREM;
        private System.Windows.Forms.Button btnBuildREMCancel;
        private System.Windows.Forms.Label lblMsg;
        private System.Windows.Forms.Button btnBuildREMSel;
        private System.Windows.Forms.Button btnBuildREMProcess;
        private System.Windows.Forms.TextBox txtBuildREMOutput;
        private System.Windows.Forms.Button btnBuildREMBrowse;
        private System.Windows.Forms.TextBox txtBuildREMDir;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox chkBuildREMCalculate;
        private System.Windows.Forms.TabPage tbPgBuildMODULE;
        private System.Windows.Forms.SplitContainer splitContainer4;
        private System.Windows.Forms.Button cmdFixAirREM;
        private System.Windows.Forms.Button btnModuleRemoveAll;
        private System.Windows.Forms.Button btnModuleAddAll;
        private System.Windows.Forms.Button btnModuleDBBrowse;
        private System.Windows.Forms.Button btnModuleStart;
        private System.Windows.Forms.Button btnModuleCancel;
        internal System.Windows.Forms.TextBox txtModuleDB;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblModuleMsg;
        internal System.Windows.Forms.ListBox lstModuleSel;
        internal System.Windows.Forms.ListBox lstModuleAval;
        private System.Windows.Forms.Button btnModuleAdd;
        private System.Windows.Forms.Button btnModuleRemove;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnModuleBrowse;
        internal System.Windows.Forms.TextBox txtModuleDir;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtModuleOut;
        private System.Windows.Forms.TabPage tbPgModuleDel;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label lblDelModuleMsg;
        private System.Windows.Forms.Button btnDelModBrowse;
        private System.Windows.Forms.Button btnDelModOpen;
        private System.Windows.Forms.TextBox txtDelModVer;
        private System.Windows.Forms.Label label3;
        internal System.Windows.Forms.TextBox txtDelModName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnDelModCancel;
        private System.Windows.Forms.Button btnDelModRemAll;
        private System.Windows.Forms.Button btnDelModAddAll;
        internal System.Windows.Forms.ListBox lstDelModSel;
        internal System.Windows.Forms.ListBox lstDelModAvail;
        private System.Windows.Forms.Button btnDelModProcess;
        private System.Windows.Forms.Button btnDelModAdd;
        private System.Windows.Forms.Button btnDelModRemove;
        private System.Windows.Forms.TextBox txtDelModOut;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TabPage tbPgRGTC;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.Label lblRgtimeMsg;
        private System.Windows.Forms.Button btbRunTimeCreationBrowse;
        private System.Windows.Forms.Button btbRunTimeCreationOpen;
        private System.Windows.Forms.TextBox txtRunTimeCreationVer;
        private System.Windows.Forms.Label label6;
        internal System.Windows.Forms.TextBox txtRunTimeCreationDB;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnRunTimeCreationCancel;
        private System.Windows.Forms.TextBox txtRunTimeCreationOut;
        private System.Windows.Forms.Button btnRunTimeCreationProcess;
        private System.Windows.Forms.TabPage tbPgDelState;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.Label lblDelStMsg;
        private System.Windows.Forms.Button btnDelStBrowse;
        private System.Windows.Forms.Button btnDelStOpen;
        private System.Windows.Forms.TextBox txtDelStVer;
        private System.Windows.Forms.Label label8;
        internal System.Windows.Forms.TextBox txtDelStDB;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnDelStCancel;
        private System.Windows.Forms.TextBox txtDelStOut;
        private System.Windows.Forms.Button btnDelStProcess;
        private System.Windows.Forms.TabPage tbPgUpload;
        private System.Windows.Forms.SplitContainer splitContainer5;
        private System.Windows.Forms.Label lblLoadMsg;
        private System.Windows.Forms.Button btnLdBrowse;
        private System.Windows.Forms.Button btnLdOpen;
        private System.Windows.Forms.TextBox txtLdVer;
        private System.Windows.Forms.Label label15;
        internal System.Windows.Forms.TextBox txtLoadDB;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnLdCancel;
        private System.Windows.Forms.TextBox txtLdOut;
        private System.Windows.Forms.Button btnLdProcess;
        private System.Windows.Forms.TabPage tbPgMergSt;
        private System.Windows.Forms.SplitContainer splitContainer8;
        private System.Windows.Forms.Label lblMergeStMsg;
        private System.Windows.Forms.Button btnMergeSTBrowse;
        private System.Windows.Forms.Button btnMergeSTOpen;
        internal System.Windows.Forms.TextBox txtMergeSTVer;
        private System.Windows.Forms.Label label24;
        internal System.Windows.Forms.TextBox txtMergeStDB;
        private System.Windows.Forms.Label label25;
        internal System.Windows.Forms.CheckBox chkMergeSynCheck;
        private System.Windows.Forms.Button btnMergeSTCancel;
        private System.Windows.Forms.TextBox txtMergeSTOut;
        private System.Windows.Forms.Button btnMergeSTProcess;
        internal System.Windows.Forms.TextBox txtMergeSTVerName;
        private System.Windows.Forms.Label label30;
        internal System.Windows.Forms.TextBox txtMergeSTDate;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Button btnMergeSTRemoveAll;
        private System.Windows.Forms.Button btnMergeSTAddAll;
        internal System.Windows.Forms.ListBox lstMergeSTStates;
        internal System.Windows.Forms.ListBox lstMergeSTAvaiSt;
        private System.Windows.Forms.Button btnMergeSTAdd;
        private System.Windows.Forms.Button btnMergeSTRemove;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        internal System.Windows.Forms.TextBox txtMergeSTModuleRoot;
        private System.Windows.Forms.Label label27;
        internal System.Windows.Forms.TextBox txtMergeSTSateRoot;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TabPage tbPgMergFederal;
        private System.Windows.Forms.SplitContainer splitContainer7;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label lblMergeFModuleMsg;
        private System.Windows.Forms.TextBox txtMergeFMasterVer;
        private System.Windows.Forms.Button btnMergeFModuleBrowse;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button btnMergeFModuleOpen;
        internal System.Windows.Forms.TextBox txtMergeFMasterDB;
        private System.Windows.Forms.TextBox txtMergeFModuleVer;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button btnMergeFMasterOpen;
        internal System.Windows.Forms.TextBox txtMergeFModuleDB;
        private System.Windows.Forms.Button btnMergeFMasterBrowse;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label lblMergeFMasterMsg;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button btnMergeFProcess;
        private System.Windows.Forms.Button btnMergeFCancel;
        internal System.Windows.Forms.TextBox txtDateSC;
        internal System.Windows.Forms.TextBox txtDateDA;
        internal System.Windows.Forms.TextBox txtVNameSC;
        internal System.Windows.Forms.TextBox txtVNameDA;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox txtMergeFdOut;
        private System.Windows.Forms.TabPage tbPgBlobsCreat;
        private System.Windows.Forms.SplitContainer splitContainer6;
        private System.Windows.Forms.Label lblBlobsMsg;
        private System.Windows.Forms.Button btnBlobsBrowse;
        private System.Windows.Forms.Button btnBlobsOpen;
        private System.Windows.Forms.TextBox txtBlobsVer;
        private System.Windows.Forms.Label label21;
        internal System.Windows.Forms.TextBox txtBlobsDB;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button btnBlobsProcess;
        private System.Windows.Forms.Button btnBlobsCancel;
        private System.Windows.Forms.GroupBox groupBox1;
        internal System.Windows.Forms.RadioButton optMissingBlobs;
        internal System.Windows.Forms.RadioButton optAllTheBlobs;
        private System.Windows.Forms.TextBox txtBlobsOut;
        private System.Windows.Forms.TabPage tbPgLog;
        private System.Windows.Forms.Button btnLogDel;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DateTimePicker dtpLog;
        private System.Windows.Forms.ComboBox cboLogPageType;
        private System.Windows.Forms.Button btnLogRefresh;
        private System.Windows.Forms.TextBox txtLogOut;
        private System.Windows.Forms.Button btnLogExport;
        private System.Windows.Forms.TabPage tbPgAuto;
        private System.Windows.Forms.Button btnAutoBrowseDB;
        internal System.Windows.Forms.TextBox txtAutoDB;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Button btnAutoCancel;
        private System.Windows.Forms.Label lblAutoMsg;
        private System.Windows.Forms.Button btnAutoSelDir;
        private System.Windows.Forms.Button btnAutoProcess;
        private System.Windows.Forms.TextBox txtAutoOut;
        private System.Windows.Forms.Button btnAutoBrowseDir;
        internal System.Windows.Forms.TextBox txtAutoDir;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.CheckBox chkAutoCalc;
        private System.Windows.Forms.TabPage tbPgCheck;
        private System.Windows.Forms.SplitContainer spDBCheck;
        private System.Windows.Forms.Label lblDBCheckMsg;
        private System.Windows.Forms.Button btnDBCheckBrowse;
        private System.Windows.Forms.Button btnDBCheckOpen;
        private System.Windows.Forms.TextBox txtDBCheckVer;
        private System.Windows.Forms.Label label39;
        internal System.Windows.Forms.TextBox txtDBCheckDB;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Button btnDBCheckProcess;
        private System.Windows.Forms.TextBox txtDBCheckOut;
        private System.Windows.Forms.GroupBox groupBox2;
        internal System.Windows.Forms.RadioButton rdoLookForDuplicateQuestionLinkText;
        internal System.Windows.Forms.RadioButton rdoMissingLink;
        internal System.Windows.Forms.RadioButton rdoFix_av_collision;
        internal System.Windows.Forms.RadioButton rdoduplicateappsn;
        internal System.Windows.Forms.RadioButton rdoDup_state_domainsn;
        internal System.Windows.Forms.RadioButton rdoApplicabilityRangeMap2;
    }
}