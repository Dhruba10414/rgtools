﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Configuration;

namespace RGTools_New
{
    public partial class frmDBConfig : Form
    {
        internal frmMain _parent = null;

        public frmDBConfig()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            _parent.SQLConfigSubmitted = false;
            this.Close();
        }

        private void btnConfigGetSQLServer_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            UTIL.iniSqlServer(cboConfigSQLServer, _parent.defaultServer);
            this.Cursor = Cursors.Default;

        }

        private void btnConfigGetSQLDB_Click(object sender, EventArgs e)
        {
            try
            {
                string constr;
                if (chkConfigSQLInte.Checked)
                {
                    constr =UTIL.GetSqlServerConnectionString(cboConfigSQLServer.Text, "master");
                }
                else
                {
                    constr = UTIL.GetSqlServerConnectionString(cboConfigSQLServer.Text, "master",
                            txtConfigSQLUser.Text, txtConfigSQLPass.Text);
                }

                using (SqlConnection conn = new SqlConnection(constr))
                {
                    conn.Open();

                    // Get the names of all DBs in the database server.
                    SqlCommand query = new SqlCommand(@"select distinct [name] from sysdatabases where name not in ('master','model','msdb','tempdb') order by [name]", conn);
                    using (SqlDataReader reader = query.ExecuteReader())
                    {
                        cboConfigSQLDB.Items.Clear();
                        cboConfigSQLDB.SelectedIndex = -1;
                        while (reader.Read())
                        {
                            cboConfigSQLDB.Items.Add((string)reader[0]);
                        }
                        if (cboConfigSQLDB.Items.Count > 0)
                            cboConfigSQLDB.SelectedIndex = 0;
                    } // using

                    conn.Close();
                } // using


                if (cboConfigSQLServer.Text.ToLower() == _parent.defaultServer)
                {
                    for (int i = 0; i < cboConfigSQLDB.Items.Count; i++)
                    {
                        if (cboConfigSQLDB.Items[i].ToString().ToLower() == _parent.defaultDB)
                        {
                            cboConfigSQLDB.SelectedIndex = i;
                            break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this,
                    ex.Message,
                    "Failed To Connect",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void chkConfigSQLInte_CheckedChanged(object sender, EventArgs e)
        {
            this.txtConfigSQLUser.Enabled = !chkConfigSQLInte.Checked;
            this.txtConfigSQLPass.Enabled = !chkConfigSQLInte.Checked;
        }

        private void btnConfigSave_Click(object sender, EventArgs e)
        {
            if (!chkConfigSQLInte.Checked && txtConfigSQLUser.Text.Trim() == "")
            {
                MessageBox.Show(this, "No user ID input!", "DB Configuration",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);

                txtConfigSQLUser.Focus();
                return;
            }

            bool SaveSuccess = true;

            _parent.SQLUser = this.txtConfigSQLUser.Text;// ConfigurationManager.AppSettings["SQLUser"];
            _parent.SQLPW = this.txtConfigSQLPass.Text;// ConfigurationManager.AppSettings["SQLPW"];

            if (cboConfigSQLServer.Text != string.Empty)
            {
                //_parent.SaveConfig("SQLServer", this.cboConfigSQLServer.Text);

                _parent.SQLServer = this.cboConfigSQLServer.Text;// ConfigurationManager.AppSettings["SQLServer"];
            }
            else
            {
                SaveSuccess = false;
            }

            if (this.cboConfigSQLDB.Text != string.Empty)
            {
                //_parent.SaveConfig("SQLDB", this.cboConfigSQLDB.Text);

                _parent.SQLDB = this.cboConfigSQLDB.Text;// ConfigurationManager.AppSettings["SQLDB"];
            }
            else
            {
                SaveSuccess = false;
            }

            if (SaveSuccess)
            {
                MessageBox.Show(this, "Saved successfully!", "DB Configuration", MessageBoxButtons.OK);
            }
            else
            {
                MessageBox.Show(this, "There some errors in configuration", "DB Configuration", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            _parent.SQLConfigSubmitted = true;

            this.Close();
        }

        private void frmDBConfig_Load(object sender, EventArgs e)
        {
            this.cboConfigSQLServer.Text = _parent.SQLServer;
            this.cboConfigSQLDB.Text = _parent.SQLDB;

            this.txtConfigSQLUser.Text = _parent.SQLUser;
            this.txtConfigSQLPass.Text = _parent.SQLPW;

            if (_parent.SQLServer == "")
            {
                this.chkConfigSQLInte.Checked = true;
            }
        }

     

    }
}
