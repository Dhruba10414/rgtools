﻿namespace RGTools_New
{
    partial class frmDBConfig
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDBConfig));
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.btnConfigGetSQLServer = new System.Windows.Forms.Button();
            this.cboConfigSQLDB = new System.Windows.Forms.ComboBox();
            this.btnConfigGetSQLDB = new System.Windows.Forms.Button();
            this.cboConfigSQLServer = new System.Windows.Forms.ComboBox();
            this.label60 = new System.Windows.Forms.Label();
            this.txtConfigSQLPass = new System.Windows.Forms.TextBox();
            this.txtConfigSQLUser = new System.Windows.Forms.TextBox();
            this.chkConfigSQLInte = new System.Windows.Forms.CheckBox();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.btnConfigSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.groupBox9.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.btnConfigGetSQLServer);
            this.groupBox9.Controls.Add(this.cboConfigSQLDB);
            this.groupBox9.Controls.Add(this.btnConfigGetSQLDB);
            this.groupBox9.Controls.Add(this.cboConfigSQLServer);
            this.groupBox9.Controls.Add(this.label60);
            this.groupBox9.Controls.Add(this.txtConfigSQLPass);
            this.groupBox9.Controls.Add(this.txtConfigSQLUser);
            this.groupBox9.Controls.Add(this.chkConfigSQLInte);
            this.groupBox9.Controls.Add(this.label61);
            this.groupBox9.Controls.Add(this.label62);
            this.groupBox9.Controls.Add(this.label63);
            this.groupBox9.Location = new System.Drawing.Point(12, 12);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(456, 194);
            this.groupBox9.TabIndex = 5;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "SQL Server Configuration";
            // 
            // btnConfigGetSQLServer
            // 
            this.btnConfigGetSQLServer.Location = new System.Drawing.Point(353, 87);
            this.btnConfigGetSQLServer.Name = "btnConfigGetSQLServer";
            this.btnConfigGetSQLServer.Size = new System.Drawing.Size(85, 23);
            this.btnConfigGetSQLServer.TabIndex = 107;
            this.btnConfigGetSQLServer.Text = "Get Server";
            this.btnConfigGetSQLServer.UseVisualStyleBackColor = true;
            this.btnConfigGetSQLServer.Click += new System.EventHandler(this.btnConfigGetSQLServer_Click);
            // 
            // cboConfigSQLDB
            // 
            this.cboConfigSQLDB.DropDownHeight = 105;
            this.cboConfigSQLDB.FormattingEnabled = true;
            this.cboConfigSQLDB.IntegralHeight = false;
            this.cboConfigSQLDB.Location = new System.Drawing.Point(22, 150);
            this.cboConfigSQLDB.Name = "cboConfigSQLDB";
            this.cboConfigSQLDB.Size = new System.Drawing.Size(313, 21);
            this.cboConfigSQLDB.TabIndex = 105;
            // 
            // btnConfigGetSQLDB
            // 
            this.btnConfigGetSQLDB.Location = new System.Drawing.Point(353, 148);
            this.btnConfigGetSQLDB.Name = "btnConfigGetSQLDB";
            this.btnConfigGetSQLDB.Size = new System.Drawing.Size(85, 23);
            this.btnConfigGetSQLDB.TabIndex = 108;
            this.btnConfigGetSQLDB.Text = "Get DB";
            this.btnConfigGetSQLDB.UseVisualStyleBackColor = true;
            this.btnConfigGetSQLDB.Click += new System.EventHandler(this.btnConfigGetSQLDB_Click);
            // 
            // cboConfigSQLServer
            // 
            this.cboConfigSQLServer.FormattingEnabled = true;
            this.cboConfigSQLServer.Location = new System.Drawing.Point(22, 87);
            this.cboConfigSQLServer.Name = "cboConfigSQLServer";
            this.cboConfigSQLServer.Size = new System.Drawing.Size(313, 21);
            this.cboConfigSQLServer.TabIndex = 104;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(19, 71);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(74, 13);
            this.label60.TabIndex = 103;
            this.label60.Text = "Select Server:";
            // 
            // txtConfigSQLPass
            // 
            this.txtConfigSQLPass.Enabled = false;
            this.txtConfigSQLPass.Location = new System.Drawing.Point(362, 33);
            this.txtConfigSQLPass.Name = "txtConfigSQLPass";
            this.txtConfigSQLPass.PasswordChar = '*';
            this.txtConfigSQLPass.Size = new System.Drawing.Size(76, 20);
            this.txtConfigSQLPass.TabIndex = 101;
            // 
            // txtConfigSQLUser
            // 
            this.txtConfigSQLUser.Enabled = false;
            this.txtConfigSQLUser.Location = new System.Drawing.Point(196, 32);
            this.txtConfigSQLUser.Name = "txtConfigSQLUser";
            this.txtConfigSQLUser.Size = new System.Drawing.Size(98, 20);
            this.txtConfigSQLUser.TabIndex = 100;
            // 
            // chkConfigSQLInte
            // 
            this.chkConfigSQLInte.Checked = true;
            this.chkConfigSQLInte.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkConfigSQLInte.Location = new System.Drawing.Point(22, 33);
            this.chkConfigSQLInte.Name = "chkConfigSQLInte";
            this.chkConfigSQLInte.Size = new System.Drawing.Size(116, 21);
            this.chkConfigSQLInte.TabIndex = 98;
            this.chkConfigSQLInte.Text = "Integrated Security";
            this.chkConfigSQLInte.UseVisualStyleBackColor = true;
            this.chkConfigSQLInte.CheckedChanged += new System.EventHandler(this.chkConfigSQLInte_CheckedChanged);
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(300, 35);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(56, 13);
            this.label61.TabIndex = 101;
            this.label61.Text = "Password:";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(144, 36);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(46, 13);
            this.label62.TabIndex = 99;
            this.label62.Text = "User ID:";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(19, 119);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(58, 13);
            this.label63.TabIndex = 97;
            this.label63.Text = "Select DB:";
            // 
            // btnConfigSave
            // 
            this.btnConfigSave.Location = new System.Drawing.Point(365, 222);
            this.btnConfigSave.Name = "btnConfigSave";
            this.btnConfigSave.Size = new System.Drawing.Size(85, 23);
            this.btnConfigSave.TabIndex = 110;
            this.btnConfigSave.Text = "&Save";
            this.btnConfigSave.UseVisualStyleBackColor = true;
            this.btnConfigSave.Click += new System.EventHandler(this.btnConfigSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(272, 222);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 109;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // frmDBConfig
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 268);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnConfigSave);
            this.Controls.Add(this.groupBox9);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmDBConfig";
            this.Text = "Configure Database";
            this.Load += new System.EventHandler(this.frmDBConfig_Load);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Button btnConfigGetSQLServer;
        internal System.Windows.Forms.ComboBox cboConfigSQLDB;
        private System.Windows.Forms.Button btnConfigGetSQLDB;
        internal System.Windows.Forms.ComboBox cboConfigSQLServer;
        private System.Windows.Forms.Label label60;
        internal System.Windows.Forms.TextBox txtConfigSQLPass;
        internal System.Windows.Forms.TextBox txtConfigSQLUser;
        internal System.Windows.Forms.CheckBox chkConfigSQLInte;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Button btnConfigSave;
        private System.Windows.Forms.Button btnCancel;
    }
}