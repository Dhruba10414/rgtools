using System;
using System.Collections.Generic;
using System.Text;

namespace RGTools_New
{
    enum RGTokenType
    {
        tokA, tokB, tokBREAK, tokCAPTION, tokDATE, tokDEFAULT, tokDEFINITION,
        tokEND, tokINDENT, tokKEY, tokLIST, tokOFF, tokSECTION, tokSUBHEADER,
        tokTABLE, OutOfTokens, Undefined
    }

    class Rgtoken
    {
        struct TokenStruct
        {
            string _name;
            RGTokenType _tok;

            public TokenStruct(string Name, RGTokenType Tok)
            {
                _name = Name;
                _tok = Tok;
            }

            public string Name
            {
                get
                {
                    return _name;
                }
            }

            public RGTokenType Tok
            {
                get
                {
                    return _tok;
                }
            }
        }

        static TokenStruct[] TokenArray = 
        { 
            new TokenStruct("A", RGTokenType.tokA), 
            new TokenStruct("B", RGTokenType.tokB),
            new TokenStruct("BREAK", RGTokenType.tokBREAK), 
            new TokenStruct("CAPTION", RGTokenType.tokCAPTION),
            new TokenStruct("DATE", RGTokenType.tokDATE), 
            new TokenStruct("DEFAULT", RGTokenType.tokDEFAULT), 
            new TokenStruct("DEF", RGTokenType.tokDEFINITION),
            new TokenStruct("END", RGTokenType.tokEND), 
            new TokenStruct("INDENT", RGTokenType.tokINDENT), 
            new TokenStruct("KEY", RGTokenType.tokKEY),
            new TokenStruct("LIST", RGTokenType.tokLIST), 
            new TokenStruct("OFF", RGTokenType.tokOFF),
            new TokenStruct("SECTION", RGTokenType.tokSECTION),
            new TokenStruct("SUBHEADER", RGTokenType.tokSUBHEADER), 
            new TokenStruct("TABLE", RGTokenType.tokTABLE)
        };

        public static RGTokenType GetRGToken(ref string ParseLine)
        {
            // Eliminate leading and trailing spaces.
            //ParseLine = ParseLine.TrimStart(new char[] { ' ' });
            ParseLine = ParseLine.Trim(new char[] { ' ' });

            // If the length of the parse line is zero, we are out of tokens.
            if (ParseLine.Length == 0)
                return RGTokenType.OutOfTokens;

            // Extract the first token and clip it from the line.
            string Token;
            int BreakPoint = ParseLine.IndexOf(' ');//.find_first_of (" "));
            if (BreakPoint == -1)
            {
                Token = ParseLine;
                ParseLine = "";
            }
            else
            {
                Token = ParseLine.Substring(0, BreakPoint);
                ParseLine=ParseLine.Remove(0, BreakPoint);
                ParseLine = ParseLine.TrimStart(new char[] { ' ' });
            }

            // Make sure the token is in upper case.
            Token=Token.ToUpper();

            // Determine Token code.
            for (int i = 0; i <TokenArray.Length; i++)
            {
                if (Token == TokenArray[i].Name)
                {
                    return TokenArray[i].Tok;
                }
            }

            return RGTokenType.Undefined;
        }

    }

}
