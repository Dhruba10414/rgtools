using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;

namespace RGTools_New
{
    class SUTIL
    {
        public static string RPad(string ts, int PadWidth)
        {
            for (int i = ts.Length; i < PadWidth; i++)
                ts = ts + " ";
            return ts;
        }

        // WrapOffset.  This function returns the position of the last character before a space for the
        //  specified width.   This function takes the following parameters:
        //
        //       TStr   string    (Passed) String to check.
        //       Width  int       (Passed) Clip width.
        //
        public static long WrapOffset(string TStr, int Width)
        {
            if (TStr.Length <= Width)
                return TStr.Length;
            else
            {
                UTIL.Assert(Width > 0, "Assertion Failed: Width > 0!");
                for (int i = Width - 1; i >= 0; i--)
                    if (TStr[i] == ' ')
                        return i;

                return Width;
            }
        }

        // strips duplicate spaces.
        public static string CompressSpaces(ref string ts)
        {
            ts = ts.Trim(new char[]{' '});
            char[] pp = new char[ts.Length + 1];
            char[] p = pp;

            string p1=string.Empty ;//= pp;
            return p1;
        }


        // Backscan. Returns the last position of the specified character in the
        // string or -1 if the character is not found.
        public static int BackScan(string ts, char Match)
        {
            for (int i = ts.Length - 1; i >= 0; i--)
                if (ts[i] == Match)
                    return i;

            return -1;
        }

        // Prepare ASCII string
        public static string PrepareASCIIString(string ts)
        {
            StringBuilder sbPP = new StringBuilder();

            for (int i = 0; i < ts.Length; i++)
            {
                switch (ts[i])
                {
                    case '\'':
                        sbPP.Append("\'\'");
                        break;
                    case '{':       // Ignore brackets.
                    case '}':
                        break;

                    default:
                        sbPP.Append(ts.Substring(i,1));
                        break;
                }
            }
            return sbPP.ToString();
        }
        public static string PrepareXMLtring(string ts)
        {
            //ts = PrepareASCIIString(ts);
            //ts = ts.Replace("<", Environment.NewLine);
            //ts = ts.Replace(">", Environment.NewLine);
            //ts = ts.Replace(@"""", Environment.NewLine);
            //ts = ts.Replace(">", Environment.NewLine);
            //return SanitizeXmlString(ts.Replace("&", "&amp;"));
            return SanitizeXmlString(ts);
        }
        public static string SanitizeXmlString(string xml)
        {

            if (xml == null)
            {

                throw new ArgumentNullException("xml");
            }


            string s = "";
            StringBuilder buffer = new StringBuilder(xml.Length);
            foreach (char c in xml)
            {
                if (IsLegalXmlChar(c))
                {
                    buffer.Append(c);
                }
                else
                {
                    s = c.ToString();
                }
            }
            return buffer.ToString();
        }
        /// <summary>  
        /// Whether a given character is allowed by XML 1.0.  
        /// </summary>  

        public static bool IsLegalXmlChar(int character)
        {
            return
            (
                 character == 0x9 /* == '\t' == 9   */          ||
                 character == 0xA /* == '\n' == 10  */          ||
                 character == 0xD /* == '\r' == 13  */          ||
                (character >= 0x20 && character <= 0xD7FF) ||
                (character >= 0xE000 && character <= 0xFFFD) ||
                (character >= 0x10000 && character <= 0x10FFFF)
            );
        } 

        public static string CompressSpaces(string ts)
        {
            string[] split = ts.Split(new char[] { ' ' },StringSplitOptions.RemoveEmptyEntries);
            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < split.Length; i++)
            {
                sb.Append(split[i] + " ");
            }

            return sb.ToString().Trim(new char[]{' '});

        }

    }
}
