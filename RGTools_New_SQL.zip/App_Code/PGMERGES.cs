//----------------------------------------------------------------------------
//  Project RGTools
//  Dakota Software Corporation
//  Copyright � 1997. All Rights Reserved.
//  FILE:    pgmerges.h
//  AUTHOR:  Marc CHANTEGREIL
//
//  OVERVIEW
//  ~~~~~~~~
//  Class definition for TPageMergeState (TPageWithDB).
//
//----------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Data;
using System.Data.Odbc;
using System.Threading;
using System.Diagnostics;
using System.Data.Sql;
using System.Data.SqlClient;

namespace RGTools_New
{
    //***************************************************************************
    //**///////////////////// CAbrModuleName ////////////////////////////////////
    //***************************************************************************
    //
    // Class to access the Dakota Auditor ModuleSN and the directory name (ex. N:\Test\Readonly\Water),
    // given a two letters module (ex. WQ).  We need to access using this two letters code, because it
    // is the way a module is referenced in the regulatory ASCII files (DADOMAIN.TXT).
    //
    class CAbrModuleName
    {

        //**********  Data Members
        protected string m_sAbrName;
        protected string m_sDir;
        protected long m_lModuleSN;

        //********** ructors, Destructors ************************************
        public CAbrModuleName(string AbrName, string Dir, long ModuleSN)
        {
            m_sAbrName = AbrName;
            m_sDir = Dir;
            m_lModuleSN = ModuleSN;

        }

        public CAbrModuleName(CAbrModuleName Other)
        {
            m_sAbrName = Other.m_sAbrName;
            m_sDir = Other.m_sDir;
            m_lModuleSN = Other.m_lModuleSN;
        }

        public CAbrModuleName()
        {
            m_sAbrName = "";
            m_sDir = "";
            m_lModuleSN = -1;
        }

        //********** Operator Methods *****************************************
        public static bool operator ==(CAbrModuleName Other1, CAbrModuleName Other2)
        {
            return Other2.m_sAbrName == Other1.m_sAbrName;
        }
        public static bool operator !=(CAbrModuleName Other1, CAbrModuleName Other2)
        {
            return Other2.m_sAbrName != Other1.m_sAbrName;
        }

        public long GetModuleSN()
        {
            return m_lModuleSN;
        }

        public long ModuleSN
        {
            get
            {
                return m_lModuleSN;
            }
        }

        public string GetDir()
        {
            return m_sDir;
        }
        public string Dir
        {
            get
            {
                return m_sDir;
            }
        }
        public void PutAbrName(string AbrName)
        {
            m_sAbrName = AbrName;
        }
        public string AbrName
        {
            set
            {
                m_sAbrName = value;
            }
            get
            {
                return m_sAbrName;
            }
        }

        public override bool Equals(object obj)
        {
            if (CAbrModuleName.Equals((obj as CAbrModuleName), null))
            {
                return false;
            }
            else
            {
                return this.m_sAbrName == ((CAbrModuleName)(obj)).m_sAbrName;
            }
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }

    //***************************************************************************
    //**///////////////////// CBLRDomain ////////////////////////////////////////
    //***************************************************************************
    //
    // Class to access the BLR Domain title (ex: Accumulation Time), given a BLR domain name (ex.: ACCUM).
    //
    class CBLRDomain
    {

        //**********  Data Members
        protected string m_sBLRName;
        protected string m_sBLRTitle = string.Empty;

        //********** ructors, Destructors ************************************
        public CBLRDomain(string BLRName, string BLRTitle)
        {
            m_sBLRName = BLRName;
            m_sBLRTitle = BLRTitle;
        }
        public CBLRDomain(CBLRDomain Other)
        {
            m_sBLRName = Other.m_sBLRName;
            m_sBLRTitle = Other.m_sBLRTitle;
        }
        public CBLRDomain()
        {
            m_sBLRName = "";
            m_sBLRTitle = "";
        }

        //********** Operator Methods *****************************************
        public static bool operator ==(CBLRDomain Other1, CBLRDomain Other2)
        {
            return Other1.m_sBLRName == Other2.m_sBLRName;
        }
        public static bool operator !=(CBLRDomain Other1, CBLRDomain Other2)
        {
            return Other1.m_sBLRName != Other2.m_sBLRName;
        }
        //public static bool operator <(CBLRDomain Other1, CBLRDomain Other2)
        //{
        //    return Other1.m_sBLRName < Other2.m_sBLRName;
        //}
        //public static bool operator >(CBLRDomain Other1, CBLRDomain Other2)
        //{
        //    return Other1.m_sBLRName > Other2.m_sBLRName;
        //}

        //********** Public Methods ***********************************************
        public string GetBLRTitle() { return m_sBLRTitle; }
        public string GetBLRName() { return m_sBLRName; }
        public void PutBLRName(string BLRName) { m_sBLRName = BLRName; }
        public string BLRName
        {
            set
            {
                m_sBLRName = BLRName;
            }
            get
            {
                return m_sBLRName;
            }
        }
        public string BLRTitle
        {
            get
            {
                return m_sBLRTitle;
            }
        }

        public override bool Equals(object obj)
        {
            if (CBLRDomain.Equals((obj as CBLRDomain), null))
            {
                return false;
            }
            else
            {
                return this.m_sBLRName == ((CBLRDomain)(obj)).m_sBLRName;
            }
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }

    //***************************************************************************
    //**///////////////////// CFederalDomain ////////////////////////////////////
    //***************************************************************************
    //
    // Class to access the Dakota Auditor Domain Serial Number, given a regulatory domain name (ex.: USCP:HAZ.31).
    //
    class CFederalDomain
    {

        //**********  Data Members
        protected string m_sRegulName;
        protected long m_lDomainSN = -1;
        protected short m_iOrder;     // Child Order.

        //********** ructors, Destructors ************************************
        public CFederalDomain(string RegulName, long DomainSN)
        {
            m_sRegulName = RegulName;
            m_lDomainSN = DomainSN;
            m_iOrder = 0;
        }

        public CFederalDomain(CFederalDomain Other)
        {
            m_sRegulName = Other.m_sRegulName;
            m_lDomainSN = Other.m_lDomainSN;
            m_iOrder = Other.m_iOrder;
        }

        public CFederalDomain()
        {
            m_sRegulName = "";
            m_lDomainSN = -1;
            m_iOrder = 0;
        }

        //********** Operator Methods *****************************************
        public static bool operator ==(CFederalDomain Other1, CFederalDomain Other2)
        {
            return Other1.m_sRegulName == Other2.m_sRegulName;
        }
        public static bool operator !=(CFederalDomain Other1, CFederalDomain Other2)
        {
            return Other1.m_sRegulName != Other2.m_sRegulName;
        }
        public override bool Equals(object obj)
        {
            if (CFederalDomain.Equals((obj as CFederalDomain), null))
            {
                return false;
            }
            else
            {
                return this.m_sRegulName == ((CFederalDomain)(obj)).m_sRegulName;
            }
        }
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        //********** Public Methods ***********************************************
        public long GetDomainSN()
        {
            return m_lDomainSN;
        }
        // Used to assign an order to the next child to attach to this domain (considered as parent).
        public short GetNextOrder() { return m_iOrder++; }

        public void PutRegulName(string RegulName)
        { m_sRegulName = RegulName; }

        public string RegulName
        {
            get
            {
                return m_sRegulName;
            }
            set
            {
                m_sRegulName = value;
            }
        }
    }

    //***************************************************************************
    //**///////////////////// CDADomain /////////////////////////////////////////
    //***************************************************************************
    class CDADomain
    {

        //**********  Data Members
        protected string m_sStateDomainName;
        protected string m_sParentDomainName;

        //********** ructors, Destructors ************************************
        public CDADomain(string StateDomainName, string ParentDomainName)
        {
            m_sStateDomainName = StateDomainName;
            m_sParentDomainName = ParentDomainName;
        }

        public CDADomain(CDADomain Other)
        {
            m_sStateDomainName = Other.m_sStateDomainName;
            m_sParentDomainName = Other.m_sParentDomainName;
        }

        //  CDADomain () : m_sStateDomainName (""), m_sParentDomainName ("") {}
        public CDADomain()
        {
            m_sStateDomainName = string.Empty;
            m_sParentDomainName = string.Empty;
        }

        //********** Operator Methods *****************************************
        public static bool operator ==(CDADomain Other1, CDADomain Other2)
        {
            return Other1.m_sStateDomainName == Other2.m_sStateDomainName &&
                  Other1.m_sParentDomainName == Other2.m_sParentDomainName;
        }
        public static bool operator !=(CDADomain Other1, CDADomain Other2)
        {
            return Other1.m_sStateDomainName != Other2.m_sStateDomainName ||
                  Other1.m_sParentDomainName != Other2.m_sParentDomainName;
        }
        //public static bool operator <(CDADomain Other1, CDADomain Other2)
        //{
        //    return (Other1.m_sStateDomainName < Other2.m_sStateDomainName) ||
        //              (Other1.m_sStateDomainName == Other2.m_sStateDomainName
        //              && Other1.m_sParentDomainName < Other2.m_sParentDomainName);
        //}
        //public static bool operator >(CDADomain Other1, CDADomain Other2)
        //{
        //    return (Other1.m_sStateDomainName > Other2.m_sStateDomainName) &&
        //              (Other1.m_sStateDomainName != Other2.m_sStateDomainName
        //              || Other1.m_sParentDomainName > Other2.m_sParentDomainName);
        //}
        public override bool Equals(object obj)
        {
            if (CDADomain.Equals((obj as CDADomain), null))
            {
                return false;
            }
            else
            {
                return this.m_sStateDomainName == ((CDADomain)(obj)).m_sStateDomainName;
            }
        }
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        //********** Public Methods ***********************************************
        public void PutStateDomainName(string StateDomainName)
        {
            m_sStateDomainName = StateDomainName;
        }
        public void PutParentDomainName(string ParentDomainName)
        {
            m_sParentDomainName = ParentDomainName;
        }
    }

    /***************************************************************************
    //**/
    //////////////////// CDADomainList ////////////////////////////////////
    //**************************************************************************
    class CDADomainList : List<CDADomain>
    {
        // ructors, Destructors.
        public CDADomainList() { }
        // ~CDADomainList ()  { Flush (TShouldDelete::Delete); }

        // Public Methods.
        //public  void Flush (TShouldDelete.DeleteType dt = TShouldDelete.NoDelete)
        //      { TISArrayAsVector <CDADomain>::Flush (dt); }
    }

    //***************************************************************************
    //**///////////////////// CState ////////////////////////////////////////////
    //***************************************************************************
    //
    // Information on a state.  Notice GetNextTableCounter () which returns the next available number for the
    // "see table nn" reference links.
    // The CopyPreviousToCurrent () method is used to rewind this counter when a state domain is plugged in several times.
    // The CopyCurrentToPrevious () method is then used to avoid rewinding the counter.
    // There is a method to set or get if a state is merging for the first time in the master database.
    //
    class CState
    {

        //**********  Data Members
        protected string m_sPostalCode = string.Empty;
        protected string m_sName = string.Empty;
        protected int m_iStateSN = -1;
        protected bool m_bIsNew = false;
        protected long m_lTableCounter;
        protected long m_lpTableCounter;

        //********** ructors, Destructors ************************************
        public CState(string PostalCode, string Name, int StateSN, bool IsNew)
        {
            m_sPostalCode = PostalCode;
            m_sName = Name;
            m_iStateSN = StateSN;
            m_bIsNew = IsNew;
            m_lTableCounter = 0;
            m_lpTableCounter = 0;
        }
        public CState(CState Other)
        {
            m_sPostalCode = Other.m_sPostalCode;
            m_sName = Other.m_sName;
            m_iStateSN = Other.m_iStateSN;
            m_bIsNew = Other.m_bIsNew;
            m_lTableCounter = Other.m_lTableCounter;
            m_lpTableCounter = Other.m_lpTableCounter;
        }
        public CState()
        {
            m_sPostalCode = "";
            m_sName = "";
            m_iStateSN = -1;
            m_bIsNew = false;
            m_lTableCounter = 0;
            m_lpTableCounter = 0;
        }

        //********** Operator Methods *****************************************
        public static bool operator ==(CState Other1, CState Other2)
        { return Other1.m_sPostalCode == Other2.m_sPostalCode; }
        public static bool operator !=(CState Other1, CState Other2)
        { return Other1.m_sPostalCode != Other2.m_sPostalCode; }
        //public static bool operator <(CState Other1, CState Other2)
        //{ return Other1.m_sPostalCode < Other2.m_sPostalCode; }
        //public static bool operator >(CState Other1, CState Other2)
        //{ return Other1.m_sPostalCode > Other2.m_sPostalCode; }
        public override bool Equals(object obj)
        {
            if (CState.Equals((obj as CState), null))
            {
                return false;
            }
            else
            {
                return this.m_sPostalCode == ((CState)(obj)).m_sPostalCode;
            }
        }
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        //********** Public Methods ***********************************************
        public string GetPostalCode()
        { return m_sPostalCode; }
        public string GetName()
        { return m_sName; }
        public int GetStateSN()
        { return m_iStateSN; }
        public bool IsNew()
        { return m_bIsNew; }
        public long GetNextTableCounter() { return ++m_lTableCounter; }

        public void CopyPreviousToCurrent() { m_lTableCounter = m_lpTableCounter; }
        public void CopyCurrentToPrevious() { m_lpTableCounter = m_lTableCounter; }
    }

    //******************************************************************
    //**//// TPageMergeState ///////////////////////////////////////////
    //******************************************************************
    class TPageMergeState //:  TPageWithDB
    {
        //public delegate DialogResult MessageCallBack(string text, string caption, MessageBoxButtons Buttons, MessageBoxIcon Icon);
        public event MessageCallBack MessageShow;
        //***************************************************************************
        //**///////////////////// Global constants //////////////////////////////////
        //***************************************************************************
        //static string SEP_LISTANSWER = "\\X7F";
        static string SEP_LISTANSWER = ASCIIEncoding.Default.GetString(new byte[] { 0X7F });//"\\X7F";
        //static string SEP_LISTREF = "\\\\X7F";  //directly run from query
        static string SEP_LISTREF = ASCIIEncoding.Default.GetString(new byte[] { 0X7F });//"\\X7F";

        static string FORMAT_PREFIX = ASCIIEncoding.Default.GetString(new byte[] { 0X07 });//"\\X07";
        static string BOLD_ON = ASCIIEncoding.Default.GetString(new byte[] { 0X11 });//"\\X11";
        static string BOLD_OFF = ASCIIEncoding.Default.GetString(new byte[] { 0X91 });//"\\X91";
        static string FIXED_ON = ASCIIEncoding.Default.GetString(new byte[] { 0X12 });//"\\X12";
        static string FIXED_OFF = ASCIIEncoding.Default.GetString(new byte[] { 0X92 });//"\\X92";
        static string PARAGRAPH_BREAK = ASCIIEncoding.Default.GetString(new byte[] { 0X0E });//"\\X0E";   // leaves a blank line.
        static string LINE_BREAK = ASCIIEncoding.Default.GetString(new byte[] { 0X0F });//"\\X0F";   // a simple CRLF.

        private frmMain _main = null;
        DataSql sqlbase = null;
        SqlTransaction transaction = null;
        List<string> lstMergeSql = new List<string>();

        //#15132-4 RGTOOLS - Testing RGTools V3.0.0.9 No Popup message to indicate AutoProcess failed in the MergeState step (step 13) because of errors in the state files.
        //Would the pop-up appear only after all processing is done for the step that is being done so that we catch all the errors for that step? For example we would not 
        //want the message to pop-up at the first error in State Merge even though even though a single error would prevent the database from being created and the process 
        //would fail. We would want the processing to continue to the end of MergeState as it does currently to capture all the errors and then report the process failure. 
        //A pop-up would appear at that time and AutoProcess would terminate by pressing OK. If no errors were detected then no pop-up would be necessary and AutoProcess 
        //could continue to the next step without any intervention from the user. 
        private string errMessage = "";
        // ructors
        public TPageMergeState(frmMain Main)
        {
            _main = Main;
            m_CodeSite = (_main.toolSheet.MainSite) ? " " : "R";

            sqlbase = new DataSql(_main.txtMergeSTServer.Text, _main.txtMergeSTDB.Text, _main.MergeSTUser, _main.MergeSTPW);
            sqlbase.checkCancel += new DataSql.IsCancel(IsCancel);
        }

        //**********  Data Members
        //string m_sMergeSQLFile = string.Empty;
        string m_sResearchDate = string.Empty;

        ////**********  OUTPUT FILES.
        //StreamWriter m_OFileMerge = null;
        StreamWriter m_OFileSDVLink = null;
        StreamWriter m_OFileStateStr = null;
        StreamWriter m_OFileQCountSt = null;
        StreamWriter m_OFileQDState = null;
        StreamWriter m_OFileStateSect = null;
        StreamWriter m_OFileQuestion = null;
        StreamWriter m_OFileQuestionB = null;
        StreamWriter m_OFileRGSection = null;
        StreamWriter m_OFileQRLink = null;
        StreamWriter m_OFileRGKeyWord = null;

        //**********  List of questions / sections / states.
        List<long> m_ListQuestionToMerge = new List<long>();
        List<long> m_ListQuestionMaster = new List<long>();
        List<long> m_ListSectionToMerge = new List<long>();
        List<long> m_ListSectionMaster = new List<long>();
        List<CState> m_ListState = new List<CState>();

        List<CAbrModuleName> m_TAbrModuleName = new List<CAbrModuleName>();
        List<CBLRDomain> m_TBLRDomain = new List<CBLRDomain>();
        List<CFederalDomain> m_TDomain = new List<CFederalDomain>();
        TLongArray m_TListOneQuestion = new TLongArray(); // List of State expansion QuestionSN which need to be non-

        int m_iNewStateVersionSN = -1;
        long m_lQuestionBodySN = -1;
        long m_lReferenceSN = -1;
        long m_lModuleSN = -1;
        bool m_bFirstOccurence = false;
        string m_tFileName;
        CState m_pCState = null;

        TCounter m_Counter = new TCounter();
        bool m_bPreformat;
        bool m_bLink;
        string m_sFileName;
        long m_lQuestionSN = -1;
        long m_lSectionSN = -1;
        long m_lCounter = -1;
        long m_lSequence = -1;
        string m_CodeSite = string.Empty;

        //******************************************************************
        public void DoProcess()
        {
            try
            {
                errMessage = "";

                sqlbase.Open();
                transaction = sqlbase.BeginTransaction();

                //General Initialization.
                InitEnv();

                if (CheckForCancel)
                {
                    CloseStream();
                    transaction.Rollback();
                    return;
                }
                // Initialize array of abreviate Module Name.
                InitAbrModuleName();

                if (CheckForCancel)
                {
                    CloseStream();
                    transaction.Rollback();
                    return;
                }

                // Initialize array of BLR (or State) Domains (using BLRTITLE.TXT).
                InitBLRDomain();

                if (CheckForCancel)
                {
                    CloseStream();
                    transaction.Rollback();
                    return;
                }

                // Initialize array of Federal Domain (using the DOMAIN.TXT files).
                InitDomain();

                if (CheckForCancel)
                {
                    CloseStream();
                    transaction.Rollback();
                    return;
                }

                // 1. Check For Serial Numbers.
                // I keep this process apart of MergeState () because of modularity, even if a few parts (mainly identify and
                // open the ASCII files) are common.
                StateSerial();

                if (CheckForCancel)
                {
                    CloseStream();
                    transaction.Rollback();
                    return;
                }

                // 2 - Creation of MergeSt.sql (see the detailed steps in the method).
                MergeState();

                if (CheckForCancel)
                {
                    CloseStream();
                    transaction.Rollback();
                    return;
                }

                if (!FullProcess())
                {
                    CloseStream();
                    transaction.Rollback();
                    return;
                }

                // 3. ISQL.
                // First, ask the user if he wants to continue.
                if (!_main.isAutoProcess)
                {
                    //DialogResult result = MessageBox.Show(
                    //        "The merging process is going now to import the data in the database.\r\nDo you want to continue? ",
                    //        "Merge State", MessageBoxButtons.YesNo, MessageBoxIcon.None);
                    _main.dResult = DialogResult.Abort;

                    MessageShow("The merging process is going now to import the data in the database.\r\nDo you want to continue? ",
                           "Merge State", MessageBoxButtons.YesNo, MessageBoxIcon.None);
                    do
                    {
                    } while (_main.dResult == DialogResult.Abort);
                    if (_main.dResult == DialogResult.No)
                    {
                        CloseStream();
                        transaction.Rollback();
                        return;
                    }
                }

                if (_main.isAutoProcess && errMessage != "")
                {
                    CloseStream();
                    transaction.Rollback();
                    return;
                }

                _main.OutMsg(PageType.MergeState, "Merging the State Sections files in the database.\r\n");

                string ret = null;
                ret = sqlbase.RunSQL(Query.DeleteConstrains, true);

                List<string> lstSQLI = new List<string>();
                List<string> lstSQLII = new List<string>();
                List<string> lstSQLIII = new List<string>();
                List<string> lstSQL = lstSQLI;
                
                string[] arr = lstMergeSql.ToArray();
                for (int i = 0; i < arr.Length; i++) 
                {
                    if (arr[i].StartsWith("LOADDATA"))
                    {
                        string[] ldTable = arr[i].Split(new char[] { ',' });

                        if (ldTable.Length == 3)
                        {
                            lstSQLII.Add(arr[i]);
                        }

                        lstSQL = lstSQLIII;
                    }
                    else
                    {
                        lstSQL.Add(arr[i]);
                    }
                }


                ret = sqlbase.RunSQL(lstSQLI.ToArray(), true);
                if (ret != "")
                {
                    transaction.Rollback();
                    ErrorThrow(ret);

                    return;
                }

                foreach (string str in lstSQLII)
                {
                    if (CheckForCancel)
                        break;

                    string[] ldTable = str.Split(new char[] { ',' });

                    _main.OutMsg(PageType.MergeState, "Merging table "+ldTable[1]+" ...\r\n");

                    sqlbase.LoadTextToTable_full(ldTable[2], ldTable[1], true);
                }

                lstSQLIII.Add("delete from QRLink where ReferenceSN not in (select ReferenceSN from RGKeyword)");
                ret = sqlbase.RunSQL(lstSQLIII.ToArray(), true);
                if (ret != "")
                {
                    transaction.Rollback();
                    ErrorThrow(ret);

                    return;
                }

                if (CheckForCancel)
                {
                    CloseStream();
                    transaction.Rollback();
                    return;
                }

                // 4. Sort the State Sections.
                SortStateSection();

                ret = sqlbase.RunSQL(Query.CreateConstrains, true);
                if (ret != "")
                {
                    transaction.Rollback();
                    ErrorThrow(ret);

                    return;
                }

                if (CheckForCancel)
                {
                    CloseStream();
                    transaction.Rollback();
                    return;
                }

                if (errMessage != "" && _main.isAutoProcess)
                {
                    CloseStream();
                    transaction.Rollback();
                    return;
                }

                transaction.Commit();
            }
            catch (Exception e)
            {
                //transaction.Rollback();
                CloseStream();
                transaction.Rollback();

                ErrorThrow(e.Message);
            }
            finally
            {
                sqlbase.Close();

                if (errMessage != "" && _main.isAutoProcess)
                {
                    ErrorThrow(errMessage);
                }
            }
        }

        void StateSerial()
        {
            //DialogResult result = DialogResult.None;
            _main.OutMsg(PageType.MergeState, "Checking Serial Numbers in the State Section Files.\r\n");
            if (!FullProcess())
            {
                _main.OutMsg(PageType.MergeState, "The 'Syntax checking only' option is not considered during the Serial Numbers process.\r\n");
            }

            // Input and Output fstreams.
            StreamWriter OFileDADomain = null;
            StreamReader IFileDADomain = null;
            StreamWriter OFileBLRSection = null;
            StreamReader IFileBLRSection = null;

            CBLRDomain pFindBLRDomain = new CBLRDomain();
            CFederalDomain pFindFederalDomain = new CFederalDomain();
            CDADomain pFindDADomain = new CDADomain();

            // List of couples (StateDomainName, ParentName).  Used for duplicates.
            CDADomainList TDADomain = new CDADomainList();

            string DirState = _main.txtMergeSTSateRoot.Text.Trim();// GetDlgField(this, IDC_DIRSTATE) + "\\";
            if (!DirState.EndsWith(@"\"))
            {
                DirState += @"\";
            }

            // First open the file which will be the new DADomain.txt.
            string FileName = Path.Combine(DirState, "DADomain.new");// DirState + "DADomain.new";

            if (File.Exists(FileName))
            {
                File.Delete(FileName);
            }

            try
            {
                OFileDADomain = new StreamWriter(FileName, false, Encoding.Default);
            }
            catch
            {
                throw (new Exception("Unable to open Temporary file " + FileName));
            }

            // Now, open the current DADomain.txt.
            FileName = Path.Combine(DirState, "DADomain.txt");
            try
            {
                IFileDADomain = new StreamReader(FileName, Encoding.Default);
            }
            catch//(Exception e)
            {
                throw (new Exception("Problem to open the file " + FileName));
            }

            // Open the files for the missing state sections files.
            string FileNameBLRMis = Path.Combine(DirState, "BLRMis.txt");
            if (File.Exists(FileNameBLRMis))
            {
                File.Delete(FileNameBLRMis);
            }

            StreamWriter OFileBLRMis = null;// (FileNameBLRMis.c_str());

            try
            {
                //OFileBLRMis = new StreamWriter(FileNameBLRMis);
                OFileBLRMis = new StreamWriter(FileNameBLRMis, false, Encoding.Default);

                _main.OutMsg(PageType.MergeState, "The file BLRMis.txt has been created" + ".\r\n");
            }
            catch
            {
                throw (new Exception("Problem to open the file " + FileNameBLRMis));
            }

            // Serial Numbers objects.
            TStateDomainSN SDomain = new TStateDomainSN(_main.toolSheet.SNDir);// _main.toolSheet.SNDir);
            TStateQuestionSN SQuestion = new TStateQuestionSN(_main.toolSheet.SNDir);
            TStateSectionSN SSection = new TStateSectionSN(_main.toolSheet.SNDir);

            int NumLine = 0;
            string Line, Word1, ParentName = string.Empty;
            long StateDomainSN;
            string StateDomName = string.Empty;
            string PrecDomName = "";
            bool IsDADomainChanged = false;
            bool SigmaAddedSN = false;

            // Now, we have a loop on every entry in DADomain.txt; and for each entry, we have to process it for all the states
            // to merge.
            while ((Line = GetLine(IFileDADomain, ref NumLine, false, true)) != null && !CheckForCancel)
            {
                // Ignore blank lines and lines beginning with an asterisk.
                if (Line.Trim(new char[]{' '}) == "" || Line.TrimStart()[0] == '*')
                {
                    OFileDADomain.WriteLine(Line);
                    continue;
                }

                // This file has 4 columns: STATE DOMAINSN  STATE DOMAIN NAME  REG. PARENT DOMAINSN  PARENT DOMAIN HEADING
                //                 Example: 960800001       ACCUM              USSH:D.OSA            "On-site Accumulation"
                //                          960800002       ACCUM              USSH:E.OSA            "On-site Accumulation"
                //                          960800003       AIR                USAQ                  "Air Quality"

                //***************************************************************************
                // Getting the fields.
                //***************************************************************************
                int iPos = 0;
                Word1 = GetWord(Line, ref iPos);


                try
                {
                    StateDomainSN = long.Parse(Word1);// atol (Word1.c_str ());
                }
                catch
                {
                    StateDomainSN = 0;
                }
                if (StateDomainSN == 0)
                {
                    // We assume that Word1 was then the State Domain Name
                    StateDomName = Word1;
                }
                else
                {
                    StateDomName = GetWord(Line, ref iPos);
                }

                // Now, get the Parent Name (where this State Domain is going to be plugged).
                // We ignore the state parent heading.
                ParentName = GetWord(Line, ref iPos);

                //***************************************************************************
                // Checking the fields
                //***************************************************************************
                try
                {
                    if (StateDomainSN == 0)
                    {
                        // Find a new SN for this State Domain.
                        StateDomainSN = SDomain.AllocateSN();
                        OFileDADomain.WriteLine(StateDomainSN + "  " + Line.Trim(new char[]{' '}));
                        IsDADomainChanged = true;
                    }
                    else
                    {
                        OFileDADomain.WriteLine(Line);  // just output the line as it is.
                    }
                    if (StateDomName == "")
                    {
                        throw (new Exception("State Domain name missing in " + FileName +
                                " - Line " + NumLine.ToString()));
                    }

                    pFindBLRDomain.PutBLRName(StateDomName);
                    _cblrDomain = pFindBLRDomain;
                    _cblrDomain = m_TBLRDomain.Find(matchCBLRDomain);
                    try
                    {
                        _cblrDomain.GetType();
                    }
                    catch
                    {
                        throw (new Exception("BLR Domain unknown in " + FileName +
                                " - Line " + NumLine.ToString()));
                    }

                    if (ParentName == "")
                    {
                        throw (new Exception("State Parent Domain Name missing in " + FileName +
                                " - Line " + NumLine.ToString()));
                    }

                    pFindFederalDomain.PutRegulName(ParentName);
                    _cfederalDomain = pFindFederalDomain;
                    _cfederalDomain = m_TDomain.Find(matchCFederalDomain);
                    try
                    {
                        _cfederalDomain.GetType();
                    }
                    catch
                    {
                        throw (new Exception("Parent Domain doesn't exist in " + FileName +
                                " - Line " + NumLine.ToString()));
                    }

                    // Check also that we don't have a duplicate.
                    pFindDADomain.PutStateDomainName(StateDomName);
                    pFindDADomain.PutParentDomainName(ParentName);
                    _cdaDomain = pFindDADomain;
                    _cdaDomain = TDADomain.Find(matchCDADomain);
                    try
                    {
                        _cdaDomain.GetType();
                        throw (new Exception("The State Domain " + StateDomName + " appears to be attached twice to " + ParentName +
                                " in " + FileName + " - Line " + NumLine.ToString()));
                    }
                    catch
                    {
                    }

                }
                catch (Exception e)
                {
                    if (_main.isAutoProcess)
                    {
                        errMessage += e.Message + ".\r\n";
                        continue;
                    }

                    _main.OutMsg(PageType.MergeState, e.Message + ".\r\n");
                    _main.processFailed = true;

                    if (!_main.isAutoProcess && !CheckForCancel)
                    {
                        
                        //result = MessageBox.Show("Do you want to continue? ", "Stop Process", MessageBoxButtons.YesNo);
                        //if (result == DialogResult.No)
                        _main.dResult = DialogResult.Abort;

                        MessageShow("Do you want to continue? ",
                               "Merge State", MessageBoxButtons.YesNo, MessageBoxIcon.None);
                        do
                        {
                        } while (_main.dResult == DialogResult.Abort);

                        if (_main.dResult == DialogResult.No)

                        {
                            throw (new Exception("Exit"));
                        }
                        else
                        {
                            continue;
                        }
                    }
                }

                //if (StateDomName == "BROWN")
                //{
                //    string s = "";
                //}

                // Add a element in TDADomain.
                TDADomain.Add(new CDADomain(StateDomName, ParentName));

                //***************************************************************************************
                // Now, have a loop on every state and read the BLR Section corresponding.
                //***************************************************************************************
                for (int iState = 0; iState < _main.lstMergeSTStates.Items.Count; iState++)
                {
                    if (CheckForCancel) break;

                    //_main.lstMergeSTStates.SetSelected(iState, true);
                    string PostalCode = _main.lstMergeSTStates.Items[iState].ToString();

                    // Now, read the BLR Section related with the current state.
                    int NumLine2 = 0;
                    string IBLRFileName = DirState + PostalCode + "\\" + StateDomName + "." + PostalCode;
                    string OBLRFileName = IBLRFileName + "X";

                    if (File.Exists(IBLRFileName))
                    {
                        if (StateDomName != PrecDomName)
                        {
                            _main.OutMsg(PageType.MergeState, StateDomName + "." + PostalCode + "\r\n");
                        }

                        bool AddedSN = false;

                        try
                        {
                            try
                            {
                                // This BLR Domain is defined for this state. Open it.
                                IFileBLRSection = new StreamReader(IBLRFileName, Encoding.Default);
                            }
                            catch
                            {
                                throw (new Exception("Problem to open the file " + IBLRFileName));
                            }

                            // Delete and then open the destination file.
                            if (File.Exists(OBLRFileName))
                            {
                                File.Delete(OBLRFileName);
                            }
                            try
                            {
                                //OFileBLRSection = new StreamWriter(OBLRFileName);
                                OFileBLRSection = new StreamWriter(OBLRFileName, false, Encoding.Default);
                            }
                            catch
                            {
                                throw (new Exception("Problem to open the temporary file " + OBLRFileName));

                            }

                            // Now we suppose that the first line is "@SECTION  StateDomainName"
                            // The following lines are the serial numbers lines.
                            Line = GetLine(IFileBLRSection, ref NumLine2, false, true);
                            if (Line == null || Line.Length < 9 || Line.Substring(0, 9) != "@ SECTION") 
                            {
                                throw (new Exception("Missing @ SECTION in " + IBLRFileName + " - Line " + NumLine2.ToString()));

                            }
                            OFileBLRSection.WriteLine(Line);

                            //***************************************************************************************
                            // Check for Serial number of the section.
                            Line = GetLine(IFileBLRSection, ref NumLine2, false, true);
                            if (Line != null && Line.Length > 4 && (
                                    Line.Substring(0, 5) == "@ SNS" || Line.Substring(0, 5) == "@RSNS"))
                            {
                                // There is already a serial number for this section.
                                // Remove this line if this serial number was created by a remote site and
                                // now we are the main site.
                                if (Line.Substring(1, 1) == "R" && _main.toolSheet.IsMainSite())
                                {
                                    // Get a SN for this section.
                                    OFileBLRSection.WriteLine("@" + m_CodeSite + "SNS" + SSection.AllocateSN());
                                    AddedSN = true;

                                    // Tell the user about that.
                                    _main.OutMsg(PageType.MergeState, "Removed Remote Section Serial Number: " + Line +
                                            " in " + IBLRFileName + "\r\n");
                                    _main.OutMsg(PageType.MergeState, "   New Section Serial Number: " +
                                            SSection.GetSN().ToString() + "\r\n");
                                }
                                else
                                {
                                    OFileBLRSection.WriteLine(Line);
                                }

                                // Go to the next line.
                                Line = GetLine(IFileBLRSection, ref NumLine2, false, true);

                            }
                            else
                            {
                                // Get a SN for this section.
                                OFileBLRSection.WriteLine("@" + m_CodeSite + "SNS" + SSection.AllocateSN());
                                AddedSN = true;
                            }

                            //***************************************************************************************
                            // Check in the BLR section file if we have Question Serial Numbers for the federal parent where
                            // this state domain is going to be plugged.
                            // In the case of remote created Serial numbers, remove them and generate new ones.
                            bool ParentFound = false;
                            bool RemoveSN = false;

                            do
                            {
                                try
                                {
                                    if (Line.Length < 5 || (Line.Substring(0, 5) != "@ SNQ" && Line.Substring(0, 5) != "@RSNQ"))  
                                    { 
                                        break; 
                                    }
                                    if (Line.Substring(15) == ParentName)
                                    {
                                        // Serial numbers have been found.  However, remove them and generate new ones if
                                        // they have been created by a remote site and we are now the main site.
                                        if (Line.Substring(1, 1) == "R" && _main.toolSheet.IsMainSite())
                                        {
                                            // Tell the user about the removed serial numbers.
                                            _main.OutMsg(PageType.MergeState, "Removed Remote Question Serial Number(s): " + Line + " in "
                                                             + IBLRFileName + "\r\n");
                                            RemoveSN = true;

                                            // Go to the next line.
                                            Line = GetLine(IFileBLRSection, ref NumLine2, false, true);

                                        }
                                        else
                                        {
                                            ParentFound = true;
                                        }
                                        break;
                                    }
                                }
                                catch { }

                                if (Line != null)
                                {
                                    OFileBLRSection.WriteLine(Line);
                                }

                            } while ((Line = GetLine(IFileBLRSection, ref NumLine2, false, true)) != null);

                            if (ParentFound == false)
                            {
                                // Add a serial number for this parent.
                                OFileBLRSection.WriteLine("@" + m_CodeSite + "SNQ" + SQuestion.GetSN() + " " + ParentName);
                                SQuestion.AllocateSN();    // Always a GLR Question.
                                AddedSN = true;

                                // Log the new added Serial number only if we removed a remote one before.
                                if (RemoveSN)
                                {
                                    _main.OutMsg(PageType.MergeState, "    New Question Serial Number(s): " + SQuestion.GetSN().ToString() + "\r\n");

                                }
                            }

                            if (AddedSN)
                            {
                                // Now read all the BLR file and write it.
                                OFileBLRSection.WriteLine(Line);
                                string Tmp;
                                while ((Line = GetLine(IFileBLRSection, ref NumLine2, false, true)) != null)
                                {
                                    OFileBLRSection.WriteLine(Line);
                                    // Now, increment the question number if ParentFound == false;
                                    if (Line != "" && ParentFound == false)
                                    {
                                        Line = Line.TrimStart(new char[] { ' ' });
                                        if (Line[0] == '@')
                                        {
                                            Tmp = Line.Substring(1);
                                            Tmp = Tmp.TrimStart(new char[] { ' ' });
                                            if (Tmp.Length == 0)
                                            {
                                                _main.OutMsg(PageType.MergeState, "@ singleton in " + IBLRFileName + "\r\n");
                                                throw (new Exception("@ singleton in " + IBLRFileName + "\r\n"));
                                            }

                                            if (Tmp[0] == 'M' || Tmp[0] == 'Q')
                                            {
                                                SQuestion.AllocateSN();
                                            }
                                        }
                                    }
                                }
                            }

                            // Close the BLR files.
                            IFileBLRSection.Close();
                            OFileBLRSection.Close();

                            // Copy the file (only if Serial Number added).
                            if (AddedSN)
                            {
                                if (!UTIL.FileCopy(OBLRFileName, IBLRFileName))
                                {
                                    throw (new Exception("Problem to update the file " + IBLRFileName));
                                }
                                _main.OutMsg(PageType.MergeState, StateDomName + "." + PostalCode + " has been modified.\r\n");
                            }

                            // Delete the temporary BLR Section file.
                            if (File.Exists(OBLRFileName))
                            {
                                File.Delete(OBLRFileName);
                            }

                            SigmaAddedSN = (SigmaAddedSN || AddedSN);

                        }
                        catch (Exception e)
                        {

                            OFileBLRSection.Close();

                            if (_main.isAutoProcess)
                            {
                                errMessage += e.Message + ".\r\n";                               
                            }

                            if (!_main.isAutoProcess && !CheckForCancel)
                            {
                                _main.OutMsg(PageType.MergeState, e.Message + ".\r\n");
                                _main.processFailed = true;
                                
                                //result = MessageBox.Show("Do you want to continue? ", "Stop Process", MessageBoxButtons.YesNo);
                                //if (result == DialogResult.No)
                                _main.dResult = DialogResult.Abort;

                                MessageShow("Do you want to continue? ",
                                       "Merge State", MessageBoxButtons.YesNo, MessageBoxIcon.None);
                                do
                                {
                                } while (_main.dResult == DialogResult.Abort);

                                if (_main.dResult == DialogResult.No)
                                {
                                    //StopProcess();
                                    //SetCancel(true);

                                    IFileBLRSection.Close();
                                    IFileDADomain.Close();
                                    OFileDADomain.Close();
                                    OFileBLRMis.Close();
                                    //OFileBLRSection.Close();

                                    throw (new Exception("Exit"));
                                }
                            }
                        }
                    }
                    else
                    {
                        if (StateDomName != PrecDomName)
                        {
                            OFileBLRMis.WriteLine(IBLRFileName);
                        }
                    }
                }

                PrecDomName = StateDomName;
            }


            IFileDADomain.Close();
            OFileDADomain.Close();
            OFileBLRMis.Close();

            //if (CheckForCancel()) return;

            if (IsDADomainChanged)
            {
                if (!UTIL.FileCopy(DirState + "DADomain.new", DirState + "DADomain.txt"))
                {
                    _main.OutMsg(PageType.MergeState, "Problem to update the file " + DirState + "DADomain.txt.\r\n");
                    throw (new Exception("Problem to update the file " + DirState + "DADomain.txt.\r\n"));
                }
                _main.OutMsg(PageType.MergeState, DirState + "DADomain.txt has been modified.\r\n");
            }
            // Clean-up
            if (File.Exists(DirState + "DADomain.new"))
            {
                File.Delete(DirState + "DADomain.new");
            }

            // Display a status for the user.
            string Message = "The Serial Numbers Checking process is completed.";
            if (SigmaAddedSN)
            {
                Message += "  New Serial Numbers have been added.";
            }
            else
            {
                Message += "  No Serial Numbers have been added.";
            }

            FileInfo fInfo = new FileInfo(FileNameBLRMis);
            if (fInfo.Length > 0)
            {
                Message += "  " + FileNameBLRMis + " has been created due to missing state sections.\r\n";
            }

            //_main.OutMsg(PageType.MergeState, Message + ".\r\n");
            
            Message += "Do you want to continue? ";

            if (!_main.isAutoProcess && !CheckForCancel)
            {
                //result = MessageBox.Show(Message, "Stop Process", MessageBoxButtons.YesNo);
                //if (result == DialogResult.No)
                _main.dResult = DialogResult.Abort;

                MessageShow(Message,
                       "Merge State", MessageBoxButtons.YesNo, MessageBoxIcon.None);
                do
                {
                } while (_main.dResult == DialogResult.Abort);

                if (_main.dResult == DialogResult.No)
                {
                    //StopProcess();
                    //SetCancel(true);
                    throw (new Exception("Exit"));
                }
            }
        }

        void MergeState()
        {
            _main.OutMsg(PageType.MergeState, "Processing the State Sections files for merging.\r\n");
            if (!FullProcess())
            {
                _main.OutMsg(PageType.MergeState, "Syntax checking only option is ON.\r\n");
            }

            if (!CheckForCancel)
            {
                ProcessListState();
            }

            // Read the list of states to process.
            // Do the Merge.
            if (!CheckForCancel)
            {
                DoMerge();

                CloseStream();
            }
            
        }

        //******************************************************************
        private void InitEnv()
        {
            m_ListQuestionMaster.Clear();
            m_ListQuestionToMerge.Clear();
            m_ListSectionMaster.Clear();
            m_ListSectionToMerge.Clear();
            m_TListOneQuestion.Clear();

            m_TAbrModuleName.Clear();
            m_TBLRDomain.Clear();
            m_TDomain.Clear();

            // Open the ISQL file used to do the real merging.
            //m_sMergeSQLFile = _main.toolSheet.GetTempDir() + "\\MergeSt.sql";

            //// Open the output streams.
            //if (File.Exists(m_sMergeSQLFile))
            //{
            //    File.Delete(m_sMergeSQLFile);
            //}

            //try
            //{
            //    //m_OFileMerge = new StreamWriter(m_sMergeSQLFile);
            //    m_OFileMerge = new StreamWriter(m_sMergeSQLFile, false, Encoding.Default);
            //}
            //catch
            //{
            //    throw (new Exception("Error when trying to open the File " + m_sMergeSQLFile));
            //}

            if (FullProcess())
            {
                //_main.OutMsg(PageType.MergeState, "Creation of the file " + m_sMergeSQLFile + ".\r\n");

                //m_OFileMerge.WriteLine("--%MERGEST.SQL: " + DateTime.Now.ToShortDateString() + " - " + 
                //        DateTime.Now.ToShortTimeString() + "\r\n");
                //m_OFileMerge.WriteLine("--%Connection to the database.");
                //m_OFileMerge.WriteLine("START ENGINE AS DB1 STARTLINE 'dbstart -b -c 4096K -ga';");
                //m_OFileMerge.WriteLine("START DATABASE '" + _main.txtMergeStDB.Text + "' AS DB1 ON DB1;");
                //m_OFileMerge.WriteLine("CONNECT TO DB1 DATABASE DB1 AS DB1 USER " +
                //        _main.SybaseUser + " IDENTIFIED BY " + _main.SybasePW + ";");
                //m_OFileMerge.WriteLine();

                //m_OFileMerge.WriteLine("--%Options Settings:");
                //m_OFileMerge.WriteLine("--%   WAIT_FOR_COMMIT = ON  is used to check foreign key integrity only on a COMMIT.");
                //m_OFileMerge.WriteLine("--%   AUTO_COMMIT     = OFF is to prevent doing a COMMIT after each command.");
                //m_OFileMerge.WriteLine("--%    COMMIT_ON_EXIT = ON  is to do an automatic commit on exit ISQL.");
                //m_OFileMerge.WriteLine("SET TEMPORARY OPTION WAIT_FOR_COMMIT = 'ON';");
                //m_OFileMerge.WriteLine("SET TEMPORARY OPTION AUTO_COMMIT     = 'OFF';");
                //m_OFileMerge.WriteLine("SET TEMPORARY OPTION COMMIT_ON_EXIT  = 'ON';");
            }

            // Get the Research Date for this state merging.
            m_sResearchDate = _main.txtMergeSTDate.Text.Trim();
            if (m_sResearchDate == "")
            {
                m_sResearchDate = "0";
            }
            else
            {
                // Get the date with the format yyyymmdd.
                DateTime TmpDate;
                try
                {
                    TmpDate = DateTime.Parse(m_sResearchDate);
                }
                catch
                {
                    throw (new Exception(m_sResearchDate + " is not a valid date."));
                }
                m_sResearchDate = TmpDate.ToString("yyyyMMdd");
            }

            // Find the next StateVersionSN.
            CMStateVersionSet pMStateVersion = new CMStateVersionSet("StateVersion");

            //pMStateVersion.SelectAllDS(); // ORDER BY StateVersionSN. delete on May 31, 2011
            switch (pMStateVersion.FetchLastDS())
            {
                case EnumSQLError.DB_NOERROR:
                    m_iNewStateVersionSN = pMStateVersion.GetStateVersionSN() + 1;
                    break;
                case EnumSQLError.DB_NOTFOUND:
                    m_iNewStateVersionSN = 1;
                    break;
                default:
                    throw (new Exception("Error when trying to access the last StateVersionSN in the Module Database."));
            }
            pMStateVersion.ClearAllFields();

            // Insert the StateVersion Record. 
            if (FullProcess())
            {
                //m_OFileMerge.WriteLine("INSERT INTO StateVersion (StateVersionSN, VersionName) VALUES ("
                //        + m_iNewStateVersionSN + ",'" + _main.txtMergeSTVerName.Text.Trim() + "');");
                //m_OFileMerge.WriteLine();

                string MergeSTVerName = _main.txtMergeSTVerName.Text.Trim();
                if (MergeSTVerName.Length > 25)
                {
                    MergeSTVerName = MergeSTVerName.Substring(0, 25);
                }
                lstMergeSql.Add("INSERT INTO StateVersion (StateVersionSN, VersionName) VALUES ("
                        + m_iNewStateVersionSN + ",'" + MergeSTVerName + "');");

                _main.OutMsg(PageType.MergeState, "The new State Version SN is: " + m_iNewStateVersionSN.ToString() + ".\r\n");
            }

            pMStateVersion = null;
        }
        //***************************************************************************
        private void InitAbrModuleName()
        {
            // Initialize array of abreviate Module Name:
            //   The 2 letters are used in the DADOMAIN.TXT and DOMAIN.TXT files to identify the module related with a DomainSN.
            //   The 2nd argument is the name of the directory containing the DOMAIN.TXT Files.
            //   The number is the serial number of the module in the database.
            // I "hard-coded" this information because it is not supposed to change;
            // else assertion or exception should catch any change.

            string DirModule = _main.txtMergeSTModuleRoot.Text.Trim();;

            if (!DirModule.EndsWith("\\"))
            {
                DirModule += "\\";
            }

            m_TAbrModuleName.Add(new CAbrModuleName("AQ", DirModule + "Air", 11570L));
            m_TAbrModuleName.Add(new CAbrModuleName("WQ", DirModule + "Water", 21156L));
            m_TAbrModuleName.Add(new CAbrModuleName("SH", DirModule + "Waste", 33778L));
            m_TAbrModuleName.Add(new CAbrModuleName("SP", DirModule + "Spill", 50552L));
            m_TAbrModuleName.Add(new CAbrModuleName("ST", DirModule + "Tanks", 60532L));
            m_TAbrModuleName.Add(new CAbrModuleName("PM", DirModule + "PCB", 70636L));
            m_TAbrModuleName.Add(new CAbrModuleName("HM", DirModule + "Trans", 81870L));
            m_TAbrModuleName.Add(new CAbrModuleName("EP", DirModule + "EPCRA", 100422L));
            m_TAbrModuleName.Add(new CAbrModuleName("TS", DirModule + "TSCA", 120332L));
            m_TAbrModuleName.Add(new CAbrModuleName("WS", DirModule + "Worker", 142862L));
            m_TAbrModuleName.Add(new CAbrModuleName("MS", DirModule + "Health", 160514L));
            m_TAbrModuleName.Add(new CAbrModuleName("CP", DirModule + "CPE", 191854L));
            m_TAbrModuleName.Add(new CAbrModuleName("ES", DirModule + "Equip", 222562L));
            m_TAbrModuleName.Add(new CAbrModuleName("CS", DirModule + "Constr", 240000L));
            m_TAbrModuleName.Add(new CAbrModuleName("BO", DirModule + "bayerair", 540000L));
            m_TAbrModuleName.Add(new CAbrModuleName("PS", DirModule + "Pipe", 580000L));
            //m_TAbrModuleName.Add(new CAbrModuleName("KM", DirModule + "Kinder", 620000L));
            m_TAbrModuleName.Add(new CAbrModuleName("PG", DirModule + "PPG", 720000L));
            //m_TAbrModuleName.Add(new CAbrModuleName("WM", DirModule + "WMI", 820000L));
            m_TAbrModuleName.Add(new CAbrModuleName("MK", DirModule + "MKG", 920000L));
            //m_TAbrModuleName.Add(new CAbrModuleName("KR", DirModule + "KMRetail", 1500000L));
            m_TAbrModuleName.Add(new CAbrModuleName("SA", DirModule + "Security", 530000L));

            // Check all the directories are there; and also the Domain.txt ASCII files.
            for (int i = 0; i < m_TAbrModuleName.Count; i++)
            {
                string sDir = m_TAbrModuleName[i].GetDir();
                if (!Directory.Exists(sDir))
                {
                    throw (new Exception(sDir + " does not exist."));
                }

                if (!sDir.EndsWith("\\"))
                {
                    sDir += "\\";
                }

                if (!File.Exists(sDir + "Domain.txt"))
                {
                    throw (new Exception(sDir + "Domain.txt does not exist."));
                }
            }
        }
        //***************************************************************************
        private void InitBLRDomain()
        {
            // Format of BLRTitle.txt is: DOMAIN NAME       DOMAIN TITLE
            //                   Example: ACCUM             Accumulation Time
            //                            AIR               Air (Regulatory Overview)

            string FileName = _main.txtMergeSTSateRoot.Text.Trim();// GetDlgField (this, IDC_DIRSTATE) + "\\BLRTitle.txt";

            if (!FileName.EndsWith(@"\"))
            {
                FileName = FileName + @"\BLRTitle.txt";
            }
            StreamReader IFileBLRDomain = null;
            try
            {
                IFileBLRDomain = new StreamReader(FileName, Encoding.Default);
            }
            catch
            {
                throw (new Exception("Problem to open the file " + FileName));
            }
            _main.OutMsg(PageType.MergeState, "Scanning the file " + FileName + ".\r\n");

            int NumLine = 0;
            string Line, Word1;
            int iPos;
            while ((Line = GetLine(IFileBLRDomain, ref NumLine)) != null)
            {
                // Get the DOMAIN NAME.
                iPos = 0;
                Word1 = GetWord(Line, ref iPos);

                // Get the DOMAIN TITLE.
                Line = Line.Substring(iPos).Trim(new char[]{' '});
                if (Line == "")
                {
                    IFileBLRDomain.Close();

                    throw (new Exception("Domain Title missing in the file " + FileName +
                            " - Line " + NumLine.ToString()));
                }

                // Add an entry in the array.
                m_TBLRDomain.Add(new CBLRDomain(Word1, Line));
            }

            IFileBLRDomain.Close();
        }
        //***************************************************************************
        private void InitDomain()
        {
            //***************************************************************************
            // Format of DOMAIN.TXT is: MARKED  SITE  DOMAIN SN   REG. DOMAIN SN,  REG. PARENT DOMAIN SN,  DOMAIN HEADING
            //                 Example:   M       R   11570       USAQ         ,   SYSTEM               ,  "Air Quality"
            //                                        11573       USAQ:MTBG    ,   USAQ                 ,  "Materials to be..."
            // Initialize array of (REG. DOMAIN SN, Dakota Auditor Domain SN).
            // There is one DOMAIN.TXT file per module directory.

            StreamReader IFileDomain = null;
            long DomainSN = -1;
            int NumLine = 0;
            string FileName = string.Empty;
            string Line = string.Empty, Word1 = string.Empty, Word2 = string.Empty;
            int iPos = 0;

            for (int i = 0; i < m_TAbrModuleName.Count; i++)
            {
                string sDir = m_TAbrModuleName[i].GetDir();

                FileName = Path.Combine(sDir, "Domain.txt");
                try
                {
                    IFileDomain = new StreamReader(FileName, Encoding.Default);
                }
                catch
                {
                    throw (new Exception("Problem to open the file " + FileName));
                }
                _main.OutMsg(PageType.MergeState, "Scanning the file " + FileName + ".\r\n");

                while ((Line = GetLine(IFileDomain, ref NumLine)) != null)
                {
                    // Ignore the first two characters (Marked and SN Site).
                    if (Line.Length >= 2)
                    {
                        Line = Line.Remove(0, 2);
                    }

                    // Get the first Word (should be the DomainSN).
                    iPos = 0;
                    Word1 = GetWord(Line, ref iPos);
                    if (Word1 == "")
                    {
                        IFileDomain.Close();

                        throw (new Exception("Domain SN missing in the file " + FileName +
                                " - Line " + NumLine.ToString()));
                    }

                    DomainSN = long.Parse(Word1);
                    // Ignore the new domains without yet a serial number.
                    if (DomainSN == 0) continue;

                    if (DomainSN < 0)
                    {
                        IFileDomain.Close();

                        throw (new Exception("Domain SN < 0 in the file " + FileName +
                                " - Line " + NumLine.ToString()));
                    }

                    // Get the regulatory Domain SN.
                    Word2 = GetWord(Line, ref iPos, ",");
                    if (Word2 == "")
                    {
                        IFileDomain.Close();

                        throw (new Exception("Domain Name missing in the file " + FileName +
                                " - Line " + NumLine.ToString()));
                    }

                    // Add an entry in the array.  The two last columns in the file are ignored.
                    m_TDomain.Add(new CFederalDomain(Word2, DomainSN));
                }

                IFileDomain.Close();
            }
        }
        //******************************************************************
        private void SortStateSection()
        {
            _main.OutMsg(PageType.MergeState, "Ordering the State Sections.\r\n");

            string sql = "SELECT StateSection.SectionSN FROM State inner join StateSection " +
                    " on State.StateSN=StateSection.StateSN inner JOIN RGSection on StateSection.SectionSN=RGSection.SectionSN " +
                    " GROUP BY StateSection.SectionSN ORDER BY MAX(StateName), MAX(Heading)";

            DataSet ds = sqlbase.GetDataSet(sql);
            if (UTIL.CheckDataSet(ds))
            {
                long h_lSequence = 1000000000L;

                List<string> sectionSNs = new List<string>();

                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    h_lSequence++;
                    sql = "UPDATE RGSection SET Sequence = " +
                            h_lSequence.ToString() + " WHERE SectionSN = " + row[0].ToString().Trim();

                    sectionSNs.Add(sql);
                    if (CheckForCancel)
                    { 
                        return; 
                    }
                }

                sqlbase.RunSQL(sectionSNs.ToArray(), true);
            }
        }

        //****************************************************************************
        private void ProcessListState()
        {
            // First, find the next available StateSN.
            short NextStateSN = 0;

            CMStateSet pMState = new CMStateSet("State");

            //pMState.SelectAll();    // Order by State Name.

            while (pMState.FetchNextDS()!=EnumSQLError.DB_NOTFOUND)
            {
                NextStateSN = Math.Max(pMState.GetStateSN(), NextStateSN);
            }
            NextStateSN++;
            pMState.ClearAllFields();

            string PostalCode = string.Empty;
            string StateName = string.Empty;

            CMStateSectionSet MStateSection = new CMStateSectionSet("StateSection");
            CMQDStateLinkSet MQDStateLink = new CMQDStateLinkSet("QDLinkState");

            for (int i = 0; i < _main.lstMergeSTStates.Items.Count; i++)
            {
                if (CheckForCancel) break;

                // Get the current state to merge.
                //_main.lstMergeSTStates.SetSelected(i, true);
                //_main.lstMergeSTStates.SelectedIndex = i;
                PostalCode = _main.lstMergeSTStates.Items[i].ToString();


                // Get the STATE NAME.
                //***MJC There may be some other way to do that (by reading in an ASCII file for example).
                while (true)
                {
                    StateName = "";

                    if (PostalCode == "AL") { StateName = "Alabama"; break; }
                    if (PostalCode == "AK") { StateName = "Alaska"; break; }
                    if (PostalCode == "AR") { StateName = "Arkansas"; break; }
                    if (PostalCode == "AZ") { StateName = "Arizona"; break; }
                    if (PostalCode == "CA") { StateName = "California"; break; }
                    if (PostalCode == "CO") { StateName = "Colorado"; break; }
                    if (PostalCode == "CT") { StateName = "Connecticut"; break; }
                    if (PostalCode == "DE") { StateName = "Delaware"; break; }
                    if (PostalCode == "DC") { StateName = "District of Columbia"; break; }
                    if (PostalCode == "FL") { StateName = "Florida"; break; }
                    if (PostalCode == "GA") { StateName = "Georgia"; break; }
                    if (PostalCode == "HI") { StateName = "Hawaii"; break; }
                    if (PostalCode == "IA") { StateName = "Iowa"; break; }
                    if (PostalCode == "ID") { StateName = "Idaho"; break; }
                    if (PostalCode == "IL") { StateName = "Illinois"; break; }
                    if (PostalCode == "IN") { StateName = "Indiana"; break; }
                    if (PostalCode == "KS") { StateName = "Kansas"; break; }
                    if (PostalCode == "KY") { StateName = "Kentucky"; break; }
                    if (PostalCode == "LA") { StateName = "Louisiana"; break; }
                    if (PostalCode == "MA") { StateName = "Massachusetts"; break; }
                    if (PostalCode == "MD") { StateName = "Maryland"; break; }
                    if (PostalCode == "ME") { StateName = "Maine"; break; }
                    if (PostalCode == "MI") { StateName = "Michigan"; break; }
                    if (PostalCode == "MN") { StateName = "Minnesota"; break; }
                    if (PostalCode == "MO") { StateName = "Missouri"; break; }
                    if (PostalCode == "MS") { StateName = "Mississippi"; break; }
                    if (PostalCode == "MT") { StateName = "Montana"; break; }
                    if (PostalCode == "NC") { StateName = "North Carolina"; break; }
                    if (PostalCode == "ND") { StateName = "North Dakota"; break; }
                    if (PostalCode == "NE") { StateName = "Nebraska"; break; }
                    if (PostalCode == "NH") { StateName = "New Hampshire"; break; }
                    if (PostalCode == "NJ") { StateName = "New Jersey"; break; }
                    if (PostalCode == "NM") { StateName = "New Mexico"; break; }
                    if (PostalCode == "NV") { StateName = "Nevada"; break; }
                    if (PostalCode == "NY") { StateName = "New York"; break; }
                    if (PostalCode == "OH") { StateName = "Ohio"; break; }
                    if (PostalCode == "OK") { StateName = "Oklahoma"; break; }
                    if (PostalCode == "OR") { StateName = "Oregon"; break; }
                    if (PostalCode == "PA") { StateName = "Pennsylvania"; break; }
                    if (PostalCode == "PR") { StateName = "Puerto Rico"; break; }
                    if (PostalCode == "RI") { StateName = "Rhode Island"; break; }
                    if (PostalCode == "SC") { StateName = "South Carolina"; break; }
                    if (PostalCode == "SD") { StateName = "South Dakota"; break; }
                    if (PostalCode == "TN") { StateName = "Tennessee"; break; }
                    if (PostalCode == "TX") { StateName = "Texas"; break; }
                    if (PostalCode == "UT") { StateName = "Utah"; break; }
                    if (PostalCode == "VA") { StateName = "Virginia"; break; }
                    if (PostalCode == "VT") { StateName = "Vermont"; break; }
                    if (PostalCode == "WA") { StateName = "Washington"; break; }
                    if (PostalCode == "WI") { StateName = "Wisconsin"; break; }
                    if (PostalCode == "WV") { StateName = "West Virginia"; break; }
                    if (PostalCode == "WY") { StateName = "Wyoming"; break; }

                    throw (new Exception(PostalCode + " is not a valid Postal Code"));
                }

                bool IsNew;
                int StateSN;
                if (pMState.SelectForPostalCode(PostalCode) == EnumSQLError.DB_NOERROR)
                {
                    _main.OutMsg(PageType.MergeState, "Reading the previous version data from the database for " +
                                        StateName + " (existing state).\r\n");

                    // Existing State.
                    IsNew = false;

                    StateSN = pMState.GetStateSN();

                    if (FullProcess())
                    {
                        //m_OFileMerge.WriteLine("--%Delete the informations related with " + StateName
                        //             + " and which are StateVersionSN independent");
                        //m_OFileMerge.WriteLine("DELETE FROM RGSection WHERE EXISTS (SELECT * FROM StateSection WHERE StateSN = "
                        //             + StateSN + " AND StateSection.SectionSN = RGSection.SectionSN);");
                        //m_OFileMerge.WriteLine("DELETE FROM BlobState WHERE StateSN = " + StateSN + " AND Class = 1;");

                        lstMergeSql.Add("DELETE FROM RGSection WHERE EXISTS (SELECT * FROM StateSection WHERE StateSN = "
                                     + StateSN + " AND StateSection.SectionSN = RGSection.SectionSN);");
                        lstMergeSql.Add("DELETE FROM BlobState WHERE StateSN = " + StateSN + " AND Class = 1;");

                        //m_OFileMerge.WriteLine();
                    }

                    // Get the list of questions related with the last version available for this state.
                    MQDStateLink.SelectForStateDesc(StateSN);        // ORDER BY StateVersionSN.

                    int LastVersionSN = 0;

                    while (MQDStateLink.FetchNext() != EnumSQLError.DB_NOTFOUND)
                    {
                        LastVersionSN = MQDStateLink.GetStateVersionSN();// reader.GetInt16(3);
                        break;
                    }
                    MQDStateLink.ClearAllFields();

                   
                    if (LastVersionSN != 0)
                    {
                        MQDStateLink.SelectForStateAndVersion(StateSN, LastVersionSN);

                        while (MQDStateLink.FetchNext() != EnumSQLError.DB_NOTFOUND)
                        {
                            try
                            {
                                m_ListQuestionMaster.Add(MQDStateLink.GetQuestionSN());// MQDStateLink.GetQuestionSN());
                            }
                            catch
                            {
                                break;
                            }
                        }

                        MQDStateLink.ClearAllFields();

                        // Get the list of sections related with this state + LastVersionSN..
                        MStateSection.SelectForStateAndVersion(StateSN, LastVersionSN);
                        while (MStateSection.FetchNext() != EnumSQLError.DB_NOTFOUND)
                        {
                            try
                            {
                                m_ListSectionMaster.Add(MStateSection.GetSectionSN());// MQDStateLink.GetQuestionSN());
                            }
                            catch
                            {
                                break;
                            }
                        }
                        MStateSection.ClearAllFields();
                    }
                    MQDStateLink.ClearAllFields();
                }
                else
                {
                    // New State.
                    IsNew = true;

                    //m_pReport.Insert ("First Time Merging for " + StateName + ".\r\n");
                    _main.OutMsg(PageType.MergeState, "First Time Merging for " + StateName + ".\r\n");
                    StateSN = NextStateSN;
                    NextStateSN++;

                    if (FullProcess())
                    {

                        //m_OFileMerge.WriteLine("INSERT INTO State (StateSN, StateName, PostalCode, MasterModuleID, MasterGroupID, "
                        //             + "MasterClassID) VALUES (" + StateSN + ",'" + StateName + "','" + PostalCode + "',0,1,5);");

                        lstMergeSql.Add("INSERT INTO State (StateSN, StateName, PostalCode, MasterModuleID, MasterGroupID, "
                                + "MasterClassID) VALUES (" + StateSN + ",'" + StateName + "','" + PostalCode + "',0,1,5);");
                    }
                }

                m_ListState.Add(new CState(PostalCode, StateName, StateSN, IsNew));
            }

            //m_OFileMerge.WriteLine();

            //pMState.ClearAllFields();
        }

        void DoMerge()
        {
            // The method is to read the regulatory files, analyze them and write ASCII files in the Temporary directory.
            // These files will be imported in a second step in the master MODULE database.

            // Database objects.
            CMModuleVersionSet pMModuleVersion = new CMModuleVersionSet("ModuleVersion");
            CMQuestionBodySet pMQuestionBody = new CMQuestionBodySet("QuestionBody");
            CMRGKeyWordSetModule pMRGKeyWord = new CMRGKeyWordSetModule("RGKeyWord");

            // Used when doing Search on the Run-Time structure.
            CAbrModuleName pFindAbrModuleName = new CAbrModuleName();
            CFederalDomain pFindFederalDomain = new CFederalDomain();
            CBLRDomain pFindBLRDomain = new CBLRDomain();

            // OUTPUT FILES.
            string FileName;
            string TempDir = _main.toolSheet.TempDir + "\\";
            FileName = TempDir + "SDVLink.txt";
            if (File.Exists(FileName))
            {
                File.Delete(FileName);
            }

            try
            {
                m_OFileSDVLink = new StreamWriter(FileName, false, Encoding.Default);
            }
            catch
            {
                throw (new Exception("Problem to open a temporary file"));
            }
            FileName = TempDir + "StateStr.txt";
            if (File.Exists(FileName))
            {
                File.Delete(FileName);
            }
            try
            {
                m_OFileStateStr = new StreamWriter(FileName, false, Encoding.Default);
            }
            catch
            {
                throw (new Exception("Problem to open a temporary file"));
            }
            FileName = TempDir + "QCountSt.txt";
            if (File.Exists(FileName))
            {
                File.Delete(FileName);
            }
            try
            {
                m_OFileQCountSt = new StreamWriter(FileName, false, Encoding.Default);
            }
            catch
            {
                throw (new Exception("Problem to open a temporary file"));
            }
            FileName = TempDir + "QDState.txt";
            if (File.Exists(FileName))
            {
                File.Delete(FileName);
            }
            try
            {
                m_OFileQDState = new StreamWriter(FileName, false, Encoding.Default);
            }
            catch
            {
                throw (new Exception("Problem to open a temporary file"));
            }
            FileName = TempDir + "StateSec.txt";
            if (File.Exists(FileName))
            {
                File.Delete(FileName);
            }
            try
            {
                m_OFileStateSect = new StreamWriter(FileName, false, Encoding.Default);
            }
            catch
            {
                throw (new Exception("Problem to open a temporary file"));
            }
            FileName = TempDir + "StQuest.txt";
            if (File.Exists(FileName))
            {
                File.Delete(FileName);
            }
            try
            {
                m_OFileQuestion = new StreamWriter(FileName, false, Encoding.Default);
            }
            catch
            {
                throw (new Exception("Problem to open a temporary file"));
            }
            FileName = TempDir + "StQuestB.txt";
            if (File.Exists(FileName))
            {
                File.Delete(FileName);
            }
            try
            {
                m_OFileQuestionB = new StreamWriter(FileName, false, Encoding.Default);
            }
            catch
            {
                throw (new Exception("Problem to open a temporary file"));
            }
            FileName = TempDir + "StRGSect.txt";
            if (File.Exists(FileName))
            {
                File.Delete(FileName);
            }
            try
            {
                m_OFileRGSection = new StreamWriter(FileName, false, Encoding.Default);
            }
            catch
            {
                throw (new Exception("Problem to open a temporary file"));
            }
            FileName = TempDir + "StQRLink.txt";
            if (File.Exists(FileName))
            {
                File.Delete(FileName);
            }
            try
            {
                m_OFileQRLink = new StreamWriter(FileName, false, Encoding.Default);
            }
            catch
            {
                throw (new Exception("Problem to open a temporary file"));
            }
            FileName = TempDir + "StRGKeyW.txt";
            if (File.Exists(FileName))
            {
                File.Delete(FileName);
            }
            try
            {
                m_OFileRGKeyWord = new StreamWriter(FileName, false, Encoding.Default);
            }
            catch
            {
                throw (new Exception("Problem to open a temporary file"));
            }

            // INPUT FILE.
            string FileNameDADomain = Path.Combine(_main.txtMergeSTSateRoot.Text, "DADomain.txt");

            StreamReader IFileDADomain = null;
            try
            {
                IFileDADomain = new StreamReader(FileNameDADomain, Encoding.Default);
            }
            catch
            {
                throw (new Exception("Problem to open the file " + FileNameDADomain));
            }

            //***************************************************************************
            // Get the serial numbers for the new question body and references to add.
            long PrevQuestionBodySN = -1;
            pMQuestionBody.SelectAllDesc();
            if (pMQuestionBody.FetchNext() != EnumSQLError.DB_NOTFOUND)
            {
                m_lQuestionBodySN = pMQuestionBody.GetQuestionBodySN();
            }
            pMQuestionBody.ClearAllFields();

            m_lQuestionBodySN = (m_lQuestionBodySN > 1000000000 ? m_lQuestionBodySN : 1000000000);// max (m_lQuestionBodySN, 1000000000L);
            PrevQuestionBodySN = m_lQuestionBodySN;

            pMRGKeyWord.SelectAllDesc(); //Sep 11, 2009
            if (pMRGKeyWord.FetchNext() == EnumSQLError.DB_NOERROR)
            {
                m_lReferenceSN = pMRGKeyWord.GetReferenceSN();
            }
            pMRGKeyWord.ClearAllFields();
            m_lReferenceSN = (m_lReferenceSN > 1000000000 ? m_lReferenceSN : 1000000000);// max (m_lReferenceSN, 1000000000L);

            //***************************************************************************
            int NumLine = 0;
            string Line, Word1;
            string StateDomName;
            string StatePrecDomName = "";
            string ParentName;
            long StateDomainSN;
            int ModuleVersionSN;

            while (((Line = GetLine(IFileDADomain, ref NumLine)) != null))
            {
                // This file has 4 columns: STATE DOMAINSN  STATE DOMAIN NAME  REG. PARENT DOMAINSN  PARENT DOMAIN HEADING
                //                 Example: 960800001       ACCUM              USSH:D.OSA            "On-site Accumulation"
                //                          960800002       ACCUM              USSH:E.OSA            "On-site Accumulation"
                //                          960800003       AIR                USAQ                  "Air Quality"
                try
                {
                    int iPos = 0;
                    Word1 = GetWord(Line, ref iPos);
                    StateDomainSN = 0;
                    try
                    {
                        StateDomainSN = long.Parse(Word1);
                    }
                    catch
                    {
                    }

                    if (StateDomainSN <= 0)
                    {
                        //throw (new Exception("State Domain SN <= 0 in the file " + FileNameDADomain + " - Line " + NumLine.ToString()));

                        ErrorThrow("State Domain SN <= 0 in the file " + FileNameDADomain + " - Line " + NumLine.ToString());
                        continue;
                    }

                    StateDomName = GetWord(Line, ref iPos);
                    if (StateDomName == "")
                    {
                        //throw (new Exception("State Domain Name missing in the file " + FileNameDADomain + " - Line " +
                        //             NumLine.ToString()));

                        ErrorThrow("State Domain Name missing in the file " + FileNameDADomain + " - Line " +
                                     NumLine.ToString());
                        continue;
                    }

                    ParentName = GetWord(Line, ref iPos);
                    if (ParentName == "")
                    {
                        //throw (new Exception("State Parent Domain Name missing in the file " + FileNameDADomain + " - Line " +
                        //             NumLine.ToString()));
                        ErrorThrow("State Parent Domain Name missing in the file " + FileNameDADomain + " - Line " +
                                     NumLine.ToString());
                        continue;
                    }
                    // We ignore the Parent Heading.

                    //***************************************************************************
                    // Find the Module where this state domain belongs (or its parent).
                    // The third and fourth letters of the ParentName is the Module.
                    pFindAbrModuleName.AbrName = ParentName.Substring(2, 2);//.PutAbrName(ParentName.Substring(2, 2));
                    _cabrModuleName = pFindAbrModuleName;
                    _cabrModuleName = m_TAbrModuleName.Find(matchCAbrModuleName);
                    try
                    {
                        _cabrModuleName.GetType();
                    }
                    catch
                    {
                        //throw (new Exception("Module unknown in " + FileNameDADomain + " - Line " + NumLine.ToString()));
                        ErrorThrow("Module unknown in " + FileNameDADomain + " - Line " + NumLine.ToString());
                        continue;
                    }
                    m_lModuleSN = _cabrModuleName.ModuleSN;//.GetModuleSN();

                    // Get the last Version for the Module (the state is always plugged in the last ModuleVersion).
                    pMModuleVersion.SelectForModuleDS(m_lModuleSN);

                    if (pMModuleVersion.FetchLastDS() == EnumSQLError.DB_NOTFOUND)
                    {
                        //throw (new Exception("No ModuleVersionSN exists for " + m_lModuleSN.ToString()));

                        ErrorThrow("No ModuleVersionSN exists for " + m_lModuleSN.ToString());
                        continue;
                    }
                    ModuleVersionSN = pMModuleVersion.GetModuleVersionSN();


                    //***************************************************************************
                    // Find the Parent Domain.
                    pFindFederalDomain.PutRegulName(ParentName);

                    _cfederalDomain = pFindFederalDomain;
                    _cfederalDomain = m_TDomain.Find(matchCFederalDomain);
                    try
                    {
                        _cfederalDomain.GetType();
                    }
                    catch
                    {
                        //throw (new Exception("Parent Domain not found in " + FileNameDADomain + " - Line " + NumLine.ToString()));

                        ErrorThrow("Parent Domain not found in " + FileNameDADomain + " - Line " + NumLine.ToString());
                        continue;
                    }
                    long ParentSN = _cfederalDomain.GetDomainSN();
                    int Order = _cfederalDomain.GetNextOrder();   // A Parent can have several states domains.

                    //***************************************************************************
                    // Add the State domain in the StateDomainStructure.
                    pFindBLRDomain.PutBLRName(StateDomName);
                    _cblrDomain = pFindBLRDomain;
                    _cblrDomain = m_TBLRDomain.Find(matchCBLRDomain);
                    try
                    {
                        _cblrDomain.GetType();
                    }
                    catch
                    {
                        //throw (new Exception("BLR Domain unknown in " + FileNameDADomain + " - Line " + NumLine.ToString()));

                        ErrorThrow("BLR Domain unknown in " + FileNameDADomain + " - Line " + NumLine.ToString());
                        continue;
                    }
                    m_OFileStateStr.WriteLine(m_iNewStateVersionSN + "," + StateDomainSN + "," + m_lModuleSN + ","
                                    + ModuleVersionSN + "," + Order + "," + ParentSN + ",'"
                                    + FormatToExport(_cblrDomain.GetBLRTitle()) + "'");
                    m_OFileSDVLink.WriteLine(m_iNewStateVersionSN + "," + StateDomainSN);

                    //***************************************************************************
                    // Now, read the BLR Section related with this state domain.
                    string StateTitle = _cblrDomain.GetBLRTitle();

                    // Read the section only once for each BLR domain (even if this state domain is plugged several times).
                    m_bFirstOccurence = (StateDomName != StatePrecDomName);
                    if (m_bFirstOccurence == false)
                    {
                        // The BLR Domain is the same as the previous one; so rollback the QuestionBodySN counter.
                        m_lQuestionBodySN = PrevQuestionBodySN;

                        // Rollback also the index for the "See Table n" links.
                        for (int iState = 0; iState < m_ListState.Count; iState++)
                        {
                            m_ListState[iState].CopyPreviousToCurrent();
                        }
                    }
                    PrevQuestionBodySN = m_lQuestionBodySN;

                    if (m_bFirstOccurence || FullProcess())
                    {
                        int StateSN;
                        string PostalCode;
                        string DirState = _main.txtMergeSTSateRoot.Text.Trim();

                        if (!DirState.EndsWith(@"\"))
                        {
                            DirState += @"\";
                        }

                        for (int iState = 0; iState < m_ListState.Count; iState++)
                        {
                            //if (CheckForCancel()) break;

                            m_pCState = m_ListState[iState];
                            m_pCState.CopyCurrentToPrevious();
                            StateSN = m_pCState.GetStateSN();
                            PostalCode = m_pCState.GetPostalCode();
                            m_sFileName = DirState + PostalCode + "\\" + StateDomName + "." + PostalCode;

                            if (File.Exists(m_sFileName))
                            {
                                // This BLR Domain is defined for this state.
                                StreamReader IFileBLRSection = null;
                                try
                                {
                                    IFileBLRSection = new StreamReader(m_sFileName, Encoding.Default);
                                }
                                catch
                                {
                                    //throw (new Exception("Error trying to open " + m_sFileName));

                                    ErrorThrow("Error trying to open " + m_sFileName);
                                    continue;
                                }

                                if (m_bFirstOccurence)
                                {
                                    _main.OutMsg(PageType.MergeState, StateDomName + "." + PostalCode + "\r\n");
                                }

                                //if (StateDomName == "ABOVE" && PostalCode == "PA")
                                //{
                                //    string s = "";
                                //}

                                try
                                {
                                    ReadBLRSection(IFileBLRSection, StateSN, StateDomainSN, StateTitle, ParentName);
                                }
                                catch (Exception e)
                                {

                                    if (StateDomName != StatePrecDomName)
                                    {
                                        string Message = e.Message;

                                        if (!_main.isAutoProcess)
                                        {
                                            _main.OutMsg(PageType.MergeState, e.Message + ".\r\n");
                                            _main.processFailed = true;
                                            
                                            _main.dResult = DialogResult.Abort;

                                            Message += ".\r\nDo you want to continue? ";
                                            MessageShow(Message,
                                                   "Merge State", MessageBoxButtons.YesNo, MessageBoxIcon.None);
                                            do
                                            {
                                            } while (_main.dResult == DialogResult.Abort);

                                            if (_main.dResult == DialogResult.No)
                                            {
                                                throw (new Exception(Message));
                                            }
                                        }
                                        else
                                        {
                                            errMessage += e.Message + ".\r\n";
                                            //throw (new Exception(Message));
                                        }
                                    }
                                }
                                IFileBLRSection.Close();
                            }
                        }
                    }

                    StatePrecDomName = StateDomName;
                }
                catch
                {                    
                    break;
                }
            }

            m_OFileSDVLink.Close();
            m_OFileStateStr.Close();
            m_OFileQCountSt.Close();
            m_OFileQDState.Close();
            m_OFileStateSect.Close();
            m_OFileQuestion.Close();
            m_OFileQuestionB.Close();
            m_OFileRGSection.Close();
            m_OFileQRLink.Close();
            m_OFileRGKeyWord.Close();

            if (_main.processFailed) return;

            if (!FullProcess()) return;
            //if (CheckForCancel()) return;

            //***************************************************************************
            // Because we have deleted existing question from the database (see CheckQuestionInDatabase() method), we need to
            // keep in sync. RGKeyWord and QuestionBody tables before doing the imports.
            // We know that the RGKeyWord for states (above 1000000000) must have a QRLink related.
            //m_OFileMerge.WriteLine("DELETE FROM RGKeyWord WHERE ReferenceSN >= 1000000000 AND NOT EXISTS (SELECT * FROM QRLink"
            //          + " WHERE QRLink.ReferenceSN = RGKeyWord.ReferenceSN);");
            //m_OFileMerge.WriteLine("DELETE FROM QuestionBody WHERE NOT EXISTS (SELECT * FROM Question" +
            //             " WHERE Question.QuestionBodySN = QuestionBody.QuestionBodySN);");

            lstMergeSql.Add("DELETE FROM RGKeyWord WHERE ReferenceSN >= 1000000000 AND NOT EXISTS (SELECT * FROM QRLink"
                    + " WHERE QRLink.ReferenceSN = RGKeyWord.ReferenceSN);");
            lstMergeSql.Add("DELETE FROM QuestionBody WHERE NOT EXISTS (SELECT * FROM Question"
                    + " WHERE Question.QuestionBodySN = QuestionBody.QuestionBodySN);");
            //***************************************************************************
            _main.OutMsg(PageType.MergeState, "Identifying the retired questions" + Environment.NewLine);

            // Variable declaration.
            string ListRef;
            long h_lQuestionSN;


            CMRGKeyWordSetQuestion MRGKeyWord = new CMRGKeyWordSetQuestion("RGKeyWord");

            // Go through the list of questionSN in the Master Module database and compare it with the new list of QuestionSN.
            int iCount = 0;
            int jCount2 = 0;
            long QuestionSN;

            m_ListQuestionMaster.Sort();

            List<string> _SQLs = new List<string>();
            foreach (long sn in m_ListQuestionMaster)
            {
                QuestionSN = sn;

                //if (m_ListQuestionToMerge.Find(QuestionSN) == null)
                if (!UTIL.ListLongFind(m_ListQuestionToMerge, QuestionSN))
                {
                    // Retired Question.
                    iCount++;
                    if ((iCount % 100) == 0)
                    {
                        _main.OutMsg(PageType.MergeState, ".");
                        jCount2++;

                        if (jCount2 > 170)
                        {
                            jCount2 = 0;
                            _main.OutMsg(PageType.MergeState, Environment.NewLine);

                        }
                    }

                    //m_OFileMerge.WriteLine("DELETE FROM QRLINK WHERE QuestionSN = " + QuestionSN + ";");
                    lstMergeSql.Add("DELETE FROM QRLINK WHERE QuestionSN = " + QuestionSN + ";");
                    // Update the RGKeyWordList based on the table QRLink.
                    ListRef = "";

                    //Modified on Apr 4, 2012 ordered by SEQUENCE
                    //MRGKeyWord.SelectForQuestionDS(QuestionSN);
                    MRGKeyWord.BeginQueryDS(null, "QuestionSN = " + QuestionSN.ToString(), "SEQUENCE asc");

                    while (MRGKeyWord.FetchNextDS() == EnumSQLError.DB_NOERROR)
                    {
                        if (ListRef != "") 
                            ListRef += SEP_LISTREF;

                        ListRef += MRGKeyWord.GetKeyWord().Trim(new char[]{' '});
                    }

                    if (ListRef != "")
                    {
                        h_lQuestionSN = QuestionSN;
                        ListRef = ListRef.Replace("'", "''");
                        string __SQLV_pgmerges_8 = "UPDATE Question SET RGKeyWordList = '" +
                                ListRef + "' WHERE QuestionSN = " + h_lQuestionSN.ToString();

                        _SQLs.Add(__SQLV_pgmerges_8);

                    }
                }
            }
            MRGKeyWord.ClearAllFields();
            if (_SQLs.Count > 0)
            {
               string ret=sqlbase.RunSQL(_SQLs.ToArray(), true);
               if (ret != "")
               {
                   transaction.Rollback();
                   ErrorThrow(ret);

                   return;
               }

            }

            //m_OFileMerge.WriteLine("CLEAR;");
            //m_OFileMerge.WriteLine();

            //if (CheckForCancel()) return;

            _main.OutMsg(PageType.MergeState, "" + iCount.ToString() + " retired questions.\r\n");
            //***************************************************************************
            _main.OutMsg(PageType.MergeState, "Identifying the retired sections" + Environment.NewLine);
            // Go through the list of SectionSN in the Master Module database and compare it with the new list of SectionSN.
            long SectionSN;
            iCount = 0;
            jCount2 = 0;
            m_ListSectionMaster.Sort();
            foreach (long sn in m_ListSectionMaster)
            {

                SectionSN = sn;// go2.Current();
                if (!UTIL.ListLongFind(m_ListSectionToMerge, SectionSN))
                {
                    // Retired Section
                    iCount++;
                    if ((iCount % 10) == 0)
                    {
                        _main.OutMsg(PageType.MergeState, ".");
                        jCount2++;

                        if (jCount2 > 170)
                        {
                            jCount2 = 0;
                            _main.OutMsg(PageType.MergeState, Environment.NewLine);

                        }
                    }
                    //m_OFileMerge.WriteLine("DELETE FROM StateSection WHERE SectionSN = " + SectionSN + ";");
                    lstMergeSql.Add("DELETE FROM StateSection WHERE SectionSN = " + SectionSN + ";");
                }
            }
            //m_OFileMerge.WriteLine();

            // Clear the ISQL Windows, every once in a while (else, ISQL freezes).
            //m_OFileMerge.WriteLine("CLEAR;");

            //if (CheckForCancel()) return;

            _main.OutMsg(PageType.MergeState, "" + iCount.ToString() + " retired sections.\r\n");

            //***************************************************************************
            // Import the newly created ASCII files in the Master Module Database.
            // TempDir has been defined above (during opening of the export files).
            //m_OFileMerge.WriteLine("INPUT INTO StateDomainStructure  FROM '" + TempDir + "StateStr.txt' FORMAT ASCII"
            //          + " (StateVersionSN, StateDomainSN, ModuleSN, ModuleVersionSN, ChildOrder, ParentSN, Heading);");
            //m_OFileMerge.WriteLine("INPUT INTO SDVLink               FROM '" + TempDir + "SDVLink.txt'  FORMAT ASCII"
            //          + " (StateVersionSN, StateDomainSN);");
            //m_OFileMerge.WriteLine("INPUT INTO QCountState           FROM '" + TempDir + "QCountSt.txt' FORMAT ASCII"
            //          + " (StateSN, StateVersionSN, StateDomainSN, QCount);");
            //m_OFileMerge.WriteLine("INPUT INTO QDStateLink           FROM '" + TempDir + "QDState.txt'  FORMAT ASCII"
            //          + " (StateSN, StateVersionSN, StateDomainSN, QDOrder, QuestionSN);");
            //m_OFileMerge.WriteLine("INPUT INTO StateSection          FROM '" + TempDir + "StateSec.txt' FORMAT ASCII"
            //          + " (StateDomainSN, StateSN, SectionSN, StateVersionSN);");
            //m_OFileMerge.WriteLine("INPUT INTO RGKeyWord             FROM '" + TempDir + "StRGKeyW.txt' FORMAT ASCII"
            //          + " (ReferenceSN, KeyWord, SectionSN, PStart, ModuleSN);");
            //m_OFileMerge.WriteLine("INPUT INTO QRLink                FROM '" + TempDir + "StQRLink.txt' FORMAT ASCII"
            //          + " (QuestionSN, Sequence, ReferenceSN);");
            //m_OFileMerge.WriteLine("INPUT INTO QuestionBody          FROM '" + TempDir + "StQuestB.txt' FORMAT ASCII"
            //          + " (QuestionBodySN, StdText, ListAnswer, NoteText, DataType, Properties);");
            //m_OFileMerge.WriteLine("INPUT INTO Question              FROM '" + TempDir + "StQuest.txt'  FORMAT ASCII"
            //          + " (QuestionSN, QuestionBodySN, RFValue);");
            //m_OFileMerge.WriteLine("INPUT INTO RGSection             FROM '" + TempDir + "StRGSect.txt' FORMAT ASCII"
            //          + " (SectionSN, ModuleSN, Heading, TextBlock);");

            lstMergeSql.Add("LOADDATA,StateDomainStructure," + TempDir + "StateStr.txt");
            lstMergeSql.Add("LOADDATA,SDVLink," + TempDir + "SDVLink.txt");
            lstMergeSql.Add("LOADDATA,QCountState," + TempDir + "QCountSt.txt");
            lstMergeSql.Add("LOADDATA,QuestionBody," + TempDir + "StQuestB.txt");
            lstMergeSql.Add("LOADDATA,Question," + TempDir + "StQuest.txt");
            lstMergeSql.Add("LOADDATA,QDStateLink," + TempDir + "QDState.txt");
            lstMergeSql.Add("LOADDATA,RGSection," + TempDir + "StRGSect.txt");
            lstMergeSql.Add("LOADDATA,StateSection," + TempDir + "StateSec.txt");
            lstMergeSql.Add("LOADDATA,RGKeyWord," + TempDir + "StRGKeyW.txt");
            lstMergeSql.Add("LOADDATA,QRLink," + TempDir + "StQRLink.txt");

            //m_OFileMerge.WriteLine();
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10001 WHERE PostalCode = 'NY';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10002 WHERE PostalCode = 'NJ';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10003 WHERE PostalCode = 'CA';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10004 WHERE PostalCode = 'TX';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10005 WHERE PostalCode = 'IL';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10006 WHERE PostalCode = 'OH';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10007 WHERE PostalCode = 'CT';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10008 WHERE PostalCode = 'PA';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10009 WHERE PostalCode = 'FL';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10010 WHERE PostalCode = 'GA';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10011 WHERE PostalCode = 'LA';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10012 WHERE PostalCode = 'VA';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10013 WHERE PostalCode = 'TN';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10014 WHERE PostalCode = 'MD';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10015 WHERE PostalCode = 'MN';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10016 WHERE PostalCode = 'NC';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10017 WHERE PostalCode = 'MI';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10018 WHERE PostalCode = 'IN';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10019 WHERE PostalCode = 'AL';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10020 WHERE PostalCode = 'AK';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10021 WHERE PostalCode = 'AR';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10022 WHERE PostalCode = 'AZ';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10023 WHERE PostalCode = 'CO';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10024 WHERE PostalCode = 'DE';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10025 WHERE PostalCode = 'DC';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10026 WHERE PostalCode = 'HI';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10027 WHERE PostalCode = 'IA';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10028 WHERE PostalCode = 'ID';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10029 WHERE PostalCode = 'KS';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10030 WHERE PostalCode = 'KY';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10031 WHERE PostalCode = 'MA';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10032 WHERE PostalCode = 'ME';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10033 WHERE PostalCode = 'MO';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10034 WHERE PostalCode = 'MS';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10035 WHERE PostalCode = 'MT';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10036 WHERE PostalCode = 'ND';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10037 WHERE PostalCode = 'NE';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10038 WHERE PostalCode = 'NH';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10039 WHERE PostalCode = 'NM';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10050 WHERE PostalCode = 'NV';");//fixed from 1040
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10041 WHERE PostalCode = 'OK';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10042 WHERE PostalCode = 'OR';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10043 WHERE PostalCode = 'PR';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10044 WHERE PostalCode = 'RI';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10045 WHERE PostalCode = 'SC';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10046 WHERE PostalCode = 'SD';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10047 WHERE PostalCode = 'UT';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10048 WHERE PostalCode = 'VT';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10049 WHERE PostalCode = 'WA';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10040 WHERE PostalCode = 'WI';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10051 WHERE PostalCode = 'WV';");
            //m_OFileMerge.WriteLine("UPDATE state SET MasterModuleID = 10052 WHERE PostalCode = 'WY';");
            //m_OFileMerge.WriteLine();

            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10001 WHERE PostalCode = 'NY';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10002 WHERE PostalCode = 'NJ';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10003 WHERE PostalCode = 'CA';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10004 WHERE PostalCode = 'TX';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10005 WHERE PostalCode = 'IL';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10006 WHERE PostalCode = 'OH';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10007 WHERE PostalCode = 'CT';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10008 WHERE PostalCode = 'PA';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10009 WHERE PostalCode = 'FL';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10010 WHERE PostalCode = 'GA';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10011 WHERE PostalCode = 'LA';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10012 WHERE PostalCode = 'VA';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10013 WHERE PostalCode = 'TN';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10014 WHERE PostalCode = 'MD';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10015 WHERE PostalCode = 'MN';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10016 WHERE PostalCode = 'NC';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10017 WHERE PostalCode = 'MI';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10018 WHERE PostalCode = 'IN';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10019 WHERE PostalCode = 'AL';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10020 WHERE PostalCode = 'AK';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10021 WHERE PostalCode = 'AR';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10022 WHERE PostalCode = 'AZ';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10023 WHERE PostalCode = 'CO';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10024 WHERE PostalCode = 'DE';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10025 WHERE PostalCode = 'DC';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10026 WHERE PostalCode = 'HI';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10027 WHERE PostalCode = 'IA';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10028 WHERE PostalCode = 'ID';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10029 WHERE PostalCode = 'KS';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10030 WHERE PostalCode = 'KY';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10031 WHERE PostalCode = 'MA';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10032 WHERE PostalCode = 'ME';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10033 WHERE PostalCode = 'MO';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10034 WHERE PostalCode = 'MS';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10035 WHERE PostalCode = 'MT';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10036 WHERE PostalCode = 'ND';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10037 WHERE PostalCode = 'NE';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10038 WHERE PostalCode = 'NH';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10039 WHERE PostalCode = 'NM';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10050 WHERE PostalCode = 'NV';");//fixed from 1040
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10041 WHERE PostalCode = 'OK';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10042 WHERE PostalCode = 'OR';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10043 WHERE PostalCode = 'PR';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10044 WHERE PostalCode = 'RI';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10045 WHERE PostalCode = 'SC';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10046 WHERE PostalCode = 'SD';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10047 WHERE PostalCode = 'UT';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10048 WHERE PostalCode = 'VT';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10049 WHERE PostalCode = 'WA';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10040 WHERE PostalCode = 'WI';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10051 WHERE PostalCode = 'WV';");
            lstMergeSql.Add("UPDATE state SET MasterModuleID = 10052 WHERE PostalCode = 'WY';");
            //***************************************************************************
            // Be sure we don't have any "pending" StateSection records.  This delete is a security.  No records should be
            // found, because the loop on retired sections (just before the input statements) must have handled that.
            //m_OFileMerge.WriteLine("--%Be sure we don't have any 'pending' StateSections records.  Should be 0.");
            //m_OFileMerge.WriteLine("DELETE FROM StateSection WHERE NOT EXISTS (SELECT * FROM RGSection"
            //        + " WHERE RGSection.SectionSN = StateSection.SectionSN);");
            //m_OFileMerge.WriteLine();

            lstMergeSql.Add("DELETE FROM StateSection WHERE NOT EXISTS (SELECT * FROM RGSection"
                    + " WHERE RGSection.SectionSN = StateSection.SectionSN);");

            //***************************************************************************
            _main.OutMsg(PageType.MergeState, "Identifying the new or updated sections" + Environment.NewLine);
            // Go through the list of New SectionSN in the Module ToMerge database and compare it with the Previous list of
            // SectionSN.
            iCount = 0;
            jCount2 = 0;
            foreach (long sn in m_ListSectionToMerge)
            {
                SectionSN = sn;// go3.Current();

                if (!UTIL.ListLongFind(m_ListSectionMaster, SectionSN))
                {
                    // New Section
                    iCount++;
                    if ((iCount % 10) == 0)
                    {
                        _main.OutMsg(PageType.MergeState, ".");
                        jCount2++;

                        if (jCount2 > 170)
                        {
                            jCount2 = 0;
                            _main.OutMsg(PageType.MergeState, Environment.NewLine);

                        }
                    }

                    //m_OFileMerge.WriteLine("UPDATE StateSection SET TagDate = " + m_sResearchDate + " WHERE SectionSN = "
                    //          + SectionSN + ";");
                    //m_OFileMerge.WriteLine("UPDATE RGKeyWord    SET TagDate = " + m_sResearchDate + " WHERE SectionSN = "
                    //          + SectionSN + ";");
                    //m_OFileMerge.WriteLine("UPDATE RGSection    SET TagDate = '" + CVTHEX.LongToHex(long.Parse(m_sResearchDate.ToString()))
                    //          + CVTHEX.LongToHex(0) + CVTHEX.LongToHex(UInt16.MaxValue) + "' WHERE SectionSN = " + SectionSN + ";");


                    lstMergeSql.Add("UPDATE StateSection SET TagDate = " + m_sResearchDate + " WHERE SectionSN = "
                              + SectionSN + ";");
                    lstMergeSql.Add("UPDATE RGKeyWord    SET TagDate = " + m_sResearchDate + " WHERE SectionSN = "
                              + SectionSN + ";");
                    lstMergeSql.Add("UPDATE RGSection    SET TagDate = '" + CVTHEX.LongToHex(long.Parse(m_sResearchDate.ToString()))
                              + CVTHEX.LongToHex(0) + CVTHEX.LongToHex(UInt16.MaxValue) + "' WHERE SectionSN = " + SectionSN + ";");
                }
            }

            //if (CheckForCancel()) return;

            _main.OutMsg(PageType.MergeState, "" + iCount.ToString() + " new or updated sections.\r\n");

            //m_OFileMerge.WriteLine();
            //m_OFileMerge.WriteLine("--%Copy the TagDate from StateSection to QCountState.");
            //m_OFileMerge.WriteLine("UPDATE QCountState SET QCountState.TagDate = StateSection.TagDate FROM QCountState, StateSection "
            //          + "WHERE StateSection.StateSN = QCountState.StateSN "
            //          + "AND StateSection.StateDomainSN = QCountState.StateDomainSN "
            //          + "AND StateSection.StateVersionSN = QCountState.StateVersionSN;");
            //m_OFileMerge.WriteLine();

            lstMergeSql.Add("UPDATE QCountState SET QCountState.TagDate = StateSection.TagDate FROM QCountState, StateSection "
                      + "WHERE StateSection.StateSN = QCountState.StateSN "
                      + "AND StateSection.StateDomainSN = QCountState.StateDomainSN "
                      + "AND StateSection.StateVersionSN = QCountState.StateVersionSN;");

            //***************************************************************************
            // Update the table RGKeyWord.
            //m_OFileMerge.WriteLine("--%Keep In sync. the RGKeyWord table with the tables QRLink and RGSection.");
            //m_OFileMerge.WriteLine("DELETE FROM RGKeyWord WHERE NOT EXISTS (SELECT SectionSN FROM RGSection"
            //          + " WHERE RGSection.SectionSN = RGKeyWord.SectionSN);");
            //// We know that the RGKeyWord for states (above 1000000000) must have a QRLink related.
            //m_OFileMerge.WriteLine("DELETE FROM RGKeyWord WHERE ReferenceSN >= 1000000000 AND NOT EXISTS (SELECT ReferenceSN"
            //          + " FROM QRLink WHERE QRLink.ReferenceSN = RGKeyWord.ReferenceSN);");
            //m_OFileMerge.WriteLine();

            lstMergeSql.Add("DELETE FROM RGKeyWord WHERE NOT EXISTS (SELECT SectionSN FROM RGSection"
                    + " WHERE RGSection.SectionSN = RGKeyWord.SectionSN);");
            // We know that the RGKeyWord for states (above 1000000000) must have a QRLink related.
            lstMergeSql.Add("DELETE FROM RGKeyWord WHERE ReferenceSN >= 1000000000 AND NOT EXISTS (SELECT ReferenceSN"
                    + " FROM QRLink WHERE QRLink.ReferenceSN = RGKeyWord.ReferenceSN);");

            //***************************************************************************
            // Update some state expansion questions, which become non state expansion question.
            for (int k = 0; k < m_TListOneQuestion.Count; k++)
            {
                //m_OFileMerge.WriteLine("UPDATE QuestionBody SET Properties = 36 WHERE QuestionBodySN = " + m_TListOneQuestion[k]
                             //+ ";");

                lstMergeSql.Add("UPDATE QuestionBody SET Properties = 36 WHERE QuestionBodySN = " + m_TListOneQuestion[k] + ";");

            }
            //m_OFileMerge.WriteLine();

            //***************************************************************************
            // Build the StateModule table from scratch from the StateDomainStructure table.
            //m_OFileMerge.WriteLine("DELETE FROM StateModule;");
            //m_OFileMerge.WriteLine("INSERT INTO StateModule SELECT DISTINCT ModuleSN, ModuleVersionSN, StateVersionSN"
            //             + " FROM StateDomainStructure GROUP BY ModuleSN, ModuleVersionSN, StateVersionSN;");
            //m_OFileMerge.WriteLine();
            //m_OFileMerge.WriteLine("COMMIT WORK;");

            ////***************************************************************************
            //m_OFileMerge.WriteLine("UPDATE Question KEY JOIN QuestionBody SET RFValue = 2 WHERE DataType = 'M';");
            //m_OFileMerge.WriteLine("COMMIT WORK;");
            //m_OFileMerge.WriteLine();

            ////***************************************************************************
            //// The following statements will be use by the SortSect program
            //m_OFileMerge.WriteLine("--%Select all the SectionSN ordered by State Postal Code, and by heading.");
            //m_OFileMerge.WriteLine("SELECT StateSection.SectionSN FROM State, StateSection KEY JOIN RGSection"
            //             + " WHERE State.StateSN = StateSection.StateSN GROUP BY StateSection.SectionSN"
            //             + " ORDER BY MAX(StateName), MAX(Heading);");
            //m_OFileMerge.WriteLine("OUTPUT TO '" + TempDir + "sortsect.txt';");
            //m_OFileMerge.WriteLine();

            //**************************
            lstMergeSql.Add("DELETE FROM StateModule;");
            lstMergeSql.Add("INSERT INTO StateModule SELECT DISTINCT ModuleSN, ModuleVersionSN, StateVersionSN"
                         + " FROM StateDomainStructure GROUP BY ModuleSN, ModuleVersionSN, StateVersionSN;");

            lstMergeSql.Add("UPDATE Question SET RFValue = 2 from Question inner JOIN QuestionBody on Question.QuestionBodySN=QuestionBody.QuestionBodySN WHERE DataType = 'M'");
            //lstMergeSql.Add("SELECT StateSection.SectionSN FROM State, StateSection KEY JOIN RGSection"
            //             + " WHERE State.StateSN = StateSection.StateSN GROUP BY StateSection.SectionSN"
            //             + " ORDER BY MAX(StateName), MAX(Heading);");
            //lstMergeSql.Add("OUTPUT TO '" + TempDir + "sortsect.txt';");
            //**************************

            pMModuleVersion.ClearAllFields();
            pMQuestionBody.ClearAllFields();
            pMRGKeyWord.ClearAllFields();
        }

        //****************************************************************************
        private void ReadBLRSection(StreamReader IFile, long StateSN, long StateDomainSN,
                string StateTitle, string ParentName)
        {
            string errMsg = "";
            // This counter is used to count the number of paragraphs in the section.  This number will then be used to find
            // the offset for the "See Table n" link.
            m_Counter.ResetCounter();

            // Becomes true when <PRE> is encountered (is true until the </PRE>).  When in Preformat mode, we keep the end of
            // lines encountered in the ASCII files and also the leading spaces.
            m_bPreformat = false;
            m_bLink = false;

            string Line;

            // Get the first line non blank (should be: @ SECTION "Name of the BLR Domain").
            int NoLine = 0;

            Line = GetLine(ref NoLine, true, true, IFile);

            if (Line == null || Line.Length<9 || Line.Substring(0, 9) != "@ SECTION") 
            {
                throw (new Exception("@ SECTION Missing In file " + m_sFileName + " at line " + (NoLine).ToString()));               
            }

            // The second line non blank should be the SN of the section. If not error.
            Line = GetLine(ref NoLine, true, true, IFile);

            if (Line == null || Line.Length < 5 || Line.Substring(0, 5) != "@ SNS" && Line.Substring(0, 5) != "@RSNS")
            {
                throw (new Exception("@ SNS Missing In file " + m_sFileName + " at line " + NoLine.ToString()));
            }
            m_lSectionSN = 1000000000L + long.Parse(Line.Substring(5));

            // The following lines are related to Question Serial Numbers.
            // Find the line containing the argument "ParentName". This line must exist; else this is an error.
            // The serial number used in the Module Database is the one found in the ASCII file + 1000000000.
            // m_ListQuestionToMerge is a structure containing the list of the Question SN of the ToMerge Database.
            m_lQuestionSN = -1;
            while ((Line = GetLine(ref NoLine, true, true, IFile)) != null )
            {
                if (Line.Length < 5)
                {
                    break;
                }

                if ((Line.Substring(0, 5) != "@ SNQ" && Line.Substring(0, 5) != "@RSNQ"))
                {
                    break;
                }

                if (Line.Length > 14 && Line.Substring(15).Equals(ParentName)) 
                {
                    m_lQuestionSN = 1000000000L + long.Parse(Line.Substring(5, 9));
                    m_ListQuestionToMerge.Add(m_lQuestionSN);
                }
            }

            if (!Line.StartsWith("@ R"))
            {
                throw (new Exception("@ R Missing In file " + m_sFileName + " at line " + NoLine.ToString()));
            }

            if (m_lQuestionSN == -1)
            {
                throw (new Exception("@ SNQ Missing for " + ParentName + " In file " + m_sFileName + " at line " + NoLine.ToString()));
            }

            // This Line is the Heading.  Ignore it.
            if (Line == null || Line == "") 
            {
                throw (new Exception("Heading of the section missing In file " + m_sFileName + " at line " + NoLine.ToString()));
            }

            // if the line is @ R. ignore it.
            if (Line[0] == '@')
                Line = GetLine(ref NoLine, true, true, IFile);


            // Add a record in the StateSection table.
            //Addtional 0 is added for TagDate field. Jun 1, 2011
            m_OFileStateSect.WriteLine(StateDomainSN + "," + StateSN + "," + m_lSectionSN +
                        "," + m_iNewStateVersionSN + ",0");
            //m_OFileStateSect.WriteLine(StateDomainSN + "," + StateSN + "," + m_lSectionSN +
            //            "," + m_iNewStateVersionSN);

            if (m_bFirstOccurence)
            {
                // Add a record in the RGSection table (the text block is added further in the process).
                m_OFileRGSection.Write(m_lSectionSN + ",-1,'" + StateTitle + "','");
                
                //assert(m_pCState);
                try
                {
                    if (!m_pCState.IsNew())
                    {
                        // Add only for existing states.
                        m_ListSectionToMerge.Add(m_lSectionSN);
                    }
                }
                catch
                {
                    throw (new Exception("m_pCState is NULL"));
                }
            }

            Line = GetLine(ref NoLine, true, true, IFile);

            if (Line == null || Line == "")
            {
                throw (new Exception("No Question text after the Heading of the section In file "
                            + m_sFileName + " at line " + NoLine.ToString()));
            }

            // Governing Law and Regulations question.
            // We have always a GLR Question even if not in the text file.
            m_lQuestionBodySN++;
            m_OFileQuestion.WriteLine(m_lQuestionSN + ",0,''," + m_lQuestionBodySN);

            // Delete if Question already in the database.
            CheckQuestionInDatabase();

            bool IsGLR = false;
            if (m_bFirstOccurence)
            {
                m_OFileQuestionB.Write(m_lQuestionBodySN + ",'");
            }
            //if (m_lQuestionBodySN == 1001175616)
            //{
            //    string s = "";
            //}
            string Tmp = "";
            if (Line.Length > 5)
            {
                Tmp = Line.Substring(0, 6);
            }

            if (Tmp.ToUpper() == "GOVERN")
            {
                IsGLR = true;
                ParseGLR(IFile, ref Line, ref NoLine);
            }

            if (m_bFirstOccurence)
            {
                // No ListAnswer and Put in Note Text the name of the BLR domain.
                // Type is GLR, No red flag value and State question as properties.
                m_OFileQuestionB.WriteLine("','','" + StateTitle + "','G',68");

                //m_OFileQuestionB.WriteLine("',,'" + StateTitle + "','G',68");
            }

            // Add a record in QDStateLink.
            m_OFileQDState.WriteLine(StateSN + "," + m_iNewStateVersionSN + "," + StateDomainSN +
                        ",0," + m_lQuestionSN);
            //m_OFileQDState.WriteLine(StateSN + "," + m_iNewStateVersionSN + "," + StateDomainSN +
            //            ",0," + m_lQuestionSN + ",-1");

            // This appears only in reguirement guide.
            bool IsRA = false;
            Tmp = "";
            if (Line.Length > 9)
            {
                Tmp = Line.Substring(0, 10);
            }
            if (Tmp.ToUpper() == "REGULATORY")
            {
                IsRA = true;
                if (IsGLR)
                {
                    if (m_bFirstOccurence)
                    {
                        m_OFileRGSection.Write(FORMAT_PREFIX + PARAGRAPH_BREAK);
                    }
                    m_Counter.IncrementCounter(2);
                }

                errMsg = ParseRA(IFile, ref Line, ref NoLine);
            }

            // Now read the questions related with the BLR Domain (and for a given state).
            short NumQuestion = 0;
            do
            {
                NumQuestion++;
                m_lQuestionSN++;
                m_ListQuestionToMerge.Add(m_lQuestionSN);
                m_lQuestionBodySN++;

                if (Line==null || Line.Length < 3 || (Line.Substring(0, 3) != "@ M" && Line.Substring(0, 3) != "@ Q")) 
                {
                    errMsg += "@ M or @ Q Missing In file " + m_sFileName + " at line " + NoLine.ToString();
                    if (!_main.isAutoProcess)
                    {
                        throw (new Exception(errMsg));
                    }

                    errMsg += Environment.NewLine;
                }

                // First, add a record for the QDStateLink table. 
                //Last -1 is not necessary. In the table QDStateLink has no such field. Jun 1, 2011
                m_OFileQDState.WriteLine(StateSN + "," + m_iNewStateVersionSN + "," + StateDomainSN +
                        "," + NumQuestion + "," + m_lQuestionSN);

                //m_OFileQDState.WriteLine(StateSN + "," + m_iNewStateVersionSN + "," + StateDomainSN +
                //            "," + NumQuestion + "," + m_lQuestionSN + ",-1");

                // The stream is at the beginning of a question.  Process it.
                m_OFileQuestion.WriteLine(m_lQuestionSN + ",0,''," + m_lQuestionBodySN);
                //m_OFileQuestion.WriteLine(m_lQuestionSN + "," + m_lQuestionBodySN + ",0");

                // ParseQuestion processes: StdText, NoteText, ListAnswer, DataType, RFValue and Properties.
                if (NumQuestion > 1 || (NumQuestion == 1 && (IsGLR || IsRA)))
                    if (m_bFirstOccurence)
                        m_OFileRGSection.Write(FORMAT_PREFIX + PARAGRAPH_BREAK);
                m_Counter.IncrementCounter(2);

                // Delete if Question already in the database.
                CheckQuestionInDatabase();

                // Now create the question by parsing the ASCII file.
                ParseQuestion(IFile, ref Line, ref NoLine, NumQuestion);

                // Get the next line which is not blank.
                if (Line == "")
                {
                    Line = GetLine(ref NoLine, true, true, IFile);
                }

            } while (Line != null && Line != "" && Line[0] == '@');

            if (errMsg != "")
            {
                throw (new Exception(errMsg));
            }

            if (m_bFirstOccurence)
            {
                // Close the text block of the section.
                //m_OFileRGSection.WriteLine("'");
                m_OFileRGSection.WriteLine("','',-1");
            }

            // Update also the QCountState table. Added last 0 for tagdate Jun 1, 2011
            m_OFileQCountSt.WriteLine(StateSN + "," + m_iNewStateVersionSN + "," + StateDomainSN + "," + NumQuestion + ",0");
            //assert(NumQuestion >= 1);  // Assume there is always at least one question.
            if (NumQuestion == 1 && m_bFirstOccurence)
            {
                // This question will be updated later to not be any longer a state expansion question (because only one
                // question for this state domain).
                m_TListOneQuestion.Add(m_lQuestionBodySN);
            }
        }

        //   // Read a Section and create the Questions and Requirement guide.
        private string GetLine(StreamReader IFile, ref int NumLine)
        {
            return GetLine(IFile, ref NumLine, true, false);
        }
        private string GetLine(ref int NumLine, StreamReader IFile)
        {
            return GetLine(ref NumLine, false, true, IFile);
        }
        private string GetLine(StreamReader IFile, ref int NoLine, bool Skip, bool StripTrailing)
        {
            string Line = null;

            while ((Line = IFile.ReadLine()) != null)
            {
                NoLine++;

                // Exit the loop if we don't want to skip any lines.
                if (!Skip) break;

                // Exit the loop if the line is not blank and doesn't begin with an asterisk.
                if (Line.Trim(new char[]{' '}) != "" && Line.Trim(new char[]{' '})[0] != '*')
                {
                    break;
                }
                Line = null;
            }

            if (Line != null && StripTrailing)
            {
                Line = Line.TrimEnd(new char[] { ' ' });//.Trim (string::Trailing);
            }

            return Line;
        }
        private string GetLine(ref int NoLine, bool SkipBlankLines, bool Strip, StreamReader IFile)
        {
            string Line = null;
            if (IFile.EndOfStream)
            {
                return Line;
            }

            while ((Line = IFile.ReadLine()) != null)
            {
                NoLine++;

                if (Strip && !m_bPreformat)
                {
                    Line = Line.TrimStart(new char[] { ' ' });// (string::Leading);
                }
                Line = Line.TrimEnd(new char[] { ' ' });// (string::Trailing);

                // Ignore line beginning with '*'.
                if (Line.TrimStart() == "" || Line.TrimStart()[0] != '*')
                {
                    Line = Line.Replace("&amp", "&");
                    Line = Line.Replace("&gt", ">");
                    Line = Line.Replace("&lt", "<");
                    Line = Line.Replace("<BR>", "\\n");

                    // Do a treatment on the line to substitute &... and <...>.
                    for (int iPos = 0; iPos < Line.Length; iPos++)
                    {

                        switch (Line[iPos])
                        {
                            case '&':
                                //ParseAmpersand(ref Line, iPos);
                                break;
                            case '<':
                                ParseBrackets(ref Line, ref iPos, NoLine);
                                break;
                        }
                    }
                    if (!SkipBlankLines || Line != "")
                    {
                        break;
                    }
                }

                Line = null;
            }
            return Line;
        }

        private string GetWord(string Line, ref int iPos)
        {
            return GetWord(Line, ref iPos, " ");
        }
        private string GetWord(string Line, ref int iPos, string Separator)
        {
            // Skip the spaces.
            while (iPos < Line.Length && Line[iPos] == ' ')
            {
                iPos++;
            }

            StringBuilder Word = new StringBuilder();
            while (iPos < Line.Length && Line[iPos].ToString() != Separator)
            {
                Word.Append(Line[iPos]);
                iPos++;
            }

            if (iPos < Line.Length)
                iPos++;  // to skip the separator.

            return Word.ToString().Trim(new char[]{' '});
        }

        //----------------------------------------------------------------------------
        private void ParseAmpersand(ref string Line, int iPos)
        {
            Line = Line.Replace("&amp", "&");
            Line = Line.Replace("&gt", ">");
            Line = Line.Replace("&lt", "<");
        }

        //----------------------------------------------------------------------------
        private void ParseBrackets(ref string Line, ref int iPos, int NoLine)
        {
            if (Line.Length > iPos + 4 && Line.Substring(iPos, 5) == "<PRE>") 
            {    
                // Preformatting.  Add a carriage return at the end of each line.
                if (m_bPreformat)
                {
                    throw (new Exception(" in m_sFileName, at line " + NoLine.ToString() + 
                            "<PRE> encountered twice in a row (</PRE> missing)"));
                }

                m_lCounter = m_pCState.GetNextTableCounter();

                if (m_bFirstOccurence)
                {
                    m_OFileQuestionB.Write("\\n\\nSee " + m_pCState.GetPostalCode() + ": Table " + m_lCounter);
                }

                // The referenceSN is the same as the QuestionSN (for now).
                m_lReferenceSN++;
                m_lSequence++;

                m_OFileQRLink.WriteLine(m_lQuestionSN.ToString() + "," + m_lSequence.ToString() + "," + m_lReferenceSN.ToString());
                //m_OFileRGKeyWord.Write(m_lReferenceSN.ToString() + "," + m_pCState.GetPostalCode() + ": Table ");

                //if (m_lCounter < 10)
                //{
                //    // Add an extra space.
                //    m_OFileRGKeyWord.Write(" ");
                //}
                //m_OFileRGKeyWord.WriteLine(m_lCounter + "," + m_lSectionSN + "," + m_Counter.GetCounter() + "," + m_lModuleSN);
                m_OFileRGKeyWord.Write(m_lReferenceSN.ToString() + ",'" + m_pCState.GetPostalCode() + ": Table ");

                if (m_lCounter < 10)
                {
                    // Add an extra space.
                    m_OFileRGKeyWord.Write(" ");
                }
                m_OFileRGKeyWord.WriteLine(m_lCounter + "'," + m_lSectionSN + "," + m_Counter.GetCounter() + "," + m_lModuleSN + ",0");

                m_bPreformat = true;
                return;
            }

            if (Line.Length > iPos + 5 && Line.Substring(iPos, 6) == "</PRE>")
            {    // End of preformat.
                if (!m_bPreformat)
                {
                    throw (new Exception(" in m_sFileName, at line " + NoLine.ToString() +
                            "</PRE> encountered before <PRE>"));
                }
                m_bPreformat = false;
                return;
            }

            if (Line.Length > iPos + 5 && Line.Substring(iPos, 6) == "<LINK>")
            {    
                // Link.  Add a carriage return at the end of each line.
                if (m_bLink)
                {
                    throw (new Exception(" in m_sFileName, at line " + NoLine.ToString() +
                            "<LINK> encountered twice in a row (</LINK> missing)"));
                }

                //assert(m_pCState);

                //m_lCounter = m_pCState.GetNextTableCounter ();
                m_tFileName = Line.Substring(iPos + 6);
                m_tFileName = m_tFileName.Trim(new char[]{' '});// (string::Both);

                if (m_tFileName == null)
                {
                    throw (new Exception(" in m_sFileName, at line " + NoLine.ToString() +
                            "No Table Name is found on the same line as the <Link> tag!"));
                }

                if (m_bFirstOccurence)
                {
                    m_OFileQuestionB.Write("\\n\\nSee " + m_tFileName);
                }

                // The referenceSN is the same as the QuestionSN (for now).
                m_lReferenceSN++;
                m_lSequence++;

                m_OFileQRLink.WriteLine(m_lQuestionSN + "," + m_lSequence + "," + m_lReferenceSN);
                m_OFileRGKeyWord.WriteLine(m_lReferenceSN + ",'" + m_tFileName + "'," + m_lSectionSN + "," + m_Counter.GetCounter() + "," + m_lModuleSN + ",0");
                m_bLink = true;
                return;
            }

            if (Line.Length > iPos + 6 && Line.Substring(iPos, 7) == "</LINK>")
            {    // End of Link.
                if (!m_bLink)
                {
                    throw (new Exception(" in m_sFileName, at line " + NoLine.ToString() +
                            "</LINK> encountered before <LINK>"));
                }
                m_bLink = false;
                return;
            }
        }

        private void ParseGLR(StreamReader IFile, ref string Line, ref int NoLine)
        {
            int NumParagraph = 0;
            string LineExport;

            bool Continue;
            do
            {
                // Get a paragraph beginning at the line "Line" and ending when encounter a blank line or eof().
                GetParagraph(IFile, ref Line, ref NoLine);
                NumParagraph++;

                if (NumParagraph > 1)
                {
                    // Close the previous paragraph (except the last one).
                    if (m_bFirstOccurence)
                    {

                        m_OFileRGSection.Write(FORMAT_PREFIX + LINE_BREAK);
                        m_OFileQuestionB.Write("\\n");
                    }

                    m_Counter.IncrementCounter();

                    if (Line != "")
                    {

                        // Separate this paragraph (if not empty) from the previous by a blank line.
                        if (m_bFirstOccurence)
                        {

                            m_OFileRGSection.Write(FORMAT_PREFIX + LINE_BREAK);
                            m_OFileQuestionB.Write("\\n");
                        }

                        m_Counter.IncrementCounter();
                    }
                }
                else
                {
                    // Set bold
                    if (m_bFirstOccurence)
                        m_OFileRGSection.Write(FORMAT_PREFIX + BOLD_ON);
                }

                LineExport = FormatToExport(Line);
                m_OFileRGSection.Write(FormatForSection(LineExport));

                if (m_bFirstOccurence)
                {
                    if (NumParagraph == 1)
                        m_OFileRGSection.Write(FORMAT_PREFIX + BOLD_OFF);
                    m_OFileQuestionB.Write(FormatForQuestion(LineExport));
                }

                // We want the insensitive comparison because "Regulatory" can be in lower or Upper case (or mixed).
                // We want to localize the insensitivity because there is a Side effect in GlobalReplace (]. considered as
                // a \\n!!!)
                Line = GetLine(ref NoLine, true, true, IFile);

                if (Line == null)
                {
                    Continue = false;
                    break;
                }

                if (Line.Length > 9 && Line.Substring(0, 10).ToUpper() == "REGULATORY")
                {
                    Continue = false;
                    break;
                }

                if (Line.Length > 0 && Line[0] == '@')
                {
                    Continue = false;
                    break;
                }

                Continue = true;

            } while (Continue);
        }

        private string ParseRA(StreamReader IFile, ref string Line, ref int NoLine)
        {
            int NumParagraph = 0;
            string LineExport;

            string ret = "";

            do
            {
                // Get a paragraph beginning at the line "Line" and ending when encounter a blank line or eof().
                GetParagraph(IFile, ref Line, ref NoLine);
                NumParagraph++;

                if (NumParagraph > 1)
                {
                    // Close the previous paragraph (except the last one).
                    if (m_bFirstOccurence)
                    {
                        m_OFileRGSection.Write(FORMAT_PREFIX + LINE_BREAK);
                    }

                    m_Counter.IncrementCounter();

                    if (Line != "")
                    {
                        if (m_bFirstOccurence)
                        {
                            // Separate this paragraph (if not empty) from the previous by a blank line.
                            m_OFileRGSection.Write(FORMAT_PREFIX + LINE_BREAK);
                        }

                        m_Counter.IncrementCounter();
                    }
                }
                else
                {
                    if (m_bFirstOccurence)
                    {
                        m_OFileRGSection.Write(FORMAT_PREFIX + BOLD_ON);
                    }
                }
                LineExport = FormatToExport(Line);
                m_OFileRGSection.Write(FormatForSection(LineExport));

                if (m_bFirstOccurence)
                {
                    if (NumParagraph == 1)
                        m_OFileRGSection.Write(FORMAT_PREFIX + BOLD_OFF);
                }

                Line = GetLine(ref NoLine, true, true, IFile);

                if (Line != null && Line.StartsWith("COMPARISON: "))
                {
                    ret += "@ M Missing In file " + m_sFileName + " at line " + NoLine.ToString() + Environment.NewLine;
                }
            } while (Line != null && Line[0] != '@');

            return ret;
        }

        private void ParseQuestion(StreamReader IFile, ref string Line, ref int NoLine, int NumQuestion)
        {
            string LineExport;
            int NumParagraph = 0;
            m_lSequence = 0;

            if (m_bFirstOccurence)
            {
                m_OFileQuestionB.Write(m_lQuestionBodySN + ",'");
            }
            while ((Line = GetLine(ref NoLine, true, true, IFile)) != null && (Line[0] != '@' && CheckBoxBegin(Line) == false))
            {

                NumParagraph++;
                GetParagraph(IFile, ref Line, ref NoLine);

                if (NumParagraph > 1)
                {

                    // Close the previous paragraph (except the last one).
                    if (m_bFirstOccurence)
                    {

                        m_OFileRGSection.Write(FORMAT_PREFIX + LINE_BREAK);
                        // Add a CR if not in Preformat mode (or if we are in the first paragraph of the preformatted).
                        if (!IsPreformatMode(Line) && !IsLinkMode(Line)) m_OFileQuestionB.Write("\\n");
                    }

                    m_Counter.IncrementCounter();

                    if (Line != "")
                    {

                        // Separate this paragraph (if not empty) from the previous by a blank line.
                        if (m_bFirstOccurence)
                        {

                            m_OFileRGSection.Write(FORMAT_PREFIX + LINE_BREAK);
                            // Add a CR if not in Preformat mode (or if we are in the first paragraph of the preformatted).
                            if (!IsPreformatMode(Line) && !IsLinkMode(Line))
                                m_OFileQuestionB.Write("\\n");
                        }
                        m_Counter.IncrementCounter();
                    }
                }
                else
                {
                    if (m_bFirstOccurence)
                        m_OFileRGSection.Write(FORMAT_PREFIX + BOLD_ON);
                }

                LineExport = FormatToExport(Line);
                m_OFileRGSection.Write(FormatForSection(LineExport));
                if (m_bFirstOccurence)
                {
                    if (NumParagraph == 1)
                        m_OFileRGSection.Write(FORMAT_PREFIX + BOLD_OFF);
                    m_OFileQuestionB.Write(FormatForQuestion(LineExport));
                }
            }

            if (Line == null)
            {
                Line = "";
            }
            if (m_bFirstOccurence)
                m_OFileQuestionB.Write("',");

            // Now see if there is any check boxes.
            if (CheckBoxBegin(Line))
            {
                // Leave a blank line between the check boxes and the standard text.
                if (m_bFirstOccurence)
                {
                    m_OFileRGSection.Write(FORMAT_PREFIX + PARAGRAPH_BREAK);
                    m_OFileQuestionB.Write("'");
                }

                m_Counter.IncrementCounter(2);

                NumParagraph = 0;
                do
                {
                    NumParagraph++;
                    GetParagraph(IFile, ref Line, ref NoLine);
                    if (NumParagraph > 1)
                    {

                        // Close the previous paragraph (except the last one).
                        if (m_bFirstOccurence)
                        {
                            m_OFileRGSection.Write(FORMAT_PREFIX + LINE_BREAK);
                        }

                        m_Counter.IncrementCounter();

                        if (Line != "")
                        {
                            if (m_bFirstOccurence)
                            {
                                m_OFileRGSection.Write(FORMAT_PREFIX + LINE_BREAK);
                                m_OFileQuestionB.Write(SEP_LISTANSWER);
                            }
                            m_Counter.IncrementCounter();
                        }
                    }

                    LineExport = FormatToExport(Line);
                    m_OFileRGSection.Write(FormatForSection(LineExport));
                    m_OFileQuestionB.Write(FormatForQuestion(LineExport));

                } while ((Line = GetLine(ref NoLine, true, true, IFile)) != null && Line[0] != '@' && CheckBox(Line));

                if (m_bFirstOccurence)
                    m_OFileQuestionB.Write("'");

                // Get the next line which is not blank.
                if (Line == "")
                {
                    Line = GetLine(ref NoLine, true, true, IFile);
                }
            }
            else   //Added on Jun 1, 2011
            {
                if (m_bFirstOccurence)
                    m_OFileQuestionB.Write("''");
            }

            if (m_bFirstOccurence)
                m_OFileQuestionB.Write(",");

            // Get the note text if one.
            if (Line != null && Line != "" && Line[0] != '@')
            {
                // Separate the note text from the previous paragraph with a blank line.
                if (m_bFirstOccurence)
                {
                    m_OFileRGSection.Write(FORMAT_PREFIX + PARAGRAPH_BREAK);
                    m_OFileQuestionB.Write("'");
                }
                m_Counter.IncrementCounter(2);

                NumParagraph = 0;
                do
                {
                    NumParagraph++;
                    // Get a paragraph beginning at the line "Line" and ending when encounter a blank line or eof().
                    GetParagraph(IFile, ref Line, ref NoLine);

                    if (NumParagraph > 1)
                    {

                        // Close the previous paragraph (except the last one).
                        if (m_bFirstOccurence)
                        {

                            m_OFileRGSection.Write(FORMAT_PREFIX + LINE_BREAK);
                            // Add a CR if not in Preformat mode (or if we are in the first paragraph of the preformatted).
                            if (!IsPreformatMode(Line) && !IsLinkMode(Line)) m_OFileQuestionB.Write("\\n");
                        }

                        m_Counter.IncrementCounter();

                        if (Line != "")
                        {
                            // Separate this paragraph (if not empty) from the previous by a blank line.
                            if (m_bFirstOccurence)
                            {
                                m_OFileRGSection.Write(FORMAT_PREFIX + LINE_BREAK);
                                // Add a CR if not in Preformat mode (or if we are in the first paragraph of the preformatted).
                                if (!IsPreformatMode(Line) && !IsLinkMode(Line)) m_OFileQuestionB.Write("\\n");
                            }
                            m_Counter.IncrementCounter();
                        }
                    }

                    LineExport = FormatToExport(Line);
                    m_OFileRGSection.Write(FormatForSection(LineExport));
                    m_OFileQuestionB.Write(FormatForQuestion(LineExport));

                } while ((Line = GetLine(ref NoLine, true, true, IFile)) != null && Line[0] != '@');

                if (m_bFirstOccurence)
                {
                    m_OFileQuestionB.Write("'");
                }

                // Get the next line which is not blank.
                if (Line == "")
                {
                    Line = GetLine(ref NoLine, true, true, IFile);
                }
            }
            else
            {
                if (m_bFirstOccurence)
                    m_OFileQuestionB.Write("''");
            }

            if (m_bFirstOccurence)
            {
                m_OFileQuestionB.Write(",");
                // Set the data type of the question.
                m_OFileQuestionB.Write("'M',");

                // State Question property.
                if (NumQuestion == 1)
                    // For the controlling question set the fifth and sixth bit to 1.
                    m_OFileQuestionB.WriteLine("52");
                else
                    m_OFileQuestionB.WriteLine("4");
            }
        }

        private void CheckQuestionInDatabase()
        {
            if (!FullProcess()) return;

            //if ((m_lQuestionSN % 1000) == 0)
            //    m_OFileMerge.WriteLine("CLEAR;");

            //m_OFileMerge.WriteLine("DELETE FROM QRLink   WHERE QuestionSN = " + m_lQuestionSN + ";");
            //m_OFileMerge.WriteLine("DELETE FROM Question WHERE QuestionSN = " + m_lQuestionSN + ";");

                //if (m_lQuestionSN == (long)1290510053)
                //{
                //    string s = "";
                //}
            lstMergeSql.Add("DELETE FROM QRLink   WHERE QuestionSN = " + m_lQuestionSN + ";");
            lstMergeSql.Add("DELETE FROM Question WHERE QuestionSN = " + m_lQuestionSN + ";");
        }

        //----------------------------------------------------------------------------
        private bool CheckBoxBegin(string Line)
        {
            if (!IsPreformatMode(Line) && !IsLinkMode(Line) && Line.Length >= 2
                    && Line.Substring(0, 2) == "1)")
            {
                return true;
            }
            return false;
        }

        //----------------------------------------------------------------------------
        private bool CheckBox(string Line)
        {
            if (IsPreformatMode(Line) || IsLinkMode(Line)) return false;

            int iPos = Line.IndexOf(")");
            if (iPos != 1 && iPos != 2) return false;

            if (iPos == 1 && int.Parse(Line.Substring(0, 1)) > 0) return true;
            if (iPos == 2 && int.Parse(Line.Substring(0, 2)) >= 10) return true;

            return false;
        }

        private void GetParagraph(StreamReader IFile, ref string Line, ref int NoLine)
        {
            string Linep = Line;

            Line = "";
            while (Linep != "")
            {
                // if the line does not end with a carriage return, add a space or a carriage return (in preformat mode).
                UTIL.Assert(Linep.Length > 0, "Assertion Failed: Linep.Length > 0!");

                if (Line != "" && (Line.Length < 2 || Line.Substring(Line.Length - 2, 2) != "\\n"))

                    if (m_bPreformat)
                        Line += "\\n";
                    else
                        Line += " ";

                // Suppress the Leading spaces (used for check boxes).
                if (!IsPreformatMode(Line))
                {
                    Linep = Linep.Trim(new char[]{' '});
                }
                Line += Linep;

                if ((Linep = GetLine(ref NoLine, false, false, IFile)) == null)
                    break;
            }
        }
         //----------------------------------------------------------------------------
        public string FormatToExport(string Input)
        {
            string Output = "";
            char c;

            // Double the quote, because the delimiter is a Quote.
            for (int i = 0; i < Input.Length; i++)
            {
                c = Input[i];
                if (c == '\'')
                    Output += "''";
                else
                    Output += c;
            }

            // Remove the tabulations.
            GlobalReplace(ref Output, "\t", "");

            return Output;
        }

        //----------------------------------------------------------------------------
        public string FormatForSection(string Input)
        {
            string Output = Input;

            if (Output.IndexOf("<PRE>") > -1)
            {
                if (m_bFirstOccurence)
                {
                    m_OFileRGSection.Write(FORMAT_PREFIX + BOLD_ON + m_pCState.GetPostalCode() + ": Table " + m_lCounter
                                   + FORMAT_PREFIX + BOLD_OFF + FORMAT_PREFIX + PARAGRAPH_BREAK);
                }
                m_Counter.IncrementCounter(2);
            }

            GlobalReplace(ref Output, "<B>\\n", FORMAT_PREFIX + BOLD_ON);
            GlobalReplace(ref Output, "</B>\\n", FORMAT_PREFIX + BOLD_OFF);
            GlobalReplace(ref Output, "<PRE>\\n", FORMAT_PREFIX + FIXED_ON);
            GlobalReplace(ref Output, "</PRE>\\n", FORMAT_PREFIX + FIXED_OFF);
            GlobalReplace(ref Output, "<LINK>\\n", FORMAT_PREFIX + BOLD_ON + "Click here to LINK TO: ");
            GlobalReplace(ref Output, "</LINK>\\n", FORMAT_PREFIX + BOLD_OFF);
            GlobalReplace(ref Output, "<B>", FORMAT_PREFIX + BOLD_ON);
            GlobalReplace(ref Output, "</B>", FORMAT_PREFIX + BOLD_OFF);
            GlobalReplace(ref Output, "<PRE>", FORMAT_PREFIX + FIXED_ON);
            GlobalReplace(ref Output, "</PRE>", FORMAT_PREFIX + FIXED_OFF);
            GlobalReplace(ref Output, "<LINK>", FORMAT_PREFIX + BOLD_ON + "Click here to LINK TO: ");
            GlobalReplace(ref Output, "</LINK>", FORMAT_PREFIX + BOLD_OFF);
            int iCount = GlobalReplace(ref Output, "\\n", FORMAT_PREFIX + LINE_BREAK);
            m_Counter.IncrementCounter(iCount);

            if (m_bFirstOccurence == false) Output = "";

            return Output;
        }

        //----------------------------------------------------------------------------
        public string FormatForQuestion(string Input)
        {
            // In Preformat mode, don't output anything.
            if (m_bFirstOccurence == false || IsPreformatMode(Input) || IsLinkMode(Input)) return "";

            string Output = Input;

            GlobalReplace(ref Output, "<B>", "");
            GlobalReplace(ref Output, "</B>", "");
            GlobalReplace(ref Output, "<PRE>", "");
            GlobalReplace(ref Output, "</PRE>", "");
            GlobalReplace(ref Output, "<LINK>", "");
            GlobalReplace(ref Output, "</LINK>", "");

            return Output;
        }

        public int GlobalReplace(ref string InOut, string Old, string New)
        {
            int iCount = 0;

            //test, InOut={','a',a',a'','''} when Old="'"
            if (InOut.IndexOf(Old) > -1)
            {
                string[] split = InOut.Split(new string[] { Old }, StringSplitOptions.None);
                iCount = split.Length - 1;

                InOut = InOut.Replace(Old, New);
            }
            
            return iCount;
        }

        private bool IsPreformatMode(string Line)
        {
            return (m_bPreformat || Line.IndexOf("</PRE>") != -1);
        }

        private bool IsLinkMode(string Line)
        {
            return (m_bLink || Line.IndexOf("</LINK>") != -1);
        }
        private bool FullProcess()
        {
            return !_main.chkMergeSynCheck.Checked;
        }

        //******************************************************************
        public void CloseStream()
        {
            //if (m_OFileMerge != null)
            //{
            //    m_OFileMerge.Close();
            //}
            if (m_OFileSDVLink != null)
            {
                m_OFileSDVLink.Close();
            }
            if (m_OFileStateStr != null)
            {
                m_OFileStateStr.Close();
            }
            if (m_OFileQCountSt != null)
            {
                m_OFileQCountSt.Close();
            }
            if (m_OFileQDState != null)
            {
                m_OFileQDState.Close();
            }
            if (m_OFileStateSect != null)
            {
                m_OFileStateSect.Close();
            }
            if (m_OFileQuestion != null)
            {
                m_OFileQuestion.Close();
            }
            if (m_OFileQuestionB != null)
            {
                m_OFileQuestionB.Close();
            }
            if (m_OFileRGSection != null)
            {
                m_OFileRGSection.Close();
            }
            if (m_OFileQRLink != null)
            {
                m_OFileQRLink.Close();
            }
            if (m_OFileRGKeyWord != null)
            {
                m_OFileRGKeyWord.Close();
            }
            //if (m_pMQuestion != null)
            //{
            //    m_pMQuestion.Reset();
            //    m_pMQuestion = null;
            //}
        }
        private static CAbrModuleName _cabrModuleName = null;
        private static bool matchCAbrModuleName(CAbrModuleName cabrModuleName)
        {
            return (_cabrModuleName == cabrModuleName);
        }

        private static CFederalDomain _cfederalDomain = null;
        private static bool matchCFederalDomain(CFederalDomain cfederalDomain)
        {
            return (_cfederalDomain == cfederalDomain);
        }

        private static CBLRDomain _cblrDomain = null;
        private static bool matchCBLRDomain(CBLRDomain cblrDomain)
        {
            return (_cblrDomain == cblrDomain);
        }

        private static CDADomain _cdaDomain = null;
        private static bool matchCDADomain(CDADomain cdaDomain)
        {
            return (_cdaDomain == cdaDomain);
        }

        private bool CheckForCancel
        {
            get
            {
                return _main.cancelPressed;// || _main.processFailed; //if failed, return
            }
        }
        internal bool IsCancel()
        {
            return _main.cancelPressed;
        }

        private void ErrorThrow(string message)
        {
            if (message != string.Empty)
            {
                _main.OutMsg(PageType.MergeState, message + ".\r\n");

                _main.processStatus = ProcessStatus.Done;
                if (message == "Exit" || message == "Abort")
                {
                    _main.processFailed = true;
                    _main.processStatus = ProcessStatus.Exit;
                }
                else
                {
                    _main.processFailed = true;
                    _main.processStatus = ProcessStatus.Failed;
                }

                //_main.ClearDisplayQueue();
            }
        }
    }
}
