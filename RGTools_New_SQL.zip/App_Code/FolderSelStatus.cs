using System;
using System.Collections.Generic;
using System.Text;

namespace RGTools_New
{
    public class FolderSelStatus
    {
        bool _sel = false;
        string _name = string.Empty;

        public FolderSelStatus(bool isChecked, string FolderName)
        {
            _sel = isChecked;
            _name = FolderName;
        }

        public FolderSelStatus(string FolderName)
        {
            _name = FolderName;
        }

        public bool Selected
        {
            get
            {
                return _sel;
            }
            set
            {
                _sel = value;
            }
        }

        public string FolderName
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }
    }
}
