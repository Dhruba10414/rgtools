using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace RGTools_New
{
    class TStrList : List<string>
    {
        private bool DuplicatesAllowed;

        public TStrList()
        {
            bool pDuplicatesAllowed = true;
            //: TArrayAsVector <string> (1,0,1)
            DuplicatesAllowed = pDuplicatesAllowed;
        }
        public TStrList(bool pDuplicatesAllowed)
        {
            //: TArrayAsVector <string> (1,0,1)
            DuplicatesAllowed = pDuplicatesAllowed;
        }

        public void DumpAll(StreamWriter sw)
        {
            for (int i = 0; i < this.Count; i++)
            {
                sw.WriteLine(base[i]);
            }
        }
        public new int Add(string t)
        {
            if (!DuplicatesAllowed)
            {
                //need to debug here, if can't find, what will be return. Jun 25, 2008
                if (this.FindFirst(t) == string.Empty) 
                    return 0;
            }

           base.Add(t);

           return base.Count - 1;
        }

        private static string _str = string.Empty;
        private static bool match(string str)
        {
            if (str.Equals(_str))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public string FindFirst(string str)
        {
            _str = str;

            return base.Find(match);
        }

    }
}
