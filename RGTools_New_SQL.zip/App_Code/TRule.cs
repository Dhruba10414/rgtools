using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.ComponentModel;
using System.Diagnostics;


namespace RGTools_New
{
    class TRule
    {
        //friend class TInitRuleBound;
        private static long RuleCount=0;

        protected long _RuleID;
        protected long _ModuleSN;

        internal string Target;

        public TRule() { }
        public TRule(long pModuleSN, string pTarget)
        {
            if (RuleCount >= 0)
            {
                _RuleID = ++RuleCount;
            }
            else
            {
                _RuleID = --RuleCount;
            }
            Target = pTarget;
            _ModuleSN = pModuleSN;
        }
        public TRule(TRule X)
        {
            //_RuleID = ++RuleCount;
            if (RuleCount >= 0)
            {
                _RuleID = ++RuleCount;
            }
            else
            {
                _RuleID = --RuleCount;
            }

            Target = X.Target;
        }

        public virtual void Dump(StreamWriter swOutputPath) { }
        public virtual void Generate(StreamWriter swEfile, TSymbolTable SymbolTable){}
        public virtual bool ConditionReferences(ref string Reference) { return false; }
        public virtual void RenameComponent(ref string OldName, ref string NewName)
        {
            if (Target == OldName)
                Target = NewName;
        }

        public long GetModuleSN()
        {
            return _ModuleSN;
        }

        public long ModuleSN
        {
            get
            {
                return _ModuleSN;
            }
        }
        public static void InitRuleBound(long pSN) { RuleCount = pSN; }

        public static bool operator ==(TRule X1, TRule X2)
        {
            if (IsNull(X1) && IsNull(X2))
            {
                return true;
            }
            else if (IsNull(X1) || IsNull(X2))
            {
                return false;
            }
            else
            {
                return X1._RuleID == X2._RuleID ? true : false;
            }
        }
        public static bool operator !=(TRule X1, TRule X2)
        {
            if (IsNull(X1) && IsNull(X2))
            {
                return false;
            }
            else if (IsNull(X1) || IsNull(X2))
            {
                return true;
            }
            else
            {
                return X1._RuleID != X2._RuleID ? true : false;
            }
        }

        public static bool operator <(TRule X1, TRule X2)
        {
            return X1._RuleID < X2._RuleID ? true : false; 
        }
        public static bool operator >(TRule X1, TRule X2)
        {
            return X1._RuleID > X2._RuleID ? true : false; 
        }
        public static bool IsNull(TRule X)
        {
            return TRule.Equals(X, null);
        }
        public override bool Equals(object rule)
        {
            if (IsNull(rule as TRule))
            {
                return false;
            }
            else
            {
                return this._RuleID == (rule as TRule)._RuleID ? true : false;
            }
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }

    class TRuleList : List<TRule>
    {
        public TRuleList() { }//:TIArrayAsVector <TRule> (10,0,10) {}
        public void Dump(string OutputPath)
        {
            StreamWriter Efile=null;

            string ts = OutputPath + "\\RULEMAP.WIN";
            try
            {
                //Efile = new StreamWriter(ts);
                Efile = new StreamWriter(ts, false, Encoding.Default);
            }
            catch
            {
                throw (new Exception("Error: Could not create " + ts + "."));
            }
            for (int i = 0; i < base.Count; i++)
            {
                string Target = base[i].Target;
                //TRule t = base[i];
                base[i].Dump(Efile);
            }

            Efile.Close();
        }//throw (xmsg);

        public void Generate(string RootDirectory, TSymbolTable SymbolTable)
        {
            string ts = RootDirectory + "\\RULES.REM";
            StreamWriter Efile = null;
            try
            {
                //Efile = new StreamWriter(ts);
                Efile = new StreamWriter(ts, false, Encoding.Default);
            }
            catch
            {
                throw (new Exception("Error: Could not create " + ts + "."));
            }

            for (int i = 0; i < base.Count; i++)
            {
                base[i].Generate(Efile, SymbolTable);
            }
            Efile.Close();

            SymbolTable.SortSymbol();
        }// throw (xmsg);

        // MergeRules attempts to remove superfluous internal variables by looking for internal
        // variables which are generated and only used once.
        public void MergeRules(TSymbolTable SymbolTable) 
        {
            // Loop though all the rules, looking for rules which set an internal variable.
            for (int i = 0; i < base.Count; i++)
            {
                // Lookup the target variable.
                TSymbol Offset = SymbolTable.FindFirst(new TSymbol(base[i].Target));

                UTIL.Assert(Offset != null, "Assertion Failed: Offset != null!");

                // If it isn't an internal variable, cycle to next one.
                if (Offset.symbolType != SymbolType.SymInternalVariable) continue;

                // LastReferenced contains a pointer to the rule which references the variable
                // in it's condition.  If there are none, or there are more than one, the
                // variable LastReferenced is set to -1.
                int LastReferenced = -1;
                for (int j = 0; j < base.Count; j++)
                {
                    if (base[j].ConditionReferences(ref base[i].Target))
                    {
                        if (LastReferenced == -1)
                            LastReferenced = j;
                        else
                        {
                            LastReferenced = -1;
                            break;
                        }
                    }
                }
                // If the variable was referenced AND it was by a set rule, update the target of
                // the current rule to the target of the rule 'last referenced' and delete the
                // 'last referenced' rule.
                //if ((LastReferenced != -1) && (typeof(TSet).GUID == typeof(base[LastReferenced]).GUID))
                if ((LastReferenced != -1) && ("RGTools_New.TSet" == base[LastReferenced].GetType().ToString()))

                {
                    base[i].Target = base[LastReferenced].Target;
                    //Destroy(LastReferenced);
                    base.Remove(base[LastReferenced]);
                    //SymbolTable.Destroy(Offset);
                    SymbolTable.Remove(Offset);
                    i--;
                }
            }
        }//;

        // ResolveTargetDuplicates makes sure that all the results are unique. If more than one
        // result is the same, and or condition is created from each rules.  e.g.
        //
        //                P1 <- IFE Q1 'Y'
        //                P1 <- IFE Q2 'Y'
        //
        //            becomes
        //
        //                V1 <- IFE Q1 'Y'
        //                V2 <- IFE Q2 'Y'
        //                P1 <- OR V1 V2
        public void ResolveTargetDuplicates(TSymbolTable SymbolTable)
        {
            // Short circuit if nothing to do.
            if (base.Count < 2) return;

            // Cycle through all the rules looking for duplicate values.
            for (int i = 0; i < base.Count - 1; i++)
            {
                // Save the name of the target being matched.
                string Target = base[i].Target;

                // The current rule is the first rule to fix up.
                TRule FixupRule = base[i];
                // Now loop through the remaining rules looking for matches.
                for (int j = i + 1; j < base.Count; j++)
                    if (base[j].Target == Target)
                    {
                        // We have a match.
                        long ModuleSN = base[j].GetModuleSN();// ModuleSN;

                        // If the fixup rule is not the initial rule, add it to the rule list.
                        if (FixupRule != base[i])
                            Add(FixupRule);

                        // Or the two matching rules together and make the new or rule the
                        // fixup rule.
                        string V1 = SymbolTable.GenerateVariable(ModuleSN);
                        FixupRule.Target = V1;

                        string V2 = SymbolTable.GenerateVariable(ModuleSN);
                        base[j].Target = V2;

                        FixupRule = new TOr(ModuleSN, Target, V1, V2);
                    }

                // If the last fixup rule is not the initial rule, add it to the rule list.
                if (FixupRule != base[i])
                    Add(FixupRule);
            }
                        // Cycle through all the rules looking for duplicate values.
        }//;
        public void CleanSetStatements(TSymbolTable SymbolTable) 
        {
            // Loop though all the rules, looking for rules which set an internal variable.
            for (int i = 0; i < base.Count; i++)
            {
                // If this is a set statement and the target is an internal variable, merge the
                // references.
                //if (typeid(TSet) == typeid(base[i]))
                if ("RGTools_New.TSet" == base[i].GetType().ToString())
                {
                    // Lookup the target variable.
                    TSymbol Offset = SymbolTable.FindFirst(new TSymbol(base[i].Target));

                    UTIL.Assert(Offset != null, "Assertion Failed: Offset != null!");

                    // If it isn't an internal variable, cycle to next one.
                    if (Offset.symbolType != SymbolType.SymInternalVariable) continue;

                    string OldName = base[i].Target;
                    string NewName =  (base[i] as TSet).VID;

                    // replace oldname with new name everywhere.
                    for (int j = 0; j < base.Count; j++)
                    {
                        base[j].RenameComponent(ref OldName, ref NewName);
                    }
                    //Destroy(i);
                    base.Remove(base[i]);
                    //SymbolTable.Destroy(Offset);
                    SymbolTable.Remove(Offset);
                    i--;
                }
            }

        }//;
        public void ImposeHierarchy(TDomainTable DomainTable, TSymbolTable SymbolTable) 
        {
            for (int i = 0; i < DomainTable.Count; i++)
            {
                bool Matched = false;
                for (int j = 0; (j < base.Count) && !Matched; j++)
                    if (base[j].Target == DomainTable[i].DomainName)
                    {
                        string V=string.Empty;


                        //if (typeid(TSet) == typeid(base[j]))
                        if ("RGTools_New.TSet" == base[j].GetType().ToString())
                        {
                            V = (base[j] as TSet).VID;
                            base.Remove(base[j]);
                            //Destroy(j);
                        }
                        else
                        {
                            V = SymbolTable.GenerateVariable(base[j].ModuleSN);
                            base[j].Target = V;
                        }

                        Add(new TAnd(DomainTable[i].ModuleSN, DomainTable[i].DomainName, DomainTable[i].ParentName, V));
                        Matched = true;
                    }
                if (!Matched)
                    Add(new TSet(DomainTable[i].ModuleSN, DomainTable[i].DomainName, DomainTable[i].ParentName));
            }

            SymbolTable.SortSymbol();
        }//;
    }

    class TIFENumber : TRule
    {
        public string QID;
        public long Number;

        public TIFENumber(long pModuleSN, string pTarget, string pQID, long pNumber)
            : base(pModuleSN, pTarget)
        {
             QID =pQID;
             Number = pNumber;
        }

        public override bool ConditionReferences(ref string Reference)
        {
            return (Reference == QID) ? true : false;
        }
        public override void Dump(StreamWriter Efile) 
        {
            Efile.WriteLine( Target + "   <- IFE " + QID + "  " + Number.ToString());
        }
        public override void Generate(StreamWriter Efile, TSymbolTable SymbolTable) 
        {
            TSymbol TOffset = SymbolTable.FindFirst(new TSymbol(Target));

            UTIL.Assert(TOffset != null, "Assertion Failed: TOffset != null!");

            Efile.Write(_RuleID.ToString() + "," + TOffset.InternalSN.ToString() + ",");

            TSymbol AOffset = SymbolTable.FindFirst(new TSymbol(QID));

            UTIL.Assert(AOffset != null, "Assertion Failed: AOffset != null!");

            Efile.WriteLine("5," + AOffset.InternalSN.ToString() + "," + Number.ToString() + "," + _ModuleSN.ToString());// + endl;
        }
        public override void RenameComponent(ref string OldName, ref string NewName)
        {
            base.RenameComponent(ref OldName, ref NewName);
            if (QID == OldName)
                QID = NewName;
        }
    }

    class TIFEAnswer : TRule
    {
        public string QID;
        public string Answer;

        public TIFEAnswer(long pModuleSN, string pTarget, string pQID, string pAnswer) 
            : base(pModuleSN, pTarget)
        {
            QID =pQID;
            Answer = pAnswer;
        }

        public override bool ConditionReferences(ref string Reference)
        {
            return (Reference == QID) ? true : false;
        }
        public override void Dump(StreamWriter Efile)
        {
            Efile.WriteLine( Target + "   <- IFE " + QID + "  " + Answer);// + endl;
        }
        public override void Generate(StreamWriter Efile, TSymbolTable SymbolTable)
        {
            TSymbol TOffset = SymbolTable.FindFirst(new TSymbol(Target));

            UTIL.Assert(TOffset != null, "Assertion Failed: TOffset != null!");

            Efile.Write(_RuleID.ToString() + "," + TOffset.InternalSN.ToString() + ",");

            TSymbol AOffset = SymbolTable.FindFirst(new TSymbol(QID));

            UTIL.Assert(AOffset != null, "Assertion Failed: AOffset != null!");

            long AnswerCode = 0;
            if (Answer.IndexOf('Y') != -1)
                AnswerCode += 1;
            if (Answer.IndexOf('N') != -1)
                AnswerCode += 2;
            if (Answer.IndexOf('A') != -1)
                AnswerCode += 4;

            Efile.WriteLine("5," + AOffset.InternalSN.ToString() + "," + AnswerCode.ToString() + "," + _ModuleSN.ToString());
        }
        public override void RenameComponent(ref string OldName, ref string NewName)
        {
            base.RenameComponent(ref OldName, ref NewName);
            if (QID == OldName)
                QID = NewName;
        }
    }

    class TAnd : TRule
    {
        public string VID1;
        public string VID2;

        public TAnd(long pModuleSN, string pTarget, string pVID1, string pVID2)
            : base(pModuleSN, pTarget)
        {
            VID1 = pVID1;
            VID2 = pVID2;
        }

        public override bool ConditionReferences(ref string Reference) 
        {
            return ((Reference == VID1) || (Reference == VID2)) ? true : false;
        }
        public override void Dump(StreamWriter Efile) 
        {
            Efile.WriteLine(Target + "   <- AND " + VID1 + "  " + VID2);// + endl;
        }
        public override void Generate(StreamWriter Efile, TSymbolTable SymbolTable) 
        {
            TSymbol TOffset = SymbolTable.FindFirst(new TSymbol(Target));

            UTIL.Assert(TOffset != null, "Assertion Failed: TOffset != null!");

            Efile.Write(_RuleID.ToString() + "," + TOffset.InternalSN.ToString() + ",");


            TSymbol Offset1 = SymbolTable.FindFirst(new TSymbol(VID1));
            UTIL.Assert(Offset1 != null, "Assertion Failed: Offset1 != null!");

            TSymbol Offset2 = SymbolTable.FindFirst(new TSymbol(VID2));

            UTIL.Assert(Offset2 != null, "Assertion Failed: Offset2 != null!");

            Efile.WriteLine("1," + Offset1.InternalSN + "," + Offset2.InternalSN.ToString() + "," + _ModuleSN.ToString());
        }
        public override void RenameComponent(ref string OldName, ref string NewName)
        {
            base.RenameComponent(ref OldName, ref NewName);
            if (VID1 == OldName)
                VID1 = NewName;
            if (VID2 == OldName)
                VID2 = NewName;
        }
    }

    class TOr : TRule
    {
        public string VID1;
        public string VID2;

        public TOr(long pModuleSN, string pTarget, string pVID1, string pVID2)
                : base(pModuleSN, pTarget)
        { 
          VID1=pVID1;
          VID2 = pVID2;
        }

        public override bool ConditionReferences(ref string Reference) 
        {
            return ((Reference == VID1) || (Reference == VID2)) ? true : false;
        }
        public override void Dump(StreamWriter Efile) 
        {
            Efile.WriteLine(Target + "   <- OR " + VID1 + "  " + VID2);
        }
        public override void Generate(StreamWriter Efile, TSymbolTable SymbolTable) 
        {
            TSymbol TOffset = SymbolTable.FindFirst(new TSymbol(Target));

            Efile.Write(_RuleID.ToString() + "," + TOffset.InternalSN + ",");


            TSymbol Offset1 = SymbolTable.FindFirst(new TSymbol(VID1));
            UTIL.Assert(Offset1 != null, "Assertion Failed: Offset1 != null!");

            TSymbol Offset2 = SymbolTable.FindFirst(new TSymbol(VID2));
            UTIL.Assert(Offset2 != null, "Assertion Failed: Offset2 != null!");

            Efile.WriteLine("2," + Offset1.InternalSN.ToString() + "," + Offset2.InternalSN.ToString() + "," + _ModuleSN.ToString());// + endl;
        }
        public override void RenameComponent(ref string OldName, ref string NewName)
        {
            base.RenameComponent(ref OldName, ref NewName);
            if (VID1 == OldName)
                VID1 = NewName;
            if (VID2 == OldName)
                VID2 = NewName;
        }
    }

    class TForcedOr : TRule
    {
        public string VID1;
        public string VID2;

        public TForcedOr(long pModuleSN, string pTarget, string pVID1, string pVID2) 
            :base(pModuleSN, pTarget)
        { 
             VID1=pVID1;
             VID2 = pVID2;
        }

        public override bool ConditionReferences(ref string Reference) 
        {
            return ((Reference == VID1) || (Reference == VID2)) ? true : false;
        }
        public override void Dump(StreamWriter Efile) 
        {
            Efile.WriteLine(Target + "   <- F-OR " + VID1 + "  " + VID2);
        }
        public override void Generate(StreamWriter Efile, TSymbolTable SymbolTable) 
        {
            TSymbol TOffset = SymbolTable.FindFirst(new TSymbol(Target));

            UTIL.Assert(TOffset != null, "Assertion Failed: TOffset != null!");

            Efile.WriteLine(_RuleID.ToString() + "," + TOffset.InternalSN + ",");


            TSymbol Offset1 = SymbolTable.FindFirst(new TSymbol(VID1));

            UTIL.Assert(Offset1 != null, "Assertion Failed: Offset1 != null!");

            TSymbol Offset2 = SymbolTable.FindFirst(new TSymbol(VID2));

            UTIL.Assert(Offset2 != null, "Assertion Failed: Offset2 != null!");

            Efile.WriteLine("6," + Offset1.InternalSN.ToString() + "," + Offset2.InternalSN.ToString() + "," + _ModuleSN.ToString());// + endl;
        }

    }

    class TNot : TRule
    {
        public string VID;

        public TNot(long pModuleSN, string pTarget, string pVID)
             : base(pModuleSN, pTarget)
        {
            VID = pVID;
        }

        public override bool ConditionReferences(ref string Reference) 
        {
            return (Reference == VID) ? true : false;
        }
        public override void Dump(StreamWriter Efile)
        {
            Efile.WriteLine(Target + "   <- NOT " + VID);// + endl;
        }
        public override void Generate(StreamWriter Efile, TSymbolTable SymbolTable) 
        {
            TSymbol TOffset = SymbolTable.FindFirst(new TSymbol(Target));
            UTIL.Assert(TOffset != null, "Assertion Failed: TOffset != null!");

            Efile.Write(_RuleID.ToString() + "," + TOffset.InternalSN.ToString() + ",");


            TSymbol Offset = SymbolTable.FindFirst(new TSymbol(VID));

            UTIL.Assert(Offset != null, "Assertion Failed: Offset != null!");

            Efile.WriteLine("3," + Offset.InternalSN.ToString() + ",0" + "," + _ModuleSN.ToString());// + endl;
        }
        public override void RenameComponent(ref string OldName, ref string NewName)
        {
            base.RenameComponent(ref OldName, ref NewName);
            if (VID == OldName)
                VID = NewName;
        }
    }

    class TSet : TRule
    {
        public string VID;

        public TSet(long pModuleSN, string pTarget, string pVID) 
            :base(pModuleSN, pTarget)
        {
            VID = pVID;
        }

        public override bool ConditionReferences(ref string Reference)
        {
            return (Reference == VID) ? true : false; 
        }
        public override void Dump(StreamWriter Efile) 
        {
            Efile.WriteLine(Target + "   <- " + VID);// endl;
        }
        public override void Generate(StreamWriter Efile, TSymbolTable SymbolTable) 
        {
            TSymbol TOffset = SymbolTable.FindFirst(new TSymbol(Target));
            UTIL.Assert(TOffset != null, "Assertion Failed: TOffset != null!");

            Efile.Write(_RuleID.ToString() + "," + TOffset.InternalSN.ToString() + ",");

            TSymbol Offset = SymbolTable.FindFirst(new TSymbol(VID));
            UTIL.Assert(Offset != null, "Assertion Failed: Offset != null!");

            Efile.WriteLine("4," + Offset.InternalSN.ToString() + ",0" + "," + _ModuleSN.ToString());// + endl;
        }
        public override void RenameComponent(ref string OldName, ref string NewName)
        {
            base.RenameComponent(ref OldName, ref NewName);
            if (VID == OldName)
                VID = NewName;
        }
    }

    class TSetComplete : TRule
    {
        public string VID;

        public TSetComplete(long pModuleSN, string pTarget, string pVID)
            : base(pModuleSN, pTarget)
        {
            VID = pVID;
        }

        public override bool ConditionReferences(ref string Reference) 
        {
            return (Reference == VID) ? true : false;
        }
        public override void Dump(StreamWriter Efile) 
        {
            Efile.WriteLine(Target + "   (SC)<- " + VID);//+ endl;
        }
        public override void Generate(StreamWriter Efile, TSymbolTable SymbolTable) 
        {
            TSymbol TOffset = SymbolTable.FindFirst(new TSymbol(Target));
            UTIL.Assert(TOffset != null, "Assertion Failed: TOffset != null!");

            Efile.WriteLine(_RuleID.ToString() + "," + TOffset.InternalSN.ToString() + ",");

            TSymbol Offset = SymbolTable.FindFirst(new TSymbol(VID));
            UTIL.Assert(Offset != null, "Assertion Failed: Offset != null!");

            Efile.WriteLine("7," + Offset.InternalSN.ToString() + ",0" + "," + _ModuleSN.ToString());// + endl;
        }
        public override void RenameComponent(ref string OldName, ref string NewName)
        {
            base.RenameComponent(ref OldName, ref NewName);
            if (VID == OldName)
                VID = NewName;
        }
    }
}
