using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace RGTools_New
{
    enum TMClass { tmQuestion, tmDomain }

    class NSTATUS
    {
        public static void TranslateModule(StreamWriter oFile, string RebuildDirectory, TMClass pTMClass) //throw (xmsg)
        {
            string What=string.Empty;

            switch (pTMClass)
            {
                case TMClass.tmQuestion:
                    What = "QUEST-SN";
                    oFile.WriteLine("Question Changes:");
                    break;

                case TMClass.tmDomain:
                    What = "DOMAINSN";
                    oFile.WriteLine("Domain Changes:");
                    break;
            }

            StreamReader OldIndex = new StreamReader(RebuildDirectory + @"\" + What + ".old", Encoding.Default);
            TSerialMap OldSNMap = new TSerialMap();

            long ChangeCount = 0L;

            if (OldIndex==null)
                throw (new Exception("Error: Could not open " + RebuildDirectory + @"\" + What + ".OLD."));

            string InputLine = "";
            while ((InputLine = OldIndex.ReadLine()) != null)
            {
                string[] fiels = InputLine.Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);

                if (fiels.Length < 3)
                {
                    throw (new Exception("Error: Format not correct in " + RebuildDirectory + @"\" + What + ".OLD."));
                }

                string ts = fiels[1];
                string DisplaySegment = fiels[2];

                OldSNMap.Add(new TSerialMapItem(ts, DisplaySegment));
            }

            StreamReader NewIndex = null;

            try
            {
                NewIndex = new StreamReader(RebuildDirectory + @"\" + What + ".txt", Encoding.Default);
            }
            catch
            {
                throw (new Exception("Error: Could not open " + RebuildDirectory + @"\" + What + ".TXT."));
            }
            TSerialMap NewSNMap=new TSerialMap();

            while ((InputLine = NewIndex.ReadLine()) != null)
            {
                string[] fiels = InputLine.Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);

                if (fiels.Length < 3)
                {
                    throw (new Exception("Error: Format not correct in " + RebuildDirectory + @"\" + What + ".TXT."));
                }

                string ts = fiels[1];
                string DisplaySegment = fiels[2];

                NewSNMap.Add(new TSerialMapItem(ts, DisplaySegment));
            }


            foreach (TSerialMapItem pSMItem in OldSNMap)
            {
                string temp = "";
                if (!NewSNMap.Map(pSMItem.OldNumber, ref temp))
                {
                    ChangeCount++;
                    oFile.WriteLine("Deleted " + pSMItem.OldNumber + " " + pSMItem.NewNumber);
                }
            }

            foreach (TSerialMapItem pSMItem in NewSNMap)
            {
                string temp = "";
                if (!OldSNMap.Map(pSMItem.OldNumber, ref temp))
                {
                    ChangeCount++;
                    oFile.WriteLine("Added " + pSMItem.OldNumber + " " + pSMItem.NewNumber);
                }
            }

            if (ChangeCount == 0)
            {
                oFile.WriteLine("  No Changes.");
            }

            return;
        }
    }
}
