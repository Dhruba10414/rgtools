//----------------------------------------------------------------------------
//  Project RGTools
//  Dakota Software Corporation
//  Copyright � 1997. All Rights Reserved.
//  FILE:    pgdelmod.h
//  AUTHOR:  Marc CHANTEGREIL
//
//  OVERVIEW
//  ~~~~~~~~
//  Class definition for TPageDelmod (TPageWithDB).
//
//----------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.IO;
//using ODBCMngr;
using System.Data.SqlClient;

//******************************************************************
//**//// TPageDelmod ///////////////////////////////////////////////
//******************************************************************
namespace RGTools_New
{
    class TPageDelmod //: public TPageWithDB
    {
        const string __SQLV_pgdelmod_53 = "COMMIT WORK";

        private frmMain _main = null;
        string SQL = string.Empty;
        DataSql sqlbase = null;

        // Constructors
        public TPageDelmod(frmMain Main)
        {
            _main = Main;
            sqlbase = new DataSql(_main.txtDelModServer.Text, _main.txtDelModDB.Text, _main.DelModuleUser, _main.DelModulePW);
            sqlbase.callBack += new DataSql.Display(sybase_callBack);
            sqlbase.checkCancel += new DataSql.IsCancel(IsCancel);
       }

        internal bool IsCancel()
        {
            return _main.cancelPressed;
        }

        //DataSet ds = null;
        SqlTransaction transaction = null;

        public void DoProcess()
        {
            // We must call first the base class method.
            _main.OutMsg(PageType.ModuleDeletion, "\r\n");
            _main.OutMsg(PageType.ModuleDeletion, "Process started at: " + DateTime.Now.ToShortTimeString() + ".\r\n");
            _main.OutMsg(PageType.ModuleDeletion, "Preparing the database.\r\n");

            try
            {
                sqlbase.Open();
                transaction = sqlbase.BeginTransaction();
                sqlbase.RunSQL(Query.DeleteConstrains, true);
                // Now, loop on all the modules of the ModDelete list box and call the method DeleteModule for each of them.
                for (int Index = 0; Index < _main.lstDelModSel.Items.Count; Index++)
                {
                    ModuleListItem _delItem = (ModuleListItem)_main.lstDelModSel.Items[Index];

                    // Update the report status.
                    _main.OutMsg(PageType.ModuleDeletion, _delItem.ModuleName + ".\r\n");

                    // Delete the current module from the database.  GetItemData returns the ModuleSN.
                    DeleteModule(_delItem.ModuleSN);

                    if (CheckForCancel || processFailed)
                    {
                        break;
                    }
                }

                if (!CheckForCancel && !processFailed)
                {
                    sqlbase.RunSQL(Query.CreateConstrains, true);
                    transaction.Commit();
                }
                else
                {
                    transaction.Rollback();
                }
            }
            catch
            {
                //transaction.Rollback();
            }
            finally
            {
                sqlbase.Close();
            }
        }

        void DeleteModule(long ModuleSN)
        {
            string[] SQL = new string[28];
            string[] MSG = new string[28];

            for (int i = 0; i < SQL.Length; i++)
            {
                SQL[i] = string.Empty;
            }

            SQL[0] = "DELETE FROM Module WHERE ModuleSN =" + ModuleSN.ToString();
            MSG[0] = "Update table Module.\r\n";

            SQL[1] = "DELETE FROM ModuleVersion WHERE ModuleSN =" + ModuleSN.ToString();
            MSG[1] = "Update table ModuleVersion.\r\n";

            SQL[2] = "DELETE FROM DomainStructure WHERE ModuleSN =" + ModuleSN.ToString();
            MSG[2] = "Update table DomainStructure.\r\n";

            SQL[3] = "DELETE FROM Blob WHERE Class in (1,2,3,4,8) AND SN =" + ModuleSN.ToString();
            MSG[3] = "Update table Blob.\r\n";

            SQL[4] = "DELETE FROM Blob WHERE (Class = 5 OR Class = 6 OR Class = 7) AND SN IN " +
                    "(SELECT DomainSN FROM DomainStructure WHERE ModuleSN =" + ModuleSN.ToString() + ")";
            MSG[4] = "";

            SQL[5] = "DELETE FROM QDLink WHERE ModuleSN =" + ModuleSN.ToString();
            MSG[5] = "Update table QDLink.\r\n";

            SQL[6] = "DELETE FROM QSLink WHERE ModuleSN =" + ModuleSN.ToString();
            MSG[6] = "Update table QSLink.\r\n";

            SQL[7] = "DELETE FROM ApplicabilityVariable WHERE ModuleSN = " + ModuleSN.ToString();
            MSG[7] = "Update table ApplicabilityVariable.\r\n";

            SQL[8] = "DELETE FROM ScreenGoal WHERE ModuleSN = " + ModuleSN.ToString();
            MSG[8] = "Update table ScreenGoal.\r\n";

            SQL[9] = "DELETE FROM TemplateRule WHERE ModuleSN = " + ModuleSN.ToString();
            MSG[9] = "Update table TemplateRule.\r\n";

            SQL[10] = "DELETE FROM RGKeyWord WHERE ModuleSN = " + ModuleSN.ToString();
            MSG[10] = "Update table RGKeyWord.\r\n";

            SQL[11] = "DELETE FROM RGTOC WHERE ModuleSN = " + ModuleSN.ToString();
            MSG[11] = "Update table RGTOC.\r\n";

            SQL[12] = "DELETE FROM StateModule WHERE ModuleSN = " + ModuleSN.ToString();
            MSG[12] = "Update table StateModule.\r\n";

            SQL[13] = "DELETE FROM StateDomainStructure  WHERE ModuleSN = " + ModuleSN.ToString();
            MSG[13] = "Update table StateDomainStructure .\r\n";

            SQL[14] = "DELETE FROM BlobState WHERE Class = 2 AND ModuleSN = " + ModuleSN.ToString();
            MSG[14] = "Update table BlobState.\r\n";

            SQL[15] = "DELETE FROM SDVLink WHERE NOT EXISTS (SELECT StateDomainSN FROM StateDomainStructure WHERE StateDomainStructure.StateDomainSN = SDVLink.StateDomainSN)";
            MSG[15] = "Update table SDVLink.\r\n";

            SQL[16] = "DELETE FROM QDStateLink WHERE NOT EXISTS (SELECT StateDomainSN FROM SDVLink WHERE SDVLink.StateDomainSN = QDStateLink.StateDomainSN)";
            MSG[16] = "Update table QDStateLink.\r\n";

            SQL[17] = "DELETE FROM QCountState WHERE NOT EXISTS (SELECT StateDomainSN FROM SDVLink WHERE SDVLink.StateDomainSN = QCountState.StateDomainSN)";
            MSG[17] = "Update table QCountState.\r\n";

            SQL[18] = "DELETE FROM StateSection WHERE NOT EXISTS (SELECT StateDomainSN FROM SDVLink WHERE SDVLink.StateDomainSN = StateSection.StateDomainSN)";
            MSG[18] = "Update table StateSection.\r\n";

            SQL[19] = "DELETE FROM Question WHERE NOT EXISTS (SELECT QuestionSN FROM QDLink WHERE QDLink.QuestionSN = Question.QuestionSN) AND NOT EXISTS (SELECT ApplicSN FROM ApplicabilityVariable WHERE AClass = 'Q' AND ASN = Question.QuestionSN) AND NOT EXISTS (SELECT QuestionSN FROM QDStateLink WHERE QDStateLink.QuestionSN = Question.QuestionSN)";
            MSG[19] = "Update table Question.\r\n";

            SQL[20] = "DELETE FROM QuestionBody WHERE NOT EXISTS (SELECT QuestionSN FROM Question WHERE Question.QuestionBodySN = QuestionBody.QuestionBodySN)";
            MSG[20] = "Update table QuestionBody.\r\n";

            SQL[21] = "DELETE FROM RGSection WHERE ModuleSN = " + ModuleSN.ToString();
            MSG[21] = "Update table RGSection.\r\n";

            SQL[22] = "DELETE FROM RGSection WHERE NOT EXISTS (SELECT SectionSN FROM RGTOC WHERE RGTOC.SectionSN = RGSection.SectionSN) AND NOT EXISTS (SELECT SectionSN FROM RGKeyWord WHERE RGkeyWord.SectionSN = RGSection.SectionSN) AND NOT EXISTS (SELECT SectionSN FROM StateSection WHERE StateSection.SectionSN = RGSection.SectionSN)";
            MSG[22] = "";

            SQL[23] = "DELETE FROM QRLink WHERE NOT EXISTS (SELECT QuestionSN FROM Question WHERE Question.QuestionSN = QRLink.QuestionSN) OR NOT EXISTS (SELECT ReferenceSN FROM RGKeyWord WHERE RGKeyWord.ReferenceSN = QRLink.ReferenceSN)";
            MSG[23] = "Update table QRLink.\r\n";

            string ret = sqlbase.RunSQL(SQL, MSG, true, true);
            if (ret != string.Empty)
            {
                ErrorThrow(ret);
                return;
            }

        }

        private void ErrorThrow(string message)
        {
            if (message != string.Empty)
            {
                _main.OutMsg(PageType.ModuleDeletion, message + ".\r\n");
                _main.processFailed = true;
            }
        }

        private void sybase_callBack(string message)
        {
            _main.OutMsg(PageType.ModuleDeletion, message);
        }

        private bool CheckForCancel
        {
            get
            {
                return _main.cancelPressed;
            }
        }
        private bool processFailed
        {
            get
            {
                return _main.processFailed;
            }
        }

        private List<string> GetMinMaxGroups(DataTable db, string FieldName)
        {
            List<string> lstMaxMin = new List<string>();

            long minSN = -1;
            long maxSN = -1;

            long previous = -1;
            long current = -1;

            const long skip = 2;

            for (int i = 0; i < db.Rows.Count; i++)
            {
                DataRow row = db.Rows[i];
                
                previous = current;
                current = long.Parse(row[FieldName].ToString());

                if (minSN < 0)
                {
                    minSN = current;
                }

                maxSN = current;
                if (previous != -1)
                {
                    if (current - previous > skip)
                    {
                        lstMaxMin.Add(minSN.ToString());
                        lstMaxMin.Add(previous.ToString());

                        minSN = current;
                    }
                }

            }

            lstMaxMin.Add(minSN.ToString());
            lstMaxMin.Add(maxSN.ToString());

            return lstMaxMin;
        }

        private static string _str_match = null;
        private static bool match(string str)
        {
            if (_str_match == str)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }

}

