using System;
using System.Collections.Generic;
using System.Text;

namespace RGTools_New
{
    class CTimer
    {
        protected static float m_lTime = 0;
        protected static float m_start = 0;
        protected static float m_end = 0;

        //private timeb XYZInternalTimer;

        public CTimer()
        {
        }

        public void ResetTimer() { m_lTime = 0; }
        public void StartTimer()
        {
            DateTime dt = new DateTime();
            m_lTime = (dt.Ticks - m_start) / 1000000;

        }
        public void StopTimer()
        {
            DateTime dt = new DateTime();
            m_start = dt.Ticks;
        }

        public float GetTimer() { return m_lTime; }
    }
}
