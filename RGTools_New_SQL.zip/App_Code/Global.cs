using System;
using System.Collections.Generic;
using System.Text;

namespace RGTools_New
{
    class GlobalStructures
    {

        private static long g_Margin;
        private static bool g_DefinitionActive = false;
        //private static bool g_HasGlossary;
        private static bool g_ListActive = false;
        private static bool g_TableActive = false;
        private static long g_ModuleSN;
        private static string g_ModuleName;

        public static void SetMargin()
        {
            g_Margin = 0;
        }
        public static void SetMargin(long pDepth)
        {
            {
                if ((pDepth < 0) || (pDepth > 2))
                {
                    throw (new Exception("Internal Error: Bad Margin Value"));
                }
                g_Margin = pDepth;
            }
        }//throw (xmsg);
        public static long GetMargin() { return g_Margin; }
        public static long Margin
        {
            set
            {
                if ((value < 0) || (value > 2))
                {
                    throw (new Exception("Internal Error: Bad Margin Value"));
                }
                g_Margin = value;
            }
            get
            {
                return g_Margin;
            }
        }

        public static void SetDefinitionActive()
        {
            g_DefinitionActive = true;
        }
        public static void ClearDefinitionActive()
        {
            g_DefinitionActive = false;
            g_Margin = 0;
            //SetMargin ();
        }
        public static bool DefinitionActive
        {
            set
            {
                g_DefinitionActive = value;
            }
            get
            {
                return g_DefinitionActive;
            }
        }

        public static void SetListActive()
        {
            if (g_ListActive)
            {
                throw (new Exception("You must end a LIST before you start a new one"));
            }

            if (g_TableActive)
            {
                throw (new Exception("You can't have a LIST within a TABLE"));
            }

            g_ListActive = true;
        }

        //Added on Dec 17, 2009
        public static void InitTableListActive()
        {
            g_ListActive = false;
            g_TableActive = false;
        }

        public static void ClearListActive()
        {
            if (!g_ListActive)
            {
                throw (new Exception("You tried to END LIST before defining one"));
            }

            g_ListActive = false;
            g_Margin = 0;
            //SetMargin ();
        }
        public static bool ListActive
        {
            set
            {
                if (value)
                {
                    if (g_ListActive)
                    {
                        throw (new Exception("You must end a LIST before you start a new one"));
                    }

                    if (g_TableActive)
                    {
                        throw (new Exception("You can't have a LIST within a TABLE"));
                    }
                }
                else
                {
                    g_Margin = 0;
                }

                g_ListActive = value;
            }
            get
            {
                return g_ListActive;
            }
        }

        public static void SetTableActive()
        {
            if (g_TableActive)
            {
                throw (new Exception("You must end a TABLE before you start a new one"));
            }

            if (g_ListActive)
            {
                throw (new Exception("You can't have a TABLE within a LIST"));
            }

            g_TableActive = true;
        }
        public static void ClearTableActive()
        {
            if (!g_TableActive)
            {
                throw (new Exception("You tried to END TABLE before defining one"));
            }

            g_TableActive = false;
            g_Margin = 0;
            //SetMargin();
        }
        public static bool TableActive
        {
            set
            {
                if (value)
                {
                    if (g_TableActive)
                    {
                        throw (new Exception("You must end a TABLE before you start a new one"));
                    }

                    if (g_ListActive)
                    {
                        throw (new Exception("You can't have a TABLE within a LIST"));
                    }
                }
                else
                {
                    g_Margin = 0;
                    //SetMargin ();
                }
                g_TableActive = value;
            }
            get
            {
                return g_TableActive;
            }
        }

        public static void SetModuleSN(long pModuleSN) { g_ModuleSN = pModuleSN; }
        public static long GetModuleSN() { return g_ModuleSN; }
        public static long ModuleSN
        {
            set
            { g_ModuleSN = value; }
            get
            {
                return g_ModuleSN;
            }
        }

        public static void SetModuleName(string pModuleName) { g_ModuleName = pModuleName; }
        public static string GetModuleName() { return g_ModuleName; }
        public static string ModuleName
        {
            set
            { g_ModuleName = value; }
            get
            {
                return g_ModuleName;
            }
        }

        public GlobalStructures()
        {
        }
    }
}
