using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Runtime.InteropServices;

namespace RGTools_New
{
    /*  Copyright (c) 1995 All Rights Reserved, Dakota Software Corporation.
    FILE:         SQLDB.H
    AUTHOR:       Marc CHANTEGREIL
    OVERVIEW
    ========
    Class definition for CSQL, CSQLDataBase, CSQLSet.
    Definition of all the generic classes useful to manage the interface between WATCOM SQL and C++.
    CSQLSet is a pure virtual class. You have to derive your own class.

    CSQL: This class is useful to declare that the application will use embedded SQL.
          You must declare only one object of this class in your application
         (recommended to declare it as a data member of your TApplication object).

    CSQLDataBase:  Declare one object of this class per Database. Useful to open, close a database.

    CSQLSet: Use to manage a set of values from the database. It is often an entity or a relation.
             When you have defined your set of values, you have to define the queries you want for
             this set (Select All, Select for a condition, ...).
             A set has one cursor at a time (a cursor is associated with a query). If you want
             several cursors in the same time on the same set of values, declare one object per cursor
             and select for each cursor the associated query.
             See the associated documentation for more information.

             To define correctly a CSQLSet Derived class, you have to:
                  1. Identify the table(s) concerned and the fields to load or set.
                  2. Set m_iField in your ructor to the number of field.
                  3. Define your protected data member (1 per field).
                  4. Define the function GetFieldCount()() (inline if possible).
                  5. Overrides the method ClearAllFields().
                  6. Overrrides the ExchangeData() method.
                  7. Define your Query method. Don't use "Select * From ..." in your Query, but list all the fields
                     you want.
                     Take an example to illustrate the steps.
                  8. If you have a LONG VARCHAR WATCOM field to handle, you have to modify your Selectxxx() functions
                     by defining a BigQuery string and passing it to the SELECT statement.
                  9. Add a ExchangeBigField() for each LONG VARCHAR to handle (see CMQuestionSet in SQLMODUL.H).

    REVISION HISTORY
    ================
    REMARK : for CSQLSet, the management of null value for an int and a char are not well defined.
             the update methods (add, delete, update) must also be tested and probably completed.
    REMARK : the management and handling of the errors are to be revised. We can probably manage the errors
             using the exception mechanism.

*/

    //***************************************************************************
    //**////////// CSQLSet  /////////////////////////////////////////////////////
    //***************************************************************************
    public enum TypeSet {NormalSet, MiniSet };
    
    class CSQLSet :DataSql           
    {
        internal virtual DataSet BaseDataSet
        {
            get { return dsBase; }
            set
            {
                //_dsWeakRef = new WeakReference(dsBase, false);
                //_ds = _dsWeakRef.Target as DataSet;

                if (_ds != null)
                {
                    int generation = GC.GetGeneration(_ds);

                    _ds = null;
                    GC.Collect(generation);
                    GC.WaitForPendingFinalizers();
                }

                _ds = dsBase.Copy();

                if (_ds.Tables.Count > 0 && _ds.Tables[0].Rows.Count > 0)
                {
                    _index = 0;
                }
                else
                {
                    _index = -1;
                }
            }
        }

        //private WeakReference _dsWeakRef = null;
        private DataSet _ds = null;
        private DataRow _row = null;
        private int _index = -1;

        private SqlDataReader _reader = null;

        internal virtual void ExchangeData(EnumAction Action) { }
        internal virtual void ExchangeDataDS(EnumAction Action) { }
        // Data Members
        protected string m_sListField;       // List of the fields for the Select statement.
        private string m_sTable;           // name of the physical table in the database.

        private string dbServer = string.Empty;
        private string dbDB = string.Empty;
        private string dbUser = string.Empty;
        private string dbPassWord = string.Empty;
        //********** Constructors, Destructors ************************************
        // pSQLDataBase : a set owns to a CSQLDatabase object necessarily.
        // Table : name of the physical table (if "", you cannot use the Add() method).

        //********** Constructors, Destructors ************************************
        public CSQLSet(string Table)
            : base()
        {
            //sybase = new DataSybase(DSN, User, PassWord);
            m_sTable = Table;

        }

        public CSQLSet(string Table, string Server, string DB, string User, string PassWord)
            : base(Server, DB, User, PassWord)
        {
            //sybase = new DataSybase(DSN, User, PassWord);
            m_sTable = Table;

            dbServer = Server;
            dbDB = DB;
            dbUser = User;
            dbPassWord = PassWord;
        }

        ~CSQLSet()
        {
            if (_ds != null)
            {
                int generation = GC.GetGeneration(_ds);

                _ds = null;
                GC.Collect(generation);
                GC.WaitForPendingFinalizers();
            }
        }
        //********** Overridables methods *****************************************
        //public enum EnumAction { GET = 1, PUT };
        public virtual void ClearAllFields()
        {
            if (_reader != null && !_reader.IsClosed)
            {
                _reader.Close();
            }
            _reader = null;
        }// = 0;                 // Also a public method.
        //protected  virtual void ExchangeData(EnumAction Action){}// = 0;
        protected virtual short GetFieldCount() { return 0; }// = 0;          // number of Fields of your derived Set (without the BigField).

        protected EnumSQLError SelectUniqueQueryDS(string ListFields, string filter, string sort)
        {
            try
            {
                BeginQueryDS(ListFields, filter, sort);

                if (_index == -1)
                {
                    return EnumSQLError.DB_NOTFOUND;
                }

                FetchNextDS();
                ExchangeDataDS(EnumAction.GET);

                if (_ds.Tables[0].Rows.Count > 1)
                {
                    return EnumSQLError.DB_MULTIPLEROW;
                }

                return EnumSQLError.DB_NOERROR;
            }
            catch//(Exception e)
            {
                return EnumSQLError.DB_NOTFOUND;
            }
        }

        internal void BeginQueryDS(string ListFields, string filter, string sort)
        {
            //if (_ds != null && _ds != dsBase)
            if (_ds != null)
            {
                int generation = GC.GetGeneration(_ds);

                _ds = null;
                GC.Collect(generation);
                GC.WaitForPendingFinalizers();
            }

            _ds = new DataSet();
            GetDataSet(filter, sort, ref _ds);

            if (_ds.Tables.Count > 0 && _ds.Tables[0].Rows.Count > 0)
            {
                _index = 0;
            }
            else
            {
                _index = -1;
            }
        }

        protected void BeginQuery(string Query)
        {
            if (Query.Trim() != string.Empty)
            {
                try
                {
                    if (!_reader.IsClosed)
                    {
                        _reader.Close();
                    }
                }
                catch //(Exception e)
                { }

                _reader = GetReader(Query);
            }
        }

        protected void BeginQueryBase(string Query)
        {
            BeginQueryBase(Query, false);
        }
        protected void BeginQueryBase(string Query, bool DisableBase)
        {
            _index = -1;

            try
            {
                if (!DisableBase)
                {
                    BaseDataSet = GetBaseDataSet(Query);
                }
                else
                {
                    if (_ds != null)
                    {
                        int generation = GC.GetGeneration(_ds);

                        _ds = null;
                        GC.Collect(generation);
                        GC.WaitForPendingFinalizers();
                    }

                    _ds = new DataSet();
                    GetDataSet(Query, ref _ds);

                    if (_ds.Tables[0].Rows.Count > 0)
                    {
                        _index = 0;
                    }
                }


                //long totalMem = GC.GetTotalMemory(false);

                //int reg = GC.GetGeneration(_ds);
                //_ds = null;
                //GC.Collect(reg);
                //GC.WaitForPendingFinalizers();

                //ReleaseBaseDataSet();
                //int reg = GC.GetGeneration(dsBase);
                //dsBase = null;
                //GC.Collect(reg);
                //GC.WaitForPendingFinalizers();
                //GC.Collect();
                //GC.WaitForPendingFinalizers();
                ////totalMem = GC.GetTotalMemory(true);

            }
            catch
            {
                _index = -1;
                //BaseDataSet = null;

                _ds = null;
            }
        }

        private SqlDataReader BeginQueryReader(string Query)
        {
            if (Query.Trim() != string.Empty)
            {
                return GetReader(Query);
            }

            return null;
        }       

        public void Reset()
        {
            //EndQuery();
            ClearAllFields();
        }     // Close the cursor if one opened. Reset the data members (call ClearAllProperties).

        protected void ExchangeField(EnumAction Action, short NoField, ref short Field)
        {
            if (Action == EnumAction.GET && _reader != null && !_reader.IsClosed)
            {
                try
                {
                    Field = _reader.GetInt16(NoField);// short.Parse(Row[NoField].ToString());
                }
                catch// (Exception e)
                {
                    Field = -1;
                }
            }
        }
        //***************************************************************************
        protected void ExchangeField(EnumAction Action, short NoField, ref int Field)
        {
            if (Action == EnumAction.GET && _reader != null && !_reader.IsClosed)
            {
                try
                {
                    Field = _reader.GetInt16(NoField);// int.Parse(Row[NoField].ToString());
                }
                catch //(Exception e)
                {
                    Field = -1;
                }
            }
        }

        //---------------------------------------------------------------------------
        protected void ExchangeField(EnumAction Action, short NoField, ref long Field)
        {
            if (Action == EnumAction.GET && _reader != null && !_reader.IsClosed)
            {
                try
                {
                    Field = _reader.GetInt32(NoField);// long.Parse(Row[NoField].ToString());
                }
                catch//(Exception e)
                {
                    Field = -1;
                }
            }
        }

        //---------------------------------------------------------------------------
        protected void ExchangeField(EnumAction Action, short NoField, ref float Field)
        {
            if (Action == EnumAction.GET && _reader != null && !_reader.IsClosed)
            {
                try
                {
                    Field = _reader.GetFloat(NoField);// float.Parse(Row[NoField].ToString());
                }
                catch// (Exception e)
                {
                    Field = -1;
                }
            }
        }
        protected void ExchangeField(EnumAction Action, short NoField, ref string Field)
        {
            if (Action == EnumAction.GET && _reader != null && !_reader.IsClosed)
            {
                try
                {
                    Field = _reader.GetString(NoField);// Row[NoField].ToString();
                }
                catch //(Exception e)
                {
                    Field = string.Empty;
                }
            }
        }
        //---------------------------------------------------------------------------
        protected void ExchangeField(EnumAction Action, short NoField, ref DateTime Field)
        {
            if (Action == EnumAction.GET && _reader != null && !_reader.IsClosed)
            {
                try
                {
                    Field = _reader.GetDateTime(NoField);// DateTime.Parse(Row[NoField].ToString());
                }
                catch// (Exception e)
                {
                    Field = DateTime.Now;
                }
            }
        }

        //***************************************************************************
        protected void ExchangeFieldDS(EnumAction Action, short NoField, ref short Field)
        {
            if (Action == EnumAction.GET && _row != null)
            {
                //try
                //{
                Field = short.Parse(_row[NoField].ToString());
                //}
                //catch// (Exception e)
                //{
                //    Field = -1;
                //}
            }
        }
        protected void ExchangeFieldDS(EnumAction Action, short NoField, ref int Field)
        {
            if (Action == EnumAction.GET && _row != null)
            {
                //try
                //{
                Field = int.Parse(_row[NoField].ToString());
                //}
                //catch //(Exception e)
                //{
                //    Field = -1;
                //}
            }
        }

        //---------------------------------------------------------------------------
        protected void ExchangeFieldDS(EnumAction Action, short NoField, ref long Field)
        {
            if (Action == EnumAction.GET && _row != null)
            {
                //try
                //{
                Field = long.Parse(_row[NoField].ToString());
                //}
                //catch//(Exception e)
                //{
                //    Field = -1;
                //}
            }
        }

        //---------------------------------------------------------------------------
        protected void ExchangeFieldDS(EnumAction Action, short NoField, ref float Field)
        {
            if (Action == EnumAction.GET && _row != null)
            {
                //try
                //{
                Field = float.Parse(_row[NoField].ToString());
                //}
                //catch// (Exception e)
                //{
                //    Field = -1;
                //}
            }
        }
        protected void ExchangeFieldDS(EnumAction Action, short NoField, ref string Field)
        {
            if (Action == EnumAction.GET && _row != null)
            {
                //try
                //{
                Field = _row[NoField].ToString();
                //}
                //catch //(Exception e)
                //{
                //    Field = string.Empty;
                //}
            }
        }
        //---------------------------------------------------------------------------
        protected void ExchangeFieldDS(EnumAction Action, short NoField, ref DateTime Field)
        {
            if (Action == EnumAction.GET && _row != null)
            {
                //try
                //{
                Field = DateTime.Parse(_row[NoField].ToString());
                //}
                //catch// (Exception e)
                //{
                //    Field = DateTime.Now;
                //}
            }
        }

        //***************************************************************************
        internal EnumSQLError FetchNext()
        {
            if (_reader == null || _reader.IsClosed)
            {
                return EnumSQLError.DB_NOTFOUND; 
            }

            try
            {
                if (_reader.Read())
                {
                    ExchangeData(EnumAction.GET);
                    return EnumSQLError.DB_NOERROR;
                }
                else
                {
                    return EnumSQLError.DB_NOTFOUND;
                }
            }
            catch //(Exception e)
            {
                return EnumSQLError.DB_NOTFOUND;
            }
        }

        internal EnumSQLError FetchPriorDS()
        {
            _row = null;
            if (_ds == null || _ds.Tables.Count == 0)
            {
                return EnumSQLError.DB_NOTFOUND;
            }

            try
            {
                _row = _ds.Tables[0].Rows[--_index];
                ExchangeDataDS(EnumAction.GET);
            }
            catch //(Exception e)
            {
                return EnumSQLError.DB_NOTFOUND;
            }

            return EnumSQLError.DB_NOERROR;
        }
        internal EnumSQLError FetchNextDS()
        {
            _row = null;

            if (_ds == null || _ds.Tables.Count == 0)
            {
                return EnumSQLError.DB_NOTFOUND;
            }

            try
            {
                _row = _ds.Tables[0].Rows[_index++];
                ExchangeDataDS(EnumAction.GET);
            }
            catch //(Exception e)
            {
                return EnumSQLError.DB_NOTFOUND;
            }

            return EnumSQLError.DB_NOERROR;
        }
        internal EnumSQLError FetchLastDS()
        {
            _row = null;
            if (_ds == null || _ds.Tables.Count == 0)
            {
                return EnumSQLError.DB_NOTFOUND;
            }

            try
            {
                _index = _ds.Tables[0].Rows.Count - 1;
                _row = _ds.Tables[0].Rows[_index];
                ExchangeDataDS(EnumAction.GET);
            }
            catch //(Exception e)
            {
                return EnumSQLError.DB_NOTFOUND;
            }

            return EnumSQLError.DB_NOERROR;
        }

        internal void FetchAbsolute(int pos)
        {
            _index = pos;
        }

        internal void Reload()
        {
            if (_ds != null)
            {
                int generation = GC.GetGeneration(_ds);

                _ds = null;
                GC.Collect(generation);
                GC.WaitForPendingFinalizers();
            }

            if (_ds == null)
            {
                _ds = dsBase.Copy();
            }

            if (_ds.Tables.Count > 0 && _ds.Tables[0].Rows.Count > 0)
            {
                _index = 0;
            }
            else
            {
                _index = -1;
            }
        }
        //private void KeepSameDB()
        //{
        //    if (dbPath != null && dbPath != string.Empty)
        //    {
        //        ODBCManager.ChangeODBCDatasource(dbDSN, dbPath);
        //    }
        //}

        public void CloseDB()
        {
            Close();
        }
        public void OpenDB()
        {
            Open();
        }

        internal void CopyData(CSQLSet SrcSet)
        {
            if (dsBase != null)
            {
                int generation = GC.GetGeneration(dsBase);

                dsBase = null;
                GC.Collect(generation);
            }

            if (_ds != null)
            {
                int generation = GC.GetGeneration(_ds);

                _ds = null;
                GC.Collect(generation);
            }

            GC.WaitForPendingFinalizers();

            dsBase = SrcSet.BaseDataSet.Copy();
            _ds = SrcSet.BaseDataSet.Copy();
        }
    }
}
