// CVTHEX.H  Copyright (c) 1995, 1997, Dakota Software Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;

namespace RGTools_New
{
    class CVTHEX
    {
        static char[] table = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
        public static string LongToHex(long IValue)
        {
            //IValue = 445;
            string retValue = "";
            retValue = System.Convert.ToString(IValue, 16).ToUpper();

            for (int i = retValue.Length; i < 8; i++)
            {
                retValue = "0" + retValue;
            }
            return "\\x" + retValue[retValue.Length - 2].ToString() + retValue[retValue.Length - 1].ToString() +
                    "\\x" + retValue[retValue.Length - 4].ToString() + retValue[retValue.Length - 3].ToString() +
                    "\\x" + retValue[retValue.Length - 6].ToString() + retValue[retValue.Length - 5].ToString() +
                    "\\x" + retValue[retValue.Length - 8].ToString() + retValue[retValue.Length - 7].ToString();
            //long HighOrder = (IValue / 65536) & 0xFFFF;
            //long LowOrder = IValue & 0xFFFF;

            //string NewValue =
            //    "\\x" + table[(LowOrder / 16) & 0xF].ToString() +
            //          table[(LowOrder) & 0xF].ToString() +
            //    "\\x" + table[(LowOrder / 4096) & 0xF].ToString() +
            //          table[(LowOrder / 256) & 0xF].ToString() +
            //    "\\x" + table[(HighOrder / 16) & 0xF].ToString() +
            //          table[HighOrder & 0xF].ToString() +
            //    "\\x" + table[(HighOrder / 4096) & 0xF].ToString() +
            //          table[(HighOrder / 256) & 0xF].ToString();

            //return NewValue;
        }

        public static string ByteToHex(byte bVal)
        {
            byte[] result = new byte[2];

            byte _b = (byte)(bVal & 0xf0);
            _b >>= 4;
            _b |= 0x30;

            if (_b >= 0x3a)
            {
                _b += 0x07;
            }
            result[0] = _b;

            _b = (byte)(bVal & 0x0f);
            _b |= 0x30;

            if (_b >= 0x3a)
            {
                _b += 0x07;
            }
            result[1] = _b;

            return ASCIIEncoding.Default.GetString(result);
        }
        public static string ByteToHexWithX(byte bVal)
        {
            byte[] result = new byte[2];

            byte _b = (byte)(bVal & 0xf0);
            _b >>= 4;
            _b |= 0x30;

            if (_b >= 0x3a)
            {
                _b += 0x07;
            }
            result[0] = _b;

            _b = (byte)(bVal & 0x0f);
            _b |= 0x30;

            if (_b >= 0x3a)
            {
                _b += 0x07;
            }
            result[1] = _b;

            return "\\x" + ASCIIEncoding.Default.GetString(result);
        }
    }
}
