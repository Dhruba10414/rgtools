using System;
using System.Collections.Generic;
using System.Text;

namespace RGTools_New
{
    class RGKeyword
    {
        public RGKeyword()
        { }

        public long ReferenceSN = 0;
        public string KeyWord = "";
        public long SectionSN = 0;
        public long PStart = 0;
        public long ModuleSN = 0;
        public long TagDate = 0;
    }

    class RGKeywordList : List<RGKeyword>
    {
        public RGKeywordList() { }

        public long FindReferenceSN(long moduleSN, long sectionSN, string Key)
        {
            Key = "'" + Key.Replace("'", "''") + "',";

            //if (Key.StartsWith("40"))
            //{
            //    string s = CVTHEX.LongToHex(23);
            //}

            foreach (RGKeyword keyW in this)
            {
                //if (keyW.ModuleSN == moduleSN && keyW.SectionSN == sectionSN && keyW.KeyWord.IndexOf(Key) >= 0)
                if (keyW.ModuleSN == moduleSN && keyW.SectionSN == sectionSN && keyW.KeyWord == Key)
                {
                    return keyW.ReferenceSN;
                }
            }

            return -1;
        }
    }
 
}
