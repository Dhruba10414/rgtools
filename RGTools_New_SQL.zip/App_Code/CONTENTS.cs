using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Diagnostics;

namespace RGTools_New
{

    class TLevelList
    {
        public static int MaxLevelList = 3;

        private long[] m_Levels = new long[MaxLevelList];

        public TLevelList()
        {
            for (int i = 0; i < MaxLevelList; i++)
                m_Levels[i] = -1;
        }

        public void SetLevel(int idx,long Level)
        {
            if (idx >= MaxLevelList)
            {
            }
            else
            {
                m_Levels[idx] = Level;
            }
        }
        public long GetLevel(int idx)
        {
            if (idx >= MaxLevelList)
            {
                return -1;
            }
            else
            {
                return m_Levels[idx];
            }
        }
    }

    class TTOCEntry
    {
        private TLevelList m_Level=new TLevelList();
        private string m_HeadingNo=string.Empty;
        private string m_HeadingText = string.Empty;
        private long m_RevDate = 0;
        private long m_Depth = 0;
        private TSectionOffset m_SectionOffset=null;

        public TTOCEntry(string pHeadingNo, string pHeadingText)
        {
            m_HeadingNo=pHeadingNo;
            m_HeadingText=pHeadingText;
            m_RevDate=0;
            m_SectionOffset = null;
            m_Depth = 1;

            // Compute the components

            // Blank is a special case (TCaption)
            if (pHeadingNo.Length == 0) return;

            // Parse the components.
            string ts = pHeadingNo;
            ts = ts.Trim(new char[]{' '});

            // Validate
            //int iPos = .find_first_not_of(".01234567890");
            int iPos = UTIL.find_first_not_of(ts,
                    new char[] {'.', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' });

            if (iPos != -1)
            {

                throw (new Exception("Bad format of the section number"));
            }

            iPos = ts.IndexOf('.');
            if (iPos == -1)
            {
                //try
                //m_Level[0] = long.Parse(ts);// long.Parse(ts);
                m_Level.SetLevel(0, long.Parse(ts));
                return;
            }
            else
            {
                //try
                m_Level.SetLevel(0,long.Parse(ts.Substring(0, iPos)));
                //m_Level[0] = long.Parse(ts.Substring(0, iPos));
                ts=ts.Remove(0, iPos + 1);
            }

            iPos = ts.IndexOf('.');
            if (iPos == -1)
            {
                //m_Level[1] = long.Parse(ts);
                m_Level.SetLevel(1, long.Parse(ts));

                if( (m_Level.GetLevel(1) != 0)) m_Depth = 2;

                // If this is a zero level, we need all caps here.
                if (m_Level.GetLevel(1) == 0)
                    m_HeadingText=m_HeadingText.ToUpper();
                return;
            }
            else
            {
                m_Level.SetLevel(1, long.Parse(ts.Substring(0, iPos)));
                ts=ts.Remove(0, iPos + 1);
            }

            iPos = ts.IndexOf('.');
            if (iPos == -1)
            {
                m_Level.SetLevel(2, long.Parse(ts));
                m_Depth = 3;
                return;
            }
            else
            {
                throw (new Exception("Only three levels in the Table of Contents are allowed at this time"));
            }
        }//throw (xmsg);

        public void SetSectionOffset(TSectionOffset pSectionOffset)
        { 
            m_SectionOffset = pSectionOffset; 
        }

        public TSectionOffset SectionOffset
        {
            set
            {
                m_SectionOffset = value;
            }
            get
            { 
                return m_SectionOffset; 
            }

        }
        public void SetRevDate(long pRevDate)
        {
            m_RevDate = pRevDate;
        }
        public long GetRevDate()
        {
            if (m_SectionOffset==null) return 0;

            return m_SectionOffset.GetSection().GetGroupLatestDate();
        }

        public long RevDate
        {
            set
            {
                m_RevDate = value;
            }
            get
            {
                if (m_SectionOffset==null) return 0;

                return m_SectionOffset.GetSection().GetGroupLatestDate();

                //return m_RevDate;
            }
        }

        public void SetDepth(long pDepth) { m_Depth = pDepth; }
        public long GetDepth() { return m_Depth; }
        public long Depth
        {
            set
            {
                m_Depth = value;
            }
            get
            {
                return m_Depth;
            }
        }

        public string GetHeadingNo() { return m_HeadingNo; }

        public string HeadingNo
        {
            get
            {
                return m_HeadingNo;
            }
        }

        public string GetHeadingText() { return m_HeadingText; }
        public string HeadingText
        {
            get
            { return m_HeadingText; }
        }

        public bool IsCaption()
        { return (m_HeadingNo.Length == 0); }
        public TSectionOffset GetSectionOffset()
        { return m_SectionOffset; }
 
        public TLevelList GetLevelList() { return m_Level; }
        public TLevelList LevelList
        {
            get
            { return m_Level; }
        }

        public static bool operator ==(TTOCEntry entry1, TTOCEntry entry2)
        {
            if (IsNull(entry1) && IsNull(entry2))
            {
                return true;
            }
            else if (IsNull(entry1) || IsNull(entry2))
            {
                return false;
            }
            else
            {
                return (entry1.m_HeadingNo == entry2.m_HeadingNo) ? true : false;
            }

        }
        public static bool operator !=(TTOCEntry entry1, TTOCEntry entry2)
        {
            if (IsNull(entry1) && IsNull(entry2))
            {
                return false;
            }
            else if (IsNull(entry1) || IsNull(entry2))
            {
                return true;
            }
            else
            {
                return (entry1.m_HeadingNo != entry2.m_HeadingNo) ? true : false;
            }
        }

        public override bool Equals(object entry)
        {
            if (IsNull(entry as TTOCEntry))
            {
                return false;
            }
            else
            {
                return this.m_HeadingNo == (entry as TTOCEntry).m_HeadingNo ? true : false;
            }
        }
        public static bool IsNull(TTOCEntry entry)
        {
            return TTOCEntry.Equals(entry, null);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }

    class TTOC : List<TTOCEntry>
    {
        public TTOC()
        {
            Add(new TTOCEntry("1.0", "Glossary"));
        }

        public new void Add(TTOCEntry pEntry)
        {
            UTIL.Assert(pEntry != null, "Assertion Failed: pEntry != null!");

            //if (pEntry.SectionOffset != null)
            //{
            //    string s = "";
            //}
            if (pEntry.IsCaption())
            {
                UTIL.Assert(base.Count > 0, "Assertion Failed: base.Count > 0!");

                TTOCEntry pPreviousEntry = base[base.Count - 1];
                if (pPreviousEntry.IsCaption())
                    pEntry.Depth=pPreviousEntry.Depth;
                else
                    pEntry.Depth = pPreviousEntry.Depth + 1;
            }

            base.Add(pEntry);// AddAt(pEntry, base.Count);
        }
        public bool Validate(StreamWriter BogueFile)
        {
            // Check to see there are no missing gaps in the sequence
            //***CSB

            return true;
        }
        public void GenerateSQL(string PathName)
        {
            string ts = PathName + "\\RGTOC.REM";
            StreamWriter oFile = null;
            try
            {
                //oFile = new StreamWriter(ts);
                oFile = new StreamWriter(ts, false, Encoding.Default);
            }
            catch
            {

                throw (new Exception("Could not open " + ts));
            }
           
            for (int i = 0; i < base.Count; i++)
            {
                TTOCEntry pTOCEntry = base[i];
                UTIL.Assert(pTOCEntry != null, "Assertion Failed: pTOCEntry != null!");

                // Structure of the output file is:
                // modulesn, sectionsn, offset, sequence, depth, headingno, headingtext, tagdate

                oFile.Write(GlobalStructures.ModuleSN + ",");  //.GetModuleSN()

                TSectionOffset pSectionOffset = pTOCEntry.SectionOffset;// GetSectionOffset();
                UTIL.Assert(pSectionOffset != null, "Assertion Failed: pSectionOffset != null!");

                TSection pSection = pSectionOffset.GetSection();

                oFile.Write(pSection.GetSectionID() + ",");
                oFile.Write(pSectionOffset.Offset + ",");
                oFile.Write(i + ",");
                oFile.Write(pTOCEntry.Depth + ",");
                oFile.Write("'" + pTOCEntry.HeadingNo + "',");
                oFile.Write("'" +SUTIL.PrepareASCIIString(pTOCEntry.HeadingText) + "',");
                oFile.WriteLine(pTOCEntry.RevDate);
            }

            oFile.Close();

        }//throw (xmsg);
        public void DumpTOC(StreamWriter BogueFile)
        {
            BogueFile.WriteLine("Table of Contents");
            for (int i = 0; i < base.Count; i++)
            {
                TTOCEntry pTOCEntry = base[i];
                UTIL.Assert(pTOCEntry != null, "Assertion Failed: pTOCEntry != null!");

                for (int j = 0; j < pTOCEntry.Depth; j++)
                {
                    BogueFile.Write("  ");
                }

                BogueFile.WriteLine("  " + pTOCEntry.HeadingNo.ToString() + "  "
                    + pTOCEntry.HeadingText);
            }

        }
    }
}
