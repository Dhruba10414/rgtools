using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Diagnostics;

namespace RGTools_New
{
    class TDomain
    {
        private string m_DomainName;
        private string m_ParentName = string.Empty;
        private string m_Title = string.Empty;
        private string m_PermanentSN = string.Empty;
        private long m_QuestionCount = 0;
        private long m_ModuleSN = 0;
        private bool m_SubQuestionDomain = false;
        private bool m_Marked = false;

        public TDomain(string pDomainName)
        {
            m_DomainName = pDomainName;
            m_ParentName = string.Empty;
            m_Title = string.Empty;
            m_ModuleSN = 0;
            m_PermanentSN = string.Empty;
            m_SubQuestionDomain = false;
            m_QuestionCount = 0;
            m_Marked = false;

            IsReferenced = false;
        }

        public TDomain(string pDomainName, string pParentName, string pPermanentSN, string pTitle, bool pMarked)
        {
            m_DomainName = pDomainName;
            m_ParentName = pParentName;
            m_Title = pTitle;
            m_ModuleSN = 0;
            m_PermanentSN = pPermanentSN;
            m_SubQuestionDomain = false;
            m_QuestionCount = 0;
            m_Marked = pMarked;

            IsReferenced = false;
        }
        public TDomain(string pDomainName, string pParentName, string pTitle, long ModuleSN, bool pSubQuestionDomain)
        {
            m_DomainName = pDomainName;
            m_ParentName = pParentName;
            m_Title = pTitle;
            m_ModuleSN = ModuleSN;
            m_SubQuestionDomain = pSubQuestionDomain;
            m_QuestionCount = 0;
            m_Marked = false;
            m_PermanentSN = string.Empty;

            IsReferenced = false;
        }

        public bool IsReferenced
        {
            get;
            set;
        }

        public string DomainName
        {
            get { return m_DomainName; }
        }
        public string ParentName
        {
            get { return m_ParentName; }
        }
        public string Title
        {
            get { return m_Title; }
        }
        public string PermanentSN
        {
            get { return m_PermanentSN; }
        }
        public long QuestionCount
        {
            get { return m_QuestionCount; }
        }
        public long ModuleSN
        {
            get { return m_ModuleSN; }
            set 
            {
                m_ModuleSN = value; 
            }
        }
        public bool IsSubQuestionDomain
        {
            get { return m_SubQuestionDomain; }
        }
        public bool IsMarked
        {
            get { return m_Marked; }
        }

        public void IncQuestionCount(long Amount)
        {
            m_QuestionCount += Amount;
        }
        public void IncQuestionCount()
        {
            m_QuestionCount++;
        }

        public static bool operator ==(TDomain domain1, TDomain domain2)
        {
            if (IsNull(domain1) && IsNull(domain2))
            {
                return true;
            }
            else if (IsNull(domain1) || IsNull(domain2))
            {
                return false;
            }
            else
            {
                return domain1.m_DomainName == domain2.m_DomainName ? true : false;
            }
        }

        public static bool operator !=(TDomain domain1, TDomain domain2)
        {
            if (IsNull(domain1) && IsNull(domain2))
            {
                return false;
            }
            else if (IsNull(domain1) || IsNull(domain2))
            {
                return true;
            }
            else
            {
                return domain1.m_DomainName != domain2.m_DomainName ? true : false;
            }
        }

        public override bool Equals(object domain)
        {
            if (IsNull(domain as TDomain))
            {
                return false;
            }
            else
            {
                return this.m_DomainName == (domain as TDomain).m_DomainName ? true : false;
            }
        }

        public static bool IsNull(TDomain domain)
        {
            return TDomain.Equals(domain, null);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }

    class TParentIndexItem
    {
        internal string ParentName;
        internal int Index;

        public TParentIndexItem(string pParentName, int pIndex)
        {
            ParentName = pParentName;
            Index = pIndex;
        }
        public TParentIndexItem(string pParentName)
        {
            int pIndex = -1;
            ParentName = pParentName;
            Index = pIndex;
        }
        public static bool operator ==(TParentIndexItem item1, TParentIndexItem item2)
        {
            if (IsNull(item1) && IsNull(item2))
            {
                return true;
            }
            else if (IsNull(item1) || IsNull(item2))
            {
                return false;
            }
            else
            {
                return item1.ParentName == item2.ParentName ? true : false;
            }
        }
        public static bool operator !=(TParentIndexItem item1, TParentIndexItem item2)
        {
            if (IsNull(item1) && IsNull(item2))
            {
                return false;
            }
            else if (IsNull(item1) || IsNull(item2))
            {
                return true;
            }
            else
            {
                return item1.ParentName != item2.ParentName ? true : false;
            }
        }
        public static bool IsNull(TParentIndexItem item)
        {
            return TParentIndexItem.Equals(item, null);
        }

        public override bool Equals(object item)
        {
            {
                if (IsNull(item as TParentIndexItem))
                {
                    return false;
                }
                else
                {
                    return this.ParentName == (item as TParentIndexItem).ParentName ? true : false;
                }
            }
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
        //public static bool operator <(TParentIndexItem item1, TParentIndexItem item2)
        //{ return item1.ParentName < item2.ParentName ? true : false; }
        //public static bool operator >(TParentIndexItem item1, TParentIndexItem item2)
        //{ return item1.ParentName > item2.ParentName ? true : false; }
    }

    class TParentIndex : List<TParentIndexItem>
    {

        public TParentIndex()
        {
            //ParentName = pParentName;
            //Index = pIndex;
        }

        private static TParentIndexItem _parentIndexItem = null;
        private static bool match(TParentIndexItem ParentIndexItem)
        {
            if (ParentIndexItem.ParentName == _parentIndexItem.ParentName)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public TParentIndexItem FindFirst(TParentIndexItem ParentIndexItem)
        {
            _parentIndexItem = ParentIndexItem;

            return base.Find(match);
        }

    }

    class TDomainTable : List<TDomain>
    {
        private TSymbolTable SymbolTable;
        private long MasterModuleID;
        private long MasterGroupID;
        private long MasterClassID;


        public TDomainTable()
        {
            //:TIArrayAsVector <TDomain> (10,0,10)
        }

        public void LoadModuleTable(string SourceDirectory, ref long ModuleSN, StreamWriter Bogue)
        {
            //char iline[200];  // Input line buffer.
            int pos;  // temporary variable.
            bool TableErrors = false;

            MasterModuleID = -1;
            MasterGroupID = -1;
            MasterClassID = -1;
            ModuleSN = 0;

 // Open the domain file and exit on error.
            string ModuleFileName = SourceDirectory + "\\MODULE.TXT";
            StreamReader MIFile = null;
            try
            {
                MIFile = new StreamReader(ModuleFileName, Encoding.Default);
            }
            catch
            {
                throw (new Exception("Error! Could not open Module Table file <" + ModuleFileName + ">."));
            }

            // Loop through the input file sucking in data.
            string InputLine = string.Empty;

            while ((InputLine = MIFile.ReadLine()) != null)
            {
                // Read a line from the domain file.
                InputLine = InputLine.Trim(new char[]{' '});;

                // If the line is blank, or it's a comment (Denoted by starting with an asterisk)
                // skip to next line.
                if ((InputLine.Length == 0) || (InputLine.Substring(0, 1) == "*")) continue;

                // Now look for =.
                if ((pos = InputLine.IndexOf('=')) == -1)
                {
                    Bogue.WriteLine("Bad Module Specification Line->" + InputLine);
                    TableErrors = true;
                    continue;
                }

                // Extract the first and second part.
                string Command = InputLine.Substring(0, pos).Trim(new char[]{' '});;
                string Value = InputLine.Substring(pos + 1, InputLine.Length - pos - 1).Trim(new char[]{' '});;

                if (Command == "MMODULEID")
                    MasterModuleID = long.Parse(Value);
                else if (Command == "MGROUPID")
                    MasterGroupID = long.Parse(Value);
                else if (Command == "MCLASSID")
                    MasterClassID = long.Parse(Value);
                else if (Command == "SERIALID")
                    ModuleSN =long.Parse(Value);
                else if (Command == "MODULESN")
                //*** do nothing for now.
                { }
                else
                {
                    Bogue.WriteLine("Bad Module Specification Line->" + InputLine);
                    TableErrors = true;
                }
            }

            // Close the input file.
            MIFile.Close();

            if (MasterModuleID == -1)
            {
                Bogue.WriteLine("Master Module ID is not defined in Module file.");
                TableErrors = true;
            }

            if (MasterGroupID == -1)
            {
                Bogue.WriteLine("Master Group ID is not defined in Module file.");
                TableErrors = true;
            }

            if (MasterClassID == -1)
            {
                Bogue.WriteLine("Master Class ID is not defined in Module file.");
                TableErrors = true;
            }

            if (ModuleSN == 0)
            {
                Bogue.WriteLine("Module SN is not defined in Module file.");
                TableErrors = true;
            }

            if (TableErrors)
                throw(new Exception("There were errors in " + ModuleFileName + "."));
        }
        public void LoadDomainTable(string SourceDirectory, TSymbolTable pSymbolTable, StreamWriter Bogue)
        {
            //char iline[200];  // Input line buffer.
            long LineCount = 0;
            int pos;  // temporary variable.
            bool TableErrors = false;
            long CurrentModuleSN = 0;
            bool MarkedDomain;

            UTIL.Assert(pSymbolTable != null, "Assertion Failed: pSymbolTable != null!");

            // Open the domain file and exit on error.
            string DomainFileName = SourceDirectory + "\\DOMAIN.TXT";
            StreamReader DIFile = null;
            try
            {

                DIFile = new StreamReader(DomainFileName, Encoding.Default);
            }
            catch
            {
                throw (new Exception("Error! Could not open Domain Table file <" + DomainFileName + ">."));
            }

            // Assign the symbol table to a reference variable.
            SymbolTable = pSymbolTable;

            // Loop through the input file sucking in data.
            string InputLine = string.Empty;

            while ((InputLine = DIFile.ReadLine()) != null)
            {
                // Read a line from the domain file.
                LineCount++;
                InputLine = InputLine.Trim(new char[]{' '});;

                // If the line is blank, or it's a comment (Denoted by starting with an asterisk)
                // skip to next line.
                if ((InputLine.Length == 0) || (InputLine.Substring(0, 1) == "*")) continue;

                // Now parse in the form: {M} serialnumber domain , parent, "title

                // Check for Marked (M or blank).
                if (InputLine.Substring(0, 1) == "M")
                {

                    MarkedDomain = true;
                    InputLine=InputLine.Remove(0, 1);

                }
                else
                { MarkedDomain = false; }

                InputLine = InputLine.Trim(new char[]{' '});;

                // Check for the remote marker for SN.
                if (InputLine.Length > 0 && InputLine.Substring(0, 1) == "R")
                {
                    InputLine=InputLine.Remove(0, 1);
                }

                // Look for the fist comma.
                if ((pos = InputLine.IndexOf(',')) == -1)
                {
                    Bogue.WriteLine("Missing , in line " + LineCount.ToString());
                    TableErrors = true;
                    continue;
                }

                // Extract the Serial number & domain name.
                string Chunk = InputLine.Substring(0, pos);
                Chunk = Chunk.Trim(new char[]{' '});;
                InputLine=InputLine.Remove(0, pos + 1);

                // Now break up chunk into serial number and domain.
                if ((pos = Chunk.IndexOf(' ')) == -1)
                {
                    Bogue.WriteLine("Missing serial number or domain in line " + LineCount);
                    TableErrors = true;
                    continue;
                }


                string PermanentSN = Chunk.Substring(0, pos);
                PermanentSN = PermanentSN.Trim(new char[]{' '});;
                Chunk=Chunk.Remove(0, pos + 1);
                string Domain = Chunk.Trim(new char[]{' '});;
                if ((pos = UTIL.find_first_not_of(PermanentSN, new char[] {'-', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' })) != -1)
                {
                    Bogue.WriteLine("Missing or invalid serial number in line " + LineCount);
                    TableErrors = true;
                    continue;
                }


                // Look for the second comma.
                if ((pos = InputLine.IndexOf(",")) == -1)
                {
                    Bogue.WriteLine("Missing , in line " + LineCount);
                    TableErrors = true;
                    continue;
                }

                // Extract the parent name.
                string Parent = InputLine.Substring(0, pos);
                Parent = Parent.Trim(new char[]{' '});;
                InputLine=InputLine.Remove(0, pos + 1);
                InputLine = InputLine.Trim(new char[]{' '});;

                // Now work on extracting the title.
                if (InputLine.Length == 0)
                {
                    Bogue.WriteLine("Missing title in line " + LineCount);
                    TableErrors = true;
                    continue;
                }

                if ((InputLine.Substring(0, 1) != "\"") || (InputLine[InputLine.Length - 1] != '"'))
                {
                    Bogue.WriteLine("Missing quote in line " + LineCount + " <" + InputLine + ">");
                    TableErrors = true;
                    continue;
                }

                string Title = InputLine.Substring(1, InputLine.Length - 2);

                // Now that all the components have been determined, add the domain to the
                // domain table and add the domain to the symbol table.
                Add(new TDomain(Domain, Parent, PermanentSN, Title, MarkedDomain));

                // Make sure we haven't created a deadlock loop.
                if (Domain == Parent)
                {
                    TableErrors = true;
                    Bogue.Write("Domain " + Domain + " references itself as the parent.");
                }

                try
                {
                    TSymbol pSymbol = SymbolTable.AddSymbol(Domain, SymbolType.SymDomain, TSymbol.Type.Defined | TSymbol.Type.Referenced, CurrentModuleSN);
                    UTIL.Assert(pSymbol != null, "Assertion Failed: pSymbol != null!");

                    pSymbol.PermanentSN = long.Parse(PermanentSN);
                    if (Parent == "SYSTEM")
                    {
                        CurrentModuleSN = pSymbol.PermanentSN;
                        pSymbol.ModuleSN = CurrentModuleSN;

                        //only increase the m_SNCounter, to keep same with old application. Oct 10, 2008
                        TSymbol.BaseSN++;
                        //// If the parent was the system domain, we want to set the module SN of the domain symbol to the
                        //// serial number of that domain, and set the CurrentModuleSN alse.
                        //TSymbol pS = SymbolTable.FindFirst(new TSymbol(Domain, SymbolType.SymDomain));

                    }

                }
                catch (Exception e)
                {
                    TableErrors = true;
                    Bogue.WriteLine(e.Message);
                }
            }

            // Close the input file.
            DIFile.Close();


            // Always add a domain symbol for the SYSTEM domain.
            SymbolTable.AddSymbol("SYSTEM", SymbolType.SymDomain, TSymbol.Type.Defined | TSymbol.Type.Referenced, 0);

            // Determine which domains belong to whicm modules.
            ResolveModules();

            // Validate the integrity of the connections of the hierarchy.
            bool bValidConn = !ValidateConnections(Bogue);
            string errMsg = "";

            if (TableErrors)
            {
                errMsg = "There were problems in " + DomainFileName + ".";
            }

            if (bValidConn)
            {
                errMsg += Environment.NewLine + "There were domain structure problems.";
            }

            if (errMsg != "")
            {
                throw (new Exception(errMsg));
            }     
         }

        // ValidateConnections makes sure that the hierarchy lineage connections are valid. (It
        // will not validate a circular relationship however.) This method takes the following
        // parameter:
        //
        //   Bogue     StreamWriter     (Passed) Open output file to output errors.
        private bool ValidateConnections(StreamWriter Bogue)
        {
            bool Valid = true;

            // Loop through all the domains in the domain table. Print error messages for all
            // domains which have a parent domain that does not exist in the domain table.
            for (int i = 0; i < this.Count; i++)
            {
                //if (SymbolTable.FindFirst(&TSymbol(ItemAt(i)->GetParentName())) == -1)
                if (SymbolTable.FindFirst(new TSymbol(base[i].ParentName, SymbolType.SymDomain)) == null)
                {
                    Bogue.WriteLine("Can't find the domain definition for parent " + base[i].ParentName);
                    Valid = false;
                }
            }
            return Valid;
        }

        //private int find_first_not_of(string str, char[] chars)
        //{
        //    int ret = -1;

        //    for (int i = 0; i < str.Length; i++)
        //    {
        //        if (str.IndexOfAny(chars, i, 1) == -1)
        //        {
        //            ret = i;
        //            break;
        //        }
        //    }
        //    return ret;
        //}

        public void AddSubQuestionDomain(string DomainName, string ParentName, long pModuleSN)
        {
            Add(new TDomain(DomainName, ParentName, DomainName, pModuleSN, true));
        }
        public void GenerateHierarchy(string OutputPath) //throw (xmsg);
        {
            string ts;
            ts = OutputPath + "\\DOMAINS.REM";
            StreamWriter DomainFile = null;
            try
            {
                //DomainFile = new StreamWriter(ts);
                DomainFile = new StreamWriter(ts, false, Encoding.Default); ;
            }
            catch
            {
                throw (new Exception("Could not create DOMAINS.REM file."));
            }

            ts = OutputPath + "\\MODULE.REM";
            StreamWriter ModuleFile = null;
            try
            {
                //ModuleFile = new StreamWriter(ts);
                ModuleFile = new StreamWriter(ts, false, Encoding.Default); 
            }
            catch
            {
                throw (new Exception("Could not create MODULE.REM file."));
            }

            ts = OutputPath + "\\MODULEV.REM";
            StreamWriter ModuleVFile = null;
            try
            {
                //ModuleVFile = new StreamWriter(ts);
                ModuleVFile = new StreamWriter(ts, false, Encoding.Default); ;
            }
            catch
            {
                throw (new Exception("Could not create MODULEV.REM file."));
            }

            ts = OutputPath + "\\DOMAINSN.TXT";
            StreamWriter DomainSNFile = null;
            try
            {
                //DomainSNFile = new StreamWriter(ts);
                DomainSNFile = new StreamWriter(ts, false, Encoding.Default); 
            }
            catch
            {
                throw (new Exception("Could not create DOMAINSN.TXT file."));
            }

            // Determine which domains belong to whicm modules.
            ResolveModules();

            //long SystemSN = (SymbolTable)[SymbolTable.FindFirst(new  TSymbol("SYSTEM"))].PermanentSN;
            long SystemSN = (SymbolTable.FindFirst(new TSymbol("SYSTEM"))).PermanentSN;

            // DOMAIN.REM format:
            //   DomainSN, Heading, ModuleSN, NQuestions, SubQuestion, Marked, ParentSN, ChildOrder
            long ofDomainSN;
            string ofHeading;
            long ofModuleSN;
            long ofNQuestions;
            string ofSubQuestion;
            string ofMarked;
            long ofParentSN;
            long ofChildOrder;

            // Cycle through the domains and spew them out.
            for (int i = 0; i < this.Count; i++)
            {
                TDomain pD = base[i];
                TSymbol tS = SymbolTable.FindFirst(new TSymbol(pD.DomainName));

                //*** DomainMap.Lookup(DomainSN)
                ofDomainSN = tS.PermanentSN;
                ofHeading = pD.Title;
                ofNQuestions = pD.QuestionCount;

                if (pD.ParentName == "SYSTEM")
                {
                    // Module File  ModuleSN, ModuleName, MasterModuleID, MasterGroupID, MasterClassID
                    //ModuleFile.WriteLine(pD.ModuleSN.ToString() + ",'" +SUTIL.PrepareASCIIString(pD.Title) + "',"
                    //       + MasterModuleID + "," + MasterGroupID + "," + MasterClassID);

                    string modulename = SUTIL.PrepareASCIIString(pD.Title);
                    if (modulename.Length > 50)
                    {
                        modulename = modulename.Substring(0, 50);
                    }

                    ModuleFile.WriteLine(pD.ModuleSN.ToString() + ",'" + modulename + "',"
                            + MasterModuleID + "," + MasterGroupID + "," + MasterClassID);

                    ModuleVFile.WriteLine(pD.ModuleSN.ToString() + ",'Release 1'");

                    //***CSB SystemSN  DomainMap.Lookup(DomainSN)
                    ofParentSN = SystemSN;

                    // If the parent is the system, use the ModuleSN for child order.
                    ofChildOrder = pD.ModuleSN;
                }
                else
                {
                    TSymbol tP = SymbolTable.FindFirst(new TSymbol(pD.ParentName));
                    //***CSB ParentSN Lookup(SN);
                    ofParentSN = tP.PermanentSN;

                    // For non system domains, use the serial number for child orders.
                    ofChildOrder = tS.InternalSN;
                }

                if (pD.PermanentSN != "")
                {
                    TSymbol tD = SymbolTable.FindFirst(new TSymbol(pD.DomainName));
                    //DomainSNFile.WriteLine(tD.InternalSN.ToString() + "," + pD.PermanentSN + "," + @"\"""
                    //             + pD.DomainName + "\"\"");
                    DomainSNFile.WriteLine(tD.InternalSN.ToString() + "," + pD.PermanentSN + "," 
                                 + pD.DomainName);
                }

                //*** ModuleSN, check.
                ofModuleSN = pD.ModuleSN;

                //***CSB Subquestion
                ofSubQuestion = (pD.IsSubQuestionDomain) ? "Y" : "N";

                //***CSB Marked
                ofMarked = (pD.IsMarked) ? "Y" : "N";

                //DomainFile.WriteLine(ofDomainSN.ToString() + ",'" + SUTIL.PrepareASCIIString(ofHeading) + "'," + ofModuleSN.ToString() + ","
                //           + ofNQuestions.ToString() + ",'" + ofSubQuestion + "','" + ofMarked + "',"
                //           + ofParentSN.ToString() + "," + ofChildOrder.ToString());

                string heading = SUTIL.PrepareASCIIString(ofHeading);
                if (heading.Length > 80)
                {
                    heading = heading.Substring(0, 80);
                    if (heading[79] == '\'' && heading[78] != '\'')
                    {
                        heading += "\'";
                    }
                }

                DomainFile.WriteLine(ofDomainSN.ToString() + ",'" + heading + "'," + ofModuleSN.ToString() + ","
                           + ofNQuestions.ToString() + ",'" + ofSubQuestion + "','" + ofMarked + "',"
                           + ofParentSN.ToString() + "," + ofChildOrder.ToString());
            }

            // Add system domain.  Obsolete, stored in separate directory.
            //   DomainFile + SystemSN + ",'System',0,-1,-1,0,'N'"  );

            // Add system Module  Obsolete, stored in separate directory
            //    ModuleFile.WriteLine("0,'System'," + SystemSN  );

            // Close the output files.
            DomainFile.Close();
            ModuleFile.Close();
            ModuleVFile.Close();
            DomainSNFile.Close();
        }

        // ResolveModules. Assigns the proper module designation to each domain.
        public void ResolveModules()
        {
            TParentIndex ParentIndex=new TParentIndex();

            // Build the index.
            for (int i = 0; i < base.Count; i++)
            {
                ParentIndex.Add(new TParentIndexItem(base[i].ParentName, i));
            }

            // Rsolve everything at the system level downward.
            ResolveLevel("SYSTEM", ParentIndex, 0);
        }

        // ResolveLevel. Resolves the module ID assignment in a domain recursively. This
        // method takes the following parameters:
        //
        //   Name          string          (Passed) Name of domain to locate and assign.
        //   ParentIndex   TParentIndex    (Passed/Updated) Index of domains by parent name.
        //   pModuleSN     long            (Passed) Serial number of passed parent domain. If
        //                                 the value is zero, it means the parent is the system
        //                                 domain and the children should inherit the module
        //                                 associated with the child of this parent, which is
        //                                 actually the top node of the hierarchy.
        private void ResolveLevel(string ParentName, TParentIndex ParentIndex, long pModuleSN)
        {
            TParentIndexItem pPI;
            long ModuleSN;

            // Find all domains
            while ((pPI = ParentIndex.FindFirst(new TParentIndexItem(ParentName))) != null)
            {

                // Find the module SN to pass downwards. If the system is the parent, this is
                // the domain ID of the child of the system, which is a module.
                if (pModuleSN == 0)
                {
                    TSymbol Offset = SymbolTable.FindFirst(new TSymbol(base[pPI.Index].DomainName));
                    UTIL.Assert(Offset != null, "Assertion Failed: Offset != null!");

                    ModuleSN = Offset.PermanentSN;
                }
                else
                    ModuleSN = pModuleSN;

                // Assign the module SN of this child and propigate it to all it's children.
                base[pPI.Index].ModuleSN = ModuleSN;
                ResolveLevel(base[pPI.Index].DomainName, ParentIndex, ModuleSN);

                // We've processed this child, so detach it from the parent index. (Note:
                // remember that the domain is still owned by the domain table, so it will
                // be deallocated from there.

                ParentIndex.Remove(pPI);

            }
        }

        private static TDomain _domain = null;
        private static bool match(TDomain domain)
        {
            if (domain.DomainName == _domain.DomainName)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public TDomain FindFirst(TDomain domain)
        {
            _domain = domain;

            return base.Find(match);
        }

    }
}
