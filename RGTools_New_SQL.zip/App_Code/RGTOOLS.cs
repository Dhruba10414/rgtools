using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.IO;

namespace RGTools_New
{
    //******************************************************************
    //**//// TRGToolsSheet /////////////////////////////////////////////
    //******************************************************************
    //class TRGToolsSheet : TPropertySheet
    class TRGToolsSheet
    {
        // Data members
        //protected CSQL m_pSQL = null;
        // The idea to have this database data member here is to share it between all the Property pages.  Using reference
        // to this data member, all the property pages will use / update this object.
        //protected CSQLDBUI m_pDBUI = null;

        protected string m_sINIFileName = string.Empty;    // name of the INI file.
        protected string m_sTempDisk = string.Empty;      // Disk of the temporary Directory.
        protected string m_sTempDir = "D:\\TmpRgt";       // Temporary Directory.
        protected string m_sSNDir = "None";          // Serial number directory.
        protected bool m_MainSite = false;        // true if Main Site.

        protected string m_DirBeginWith="F7";

       const string ExcelConnection="Provider=Microsoft.Jet.Oledb.4.0;Extended Properties=Excel 8.0;Data Source=";
       const string selFilesConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\App_Data\selFiles.mdb";

        // Constructors, Destructors.
        public TRGToolsSheet()
        {
            // Initialize the SQL Environment.
            if (ConfigurationManager.AppSettings["ExcelConnection"] == null)
            {
                SaveConfig("ExcelConnection", ExcelConnection);
            }
            if (ConfigurationManager.AppSettings["selFilesConnectionString"] == null)
            {
                SaveConfig("selFilesConnectionString", selFilesConnectionString);
            }

            if (ConfigurationManager.AppSettings["DirBeginWith"] != null)
            {
                m_DirBeginWith = ConfigurationManager.AppSettings["DirBeginWith"];
            }
            else
            {
                m_DirBeginWith = "F7";
                SaveConfig("DirBeginWith", m_DirBeginWith);
            }


            // Location of the INI file.
            m_sINIFileName =UTIL.GetEXEDirectory() + "\\rgtools.ini";

            // See what kind of site we are (Main Site or Remote).
            string Site="San Diego";
            if (ConfigurationManager.AppSettings["Site"] != null)
            {
                Site = ConfigurationManager.AppSettings["Site"];
            }
            else
            {
                Site = "Main";
                SaveConfig("Site", Site);
            }

            m_MainSite = (Site.Trim(new char[]{' '}) == "Main");

            // Temporary directory used to create temporary files.
            if (ConfigurationManager.AppSettings["TempDir"] != null)
            {
                m_sTempDir = ConfigurationManager.AppSettings["TempDir"];
            }
            else
            {
                SaveConfig("TempDir", m_sTempDir);
            }

            // Decompose in drive and directory.
            m_sTempDisk = UTIL.GetDiskForPath(m_sTempDir);

            // Serial number directory.
            if (ConfigurationManager.AppSettings["SNDir"] != null)
            {
                m_sSNDir = ConfigurationManager.AppSettings["SNDir"];
            }
            else
            {
                m_sSNDir = "N:\\Test\\Database\\Serial";
                SaveConfig("SNDir", m_sSNDir);
            }
            
            if (m_sSNDir == "None")
            {
                if (m_MainSite)
                {
                    m_sSNDir = "N:\\Test\\Database\\Serial";
                }
                else
                {
                    m_sSNDir = UTIL.GetEXEDirectory() + "\\Serial";

                    // Create the directory if not exist.
                    if (!Directory.Exists(m_sSNDir))
                    {
                        Directory.CreateDirectory(m_sSNDir);
                    }
                }

                SaveConfig("SNDir", m_sSNDir);
            }

        }

        // public methods.
        // Create and empty (if already created) the temporary directory.  Throw Exception.
        public void CreateTemp()
        {
            if(!Directory.Exists(m_sTempDir))
            {
                Directory.CreateDirectory(m_sTempDir);
            }
            else
            {
               UTIL.RemoveFilesInDir (m_sTempDir);
            }
        }
        private void SaveConfig(string key, string value)
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            if (config.AppSettings.Settings[key] == null)
            {
                config.AppSettings.Settings.Add(key, value);
            }
            else
            {
                config.AppSettings.Settings[key].Value = value;
            }

            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");
        }

        public string GetINIFileName() { return m_sINIFileName; }
        public string INIFileName
        {
            get
            { return m_sINIFileName; }
        }
        public string GetTempDir() { return m_sTempDir; }
        public string TempDir
        {
            get
            { 
                return m_sTempDir; 
            }
            set
            {
                m_sTempDir = value;
            }
        }
        public string GetTempDisk() { return m_sTempDisk; }
        public string TempDisk
        {
            get
            { return m_sTempDisk; }
        }
        public string GetSNDir() { return m_sSNDir; }
        public string SNDir
        {
            get
            {
                return m_sSNDir;
            }
            set
            {
                m_sSNDir = value;
            }
        }
        public bool IsMainSite() { return m_MainSite; }
        public bool MainSite
        {
            get
            { return m_MainSite; }
        }

        public string DirBeginWith
        {
            get
            {
                return m_DirBeginWith;
            }
        }

    }
}
