using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Diagnostics;
using System.Data;
using System.Runtime.InteropServices;
using System.Drawing;
using System.Data.SqlClient;

namespace RGTools_New
{
    public enum TypeFlagCopy { CreateMode, AppendMode };

    class UTIL
    {
        [StructLayout(LayoutKind.Sequential)]
        public struct PROCESSENTRY32
        {
            public uint dwSize;
            public uint cntUsage;
            public int th32ProcessID;
            public IntPtr th32DefaultHeapID;
            public uint th32ModuleID;
            public uint cntThreads;
            public uint th32ParentProcessID;
            public int pcPriClassBase;
            public uint dwFlags;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
            public string szExeFile;
        };

        [DllImport("kernel32.dll")]
        static extern bool Process32First(IntPtr hSnapshot, ref PROCESSENTRY32 lppe);
        [DllImport("kernel32.dll")]
        static extern bool Process32Next(IntPtr hSnapshot, ref PROCESSENTRY32 lppe);
        [DllImport("kernel32.dll", SetLastError = true)]
        static extern IntPtr CreateToolhelp32Snapshot(SnapshotFlags dwFlags, uint th32ProcessID);
        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool GetExitCodeProcess(IntPtr hProcess, out uint lpExitCode);
        [DllImport("kernel32.dll")]
        static extern IntPtr OpenProcess(ProcessAccessFlags dwDesiredAccess, [MarshalAs(UnmanagedType.Bool)] bool bInheritHandle, int dwProcessId);
        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool TerminateProcess(IntPtr hProcess, uint uExitCode);

        internal static frmMain _main = null;

        public static bool IsADate(string DateString)
        {
            if (DateString != "")
            {
                try
                {
                    DateTime.Parse(DateString);
                    return true;
                }
                catch
                {
                    return false;
                }

            }

            return true;
        }

        public static bool FileCopy ( string PathFileOrig,  string PathFileDest, TypeFlagCopy Flag)
        {
            _main.copyFailed = false;
            // First, delete the destination file (if in Create Mode).
            if (Flag == TypeFlagCopy.CreateMode) 
            {
                try
                {
                    if (File.Exists(PathFileDest))
                    {
                        File.SetAttributes(PathFileDest, FileAttributes.Archive);
                        File.Delete(PathFileDest);
                    }
                    //File.Copy(PathFileOrig, PathFileDest);
                    try
                    {
                        Stream original = new FileStream(PathFileDest, FileMode.CreateNew);
                        Stream extra = new FileStream(PathFileOrig, FileMode.Open, FileAccess.Read);
                        bool ret = true;

                        byte[] buffer = new byte[32 * 1024];

                        int blockSize;
                        while ((blockSize = extra.Read(buffer, 0, buffer.Length)) > 0)
                        {
                            if (_main != null && _main.cancelPressed)
                            {
                                ret = false;
                                break;
                            }
                            original.Write(buffer, 0, blockSize);
                        }

                        original.Close();
                        extra.Close();

                        if (!ret)
                        {
                            File.Delete(PathFileDest);
                            //_main.copyFailed = true; ;
                        }

                        return ret;
                    }
                    catch//(Exception ee)
                    {
                        return false;
                    }
                    //RemoveFile (PathFileDest);
                    //return true;
                }
                catch// (Exception e)
                {
                    return false;
                }
            }
            else
            {
                try
                {
                    Stream original = new FileStream(PathFileDest, FileMode.Append);
                    Stream extra = new FileStream(PathFileOrig, FileMode.Open, FileAccess.Read);
                    bool ret = true;

                    byte[] buffer = new byte[32 * 1024];

                    int blockSize;
                    while ((blockSize = extra.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        if (_main != null && _main.cancelPressed)
                        {
                            ret = false;
                            break;
                        }
                        original.Write(buffer, 0, blockSize);
                    }

                    original.Close();
                    extra.Close();

                    return ret;
                }
                catch//(Exception ee)
                {
                    return false;
                }
            }

        }
        public static bool FileCopy(string PathFileOrig, string PathFileDest)
        {
            return FileCopy(PathFileOrig, PathFileDest, TypeFlagCopy.CreateMode);
        }
        public static void FileCopy(object PathFile)
        {
            try
            {
                string[] path = (string[])PathFile;

                if (path.Length < 2)
                {
                    _main.copyFailed = true;

                    return;
                }

                if (_main != null)
                {
                    _main.copyFailed = !FileCopy(path[0], path[1], TypeFlagCopy.CreateMode);
                }
                else
                {
                    FileCopy(path[0], path[1], TypeFlagCopy.CreateMode);
                }
            }
            catch
            {
                _main.copyFailed = true;
            }
        }

        public static string GetDiskForPath(string path)
        {
            if (path.Length >= 2 && path.Substring(1, 1) == ":") 
            {
                return path.Substring(0, 1);
            } else 
            {
                path=Directory.GetCurrentDirectory();
                return GetDiskForPath(path);
            }
        }

        //
        public static bool RemoveFilesInDir(string Path)
        {
            bool _err = false;

            try
            {
                string[] dirs = Directory.GetFiles(Path, "*.*");
                foreach (string dir in dirs)
                {
                    if (dir.ToLower().EndsWith(".ser"))
                    {
                        continue;
                    }

                    try
                    {
                        File.Delete(dir);
                    }
                    catch//(Exception e)
                    {
                        _err = true;
                        continue;
                    }
                }

                return _err;
            }
            catch 
            {
                return false;
            }
        }

        public static void RemoveFile(string FileName)
        {
            if (File.Exists(FileName))
            {
                File.Delete(FileName);
            }
        }

        public static long FileSize(string FileName)
        {
            try
            {
                FileInfo fInfo = new FileInfo(FileName);
                return fInfo.Length;
            }
            catch
            {
                return 0;
            }


        }

        ////
        public static string GetEXEDirectory()
        {
            return Application.StartupPath;
        }

        //
        public static void ThrowSQLException(string File, long Line)
        {
            //    //string Title(GetApplicationObject()->GetName());
            //    if (SQLCODE < 0) 
            //    {
            //        // Treat the error depending on the SQLCODE. Some of the errors are displayed in a more meaningful way.
            //        switch (SQLCODE) 
            //        {
            //            case SQLE_UNABLE_TO_START_ENGINE: 
            //{   // Could be a executable missing or a low memory.
            //                if (access("dbsql.exe", 0) != 0)
            //                    DisplayError("dbsql.exe missing.", Title);
            //                else
            //                    DisplayError("Unable to start the database engine.", Title);
            //            } break;
            //            case SQLE_UNABLE_TO_START_DATABASE: 
            //{ // Database not found or not enough memory to open the database.
            //                DisplayError("Unable to start database.", Title);
            //            } break;
            //            case SQLE_DATABASE_NOT_FOUND: 
            //{
            //                DisplayError("The database has not been found.", Title);
            //            } break;
            //            case SQLE_NO_MEMORY: 
            //{                // Not enough memory to run properly.
            //                DisplayError("Not Enough Memory to start the database engine.  Close some applications and restart.", Title);
            //            } break;
            //            default: DisplaySQLError(File + "-" + NumToString(Line));
            //        }
            //        // Now, throw the exception.
            //        CXSQL  XSQL(File, Line, 0, SQLCODE);
            //        XSQL.Throw();
            //    }
        }

        public static void ThrowSQLException(string File, long Line, string ErrorMsg)
        {
            //CXSQL  XSQL(File, Line, ErrorMsg);
            //XSQL.Throw();
        }

        public static void ThrowSQLException(string File, long Line, uint ErrorId)
        {
            //CXSQL  XSQL(File, Line, 0, ErrorId);
            //XSQL.Throw();
        }

        public static string LineClassToString(TParseLine.LineClass pClass)
        {
            switch (pClass)
            {

                case TParseLine.LineClass.lcText:
                    return "Text";

                case TParseLine.LineClass.lcSection:
                    return "SECTION";

                case TParseLine.LineClass.lcBreak:
                    return "BREAK";

                case TParseLine.LineClass.lcKey:
                    return "KEY";

                case TParseLine.LineClass.lcDefinition:
                    return "DEFINITION";

                case TParseLine.LineClass.EndOfFile:
                    return "End of File";

                case TParseLine.LineClass.lcSubHeader:
                    return "SUBHEADER";

                case TParseLine.LineClass.lcCaption:
                    return "CAPTION";

                case TParseLine.LineClass.lcList:
                    return "LIST";

                case TParseLine.LineClass.lcEndList:
                    return "END LIST";

                case TParseLine.LineClass.lcTable:
                    return "TABLE";

                case TParseLine.LineClass.lcEndTable:
                    return "END TABLE";

                case TParseLine.LineClass.lcIndent:
                    return "INDENT";

                case TParseLine.LineClass.lcDate:
                    return "DATE";

                default:
                    return "Unknown";
            }
        }

        public static string RPad(string ts, int PadWidth)
        {
            for (int i = ts.Length; i < PadWidth; i++)
                ts = ts + " ";
            return ts;
        }


        // WrapOffset.  This function returns the position of the last character before a space for the
        //  specified width.   This function takes the following parameters:
        //
        //       TStr   string    (Passed) String to check.
        //       Width  int       (Passed) Clip width.
        //
        public static long WrapOffset(string TStr, int Width)
        {
            if (TStr.Length <= Width)
                return TStr.Length;
            else
            {
                UTIL.Assert(Width > 0, "Assertion Failed: Width > 0!");
                for (int i = Width - 1; i >= 0; i--)
                    if (TStr[i] == ' ')
                        return i;

                return Width;
            }
        }

        // strips duplicate spaces.


        // Backscan. Returns the last position of the specified character in the
        // string or -1 if the character is not found.
        public static int BackScan(string ts, char Match)
        {
            return ts.LastIndexOf(Match);
        }
        public static int BackScan(string ts )
        {
            char Match='-';

            return ts.LastIndexOf(Match);
        }

        public static int find_first_not_of(string str, char[] chars)
        {
            int ret = -1;

            for (int i = 0; i < str.Length; i++)
            {
                if (str.IndexOfAny(chars, i, 1) == -1)
                {
                    ret = i;
                    break;
                }
            }
            return ret;
        }

        public static bool ListLongFind(List<long> lngList, long value)
        {
            _data = value;

            return value == lngList.Find(matchData);
            //foreach (long lng in lngList)
            //{
            //    if (lng == value)
            //    {
            //        return true;
            //    }
            //}
            //return false;
        }

        private static long _data =0;
        private static bool matchData(long data)
        {
            if (data == _data)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
 
        public static bool CheckDataSet(DataSet ds)
        {
            if (ds == null || ds.Tables.Count < 1 || ds.Tables[0].Rows.Count < 1) 
            {
                return false;
            }

            return true;
        }

        public static bool CheckDataSet(DataSet ds, string tbName)
        {
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[tbName].Rows.Count > 0) 
            {
                return true;
            }

            return false;
        } 

        public static void Assert(bool Condition, string Message)
        {
            if (!Condition)
            {
                throw (new Exception(Message));
                //MessageBox.Show(Message, "Assretion Failed", MessageBoxButtons.OK);

                //Application.Exit();
            }
        }


        public enum SnapshotFlags : int
        {

            TH32CS_SNAPHEAPLIST = 0x00000001,
            TH32CS_SNAPPROCESS = 0x00000002,
            TH32CS_SNAPTHREAD = 0x00000004,
            TH32CS_SNAPMODULE = 0x00000008,
            TH32CS_SNAPMODULE32 = 0x00000010,
            TH32CS_SNAPALL = (TH32CS_SNAPHEAPLIST | TH32CS_SNAPPROCESS | TH32CS_SNAPTHREAD | TH32CS_SNAPMODULE)
            //TH32CS_INHERIT = 0x80000000;
        }
        public enum ProcessAccessFlags : int
        {
            All = 0x001F0FFF,
            Terminate = 0x00000001,
            CreateThread = 0x00000002,
            VMOperation = 0x00000008,
            VMRead = 0x00000010,
            VMWrite = 0x00000020,
            DupHandle = 0x00000040,
            SetInformation = 0x00000200,
            QueryInformation = 0x00000400,
            Synchronize = 0x00100000
            //STANDARD_RIGHTS_REQUIRED = 0x000F0000,
            //SYNCHRONIZE = 0x00100000,
            //PROCESS_ALL_ACCESS = (STANDARD_RIGHTS_REQUIRED | SYNCHRONIZE | 0xFFFF)
        }
        public static bool KillProcess(string pName)
        {
            IntPtr hndl = CreateToolhelp32Snapshot(SnapshotFlags.TH32CS_SNAPPROCESS, 0);
            uint dwExitCode = 0;

            PROCESSENTRY32 procEntry = new PROCESSENTRY32();
            //procEntry.dwSize = sizeof(PROCESSENTRY32);
            procEntry.dwSize = (uint)System.Runtime.InteropServices.Marshal.SizeOf(typeof(PROCESSENTRY32));

            if (!Process32First(hndl, ref procEntry))
            {
                return false;
            }

            do
            {
                if (procEntry.szExeFile.ToLower() == pName)
                {
                    IntPtr hHandle = OpenProcess(ProcessAccessFlags.All, false, procEntry.th32ProcessID);

                    GetExitCodeProcess(hHandle, out dwExitCode);
                    bool bl = TerminateProcess(hHandle, dwExitCode);
                    return true;
                }
            } while (Process32Next(hndl, ref procEntry));

            return false;
        }

        public static DialogResult InputBox(string title, string promptText, ref string value)
        {
            Form form = new Form();
            Label label = new Label();
            TextBox textBox = new TextBox();
            Button buttonOk = new Button();
            Button buttonCancel = new Button();

            form.Text = title;
            label.Text = promptText;
            textBox.Text = value;

            buttonOk.Text = "OK";
            buttonCancel.Text = "Cancel";
            buttonOk.DialogResult = DialogResult.OK;
            buttonCancel.DialogResult = DialogResult.Cancel;

            label.SetBounds(9, 20, 372, 13);
            textBox.SetBounds(12, 36, 372, 20);
            buttonOk.SetBounds(228, 72, 75, 23);
            buttonCancel.SetBounds(309, 72, 75, 23);

            label.AutoSize = true;
            textBox.Anchor = textBox.Anchor | AnchorStyles.Right;
            buttonOk.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            buttonCancel.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;

            form.ClientSize = new Size(396, 107);
            form.Controls.AddRange(new Control[] { label, textBox, buttonOk, buttonCancel });
            form.ClientSize = new Size(Math.Max(300, label.Right + 10), form.ClientSize.Height);
            form.FormBorderStyle = FormBorderStyle.FixedDialog;
            form.StartPosition = FormStartPosition.CenterScreen;
            form.MinimizeBox = false;
            form.MaximizeBox = false;
            form.AcceptButton = buttonOk;
            form.CancelButton = buttonCancel;

            DialogResult dialogResult = form.ShowDialog(_main);
            value = textBox.Text;
            return dialogResult;
        }

        public static string GetSqlServerConnectionString(string address, string db)
        {
            string res = @"Connect Timeout=0;Data Source=" + address.Trim() +
                    ";Initial Catalog=" + db.Trim() + ";Integrated Security=SSPI;";
            return res;
        }
        public static string GetSqlServerConnectionString(string address, string db, string user, string pass)
        {
            string res = @"Connect Timeout=0;Data Source=" + address.Trim() +
                ";Initial Catalog=" + db.Trim() + ";User ID=" + user.Trim() + ";Password=" + pass.Trim();
            return res;
        }

        public static void iniSqlServer(ComboBox cboServer, string defaultServer)
        {
            cboServer.Items.Clear();

            List<SqlServerList> AllInstanceSqlserver = GetInstance.GetInstanceName();

            foreach (SqlServerList sqlSvr in AllInstanceSqlserver)
            {
                string fullSvrName = null;
                if (sqlSvr.InstanceName == "")
                {
                    fullSvrName = sqlSvr.ServerName;
                }
                else
                {
                    fullSvrName = sqlSvr.ServerName + @"\" + sqlSvr.InstanceName;
                }

                cboServer.Items.Add(fullSvrName);

            }

            for (int i = 0; i < cboServer.Items.Count; i++)
            {
                if (cboServer.Items[i].ToString().ToLower() == defaultServer)
                {
                    cboServer.SelectedIndex = i;
                    break;
                }
            }

            if (cboServer.Items.Count > 0 && cboServer.SelectedIndex == -1)
            {
                cboServer.SelectedIndex = 0;
            }
        }

        //public static string BulkCopy(SqlConnection sourceConnection, SqlConnection destinationConnection, string TableName, SqlTransaction Transaction)
        //{
        //    //// Use bulk copy to copy the data table into the destination table 
        //    //using (SqlBulkCopy bulkCopy = new SqlBulkCopy(destinationConnection, SqlBulkCopyOptions.Default, transaction)) 
        //    //{ 
        //    //    bulkCopy.DestinationTableName = destinationTablename; 
        //    //    bulkCopy.NotifyAfter = 1000; 
        //    //    bulkCopy.WriteToServer(sourceData);
        //    //    bulkCopy.Close(); 
                
        //    //    // Log success 
        //    //    result = true; 
        //    //    TransportLog.LogMessage(destinationServiceName, "Task successful: Updated table " + destinationTablename + " successfully."); }

        //    // Open a sourceConnection to the AdventureWorks database.
        //    if (sourceConnection.State == ConnectionState.Closed)
        //    {
        //        sourceConnection.Open();
        //    }
        //    if (destinationConnection.State == ConnectionState.Closed)
        //    {
        //        destinationConnection.Open();
        //    }

        //    // Get data from the source table as a SqlDataReader.
        //    SqlCommand commandSourceData = new SqlCommand("SELECT  * FROM " + TableName, sourceConnection);
        //    SqlDataReader reader = commandSourceData.ExecuteReader();

        //    using (SqlBulkCopy bulkCopy = new SqlBulkCopy(destinationConnection,
        //            SqlBulkCopyOptions.Default, Transaction))
        //    {

        //        bulkCopy.DestinationTableName = TableName;
        //        bulkCopy.BulkCopyTimeout = 360;
        //        try
        //        {
        //            // Write from the source to the destination.
        //            bulkCopy.WriteToServer(reader);
        //        }
        //        catch (Exception ex)
        //        {
        //            return ex.Message;
        //        }
        //        finally
        //        {
        //            reader.Close();
        //            bulkCopy.Close();
        //        }
        //    }

        //    return "";
        //}
        public static string BulkCopy(SqlConnection sourceConnection, SqlConnection destinationConnection,
                string TableName, SqlTransaction Transaction)
        {
            // Open a sourceConnection to the AdventureWorks database.
            if (sourceConnection.State == ConnectionState.Closed)
            {
                sourceConnection.Open();
            }
            if (destinationConnection.State == ConnectionState.Closed)
            {
                destinationConnection.Open();
            }

            // Get data from the source table as a SqlDataReader.
            SqlCommand commandSourceData = new SqlCommand("SELECT  * FROM " + TableName, sourceConnection);
            SqlDataReader reader = commandSourceData.ExecuteReader();

            commandSourceData.CommandTimeout = 0;

            using (SqlBulkCopy bulkCopy = new SqlBulkCopy(destinationConnection,
                    SqlBulkCopyOptions.Default, Transaction))
            {

                bulkCopy.DestinationTableName = TableName;
                bulkCopy.BulkCopyTimeout = 0;

                //bulkCopy.BatchSize = 3000;
                try
                {
                    // Write from the source to the destination.
                    bulkCopy.WriteToServer(reader);
                }
                catch (Exception ex)
                {
                    return ex.Message;
                }
                finally
                {
                    if (reader != null)
                    {
                        reader.Close();
                        reader.Dispose();
                    }
                    if (bulkCopy != null)
                    {
                        bulkCopy.Close();
                        ((IDisposable)bulkCopy).Dispose();
                    }
                }
            }

            return "";
        }
        public static string BulkCopy(SqlConnection sourceConnection, SqlConnection destinationConnection,
                string TableName, string[] FieldNames, SqlTransaction Transaction)
        {
            // Open a sourceConnection to the AdventureWorks database.
            if (sourceConnection.State == ConnectionState.Closed)
            {
                sourceConnection.Open();
            }
            if (destinationConnection.State == ConnectionState.Closed)
            {
                destinationConnection.Open();
            }

            // Get data from the source table as a SqlDataReader.
            StringBuilder sbSelect = new StringBuilder();

            if (FieldNames == null || FieldNames.Length == 0)
            {
                sbSelect.Append("*");
            }
            else
            {
                foreach (string str in FieldNames)
                {
                    sbSelect.Append(str + ",");
                }

                if (sbSelect.Length > 0)
                {
                    sbSelect.Remove(sbSelect.Length - 1, 1);
                }
            }

            SqlCommand commandSourceData = new SqlCommand("SELECT " + sbSelect.ToString() + " FROM " + TableName, sourceConnection);
            SqlDataReader reader = commandSourceData.ExecuteReader();

            using (SqlBulkCopy bulkCopy = new SqlBulkCopy(destinationConnection,
                    SqlBulkCopyOptions.Default, Transaction))
            {

                bulkCopy.DestinationTableName = TableName;
                bulkCopy.BulkCopyTimeout = 3600;
                if (FieldNames != null)
                {
                    foreach (string str in FieldNames)
                    {
                        bulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping(str, str));
                    }
                }

                try
                {
                    // Write from the source to the destination.
                    bulkCopy.WriteToServer(reader);
                }
                catch (Exception ex)
                {
                    return ex.Message;
                }
                finally
                {
                    if (reader != null)
                    {
                        reader.Close();
                        reader.Dispose();
                    }
                    if (bulkCopy != null)
                    {
                        bulkCopy.Close();
                        ((IDisposable)bulkCopy).Dispose();
                    }

                }
            }

            return "";
        }
        public static string BulkCopy(SqlConnection sourceConnection, SqlConnection destinationConnection,
                string TableName, string[] FieldNames, string SqlSelect, SqlTransaction Transaction)
        {
            // Open a sourceConnection to the AdventureWorks database.
            if (sourceConnection.State == ConnectionState.Closed)
            {
                sourceConnection.Open();
            }
            if (destinationConnection.State == ConnectionState.Closed)
            {
                destinationConnection.Open();
            }

            // Get data from the source table as a SqlDataReader.
            SqlCommand commandSourceData = new SqlCommand(SqlSelect, sourceConnection);
            SqlDataReader reader = commandSourceData.ExecuteReader();

            using (SqlBulkCopy bulkCopy = new SqlBulkCopy(destinationConnection,
                    SqlBulkCopyOptions.Default, Transaction))
            {

                bulkCopy.DestinationTableName = TableName;
                bulkCopy.BulkCopyTimeout = 3600;
                if (FieldNames != null)
                {
                    foreach (string str in FieldNames)
                    {
                        bulkCopy.ColumnMappings.Add(new SqlBulkCopyColumnMapping(str, str));
                    }
                }

                try
                {
                    // Write from the source to the destination.
                    bulkCopy.WriteToServer(reader);
                }
                catch (Exception ex)
                {
                    return ex.Message;
                }
                finally
                {
                    if (reader != null)
                    {
                        reader.Close();
                        reader.Dispose();
                    }
                    if (bulkCopy != null)
                    {
                        bulkCopy.Close();
                        ((IDisposable)bulkCopy).Dispose();
                    }
                }
            }

            return "";
        }

        public static StreamWriter CreateStream(string OutputDirectory)
        {
            string ts = OutputDirectory;
            StreamWriter oFile = null;

            try
            {
                //oFile = new StreamWriter(ts);
                //oFile = new StreamWriter(ts, false, Encoding.Default);
                oFile = new StreamWriter(ts, false, Encoding.Unicode);
            }
            catch (Exception e)
            {
                throw (new Exception(e.Message + Environment.NewLine + "Could not create " + ts + "."));
            }

            return oFile;
        }
    }
}
