// _TOKEN_H_  Copyright (c) 1993, 1995,  Dakota Software Corporation. All rights reserved.
// This unit defines a simple object that takes an input string and converts it into a token stream.
//
//  The following tokens are extracted:
//
//      tokSYSTEM      SYSTEM   tokDOMAIN  DOMAIN   tokSUBQUESTION  SUBQUESTION
//      tokPARENT      PARENT   tokEND     END      tokSET          SET
//      tokTITLE       TITLE    tokIF      IF       tokNOT          NOT
//      tokAND         AND      tokOR      OR       tokLeftParen    (
//      tokRightParen  )        tokAsterisk     *   tokFOR          FOR
//      tokIs          IS       tokQuoted  "..."    tokComma        ,
//      tokDollar      $        tokRList   [...]    tokSymbol      any other text/numbers/dashes
//      OutofTokens
//
//  To use this object:
//
//    1. Instantiate the object using new and init.
//
//           TTokenPump P;
//
//           TTokenPump* P = new TTokenPump ();
//
//    2. Then you need to load a line to be broken into tokens, using Load.
//
//           P.Load ('IF (QID IS [NYPD]) OR (ABC WAS NOT ANSWERED) SET NO_AUDIT');
//
//    3. Now you can play with the parsed information using the following methods:
//
//           SaveNote          Saves a note message associated with the parsing of the token stream.
//           SaveError         Similar to SaveNote, but adds the prefix '-> Error:'.
//           SaveWarning       Similar to SaveNote, but adds the prefix '-> Warning:'.
//           Peek              Returns the token type of the current token.
//           Clear             Reinitializes and clears the token stream.
//           AdvanceToken      Advances pointer to the next token in the stream.
//           CurrentToken      Returns a pointer to the current token.
//
//    4. If you want to parse additional lines, repeat from step (2).
//
//    5. When you are all done, you need to dellocate the object.
//
//            delete P;
//
//  Revision History
//
//     08/04/95   CSB   Expand to recognize new identifiers, COMPLETE, DOS, FORMAT, LIST
//     03/27/95   CSB.  Convert to C++, add new flow tokens, delete obsolete tokens.
//     11/18/93   CSB.  Add SaveWarning method.
//     07/23/93   CSB.  Removed SHOW and ANSWERED tokens because they are obsolete.
//     07/23/93   CSB.  Initial Release.

using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;

namespace RGTools_New
{
    public enum TTokenType
    {
        tokSYSTEM, tokDOMAIN, tokSUBQUESTION, tokPARENT, tokEND, tokSET,
        tokTITLE, tokIF, tokNOT, tokAND, tokOR, tokLeftParen, tokRightParen,
        tokComma, tokAsterisk, tokSymbol, tokIS, tokDollar, tokForcedOR,
        tokVARIABLE,
        tokFORMAT, tokLIST, tokDOS, tokCOMPLETE,
        tokRList, tokQuoted, OutOfTokens, Undefined
    }

    class TToken
    {
        protected string Name;
        protected TTokenType Value;

        public TToken() { Name = ""; Value = TTokenType.Undefined; } // ructor
        public TToken(string PName, TTokenType PValue) { SetName(PName); Value = PValue; }

        public void SetName(string PName) { Name = PName; Name = Name.Trim(new char[]{' '}); }
        public string GetName() { return Name; }
        public string TokenName
        {
            set
            {
                Name = value.Trim(new char[]{' '});
            }
            get
            {
                return Name;
            }
        }

        public void SetTokenType(TTokenType PValue) { Value = PValue; }
        public TTokenType GetTokenType() { return Value; }
        public TTokenType TokenType
        {
            set
            {
                Value = value;
            }
            get
            {
                return Value;
            }
        }

        //in C# may be there can not override operator=  Jun 26, 2008
        //public static  void operator= (TToken token)
        //       { Name = token.Name; Value = token.Value; }
        public static bool operator ==(TToken token1, TToken token2)
        {
            if (IsNull(token1) && IsNull(token2))
            {
                return true;
            }
            else if (IsNull(token1) || IsNull(token2))
            {
                return false;
            }
            else
            {
                return token1.Name == token2.Name ? true : false;
            }
        }
        public static bool operator !=(TToken token1, TToken token2)
        {
            if (IsNull(token1) && IsNull(token2))
            {
                return false;
            }
            else if (IsNull(token1) || IsNull(token2))
            {
                return true;
            }
            else
            {
                return token1.Name != token2.Name ? true : false;
            }
        }
        public static bool IsNull(TToken token)
        {
            return TToken.Equals(token, null);
        }
        public override bool Equals(object token)
        {
            if (IsNull(token as TToken))
            {
                return false;
            }
            else
            {
                return this.Name == (token as TToken).Name ? true : false;
            }
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }

    class TTokenPump
    {
        protected List<TToken> TokenList=new List<TToken>();     // List of tokens
        protected string OriginalLine;  // Original Input Line
        protected int CurrentTokenNumber = 0;     // Current token being referenced

        public TStrList NoteList = new TStrList(true);          // Error list, if any. not sure: True or false. Jun 25, 2008

        public TTokenPump() // ructor
        {
            CurrentTokenNumber = 0;
        }


        // Load.  Loads a new input line into the token pump. Input lines //ning with a
        //  space or an asterisk are not parsed.
        public void Load(ref string InputLine)
        {
            // First clear the Token List.
            Clear();

            // Save a copy of the input line for display if needed. 
            OriginalLine = InputLine;

            UTIL.Assert(InputLine.Length > 0, "Assertion Failed: InputLine.Length > 0!");

            // Allocate token
            TToken Token = new TToken();

            // Scan through the tokens.
            while (GetToken(ref InputLine, Token))
            {
                // Add this token to the list and generate a new one.
                TokenList.Add(Token);

                Token = new TToken();
            }
        }
        public void SaveError(string Description)
        {
            StringBuilder estr = new StringBuilder();
            estr.Append("-> Error: " + Description + Environment.NewLine);// ends;
            SaveNote(estr.ToString());
        }
        public void SaveWarning(string Description)
        {
            StringBuilder wstr = new StringBuilder();
            wstr.Append("-> Warning: " + Description + Environment.NewLine);// ends;
            SaveNote(wstr.ToString());
        }
        public void SaveNote(string Description)
        {
            NoteList.Add(Description);
        }
        public TTokenType Peek()
        {
            if ((TokenList.Count == 0) || (TokenList.Count <= CurrentTokenNumber))
                return TTokenType.OutOfTokens;
            else
                return CurrentToken.TokenType;//.GetTokenType();
        }
        public TTokenType TokenType
        {
            get
            {
                if ((TokenList.Count == 0) || (TokenList.Count <= CurrentTokenNumber))
                    return TTokenType.OutOfTokens;
                else
                    return CurrentToken.TokenType;// GetTokenType();

            }
        }
        public void Clear()
        {
            TokenList.Clear();

            // Reset the error list.
            NoteList.Clear();

            // Current Token is back to zero.
            CurrentTokenNumber = 0;
        }

        public TToken CurrentToken
        {
            get
            {
                return TokenList[CurrentTokenNumber];
            }
        }
        public void Dump()
        {
            for (int i = 0; i < TokenList.Count; i++)
            {
                //if (i == CurrentTokenNumber)
                //    cout + '*';
                //cout + TokenList[i].TokenName + " " + TokenList[i].TokenType + endl;
            }
        }

        struct stuctToken
        {
            private string _Name;
            private TTokenType _Tok;

            public stuctToken(string Name, TTokenType Tok)
            {
                _Tok = Tok;
                _Name = Name;
            }

            public string Name
            {
                get
                {
                    return _Name;
                }
            }
            public TTokenType Tok
            {
                get
                {
                    return _Tok;
                }
            }
        }

        static stuctToken[] TokenArray = new stuctToken[]  
        { 
            new stuctToken("SYSTEM", TTokenType.tokSYSTEM), 
            new stuctToken("DOMAIN", TTokenType.tokDOMAIN),
            new stuctToken("SUBQUESTION", TTokenType.tokSUBQUESTION), 
            new stuctToken("PARENT", TTokenType.tokPARENT),
            new stuctToken("END", TTokenType.tokEND), 
            new stuctToken("SET", TTokenType.tokSET), 
            new stuctToken("TITLE", TTokenType.tokTITLE),
            new stuctToken("NOT", TTokenType.tokNOT), 
            new stuctToken("AND", TTokenType.tokAND), 
            new stuctToken("OR", TTokenType.tokOR),
            new stuctToken("VARIABLE", TTokenType.tokVARIABLE), 
            new stuctToken("DOS", TTokenType.tokDOS),
            new stuctToken("FORMAT", TTokenType.tokFORMAT), 
            new stuctToken("LIST", TTokenType.tokLIST),
            new stuctToken("COMPLETE", TTokenType.tokCOMPLETE), 
            new stuctToken(",", TTokenType.tokComma),
            new stuctToken("(", TTokenType.tokLeftParen), 
            new stuctToken(")", TTokenType.tokRightParen),
            new stuctToken("F-OR", TTokenType.tokForcedOR),
            new stuctToken("*", TTokenType.tokAsterisk), 
            new stuctToken("IS", TTokenType.tokIS), 
            new stuctToken("IF", TTokenType.tokIF),
            new stuctToken(",", TTokenType.tokComma), 
            new stuctToken("$", TTokenType.tokDollar)
        };

        private bool GetToken(ref string InputLine, TToken Token)
        {
            //int TokenCount = 31;

            // Eliminate leading and trailing spaces //
            InputLine = InputLine.Trim(new char[]{' '});

            // If the length of the line is zero, there are no more tokens.
            if (InputLine.Length == 0)
                return false;

            // If the first character is quote, we have a special case of a quoted string.
            if (InputLine[0] == '"')
            {
                InputLine=InputLine.Remove(0, 1);

                int BreakQuote = InputLine.IndexOf(@"\""");
                if (BreakQuote == -1)
                {
                    Token.SetName(InputLine);
                    InputLine = "";
                    SaveWarning("No closing quote!");
                }
                else
                {
                    Token.SetName(InputLine.Substring(0, BreakQuote));
                    InputLine=InputLine.Remove(0, BreakQuote + 1);
                }

                Token.SetTokenType(TTokenType.tokQuoted);

                return true;
            }

            // scan for break character
            int BreakPoint = UTIL.find_first_not_of(InputLine, new char[] { 'A','B','C','D','E','F','G','H','I',
                'J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e',
                'f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','.',
                '0','1','2','3','4','5','6','7','8','9','[',']','_','-',':' });

            // Extract token and clip it from the input line.
            if (BreakPoint == -1)
            {
                Token.SetName(InputLine);
                InputLine = "";
            }
            else
            {
                if (BreakPoint == 0) BreakPoint = 1;
                Token.SetName(InputLine.Substring(0, BreakPoint));
                InputLine=InputLine.Remove(0, BreakPoint);
            }

            // Determine Token code.
            for (int i = 0; i < TokenArray.Length; i++)
            {
                if (Token.TokenName == TokenArray[i].Name)  //.GetName()
                {
                    //Token.SetTokenType(TokenArray[i].Tok);
                    Token.TokenType = TokenArray[i].Tok;
                    return true;
                }
            }
            // Token must be a variable. Unless it's an rlist.
            //Token.SetTokenType((Token.TokenName[0] == '[') ? TTokenType.tokRList : TTokenType.tokSymbol);//.GetName()
            Token.TokenType=(Token.TokenName[0] == '[') ? TTokenType.tokRList : TTokenType.tokSymbol;//.GetName()
            return true;
        }

        public static TTokenPump operator ++(TTokenPump t)
        {
            t.CurrentTokenNumber++;
            return t;
        }   
    }
}
