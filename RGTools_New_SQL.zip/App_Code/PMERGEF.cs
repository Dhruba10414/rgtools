﻿//----------------------------------------------------------------------------
//  Project RGTools
//  Dakota Software Corporation
//  Copyright � 1997. All Rights Reserved.
//  FILE:    pgmergef.h
//  AUTHOR:  Marc CHANTEGREIL
//
//  OVERVIEW
//  ~~~~~~~~
//  Class definition for TPageMergeFederal (TPageWithDB).
//
//----------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Threading;
using System.Diagnostics;
using System.Windows.Forms;
//using System.Data;
//using System.Data.Sql;
using System.Data.SqlClient;
using System.Collections;

namespace RGTools_New
{
    //****************************************************************************
    //**////////////////// TListModule ///////////////////////////////////////////
    //****************************************************************************
    using ListModuleType = List<TListModule>;
    using ListModuleTypeIterator = List<TListModule>;

    class TListModule
    {
        // Data members
        protected string m_sModuleName;
        protected long m_lModuleSN;
        protected short m_iModuleVersionSN;

        // ructors, Destructors
        public TListModule(string ModuleName, long ModuleSN, short ModuleVersionSN)
        {
            m_sModuleName = ModuleName;
            m_lModuleSN = ModuleSN;
            m_iModuleVersionSN = ModuleVersionSN;
        }
        public TListModule(TListModule Other)
        {
            m_sModuleName = Other.m_sModuleName;
            m_lModuleSN = Other.m_lModuleSN;
            m_iModuleVersionSN = Other.m_iModuleVersionSN;
        }

        public static bool operator ==(TListModule c1, TListModule c2) { return c1.m_lModuleSN == c2.m_lModuleSN; }
        public static bool operator !=(TListModule c1, TListModule c2) { return c1.m_lModuleSN != c2.m_lModuleSN; }
        public static bool operator <(TListModule c1, TListModule c2) { return c1.m_lModuleSN < c2.m_lModuleSN; }
        public static bool operator >(TListModule c1, TListModule c2) { return c1.m_lModuleSN > c2.m_lModuleSN; }
        public string GetModuleName() { return m_sModuleName; }
        public long GetModuleSN() { return m_lModuleSN; }
        public short GetModuleVersionSN() { return m_iModuleVersionSN; }

        public string ModuleName
        {
            get
            {
                return m_sModuleName;
            }
        }
        public long ModuleSN
        {
            get
            {
                return m_lModuleSN;
            }
        }
        public short ModuleVersionSN
        {
            get
            {
                return m_iModuleVersionSN;
            }
        }
        public override bool Equals(object obj)
        {
            if (TListModule.Equals((obj as TListModule), null))
            {
                return false;
            }
            else
            {
                return m_lModuleSN == ((TListModule)obj).m_lModuleSN;
            }
        }
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override string ToString()
        {
            return m_sModuleName; 
        }
    }

    //******************************************************************
    //**//// TPageMergeFederal /////////////////////////////////////////
    //******************************************************************
    class TPageMergeFederal
    {
        static string SEP_LISTREF = ASCIIEncoding.Default.GetString(new byte[] { 0X7f });//"\\X7F";

        const string _sqlGostQeustionTable = "IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE='BASE TABLE' AND TABLE_NAME='RetiredQuest') CREATE TABLE [dbo].[RetiredQuest](NewQuestionSN int NOT NULL,OldQuestionSN int NOT NULL,KLIne nvarchar(500) NULL,ModuleVersionSN int NULL,IsDeleted bit NULL)";

        private frmMain _main = null;

        // Data Members
        protected CMModuleSet MModuleToMerge = null;
        protected CMModuleVersionSet MModuleVersionToMerge = null;
        protected CMModuleSet MModuleMaster = null;
        protected CMModuleVersionSet MModuleVersionMaster = null;
        protected CMQDLinkSet MQDLinkMaster = null;
        protected CMApplicVarSetPure MApplicVarMaster = null;

        DataSql sqlbaseMaster = null;
        DataSql sqlbaseModule = null;
     
        // constructors, Destructors.
        public TPageMergeFederal(frmMain Main)
        {
            _main = Main;

            sqlbaseMaster = new DataSql(_main.txtMergeFMMasterServer.Text, _main.txtMergeFMMasterDB.Text,
                    _main.MergeFMMasterUser, _main.MergeFMMasterPW);
            sqlbaseModule = new DataSql(_main.txtMergeFMModuleServer.Text, _main.txtMergeFMModuleDB.Text,
                    _main.MergeFMModuleUser, _main.MergeFMModulePW);
        }

        public void DoProcess()
        {
            try
            {
                // Merging - First pass (creation of Merge.sql).
                MergeFederal();
            }
            catch (Exception e)
            {
                ErrorThrow("Interrupted in " + e.Message);
            }
        }

        // private methods.
        private void MergeFederal()
        {
            string errMessage = "";
            string msg = null;
            
            sqlbaseMaster.Open();
            MModuleMaster = new CMModuleSet("Module");
            MModuleVersionMaster = new CMModuleVersionSet("ModuleVersion");
            sqlbaseMaster.RunSQL(_sqlGostQeustionTable);
            sqlbaseMaster.Close();

            // Contains the list of QuestionSN for the last Module version.
            Hashtable QuestInMaster = new Hashtable();

            //***************************************************************************
            // Get the Version Names and Research Dates for both products.
            string DAVersionName = _main.txtVNameDA.Text.Trim();
            if (DAVersionName.Length > 25)
            {
                DAVersionName = DAVersionName.Substring(0, 25);
            }
            string BNAVersionName = _main.txtVNameSC.Text.Trim();
            if (BNAVersionName.Length > 25)
            {
                BNAVersionName = BNAVersionName.Substring(0, 25);
            }

            string DAResearchDate = _main.txtDateDA.Text.Trim();
            if (DAResearchDate == "" || !UTIL.IsADate(DAResearchDate))
            {
                DAResearchDate = "0";
            }
            else
            {
                DateTime TmpDate;
                try
                {
                    TmpDate = DateTime.Parse(DAResearchDate);
                }
                catch
                {
                    throw (new Exception(DAResearchDate + " is not a valid date."));
                }
                DAResearchDate = TmpDate.ToString("yyyyMMdd");
            }

            string BNAResearchDate = _main.txtDateSC.Text.Trim();// GetDlgField (this, IDC_DATEBNA);
            if (BNAResearchDate == "" || !UTIL.IsADate(BNAResearchDate))
            {
                BNAResearchDate = "0";
            }
            else
            {
                DateTime TmpDate;
                try
                {
                    TmpDate = DateTime.Parse(BNAResearchDate);
                }
                catch
                {
                    throw (new Exception(BNAResearchDate + " is not a valid date."));
                }
                BNAResearchDate = TmpDate.ToString("yyyyMMdd");
            }

            //***************************************************************************
            // Find the next ModuleVersionSN (Module Independent).
            if (MModuleVersionMaster.FetchLastDS() != EnumSQLError.DB_NOERROR)
            {
                throw (new Exception("Error when trying to access the last ModuleVersionSN in Module Master."));
            }

            int intLastModuleVersionSN = MModuleVersionMaster.GetModuleVersionSN();
            int NewModuleVersionSN = intLastModuleVersionSN+1;
            _main.OutMsg(PageType.MergeFederal, "The new Module Version SN is " + NewModuleVersionSN.ToString() + ".\r\n");

            //***************************************************************************
            // Do a loop on all the modules to merge.
            long ModuleSN;
            string ModuleName;

            _main.OutMsg(PageType.MergeFederal, "Processing Modules.\r\n");

            sqlbaseModule.Open();

            MModuleToMerge = new CMModuleSet("Module");
            MModuleVersionToMerge = new CMModuleVersionSet("ModuleVersion");
            CMQuestionSet MQuestionToMerge = new CMQuestionSet("Question");
            CMRetiredQuestSet MRetiredQuest = new CMRetiredQuestSet("RetiredQuest");

            sqlbaseModule.RunSQL(Query.DeleteConstrains, true);

            // Update the ToMerge Module Database with the new VersionSN and VersionName for this module.
            sqlbaseModule.RunSQL(new string[]{
                            "delete from  dbo.question where dbo.question.questionbodysn not in (select questionbodysn from dbo.questionbody)",
                            "UPDATE RetiredQuest SET IsDeleted = 0,ModuleVersionSN = " + NewModuleVersionSN.ToString(),
                            "UPDATE aw_Hyperlink SET ModuleVersionSN = " + NewModuleVersionSN.ToString() +
                            " WHERE ModuleSN <>0 ",
                            "UPDATE aw_InfoOnly SET ModuleVersionSN = " + NewModuleVersionSN.ToString() +
                            " WHERE ModuleSN <>0 ",
                            "UPDATE DomainStructure SET ModuleVersionSN = " + NewModuleVersionSN.ToString() +
                            " WHERE ModuleSN <>0 ",
                            "UPDATE QDLink SET ModuleVersionSN = " + NewModuleVersionSN.ToString() +
                            " WHERE ModuleSN <>0 ",
                            "UPDATE QSLink SET ModuleVersionSN = " + NewModuleVersionSN.ToString() +
                            " WHERE ModuleSN <>0 ",
                            "UPDATE ScreenGoal SET ModuleVersionSN = " + NewModuleVersionSN.ToString() +
                            " WHERE ModuleSN <>0 ",
                            "UPDATE ApplicabilityVariable SET ModuleVersionSN = " + NewModuleVersionSN.ToString() +
                            " WHERE ModuleSN <>0 ",
                            "UPDATE TemplateRule  SET ModuleVersionSN = " + NewModuleVersionSN.ToString() +
                            " WHERE ModuleSN <>0 ",
                            "UPDATE ModuleVersion SET ModuleVersionSN = " + NewModuleVersionSN.ToString() + 
                            ", VersionName = '" +   DAVersionName + "', BNAVersionName = '" + BNAVersionName + 
                            "', DAResearchDate = " + DAResearchDate + ", BNAResearchDate = " + BNAResearchDate +
                            " WHERE ModuleSN <>0 "},
                            true);

            sqlbaseModule.RunSQL(Query.CreateConstrains, true);
            sqlbaseModule.Close();

            sqlbaseMaster.Open();

            sqlbaseMaster.RunSQL(Query.DeleteConstrains, true);
            sqlbaseMaster.RunSQL(new string[]{
                    "DELETE FROM ApplicabilityVariable WHERE ModuleVersionSN="+NewModuleVersionSN.ToString(), 
                    "DELETE FROM aw_Hyperlink WHERE ModuleVersionSN="+NewModuleVersionSN.ToString(), 
                    "DELETE FROM aw_InfoOnly WHERE ModuleVersionSN="+NewModuleVersionSN.ToString(), 
                    "DELETE FROM blob WHERE ModuleVersionSN="+NewModuleVersionSN.ToString(), 
                    "DELETE FROM BlobState WHERE ModuleVersionSN="+NewModuleVersionSN.ToString(), 
                    "DELETE FROM DomainStructure WHERE ModuleVersionSN="+NewModuleVersionSN.ToString(), 
                    "DELETE FROM moduleversion WHERE ModuleVersionSN="+NewModuleVersionSN.ToString(), 
                    "DELETE FROM QDLink WHERE ModuleVersionSN="+NewModuleVersionSN.ToString(), 
                    "DELETE FROM QSLink WHERE ModuleVersionSN="+NewModuleVersionSN.ToString(), 
                    "DELETE FROM ScreenGoal WHERE ModuleVersionSN="+NewModuleVersionSN.ToString(), 
                    "DELETE FROM StateModule WHERE ModuleVersionSN="+NewModuleVersionSN.ToString(), 
                    "DELETE FROM TemplateRule WHERE ModuleVersionSN="+NewModuleVersionSN.ToString()
                    },
                    true);

            MModuleVersionMaster = new CMModuleVersionSet("ModuleVersion");

            List<string> lstMergeFdSql = new List<string>();
            SqlTransaction transaction = sqlbaseMaster.BeginTransaction();

            MQDLinkMaster = new CMQDLinkSet("QDLink", intLastModuleVersionSN.ToString());
            MApplicVarMaster = new CMApplicVarSetPure("ApplicabilityVariable", intLastModuleVersionSN.ToString());

            if (MQDLinkMaster.BaseDataSet.Tables.Count == 0 || MApplicVarMaster.BaseDataSet.Tables.Count == 0)
            {
                _main.OutMsg(PageType.MergeFederalMaster, "Error occuurs when accessing tables QDLink and ApplicabilityVariable");
                transaction.Rollback();
                sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                sqlbaseMaster.Close();
                _main.processFailed = true;
                return;
            }


            while (MModuleToMerge.FetchNextDS() == EnumSQLError.DB_NOERROR)
            {
                if (CheckForCancel())
                {
                    transaction.Rollback();
                    sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                    sqlbaseMaster.Close();
                    return;
                }

                _main.OutMsg(PageType.MergeFederal, "   " + MModuleToMerge.GetModuleName().Trim(new char[] { ' ' }) + ".\r\n");

                ModuleSN = MModuleToMerge.GetModuleSN();
                ModuleName = MModuleToMerge.GetModuleName();

                // Check the ModuleVersionSN in the Module to Merge Database.
                MModuleVersionToMerge.SelectForModuleDS(ModuleSN);
                if (MModuleVersionToMerge.FetchNextDS() != EnumSQLError.DB_NOERROR)
                {                   
                    if (!_main.isAutoProcess)
                    {
                        transaction.Rollback();
                        sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                        sqlbaseMaster.Close();
                        
                        throw (new Exception("The Module " + ModuleName + " doesn't have any Version SN in the Module To Merge Database!"));
                    }
                    else
                    {
                        errMessage += "The Module " + ModuleName + " doesn't have any Version SN in the Module To Merge Database!\r\n";
                    }
                }

                // Check there is only one ModuleVersionSN for this module.
                if (MModuleVersionToMerge.FetchNextDS() != EnumSQLError.DB_NOTFOUND)
                {
                    if (!_main.isAutoProcess)
                    {
                        transaction.Rollback();
                        sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                        sqlbaseMaster.Close();

                        throw (new Exception("The Module " + ModuleName + " has more than one Version SN in the Module To Merge Database!"));
                    }
                    else
                    {
                        errMessage += "The Module " + ModuleName + " has more than one Version SN in the Module To Merge Database!\r\n";
                    }
                }

                if (MModuleMaster.SelectSNDS(ModuleSN) == EnumSQLError.DB_NOERROR)
                {
                    // Module found in the Master. Generate the statements to remove everything related with this module
                    // (and which are not ModuleVersion dependent).
                    lstMergeFdSql.Add("DELETE FROM Module    WHERE ModuleSN = " + ModuleSN.ToString());
                    lstMergeFdSql.Add("DELETE FROM RGSection WHERE ModuleSN = " + ModuleSN.ToString());
                    lstMergeFdSql.Add("DELETE FROM RGTOC     WHERE ModuleSN = " + ModuleSN.ToString());
                    lstMergeFdSql.Add("DELETE FROM Blob      WHERE SN = " + ModuleSN.ToString() + " AND Class = 4;");
                    lstMergeFdSql.Add("DELETE FROM RGKeyWord WHERE ModuleSN = " + ModuleSN.ToString() + " AND ReferenceSN < 1000000000;");
                }

                if (ModuleSN != 0)
                {

                    // Insert the ModuleVersion Record in the Module Master Database.
                    lstMergeFdSql.Add("INSERT INTO ModuleVersion (ModuleVersionSN, ModuleSN, VersionName, BNAVersionName,"
                            + " DAResearchDate, BNAResearchDate) VALUES (" + NewModuleVersionSN.ToString() + "," + ModuleSN + ",'"
                            + DAVersionName + "','" + BNAVersionName + "'," + DAResearchDate + "," + BNAResearchDate + ")");
                
                }
                else
                {
                    // The system module has always only one version: the version 0.  This is the only case of a replacement
                    // of a version.  The only thing related with this version is one applicabilityvariable record.
                    // We delete this record.  The input from the Module To Merge database will add an applicabilityvariable
                    // record for the system module.  This delete statement is in fact to avoid a duplication of record
                    // during the import of the to merge module database.
                    lstMergeFdSql.Add("DELETE FROM ApplicabilityVariable WHERE ModuleSN = 0;");

                }

                MModuleVersionMaster.SelectForModuleDS(ModuleSN);

                // Get the last ModuleVersionSN for this module in the Master Database.
                if (MModuleVersionMaster.FetchLastDS() == EnumSQLError.DB_NOERROR)
                {
                    // This Module is already in the Module Master database.
                    //short LastModuleVersionSN = MModuleVersionMaster.GetModuleVersionSN();

                    // Now, dump all the Questions SN for the last version of this module.
                    // First the compliance questions.
                    MQDLinkMaster.SelectForModuleDS(ModuleSN);//MQDLinkMaster =  new CMQDLinkSet("QDLink", ModuleSN.ToString(), LastModuleVersionSN.ToString());

                    while (MQDLinkMaster.FetchNextDS() == EnumSQLError.DB_NOERROR)
                    {
                        try
                        {
                            QuestInMaster.Add(MQDLinkMaster.GetQuestionSN(), MQDLinkMaster.GetQuestionSN());
                        }
                        catch { }
                    }

                    // Second the pure applicability questions.
                    //MApplicVarMaster = new CMApplicVarSetPure("ApplicabilityVariable", ModuleSN.ToString(), LastModuleVersionSN.ToString());
                    MApplicVarMaster.SelectPureForModuleDS(ModuleSN);

                    while (MApplicVarMaster.FetchNextDS() == EnumSQLError.DB_NOERROR)
                    {
                        try
                        {
                            QuestInMaster.Add(MApplicVarMaster.GetASN(), MApplicVarMaster.GetASN());
                        }
                        catch { }
                    }
                }
            }

            //***************************************************************************
            //m_OFileMerge.WriteLine("--%Because the RGKeyWord table has been updated (records deleted), "
            //           + "we need to keep in sync. the QRLink table.");

            lstMergeFdSql.Add("DELETE FROM QRLink WHERE NOT EXISTS (SELECT ReferenceSN FROM RGKeyWord"
                       + " WHERE RGKeyWord.ReferenceSN = QRLink.ReferenceSN)");
            //***************************************************************************
            // For all the modules in Module Master and not in Module To Merge, update the version names.  We do that only
            // if at least one Research Date is not null.
            if (DAResearchDate != "0" || BNAResearchDate != "0")
            {
                //m_OFileMerge.WriteLine("--%For these modules in Module Master and not in Module ToMerge, update the version names.");

                ListModuleType ListModule = new ListModuleType();

                MModuleMaster.Reload();
                while (MModuleMaster.FetchNextDS() == EnumSQLError.DB_NOERROR)
                {
                    if (CheckForCancel())
                    {
                        transaction.Rollback();
                        sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                        sqlbaseMaster.Close();
                        return;
                    }

                    ModuleSN = MModuleMaster.GetModuleSN();
                    if (MModuleToMerge.SelectSNDS(ModuleSN) == EnumSQLError.DB_NOTFOUND)
                    {
                        // Get the last ModuleVersionSN.
                        MModuleVersionMaster.SelectForModuleDS(ModuleSN);
                        if (MModuleVersionMaster.FetchLastDS() != EnumSQLError.DB_NOERROR)
                        {                                                      
                            if (!_main.isAutoProcess)
                            {
                                transaction.Rollback();
                                sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                                sqlbaseMaster.Close();

                                throw (new Exception("Error when trying to access the last ModuleVersion SN in Module Master for "
                                       + MModuleMaster.GetModuleName()));
                            }
                            else
                            {
                                errMessage += "Error when trying to access the last ModuleVersion SN in Module Master for "
                                       + MModuleMaster.GetModuleName() + "\r\n";
                            }
                        }

                        ListModule.Add(new TListModule(MModuleMaster.GetModuleName(), ModuleSN,
                                                     MModuleVersionMaster.GetModuleVersionSN()));
                    }
                }

                if (CheckForCancel())
                {
                    transaction.Rollback();
                    sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                    sqlbaseMaster.Close();
                    return;
                }

                if (ListModule.Count > 0)
                {
                    // Have the user select the modules he wants to update the research date.
                    // TSelectInList uses its argument as an input to set the initial list and output to give back the selected
                    // items.

                    if (!_main.isAutoProcess)
                    {
                        TSelectInListDialog frmDialog = new TSelectInListDialog();
                        frmDialog.AddList(ListModule);

                        if (frmDialog.ShowDialog(_main) == DialogResult.Cancel)
                        {
                            ListModule.Clear();
                        }
                    }
                    else
                    {
                        ListModule.Clear(); //default: do not update
                    }

                    foreach (TListModule lstModule in ListModule)
                    {
                        if (CheckForCancel())
                        {
                            transaction.Rollback();
                            sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                            sqlbaseMaster.Close();
                            return;
                        }

                        if (DAResearchDate != "0")
                        {
                            lstMergeFdSql.Add("UPDATE ModuleVersion SET VersionName = '" + DAVersionName
                                         + "', DAResearchDate = " + DAResearchDate + " WHERE ModuleSN = "
                                         + lstModule.GetModuleSN() + " AND ModuleVersionSN = "
                                         + lstModule.GetModuleVersionSN());
                        }

                        if (BNAResearchDate != "0")
                        {
                            lstMergeFdSql.Add("UPDATE ModuleVersion SET BNAVersionName = '" + BNAVersionName
                                         + "', BNAResearchDate = " + BNAResearchDate + " WHERE ModuleSN = "
                                         + lstModule.GetModuleSN() + " AND ModuleVersionSN = "
                                         + lstModule.GetModuleVersionSN());
                        }
                    }
                }
            }

            if (CheckForCancel())
            {
                transaction.Rollback();
                sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                sqlbaseMaster.Close();
                return;
            }

            //***************************************************************************
            _main.OutMsg(PageType.MergeFederal, "Parsing Questions in the database to merge" + Environment.NewLine);

            // Delete all the link between Questions and References for the questions which are no more active (retired).
            // We don't have the list of retired questions.  We have, instead, the list of active questions.
            // So, by comparing the list of active questionSN in the Master Module Database (QuestInMaster)
            // and the list of active questions in the To Merge Module Database, we will know the retired questions.

            long QuestionSN;

            string ListRef;
            long h_lQuestionSN;

            // First build a B-tree containing all the active questions for the new version to merge.
            int jCount = 0;
            int jCount2 = 0;

            Hashtable QuestInToMerge = new Hashtable();
            while (MQuestionToMerge.FetchNextDS() == EnumSQLError.DB_NOERROR)
            {
                if (CheckForCancel())
                {
                    transaction.Rollback();
                    sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                    sqlbaseMaster.Close();
                    return;
                }

                jCount++;
                if (jCount % 200 == 0)
                {
                    _main.OutMsg(PageType.MergeFederal, ".");
                    jCount2++;

                    if (jCount2 > 170)
                    {
                        jCount2 = 0;
                        _main.OutMsg(PageType.MergeFederal, Environment.NewLine);

                    }
                }

                QuestionSN = MQuestionToMerge.GetQuestionSN();
                //assert (QuestionSN > 0);

                try
                {
                    QuestInToMerge.Add(QuestionSN, QuestionSN);
                }
                catch { }
            }

            _main.OutMsg(PageType.MergeFederal, " " + jCount.ToString() + " questions.\r\n");

            //m_OFileMerge.WriteLine("--%Delete the QRlink for the Retired Questions");

            //2017/3/31
            Hashtable hRetiredQuest= new Hashtable();
            Hashtable hNewQuest = new Hashtable();

            //2009.09.11
            CMRGKeyWordSetQuestion MRGKeyWord = null;
            // Read the list of active questions for the last used version, and compare each SN in the B-Tree.
            _main.OutMsg(PageType.MergeFederal, "Identifying the retired questions" + Environment.NewLine);

            jCount = 0;
            List<string> _SQLs = new List<string>();
            jCount2 = 0;

            foreach (DictionaryEntry de in QuestInMaster)
            {
                if (CheckForCancel())
                {
                    transaction.Rollback();
                    sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                    sqlbaseMaster.Close();
                    return;
                }

                QuestionSN = (long)de.Value;

                // Look in the B-Tree.
                if (QuestInToMerge[QuestionSN] == null)
                {
                    // Retired Question.
                    jCount++;
                    hRetiredQuest.Add(QuestionSN, QuestionSN);

                    if (jCount % 10 == 0)
                    {
                        _main.OutMsg(PageType.MergeFederal, ".");
                        jCount2++;

                        if (jCount2 > 170)
                        {
                            jCount2 = 0;
                            _main.OutMsg(PageType.MergeFederal, Environment.NewLine);

                        }
                    }

                    MRGKeyWord = new CMRGKeyWordSetQuestion("RGKeyWord", QuestionSN);

                    //order by SEQUENCE. added on Apr 4, 2012
                    MRGKeyWord.BeginQueryDS(null, "", "SEQUENCE asc");
                   
                    // Update this RGKeyWordList based on the table QRLink.
                    ListRef = "";
                    while (MRGKeyWord.FetchNextDS() == EnumSQLError.DB_NOERROR)
                    {
                        if (ListRef != "")
                            ListRef += SEP_LISTREF;
                        ListRef += MRGKeyWord.GetKeyWord().Trim(new char[] { ' ' });
                    }
                    if (ListRef != "")
                    {
                        h_lQuestionSN = QuestionSN;

                        ListRef = ListRef.Replace("'", "''");

                        string __SQLV_PGMERGEF_8 = "UPDATE Question SET RGKeyWordList = '" +
                                ListRef + "' WHERE QuestionSN = " + h_lQuestionSN.ToString();

                        _SQLs.Add(__SQLV_PGMERGEF_8);
                    }
                }
            }

            if (_SQLs.Count > 0)
            {
                msg = sqlbaseMaster.RunSQL(_SQLs.ToArray(), true);

                if (msg != "")
                {
                    if (!_main.isAutoProcess)
                    {
                        _main.OutMsg(PageType.MergeFederalMaster, msg);
                        transaction.Rollback();
                        sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                        sqlbaseMaster.Close();
                        _main.processFailed = true;
                        return;
                    }
                    else
                    {
                        errMessage += msg + "\r\n";
                    }
                }

            }

            _main.OutMsg(PageType.MergeFederal, " " + jCount.ToString() + " retired questions.\r\n");

            if (lstMergeFdSql.Count > 0)
            {
                msg = sqlbaseMaster.RunSQL(lstMergeFdSql.ToArray(), true);

                if (msg != "")
                {
                    if (!_main.isAutoProcess)
                    {
                        _main.OutMsg(PageType.MergeFederalMaster, msg);
                        transaction.Rollback();
                        sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                        sqlbaseMaster.Close();
                        _main.processFailed = true;
                        return;
                    }
                    else
                    {
                        errMessage += msg + "\r\n";
                    }
                }
            }

            //***************************************************************************
            _main.OutMsg(PageType.MergeFederal, "Identifying the new questions" + Environment.NewLine);
            //m_OFileMerge.WriteLine("--%Delete the active Questions in the Master Database.");
            //m_OFileMerge.WriteLine("--%They will be imported from the To Merge Database");

            jCount = 0;
            jCount2 = 0;
            _SQLs.Clear();

            foreach (DictionaryEntry de in QuestInToMerge)
            {
                if (CheckForCancel())
                {
                    transaction.Rollback();
                    sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                    sqlbaseMaster.Close();
                    return;
                }

                //if (ListLongFind(QuestInMaster, sn))
                QuestionSN = (long)de.Value;
                if (QuestInMaster[QuestionSN] != null)
                {
                    // Existing question.
                    // We know that for federal questions, there is a bijection between Question and QuestionBody.
                    _SQLs.Add("DELETE FROM Question WHERE QuestionSN = " + QuestionSN.ToString());
                    _SQLs.Add("DELETE FROM QuestionBody WHERE QuestionBodySN = " + QuestionSN.ToString());
                }
                else
                {
                    // New Question.
                    jCount++;
                    hNewQuest.Add(QuestionSN, QuestionSN);

                    if (jCount % 100 == 0)
                    {
                        _main.OutMsg(PageType.MergeFederal, ".");
                        jCount2++;

                        if (jCount2 > 170)
                        {
                            jCount2 = 0;
                            _main.OutMsg(PageType.MergeFederal, Environment.NewLine);

                        }
                    }
                }
            }

            if (_SQLs.Count > 0)
            {
                msg = sqlbaseMaster.RunSQL(_SQLs.ToArray(), true);

                if (msg != "")
                {
                    if (!_main.isAutoProcess)
                    {
                        _main.OutMsg(PageType.MergeFederalMaster, msg);
                        transaction.Rollback();
                        sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                        sqlbaseMaster.Close();
                        _main.processFailed = true;
                        return;
                    }
                    else
                    {
                        errMessage += msg + "\r\n";
                    }
                }
            }

            _main.OutMsg(PageType.MergeFederal, " " + jCount.ToString() + " new questions.\r\n");

            if (errMessage != "" && _main.isAutoProcess)
            {
                transaction.Rollback();
                sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                sqlbaseMaster.Close();

                ErrorThrow(errMessage);
                return;
            }


            //***************************************************************************
            _main.OutMsg(PageType.MergeFederal, "Identifying the ghosting retired questions" + Environment.NewLine);
            long NewQuestionSN, OldQuestionSN;
            _SQLs.Clear();
            while (MRetiredQuest.FetchNextDS() == EnumSQLError.DB_NOERROR)
            {
                if (CheckForCancel())
                {
                    transaction.Rollback();
                    sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                    sqlbaseMaster.Close();
                    return;
                }

                NewQuestionSN = MRetiredQuest.NewQuestionSN;
                OldQuestionSN = MRetiredQuest.OldQuestionSN;

                if (hNewQuest[NewQuestionSN] == null) 
                {
                    _SQLs.Add("UPDATE RetiredQuest SET IsDeleted = 1 WHERE NewQuestionSN = " + NewQuestionSN.ToString() +
                            " AND ModuleVersionSN=" + NewModuleVersionSN.ToString());
                }

                if (hRetiredQuest[OldQuestionSN] == null)
                {
                    _SQLs.Add("UPDATE RetiredQuest SET IsDeleted = 1 WHERE OldQuestionSN = " + OldQuestionSN.ToString() +
                            " AND ModuleVersionSN=" + NewModuleVersionSN.ToString());
                 }
            }

             //***************************************************************************
            // Generate the Ascii files from the ToMerge Module Database.
            // Give explicitly the names of the fields; because we don't know the order in the ModuleToMerge Database; and we
            // need a specific order in the ModuleMaster Database.

            string TempDir = _main.toolSheet.TempDir.Trim(new char[] { ' ' });   // m_pSheetParent.GetTempDir() + "\\";
            if (!TempDir.EndsWith("\\"))
            {
                TempDir += "\\";
            }

            // Import the newly created ASCII files in the Master Module Database.
            SqlConnection srcConnection = new SqlConnection(sqlbaseModule.ConnectionString);
            srcConnection.Open();
            
            _main.OutMsg(PageType.MergeFederal, "Copying table aw_Hyperlink....\r\n");
            msg = UTIL.BulkCopy(srcConnection, sqlbaseMaster.Connection, "aw_Hyperlink", transaction);
            if (msg != "")
            {
                _main.OutMsg(PageType.MergeFederalMaster, msg);
                transaction.Rollback();
                srcConnection.Close();
                sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                sqlbaseMaster.Close();
                _main.processFailed = true;
                return;
            }
            _main.OutMsg(PageType.MergeFederal, "Copying table aw_InfoOnly....\r\n");
            msg = UTIL.BulkCopy(srcConnection, sqlbaseMaster.Connection, "aw_InfoOnly", transaction);
            if (msg != "")
            {
                _main.OutMsg(PageType.MergeFederalMaster, msg);
                transaction.Rollback();
                srcConnection.Close();
                sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                sqlbaseMaster.Close();
                _main.processFailed = true;
                return;
            }
            _main.OutMsg(PageType.MergeFederal, "Copying table Module....\r\n");
            msg = UTIL.BulkCopy(srcConnection, sqlbaseMaster.Connection, "Module", transaction);
            if (msg != "")
            {
                _main.OutMsg(PageType.MergeFederalMaster, msg);
                transaction.Rollback();
                srcConnection.Close();
                sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                sqlbaseMaster.Close();
                _main.processFailed = true;
                return;
            }
            _main.OutMsg(PageType.MergeFederal, "Copying table DomainStructure....\r\n");
            msg = UTIL.BulkCopy(srcConnection, sqlbaseMaster.Connection, "DomainStructure", transaction);
            if (msg != "")
            {
                _main.OutMsg(PageType.MergeFederalMaster, msg);
                transaction.Rollback();
                srcConnection.Close();
                sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                sqlbaseMaster.Close();
                _main.processFailed = true;
                return;
            }
            _main.OutMsg(PageType.MergeFederal, "Copying table Question....\r\n");

            
            msg = UTIL.BulkCopy(srcConnection, sqlbaseMaster.Connection, "Question", transaction);
            if (msg != "")
            {
                _main.OutMsg(PageType.MergeFederalMaster, msg);
                transaction.Rollback();
                srcConnection.Close();
                sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                sqlbaseMaster.Close();
                _main.processFailed = true;
                return;
            }
            _main.OutMsg(PageType.MergeFederal, "Copying table QuestionBody....\r\n");
            msg = UTIL.BulkCopy(srcConnection, sqlbaseMaster.Connection, "QuestionBody", transaction);
            if (msg != "")
            {
                _main.OutMsg(PageType.MergeFederalMaster, msg);
                transaction.Rollback();
                srcConnection.Close();
                sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                sqlbaseMaster.Close();
                _main.processFailed = true;
                return;
            }
            _main.OutMsg(PageType.MergeFederal, "Copying table QDLink....\r\n");
            msg = UTIL.BulkCopy(srcConnection, sqlbaseMaster.Connection, "QDLink", transaction);
            if (msg != "")
            {
                _main.OutMsg(PageType.MergeFederalMaster, msg);
                transaction.Rollback();
                srcConnection.Close();
                sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                sqlbaseMaster.Close();
                _main.processFailed = true;
                return;
            }
            _main.OutMsg(PageType.MergeFederal, "Copying table QSLink....\r\n");
            msg = UTIL.BulkCopy(srcConnection, sqlbaseMaster.Connection, "QSLink", transaction);
            if (msg != "")
            {
                _main.OutMsg(PageType.MergeFederalMaster, msg);
                transaction.Rollback();
                srcConnection.Close();
                sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                sqlbaseMaster.Close();
                _main.processFailed = true;
                return;
            }
            _main.OutMsg(PageType.MergeFederal, "Copying table ApplicabilityVariable....\r\n");
            msg = UTIL.BulkCopy(srcConnection, sqlbaseMaster.Connection, "ApplicabilityVariable", transaction);
            if (msg != "")
            {
                _main.OutMsg(PageType.MergeFederalMaster, msg);
                transaction.Rollback();
                srcConnection.Close();
                sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                sqlbaseMaster.Close();
                _main.processFailed = true;
                return;
            }
            _main.OutMsg(PageType.MergeFederal, "Copying table ScreenGoal....\r\n");
            msg = UTIL.BulkCopy(srcConnection, sqlbaseMaster.Connection, "ScreenGoal", transaction);
            if (msg != "")
            {
                _main.OutMsg(PageType.MergeFederalMaster, msg);
                transaction.Rollback();
                srcConnection.Close();
                sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                sqlbaseMaster.Close();
                _main.processFailed = true;
                return;
            }
            _main.OutMsg(PageType.MergeFederal, "Copying table TemplateRule....\r\n");
            msg = UTIL.BulkCopy(srcConnection, sqlbaseMaster.Connection, "TemplateRule", transaction);
            if (msg != "")
            {
                _main.OutMsg(PageType.MergeFederalMaster, msg);
                transaction.Rollback();
                srcConnection.Close();
                sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                sqlbaseMaster.Close();
                _main.processFailed = true;
                return;
            }
            _main.OutMsg(PageType.MergeFederal, "Copying table RGSection....\r\n");
            msg = UTIL.BulkCopy(srcConnection, sqlbaseMaster.Connection, "RGSection", transaction);
            if (msg != "")
            {
                _main.OutMsg(PageType.MergeFederalMaster, msg);
                transaction.Rollback();
                srcConnection.Close();
                sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                sqlbaseMaster.Close();
                _main.processFailed = true;
                return;
            }
            _main.OutMsg(PageType.MergeFederal, "Copying table RGKeyWord....\r\n");
            msg = UTIL.BulkCopy(srcConnection, sqlbaseMaster.Connection, "RGKeyWord", transaction);
            if (msg != "")
            {
                _main.OutMsg(PageType.MergeFederalMaster, msg);
                transaction.Rollback();
                srcConnection.Close();
                sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                sqlbaseMaster.Close();
                _main.processFailed = true;
                return;
            }
            _main.OutMsg(PageType.MergeFederal, "Copying table QRLink....\r\n");
            msg = UTIL.BulkCopy(srcConnection, sqlbaseMaster.Connection, "QRLink", transaction);
            if (msg != "")
            {
                _main.OutMsg(PageType.MergeFederalMaster, msg);
                transaction.Rollback();
                srcConnection.Close();
                sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                sqlbaseMaster.Close();
                _main.processFailed = true;
                return;
            }
            _main.OutMsg(PageType.MergeFederal, "Copying table RGTOC....\r\n");
            msg = UTIL.BulkCopy(srcConnection, sqlbaseMaster.Connection, "RGTOC", transaction);
            if (msg != "")
            {
                _main.OutMsg(PageType.MergeFederalMaster, msg);
                transaction.Rollback();
                srcConnection.Close();
                sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                sqlbaseMaster.Close();
                _main.processFailed = true;
                return;
            }
            _main.OutMsg(PageType.MergeFederal, "Copying table RETIREDQUEST....\r\n");
            msg = UTIL.BulkCopy(srcConnection, sqlbaseMaster.Connection, "RETIREDQUEST", transaction);
            if (msg != "")
            {
                _main.OutMsg(PageType.MergeFederalMaster, msg);
                transaction.Rollback();
                srcConnection.Close();
                sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                sqlbaseMaster.Close();
                _main.processFailed = true;
                return;
            }

            srcConnection.Close();


            if (_SQLs.Count > 0)
            {
                msg = sqlbaseMaster.RunSQL(_SQLs.ToArray(), true);

                if (msg != "")
                {
                    if (!_main.isAutoProcess)
                    {
                        _main.OutMsg(PageType.MergeFederalMaster, msg);
                        transaction.Rollback();
                        sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                        _main.processFailed = true;
                        return;
                    }
                    else
                    {
                        errMessage += msg + "\r\n";
                    }
                }
            }
            //m_OFileMerge.WriteLine("--%Update the sequence number for federal sections");
            //m_OFileMerge.WriteLine("--%The SectionSN for federal sections gives the right order");
            //m_OFileMerge.WriteLine("--%Properties and red flag Adjustements");

            msg = sqlbaseMaster.RunSQL(new string[]{
                    "UPDATE RGSection SET Sequence = SectionSN WHERE SectionSN < 1000000000;",
                    "UPDATE questionbody SET Properties = 1"
                    + " WHERE Properties = 0 AND (CHARINDEX('Not specifically a regulatory requirement',stdtext) > 0"
                    + " OR CHARINDEX('Not specifically a regulatory requirement',notetext) > 0"
                    + " OR CHARINDEX('Not specifically an ISO 14001 requirement',stdtext) > 0"
                    + " OR CHARINDEX('Not specifically an ISO 14001 requirement',notetext) > 0);",
                    "UPDATE questionbody SET Properties = 2 WHERE Properties = 0 AND (CHARINDEX('Proposed',stdtext) = 1"
                       + " OR CHARINDEX('Draft Proposed',stdtext) = 1);",
                    "UPDATE Question SET RFValue = 2 from Question inner JOIN QuestionBody on question.QuestionSN=QuestionBody.QuestionBodySN WHERE DataType = 'M'"}
                    , true);

            if (msg != "")
            {
                _main.OutMsg(PageType.MergeFederalMaster, msg);
                transaction.Rollback();
                sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
                sqlbaseMaster.Close();
                _main.processFailed = true;
                return;
            }

            sqlbaseMaster.RunSQL(Query.CreateConstrains, true);
            transaction.Commit();
            sqlbaseMaster.Close();

        }        

        private bool CheckForCancel()
        {
            return _main.cancelPressed;
        }
       
        private void ErrorThrow(string message)
        {
            if (message != string.Empty)
            {
                _main.OutMsg(PageType.MergeFederal, message + ".\r\n");
                _main.processFailed = true;
            }
        }


    }
}
