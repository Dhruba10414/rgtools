//----------------------------------------------------------------------------
//  Project RGTools
//  Dakota Software Corporation
//  Copyright � 1997. All Rights Reserved.
//  FILE:    pgunload.h
//  AUTHOR:  Marc CHANTEGREIL
//
//  OVERVIEW
//  ~~~~~~~~
//  Class definition for TPageUnload (TPageWithDB).
//
//----------------------------------------------------------------------------

//******************************************************************
//**//// TPageUnload ///////////////////////////////////////////////
//******************************************************************

using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using System.Threading;

namespace RGTools_New
{
    class TPageUnload
    {
        private frmMain _main = null;

        public TPageUnload(frmMain Main)
        {
            _main = Main;
        }


        // Data Members
        protected string m_sTempDBName;

        public void DoProcess()
        { }
        //public void DoProcess()
        //{

        //    // First get the informations about the database.
        //    string DatabaseName = _main.txtLoadDB.Text.Trim();

        //    //------------------------------------------------------------------------------------
        //    // 1. Test for free space.  We need once the size of the database for a temporary database.
        //    //    and once for the unload files created (*.dat).
        //    //------------------------------------------------------------------------------------
        //    //_main.OutMsg(PageType.UnloadReload, "Checking for free space.\r\n");
        //    //CheckForFreeSpace (FileSize (DatabaseName.c_str ()) * 2);   // Might throw a CXMSG exception.

        //    //------------------------------------------------------------------------------------
        //    // 2. Unload the database.
        //    //------------------------------------------------------------------------------------
        //    _main.OutMsg(PageType.UnloadReload, "Unload in progress.\r\n");

        //    string ReloadSQLName = _main.toolSheet.TempDir + "\\Reload.sql";

        //    ProcessStartInfo startInfo = null;
        //    Process myProcess = null;
        //    try
        //    {
        //        startInfo = new ProcessStartInfo(Application.StartupPath + @"\dll\dbunload.exe");
        //        startInfo.WindowStyle = ProcessWindowStyle.Normal;
        //        startInfo.Arguments = "-c \"uid=dba;pwd=sql\" -r " + ReloadSQLName + " -y " + _main.toolSheet.TempDir;

        //        DataSybase sybase=new DataSybase(_main.DSNName,_main.SybaseUser,_main.SybasePW);
        //        sybase.Open();
        //        myProcess = Process.Start(startInfo);

        //        while (!myProcess.HasExited)
        //        {
        //            Thread.Sleep(200);
        //            Application.DoEvents();

        //            _main.OutMsg();
        //            if (CheckForCancel())
        //            {
        //                myProcess.Close();
        //                break;
        //            }
        //        }

        //        sybase.Close();

        //    }
        //    catch 
        //    {
        //        ErrorThrow("Error in DBUnload utility.\r\n");
        //        return;
        //    }

        //    //------------------------------------------------------------------------------------
        //    // 3. Closing the database.
        //    //------------------------------------------------------------------------------------
        //    //_main.OutMsg(PageType.UnloadReload, "Closing the database.\r\n");
        //    //try
        //    //{
        //    //    //DataSybase.Close();
        //    //}
        //    //catch
        //    //{
        //    //    //_main.OutMsg(PageType.UnloadReload, "Problem in Closing of the database.\r\n");
        //    //    ErrorThrow("Problem in Closing of the database.\r\n");
        //    //    return;
        //    //}

        //    if (CheckForCancel())
        //    {
        //        _main.OutMsg(PageType.UnloadReload, "Cancelled.\r\n");
        //        return;
        //    }

        //    //------------------------------------------------------------------------------------
        //    // 4. Create the Temporary database.
        //    //------------------------------------------------------------------------------------
        //    // First, get the name for the Temporary database to create.
        //    m_sTempDBName = _main.toolSheet.TempDir + "\\DBTemp.db";

        //    // Remove it if exist.
        //    if (File.Exists(m_sTempDBName))
        //    {
        //        FileInfo fInfo = new FileInfo(m_sTempDBName);
        //        if (fInfo.IsReadOnly)
        //        {
        //            fInfo.IsReadOnly = false;
        //            fInfo.Delete();
        //        }
        //    }

        //    // Run the process.
        //    try
        //    {
        //        startInfo = new ProcessStartInfo(Application.StartupPath + @"\dll\dbinit.exe");
        //        startInfo.WindowStyle = ProcessWindowStyle.Normal;
        //        startInfo.Arguments = "-n -p 4096 " + m_sTempDBName;

        //        myProcess = Process.Start(startInfo);
        //    }
        //    catch 
        //    {
        //        //_main.OutMsg(PageType.UnloadReload, "Error in DBInit utility.\r\n");
        //        ErrorThrow("Error in DBInit utility.\r\n");
        //        return;
        //    }

        //    //FileInfo fileInf = new FileInfo(m_sTempDBName);
        //    do
        //    {
        //        Thread.Sleep(200);
        //        Application.DoEvents();
        //        _main.OutMsg();
        //        //if (fileInf.Length >= 500000)
        //        if (myProcess.HasExited)
        //        {
        //            break;
        //        }

        //        if (CheckForCancel())
        //        {
        //            myProcess.Close();
        //            break;
        //        }
        //    } while (true);

        //    if (CheckForCancel())
        //    {
        //        return;
        //    }

        //    //if (cwait (0, ChildPID, WAIT_CHILD) == -1) {
        //    //    CXMSG XMSG (strerror (errno), "DBInit utility - Wait");
        //    //    XMSG.Throw ();

        //    //------------------------------------------------------------------------------------
        //    // 5. Reload the database.
        //    //------------------------------------------------------------------------------------
        //    _main.OutMsg(PageType.UnloadReload, "Reload in Progress.\r\n");

        //    // Create the SQL file to start the reload.
        //    string sFileReload = _main.toolSheet.TempDir + "\\RStart.sql";
        //    if (File.Exists(sFileReload))
        //    {
        //        File.Delete(sFileReload);

        //    }
        //    StreamWriter oFileReload = null;
        //    try
        //    {
        //        //oFileReload = new StreamWriter(sFileReload);
        //        oFileReload = new StreamWriter(sFileReload, false, Encoding.Default);
        //        oFileReload.WriteLine("START ENGINE AS DB1 STARTLINE 'dbstart -b -c 4096K -ga';");
        //        oFileReload.WriteLine("START DATABASE '" + m_sTempDBName + "' AS DB1 ON DB1;");
        //        oFileReload.WriteLine("CONNECT TO DB1 DATABASE DB1 AS DB1 USER " +
        //                _main.SybaseUser + " IDENTIFIED BY " + _main.SybasePW + ";");
        //        oFileReload.WriteLine();
        //        oFileReload.WriteLine("READ " + ReloadSQLName + ";");
        //        oFileReload.WriteLine();
        //        oFileReload.WriteLine("STOP DATABASE DB1 ON DB1 UNCONDITIONALLY;");
        //        oFileReload.Close();
        //    }
        //    catch
        //    {
        //        //_main.OutMsg(PageType.UnloadReload, "Error when trying to open the File!" + sFileReload + "\r\n");
        //        ErrorThrow("Error when trying to open the File!" + sFileReload + "\r\n");
        //        return;
        //    }

        //    if (CheckForCancel())
        //    {
        //        return;
        //    }

        //    // Now, call ISQL to read Reload.sql on the current database.
        //    try
        //    {
        //        startInfo = new ProcessStartInfo(Application.StartupPath + @"\dll\isql.exe");
        //        startInfo.WindowStyle = ProcessWindowStyle.Normal;
        //        startInfo.Arguments = sFileReload;

        //        myProcess = Process.Start(startInfo);
        //    }
        //    catch 
        //    {
        //        //_main.OutMsg(PageType.UnloadReload, "Error in ISQL utility.\r\n");
        //        ErrorThrow("Error in ISQL utility.\r\n");
        //        return;
        //    }

        //    //fileInf = new FileInfo(m_sTempDBName);
        //    do
        //    {
        //        Thread.Sleep(200);
        //        Application.DoEvents();
        //        _main.OutMsg();

        //        //if (fileInf.Length >= 5000000 && myProcess.HasExited)
        //        if (myProcess.HasExited)
        //        {
        //            break;
        //        }

        //        if (CheckForCancel())
        //        {
        //            myProcess.Close();
        //            break;
        //        }
        //    } while (true);

        //    if (CheckForCancel())
        //    {
        //        return;
        //    }

        //    //if (cwait (0, ChildPID, WAIT_CHILD) == -1) {
        //    //    CXMSG XMSG (strerror (errno), "ISQL utility - Wait");
        //    //    XMSG.Throw ();
        //    //}

        //    //------------------------------------------------------------------------------------
        //    // 6. Rename the current database to be able to get it back unchanged in crash situation (if option chosen); or
        //    //    Delete it (if no backup required).  Rename the temporary database the name of the current database.
        //    //------------------------------------------------------------------------------------
        //    //RemoveFile (DatabaseName.c_str ());
        //    if (File.Exists(DatabaseName))
        //    {
        //        FileInfo fInfo = new FileInfo(DatabaseName);
        //        if (fInfo.IsReadOnly)
        //        {
        //            fInfo.IsReadOnly = false;
        //            fInfo.Delete();
        //        }
        //    }

        //    try
        //    {
        //        File.Move(m_sTempDBName, DatabaseName);
        //    }
        //    catch
        //    {
        //        //_main.OutMsg(PageType.UnloadReload, "Error in Rename Database.\r\n");
        //        ErrorThrow("Error in Rename Database.\r\n");
        //        return;
        //    }

        //    if (CheckForCancel())
        //    {
        //        return;
        //    }

        //    // The database has changed.
        //    //SetHasChanged (true);

        //    //------------------------------------------------------------------------------------
        //    // 7. Reopen the database to check it opens correctly.
        //    //------------------------------------------------------------------------------------
        //    try
        //    {
        //        //DataSybase.Open();
        //    }
        //    catch 
        //    {
        //        //_main.OutMsg(PageType.UnloadReload, "Problem in Open of the database.\r\n");
        //        ErrorThrow("Problem in Open of the database.\r\n");
        //        return;
        //    }

        //    //if (CmOpenClose () == false) {
        //    //CXMSG XMSG ("Problem in Open of the database");
        //    //XMSG.Throw ();
        //    //}
        //    try
        //    {
        //        //DataSybase.Close();
        //    }
        //    catch
        //    {
        //        //_main.OutMsg(PageType.UnloadReload, "Problem in Closing of the database.\r\n");
        //        ErrorThrow("Problem in Closing of the database.\r\n");
        //        return;
        //    }
        //}

        //protected void EnableControl ();
        protected bool CheckForCancel()
        {
            return _main.cancelPressed;
        }
        private void ErrorThrow(string message)
        {
            if (message != string.Empty)
            {
                _main.OutMsg(PageType.UnloadReload, message + ".\r\n");
                _main.processFailed = true;
            }
        }
    }

}
