//----------------------------------------------------------------------------
//  Project RGTools
//  Dakota Software Corporation
//  Copyright � 1997. All Rights Reserved.
//  FILE:    dbui.h
//  AUTHOR:  Marc CHANTEGREIL
//
//  OVERVIEW
//  ~~~~~~~~
//  Class definition for CSQLDBUI (CSQLDatabase).
//
//----------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Data.Sql;

namespace RGTools_New
{
    class CSQLDBUI : DataSql
    {
        public enum eDBType { ModuleDev, ModuleRT, Audit, Other, Void };

        public enum eDBStatus { MissingTables, DuplicatedKeys, Normal };

        protected string m_sDBVersionSN = string.Empty;
        protected string m_sDBCurrentSN = string.Empty;
        protected eDBType m_eDBType = eDBType.Other;
        protected bool m_ValidateDB = false;

        //public bool ValidateDB
        //{
        //    get
        //    {
        //        return m_ValidateDB;
        //    }
        //}
        public eDBStatus DBStatus = eDBStatus.Normal;

        private frmMain _main = null;
        // Constructors, Destructors
        public CSQLDBUI(frmMain Main): base()
        {
            _main = Main;
            GetDBVersionSN();
            Validate();
            OpenClose();
        }

        SqlDataReader reader = null;
        private void Validate()
        {
            m_ValidateDB = true;
            
            foreach (string str in Query.CheckTables)
            {
                reader = GetReader(str);

                if (!reader.Read())
                {
                    m_ValidateDB = false;
                    DBStatus = eDBStatus.MissingTables;
                    break;
                }

                reader.Close();
            }

            if (m_ValidateDB)
            {
                //foreach (string str in Query.CheckDulicatedKeys)
                //{
                //    reader = GetReader(str);

                //    if (reader.Read())
                //    {
                //        m_ValidateDB = false;
                //        DBStatus = eDBStatus.DuplicatedKeys;
                //        break;
                //    }
                //    reader.Close();
                //}
            }
        }

        // Toggle method. Open the database if closed; close it if opened.  Throw CXMSG and CXSQL exceptions.
        // Needs the Parent Dialog Box to access to the right buttons.
        private void OpenClose()
        {
            // Reset data members.
            //m_sDatabaseName = "";
            m_eDBType = eDBType.Void;

            //*********************************************************************
            // Find out if this Database is a Module database or an Audit database or other.
            //*********************************************************************
            if (FindTable("Module"))
            {

                // We have a Module Database.  Determine the type (QDLink is only in Development).
                m_eDBType = (FindTable("QDLink")) ? eDBType.ModuleDev : eDBType.ModuleRT;

            }
            else
            {

                // We have an Audit database if the table ModuleLoad is defined.
                m_eDBType = (FindTable("ModuleLoad")) ? eDBType.Audit : eDBType.Other;
            }

            // The database has been opened or closed.  We need to resync. the controls of its parent dialog box.
            //SyncControls(Parent);
        }

        //string  GetShortName ()      ;
        public eDBType GetDBType() { return m_eDBType; }

        public eDBType DBType
        {
            get
            {
                return m_eDBType;
            }
        }

        // Notice that here we hide GetDBVersionSN () defined in CSQLDatabase.  We do that because the base class method
        // looks each time in the database and we want users to avoid this when they need to VersionSN.  The CSQLDBUI
        // class defines this class during the OpenClose () method.
        public string DBVersionSN
        {
            get
            {
                return m_sDBVersionSN;
            }
        }

        public string DBCurrentSN
        {
            get
            {
                return m_sDBCurrentSN;
            }
        }
        // return true if the table 'TableName' has been defined in the database.
        //static string __SQLV_dbui_2 = "SELECT tname FROM sys.syscolumns WHERE tname = '";
        static string __SQLV_dbui_2 = "SELECT name FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.";

        public  bool  FindTable (string TableName)
        {
            string Query = __SQLV_dbui_2 + TableName + "')";
            DataSet ds = GetDataSet(Query);

            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        // Sync. the controls with the status of the database (opened or closed).  This method is useful when the database
        // has been opened by another GUI and the parent dialog box wants to synchronize itself with the database status.
        //public void SyncControls (TDialog* Parent);
        private void GetDBVersionSN()
        {
            m_sDBVersionSN = string.Empty;
            m_sDBCurrentSN = string.Empty;

            string Query = ("SELECT VersionID FROM Version");
            DataSet ds = GetDataSet(Query);

            try
            {
                m_sDBVersionSN = ds.Tables[0].Rows[0][0].ToString();
            }
            catch//(Exception e)
            {
                //_main.processError = true;
            }
            finally
            {
            }

            Query = ("select Max(ModuleVersionSN) from dbo.moduleversion");
            ds = GetDataSet(Query);

            try
            {
                m_sDBCurrentSN = ds.Tables[0].Rows[0][0].ToString();
            }
            catch//(Exception e)
            {
                //_main.processError = true;
            }
            finally
            {
            }
        }

        

        public void CloseDB()
        {
            base.Close();
        }
    }
}
