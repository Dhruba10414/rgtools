﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Data.Sql;
using System.IO;
using System.Windows.Forms;
//using DbAccess;
//using Converter;

namespace RGTools_New
{
    class IPhone : DataSql
    {
        private PageType pgType = PageType.IPhone;
        private string TmpRGT = null;

        const string CreateRgsectionHtml = "If not exists (SELECT name FROM dbo.sysobjects where name = 'rgsectionHtml') " +
            "CREATE TABLE [dbo].rgsectionHtml( " +
            "[SectionSN] [int] NOT NULL, " +
            "[ModuleSN] [int] NULL, " +
            "[Heading] [varchar](120) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, " +
            "[TextBlock] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL, " +
            "[Sequence] [int] NULL " +
            ") ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]";

        private frmMain _main = null;
        public IPhone(frmMain Main)
            : base(Main.SQLServer, Main.SQLDB, Main.SQLUser, Main.SQLPW)
        {
            _main = Main;
            TmpRGT = _main.toolSheet.TempDir;

            checkCancel += new DataSql.IsCancel(isCancel);
        }

        internal bool isCancel()
        {
            return _main.cancelPressed;
        }

        private bool CheckForCancel
        {
            get
            {
                return _main.cancelPressed;
            }
        }

        public void CreateIPhoneSQLDB()
        {
            try
            {
                Open();

                string SQL = "BEGIN TRY DROP TABLE rgsectionHtml END TRY BEGIN CATCH END CATCH";

                this.RunSQL(SQL);

                RunSQL(CreateRgsectionHtml);

                _main.OutMsg(pgType, "Consolidating IPHONERGSECT.REM....\r\n");
                BuildConsolidateREM();
                _main.OutMsg(pgType, "Loading IPHONERGSECT.REM....\r\n");

                if (!LoadTextToTable(Path.Combine(TmpRGT, "IPHONERGSECT.REM"), "IPHONERGSECT"))
                {
                    _main.processFailed = true;
                }


                SQL = "select ModuleVersionSN FROM dakref.dbo.Version";

                DataSet ds = GetDataSet(SQL);

                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    string ModuleVersionSN = ds.Tables[0].Rows[0][0].ToString();

                    foreach (string str in Query.CreateIPhoneTables)
                    {
                        RunSQL(str.Replace("******", ModuleVersionSN));

                        if (CheckForCancel)
                        {
                            break;
                        }
                    }

                    foreach (string str in Query.CreateIPhoneIndexes)
                    {
                        RunSQL(str);
                        if (CheckForCancel)
                        {
                            break;
                        }
                    }
                }

                Close();

            }
            catch (Exception e)
            {
                _main.processFailed = true;
                _main.OutMsg(pgType, e.Message);
            }
        }

        protected void BuildConsolidateREM()
        {

            string ConcatREM = Path.Combine(TmpRGT, "IPHONERGSECT.REM");// TmpRGT + REMFile;

            if (File.Exists(ConcatREM))
            {
                File.Delete(ConcatREM);
            }
            StreamWriter sw = null;

            try
            {
                sw = new StreamWriter(ConcatREM, false, Encoding.Default);
            }
            catch (Exception e)
            {
                throw (e);
            }
            finally
            {
                sw.Close();
            }
            
            ModuleListItem _item=null;
            for (int i = 0; i <_main.chkLstBox.Items.Count ; i++)
            {

                _item = _main.chkLstBox.Items[i] as ModuleListItem;
                if (_item.Enable && _main.chkLstBox.GetItemCheckState(i) == CheckState.Checked)
                {
                    if (!UTIL.FileCopy(Path.Combine(_item.ModuleFolder, "IPHONERGSECT.REM"), ConcatREM, TypeFlagCopy.AppendMode))
                    {
                        _main.OutMsg(pgType, "Error during the creation of the consolidated REM files for IPHONERGSECT.REM");
                        break;
                    }
                }
            }
        }

    }
}
