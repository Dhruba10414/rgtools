using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Diagnostics;
using NaturalNumericSort;

namespace RGTools_New
{
    class TKey
    {
        private string m_KeyValue;
        private long m_RevDate;
        private TSectionOffset m_SectionOffset;
        private static long ms_MasterSequence;
        private long m_KeyID;

        public TKey(string pKeyValue)
        {
            m_KeyValue = pKeyValue.Trim(new char[] { ' ' });
            m_RevDate = 0;
            m_SectionOffset = null;
            //ms_MasterSequence++;
            m_KeyID = ++ms_MasterSequence;
        }

        public void SetSectionOffset(TSectionOffset pOffset)
        {
            UTIL.Assert(pOffset != null, "Assertion Failed: pOffset != null!");

            m_SectionOffset = pOffset;
        }
        public string GetKeyValue() { return m_KeyValue; }
        public string KeyValue
        {
            get
            {
                return m_KeyValue;
            }
        }
        public TSectionOffset GetSectionOffset()
        { return m_SectionOffset; }
        public TSectionOffset SectionOffset
        {
            get
            {
                return m_SectionOffset;
            }
        }
        public long GetRevDate()
        { return m_RevDate; }
        public long RevDate
        {
            get
            {
                return m_RevDate;
            }
            set
            {
                m_RevDate = value;
            }
        }
        public long GetKeyID()
        { return m_KeyID; }
        public long KeyID
        {
            get
            {
                return m_KeyID;
            }
        }
        public long GetKeySN()
        { return m_KeyID + GlobalStructures.ModuleSN; }
        public long KeySN
        {
            get
            {
                if (GlobalStructures.ModuleSN >= 0)
                {
                    return m_KeyID + GlobalStructures.ModuleSN;
                }
                else
                {
                    return GlobalStructures.ModuleSN- m_KeyID ;
                }
            }
        }
        public static void SetMasterSequence(long pMasterSequence)
        { ms_MasterSequence = pMasterSequence; }
        public static long MasterSequence
        {
            set
            {
                ms_MasterSequence = value;
            }
            get
            {
                return ms_MasterSequence;
            }
        }
        //public void SetRevDate(long pDate)
        //{ m_RevDate = pDate; }
 

        public static bool operator ==(TKey key1, TKey key2)
        {
            if (IsNull(key1) && IsNull(key2))
            {
                return true;
            }
            else if (IsNull(key1) || IsNull(key2))
            {
                return false;
            }
            else
            {
                return (key1.m_KeyValue == key2.m_KeyValue) ? true : false;
            }
        }

        //public static bool operator <(TKey key1, TKey key2)
        //{ return (key1.m_KeyValue < key2.m_KeyValue) ? true : false; }
        public static bool operator !=(TKey key1, TKey key2)
        {
            if (IsNull(key1) && IsNull(key2))
            {
                return false;
            }
            else if (IsNull(key1) || IsNull(key2))
            {
                return true;
            }
            else
            {
                return (key1.m_KeyValue != key2.m_KeyValue) ? true : false;
            }
        }

        //public static bool operator >(TKey key1, TKey key2)
        //{ return (key1.m_KeyValue > key2.m_KeyValue) ? true : false; }
        public static bool IsNull(TKey key)
        {
            return TKey.Equals(key, null);
        }
        public override bool Equals(object key)
        {
            if (IsNull(key as TKey))
            {
                return false;
            }
            else
            {
                return this.m_KeyValue == (key as TKey).m_KeyValue ? true : false;
            }
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

    }

    class TKeyList : List<TKey>
    {

        public TKeyList() { }

        public new int Add(TKey pKey)
        {
            UTIL.Assert(pKey != null, "Assertion Failed: pKey != null!");
            //Keep with old app, oct 10, 2008
            TKey.MasterSequence++;

            TKey pFoundKey = FindFirst(pKey);
            //if (pFoundKey && (pFoundKey->GetKeyValue() == pKey->GetKeyValue()))
            if (pFoundKey != null)
            {
                throw (new Exception(pKey.GetKeyValue() + " is defined more than once"));
            }

            base.Add(pKey);
            //SortKey();
            //return TIBinarySearchTreeImp<TKey>::Add (pKey);
            return base.Count - 1;
        }//throw (xmsg);
        public void GenerateSQL(string PathName, StreamWriter Bogue, RGKeywordList rKeywordList)
        {
            string ts = PathName + "\\RGKEYWD.REM";
            StreamWriter ofKeyWord = null;
            try
            {
                //ofKeyWord = new StreamWriter(ts);
                ofKeyWord = new StreamWriter(ts, false, Encoding.Default);
            }
            catch
            {
                throw (new Exception("Could not open " + ts));
            }

            // First try to open the input file.
            ts = PathName + "\\QUESTION.TXT";
            StreamReader QIFile = null;// (ts);

            try
            {
                QIFile = new StreamReader(ts, Encoding.Default);
            }
            catch
            {
                throw (new Exception("Could not open " + ts));
            }

            ts = PathName + "\\QRLINK.REM";
            StreamWriter ofQRLink = null;// (ts);
            try
            {
                //ofQRLink = new StreamWriter(ts);
                ofQRLink = new StreamWriter(ts, false, Encoding.Default);
            }
            catch
            {
                throw (new Exception("Could not open " + ts));
            }

            //added on Oct 6, 2008
            ts = PathName + "\\INFOONLY.REM";
            StreamWriter ofInfoOnly = null;// (ts);
            try
            {
                //ofInfoOnly = new StreamWriter(ts);
                ofInfoOnly = new StreamWriter(ts, false, Encoding.Default);
            }
            catch
            {
                throw (new Exception("Could not open " + ts));
            }


            bool BugFree = true;

            string InputLine;
            //char iline[500];
            long CurrentSN = 0L;
            long SequenceNumber = 0L;
            bool BoffQuestion = false;
            bool Xline = false;

            // Loop through the input, discarding comments and sorting commands from content.
            while ((InputLine = QIFile.ReadLine()) != null)
            {
                // Look for serial numbers and reference lines.
                if (InputLine.Length > 0)
                {
                    Xline = false;

                    switch (InputLine.Substring(0, 1))
                    {
                        case "@":
                            if (!BoffQuestion)
                            {
                                InputLine=InputLine.Remove(0, 1);
                                InputLine = InputLine.Trim(new char[]{' '});
                                if (InputLine == "DOS")
                                    BoffQuestion = true;
                            }
                            break;

                        case "E":
                            BoffQuestion = false;
                            break;

                        case "K":
                            if (!BoffQuestion)
                            {
                                InputLine=InputLine.Remove(0, 1);
                                InputLine = InputLine.Trim(new char[]{' '});

                                if ((InputLine == "FACILITY") || (InputLine == "MATERIALS") || (InputLine == "NO_AUDIT") ||
                                    (InputLine == "END_AUDIT") || (InputLine == "GENERATE") || (InputLine.IndexOf("ZZZZ") != -1) ||
                                    (InputLine.IndexOf("zzzz") != -1) || (InputLine.Substring(0, 1) == "N"))
                                    BoffQuestion = true;
                            }
                            break;

                        case "#":
                            if (!BoffQuestion)
                            {
                                InputLine=InputLine.Remove(0, 2);
                                InputLine = InputLine.Trim(new char[]{' '});
                                try
                                {
                                    CurrentSN = long.Parse(InputLine);
                                }
                                catch
                                {
                                }
                                SequenceNumber = 0;
                            }
                            break;
                        case "X":
                            Xline = true;
                            goto case "R";
                        case "R":
                            if (!BoffQuestion)
                            {
                                int iPos = InputLine.IndexOf(" ");
                                UTIL.Assert(iPos != -1, "Assertion Failed: iPos != -1!");
                                InputLine=InputLine.Remove(0, iPos);
                                InputLine = InputLine.Trim(new char[]{' '});

                                SequenceNumber++;

                                TKey pKey =this.FindFirst(new TKey(InputLine));
                                if (pKey!=null && (pKey.GetKeyValue() == InputLine))
                                {
                                    // QuestionSN, ReferenceSN, Sequence
                                    ofQRLink.WriteLine(CurrentSN + ","
                                             + pKey.KeySN + ","
                                             + SequenceNumber);

                                    if (Xline)
                                    {
                                        //ofInfoOnly << CurrentSN << ","
                                        //        << pKey->GetKeySN() << ","
                                        //       << GlobalStructures::GetModuleSN()  << endl;
                                        ofInfoOnly.WriteLine(CurrentSN + ","
                                             + pKey.KeySN + ","
                                             + GlobalStructures.GetModuleSN());
                                    }
                                }
                                else
                                {
                                    Bogue.WriteLine("The Key <" + InputLine + "> in QUESTION.TXT was not found in REFLIB.TXT.");
                                    BugFree = false;
                                }
                            }
                            break;

                        default:
                            break;
                    }
                }
            }

            SortKey();

            RGKeyword keyword = null;
            foreach(TKey pKey in this)
            {
                //ofKeyWord.WriteLine(pKey.KeySN + ","
                //          + "'" +SUTIL.PrepareASCIIString(pKey.KeyValue) + "',"
                //          + pKey.SectionOffset.Offset.ToString() + ","
                //          + pKey.SectionOffset.Section.SectionID.ToString() + ","
                //          + GlobalStructures.ModuleSN.ToString() + ","
                //          + pKey.RevDate.ToString());

                string kw = SUTIL.PrepareASCIIString(pKey.KeyValue);

                if (kw.Length > 66)
                {
                    kw = kw.Substring(0, 66);
                    if (kw[65] == '\'' && kw[64] != '\'')
                    {
                        kw += "\'";
                    }
                }

                ofKeyWord.WriteLine(pKey.KeySN + ","
                      + "'" + kw + "',"
                      + pKey.SectionOffset.Offset.ToString() + ","
                      + pKey.SectionOffset.Section.SectionID.ToString() + ","
                      + GlobalStructures.ModuleSN.ToString() + ","
                      + pKey.RevDate.ToString());

                keyword = new RGKeyword();

                keyword.ReferenceSN = pKey.KeySN;
                keyword.KeyWord = "'" + SUTIL.PrepareASCIIString(pKey.KeyValue) + "',";
                keyword.SectionSN = pKey.SectionOffset.Section.SectionID;
                keyword.PStart = pKey.SectionOffset.Offset;
                keyword.ModuleSN = GlobalStructures.ModuleSN;
                keyword.TagDate = pKey.RevDate;

                rKeywordList.Add(keyword);
            }

            ofKeyWord.Close();
            ofQRLink.Close();
            QIFile.Close();
            ofInfoOnly.Close();
            if (!BugFree)
                throw(new Exception("There were problems generating the Key SQL statements"));

            return;
        }

        private static TKey _key = null;
        private static bool match(TKey key)
        {
            if (key.KeyValue == _key.KeyValue)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public TKey FindFirst(TKey key)
        {
            _key = key;

            return base.Find(match);
        }

        private static int CompareTKey(TKey key1, TKey key2)
        {
            if (key1 == null)
            {
                if (key2 == null)
                {
                    return 0;
                }
                else
                {
                    return -1;
                }
            }
            else
            {
                if (key2 == null)
                {
                    return 1;
                }
                else
                {
                    //return UTIL.CmpareString(key1.KeyValue, key2.KeyValue);
                    return string.Compare(key1.KeyValue, key2.KeyValue, StringComparison.Ordinal);
                    //return StringLogicalComparer.Compare(key1.KeyValue, key2.KeyValue);
                }
            }
        }
        internal void SortKey()
        {
            base.Sort(CompareTKey);
        }


    }

}
