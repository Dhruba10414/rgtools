using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Threading;

namespace RGTools_New
{
    class DuplicateValidator : List<string>
    {
        public DuplicateValidator() { }
        public bool Validate(string pString)
        {
            if (FindFirst(pString)!=null)
                return false;

            Add(pString);

            return true;
        }

        private static string _duplicate = null;
        private static bool match(string duplicate)
        {
            if (duplicate .Equals(_duplicate))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public string FindFirst(string duplicate)
        {
            _duplicate = duplicate;

            return base.Find(match);
        }

    }

    class NSERIAL
    {
        public static void UpdateQuestion(string path, StreamWriter BogueFile, string SNDir, bool IsMainSite)
        {
            // We have two files, new name and backup name.
            string OriginalFileName = path + "\\QUESTION.TXT";
            string BackupFileName = path + "\\QUESTION.FSF";
            string TempFileName = path + "\\QUESTION.TMP";
            List<string> QBody = new List<string>();

            FileInfo _fileInfor = null;

            // If there is an old temp file, delete it.
            if (File.Exists(TempFileName))
            {
                _fileInfor = new FileInfo(TempFileName);

                try
                {
                    _fileInfor.Attributes = FileAttributes.Archive;
                    _fileInfor.Delete();
                }
                catch// (Exception e)
                {
                    throw (new Exception("Could not delete temporary file " + TempFileName));
                }
            }

            // Open the question file and exit on error
            StreamReader QIFile = null;
            try
            {
                //QIFile = new StreamReader(OriginalFileName);
                QIFile = new StreamReader(OriginalFileName, Encoding.Default);
                //string InputLine1 = QIFile.ReadLine();
            }
            catch
            {
                throw (new Exception("Could not open " + OriginalFileName + "."));
            }

            // Open the temporary file and exit on error.
            StreamWriter QOFile = null;
            try
            {
                //QOFile = new StreamWriter(TempFileName);
                QOFile = new StreamWriter(TempFileName, false, Encoding.Default); //Encoding.Default);
            }
            catch
            {
                throw (new Exception("Error! Could not open the temporary file " + TempFileName + "."));
            }

            bool HasErrors = false;
            DuplicateValidator KLineValidator = new DuplicateValidator();
            DuplicateValidator SNValidator = new DuplicateValidator();
            DuplicateValidator KReferenceValidator = new DuplicateValidator();
            TQuestionSN WQuestionSN = new TQuestionSN(SNDir);

            string KLine = string.Empty;
            //char[] iline = new char[200];  // Input line buffer.
            long WQCount = 0L;

            int LineCount = 0;
            // Loop through the input file sucking in data.
            string InputLine = string.Empty;

            try
            {
                while ((InputLine = QIFile.ReadLine()) != null)
                {
                    LineCount++;
                    //if (InputLine.IndexOf("@ DOMAIN RUST:D.1") > -1)
                    //{
                    //    string s = "";
                    //}

                    if ((InputLine.Length > 0) && (InputLine.Substring(0, 1) == "K"))
                    {

                        KLine = InputLine;
                        string SNLine = string.Empty;

                        QBody.Clear();
                        QBody.Add(InputLine);
                        //QBody.Add(new string(InputLine));

                        // Since this is a K line, add it to the K line validator.
                        InputLine = InputLine.Remove(0, 1);
                        string CurrentKLine = InputLine.Trim(new char[] { ' ' });
                        if (!KLineValidator.Validate(CurrentKLine))
                        {
                            HasErrors = true;
                            BogueFile.WriteLine("K line for " + InputLine + " occurs more than once.");

                            continue;
                        }
                        
                        bool RemoteSN = (false);

                        while ((InputLine = QIFile.ReadLine()) != null)
                        {
                            LineCount++;
                            //InputLine = iline;
                            if (InputLine.Length > 0)
                            {
                                if (InputLine.Substring(0, 1) == "E")
                                {
                                    QBody.Add(InputLine);
                                    break;
                                }

                                if ((InputLine.Substring(0, 1) == "R") || (InputLine.Substring(0, 1) == "X"))
                                {
                                    string Reference = (InputLine);
                                    Reference = Reference.Remove(0, 2);
                                    Reference = Reference.Trim(new char[] { ' ' });
                                    if (!KReferenceValidator.Validate(CurrentKLine + " " + Reference))
                                    {
                                        HasErrors = true;
                                        BogueFile.WriteLine("Question " + CurrentKLine + " has a duplicate reference "
                                                  + Reference + ".");
                                    }
                                }

                                if (InputLine.Substring(0, 1) == "#")
                                {

                                    // Check that we have only one Serial Number line (whatever site: remote or main).
                                    if (SNLine.Length != 0)
                                    {

                                        HasErrors = true;
                                        BogueFile.WriteLine("Double serial number (" + SNLine + ") in QUESTION.TXT.");
                                        continue;
                                    }

                                    // See if Serial Number was created by the Main Site or a Remote Site.
                                    RemoteSN = (InputLine.Length >= 2 && InputLine[1] == 'R');

                                    // If the Serial Number was created by a remote site and we are now the main site,
                                    // remove it from the file and we log this in the Bogue file.
                                    if (RemoteSN && IsMainSite)
                                    {

                                        BogueFile.WriteLine("Remote Serial Number (" + InputLine + ") for " + KLine.Trim(new char[] { ' ' })
                                                  + " removed in QUESTION.TXT.");

                                    }
                                    else
                                    {
                                        SNLine = InputLine;

                                        // Add the serial number to the validator to make sure there are no duplicates.
                                        InputLine = InputLine.Remove(0, 2);
                                        InputLine = InputLine.Trim(new char[] { ' ' });
                                        if (!SNValidator.Validate(InputLine))
                                        {
                                            HasErrors = true;
                                            BogueFile.WriteLine("Serial Number (" + InputLine + ") used more than once in QUESTION.TXT");
                                        }
                                    }
                                    continue;
                                }
                            }

                            QBody.Add(InputLine);
                        }

                        QOFile.WriteLine(QBody[0]);

                        if (SNLine.Length == 0)
                        {

                            string tmp = string.Empty;
                            string CodeSite = (IsMainSite) ? " " : "R";

                            //tmp = "#" + CodeSite + WQuestionSN.AllocateSN().ToString() + Environment.NewLine;// +Environment.NewLine;
                            tmp = "#" + CodeSite + WQuestionSN.AllocateSN().ToString();// +Environment.NewLine;

                            SNLine = tmp;
                            //delete[] tmp;
                            WQCount++;

                            //if (RemoteSN && IsMainSite)
                            if (IsMainSite)
                            {

                                //BogueFile.WriteLine("   New Question Serial Number is (" + SNLine + ").");
                                //BogueFile.WriteLine();
                            }
                        }

                        QOFile.WriteLine(SNLine);
                        for (int i = 1; i < QBody.Count; i++)
                        {
                            QOFile.WriteLine(QBody[i]);
                        }
                    }
                    else
                    {
                        QOFile.WriteLine(InputLine);
                    }
                }
            }
            catch (Exception e)
            {
                throw (new Exception(e.Message + " in Question.txt line " + LineCount));
            }
            finally
            {
                QIFile.Close();
                QOFile.Close();
            }

            if (HasErrors)
            {
                throw (new Exception("There were errors updating question serial numbers."));
            }

            // Now that we have an updated temporary file, rename the source file to .FSF and rename the
            // temp file to .TXT.

            if (File.Exists(BackupFileName))
            {

                _fileInfor = new FileInfo(BackupFileName);
                try
                {
                    _fileInfor.Attributes = FileAttributes.Archive;
                    _fileInfor.Delete();
                }
                catch //(Exception e)
                {
                    //throw (e);
                    throw (new Exception("Could not access backup file " + BackupFileName + ", process aborted."));

                }
            }

            // Rename new file to backup and temp to new file.
            try
            {
                File.Move(OriginalFileName, BackupFileName);
            }
            catch
            {
                throw (new Exception("Problem making backup of serialized " + OriginalFileName + "."));
            }
            //if (rename (OriginalFileName, BackupFileName) != 0)
            //    throw(new Exception("Problem making backup of serialized " + OriginalFileName + ".");

            try
            {
                File.Move(TempFileName, OriginalFileName);
            }
            catch
            {
                throw (new Exception("Problem copying temp to " + OriginalFileName + "."));
            }

            BogueFile.WriteLine(WQCount.ToString() + " Windows Question Serial Numbers generated. ["
                    + WQuestionSN.RemainingSN().ToString() + "]");
        }

        public static void UpdateDomain(string path, StreamWriter BogueFile, string SNDir, bool IsMainSite) 
        {
            //Thread.BeginCriticalRegion();
            // We have two files, new name and backup name.
            string OriginalFileName = path + "\\DOMAIN.TXT";
            string BackupFileName = path + "\\DOMAIN.FSF";
            string TempFileName = path + "\\DOMAIN.TMP";

            StreamReader DIFile = null;
            StreamWriter DOFile = null;
            TDomainSN DomainSN = new TDomainSN(SNDir);
            bool HasErrors = false;

            //char[] iline = new char[200];  // Input line buffer.
            long DCount = 0L;
            long LineNumber = 0L;

            DuplicateValidator SNValidator = new DuplicateValidator();
            DuplicateValidator DomainValidator = new DuplicateValidator();
            FileInfo _fileInfor = null;
            try
            {
                // If there is an old temp file, delete it.
                if (File.Exists(TempFileName))
                {
                    _fileInfor = new FileInfo(TempFileName);
                    try
                    {
                        _fileInfor.Attributes = FileAttributes.Archive;
                        _fileInfor.Delete();
                    }
                    catch //(Exception e)
                    {
                        throw (new Exception("Could not delete temporary file " + TempFileName));

                    }
                }
                // Open the question file and exit on error

                try
                {
                    DIFile = new StreamReader(OriginalFileName, Encoding.Default);
                }
                catch
                {
                    throw (new Exception("Could not open " + OriginalFileName + "."));
                }
                finally
                {
                    Thread.EndCriticalRegion();
                }

                // Open the temporary file and exit on error.
                try
                {
                    DOFile = new StreamWriter(TempFileName, false, Encoding.Default);
                }
                catch
                {
                    throw (new Exception("Error! Could not open the temporary file " + TempFileName + "."));
                }
                finally
                {
                    Thread.EndCriticalRegion();
                }


                // Loop through the input file sucking in data.
                string InputLine = string.Empty;
                while ((InputLine = DIFile.ReadLine()) != null)
                {
                    // Read a line from the domain file.
                    InputLine = InputLine.Trim(new char[]{' '});
                    LineNumber++;

                    // Format is { M } sn  domain-name , ...
                    if ((InputLine.Length == 0) || (InputLine.Substring(0, 1) == "*"))
                    {
                        DOFile.WriteLine(InputLine);
                    }
                    else
                    {
                        // Break up the line into components.
                        int pos;
                        if ((pos = InputLine.IndexOf(",")) == -1)
                        {
                            HasErrors = true;
                            BogueFile.WriteLine("Domain formatting error in DOMAIN.TXT line " + LineNumber + ".");
                        }
                        else
                        {
                            string Remainder = InputLine;
                            Remainder = Remainder.Remove(0, pos + 1);

                            // Parse M line and serial number.
                            string Chunk = InputLine.Substring(0, pos);
                            Chunk = Chunk.Trim(new char[]{' '});

                            string MarkedDomain = string.Empty;
                            string CodeSite = string.Empty;
                            string SerialNumber;
                            string DomainName = string.Empty;
                            string ParentName = string.Empty;
                            string DomainTitle = string.Empty;

                            // Get the marked status (M or space).
                            if (Chunk.Substring(0, 2) == "M ")
                            {

                                MarkedDomain = "M";
                                Chunk = Chunk.Remove(0, 1);

                            }
                            else
                            {
                                MarkedDomain = " ";
                            }


                            // Get the site that has created this serial number.
                            if (Chunk.Substring(0, 2) == "R ")
                            {

                                CodeSite = "R";
                                Chunk = Chunk.Remove(0, 1);

                            }
                            else
                            {
                                CodeSite = " ";
                            }

                            // Remove any leading or trailing blank.
                            // After the strip (), chunk is: [<Serial Number>] + <Spaces> + <Domain Name>   // [] means optional.
                            Chunk = Chunk.Trim(new char[]{' '});

                            // Get the serial number.
                            pos = Chunk.IndexOf(" ");
                            if (pos == -1)
                            {

                                SerialNumber = string.Empty;

                            }
                            else
                            {

                                SerialNumber = Chunk.Substring(0, pos);
                                Chunk = Chunk.Remove(0, pos);

                                // If the Serial Number was created by a remote site and we are now the main site,
                                // remove it from the file and we log this in the Bogue file.
                                if (CodeSite == "R" && IsMainSite)
                                    //if (IsMainSite)
                                {

                                    BogueFile.WriteLine("Remote Domain Serial Number (" + SerialNumber + ") for domain "
                                              + Chunk.Trim(new char[]{' '}) + " removed in DOMAIN.TXT (line "
                                              + LineNumber + ").");
                                    SerialNumber = string.Empty;
                                }
                            }

                            DomainName = Chunk.Trim(new char[] { ' ' });

                            // Create a serial number if necessary.
                            if (SerialNumber == string.Empty)
                            {
                                string NewSN;
                                NewSN = DomainSN.AllocateSN().ToString();// +Environment.NewLine;
                                SerialNumber = NewSN;
                                //delete [] NewSN;
                                DCount++;

                                // Log in the Bogue File, the new allocated Serial Number
                                // (only in the case of removing the remote one).
                                //if (CodeSite == "R" && IsMainSite)
                                if (IsMainSite)
                                {
                                    //BogueFile.WriteLine("   New Domain Serial Number for domain "+
                                    //        DomainName+ " is (" + SerialNumber + ").");
                                }

                                // The Code Site is the current.
                                CodeSite = (IsMainSite) ? " " : "R";
                            }

                            // Get the Domain Name.

                            // Continue working with Remainder of input line.
                            if ((pos = Remainder.IndexOf(',')) == -1)
                            {
                                HasErrors = true;
                                BogueFile.WriteLine("Domain formatting error in DOMAIN.TXT line " + LineNumber + ".");
                            }
                            else
                            {
                                ParentName = Remainder.Substring(0, pos);
                                ParentName = ParentName.Trim(new char[]{' '});

                                Remainder = Remainder.Remove(0, pos + 1);
                                DomainTitle = Remainder.Trim(new char[]{' '});
                            }

                            DOFile.WriteLine(MarkedDomain + CodeSite + SUTIL.RPad(SerialNumber, 9) + "  " + SUTIL.RPad(DomainName, 22)
                                        + "  ,  " + SUTIL.RPad(ParentName, 22) + " , " + DomainTitle);

                            if (!SNValidator.Validate(SerialNumber))
                            {
                                HasErrors = true;
                                BogueFile.WriteLine("Duplicate domain serial number " + SerialNumber.ToString() + " in DOMAIN.TXT line "
                                          + LineNumber.ToString() + ".");
                            }

                            if (!DomainValidator.Validate(DomainName))
                            {
                                HasErrors = true;
                                BogueFile.WriteLine("Duplicate domain name " + DomainName + " in DOMAIN.TXT line " +
                                        LineNumber.ToString() + ".");
                            }
                        }
                    }
                }

                DIFile.Close();
                DOFile.Close();
            }

            catch
            {
                DIFile.Close();
                DOFile.Close();
            }
            //Thread.EndCriticalRegion();

            if (HasErrors)
                throw (new Exception("There were errors updating domain serial numbers."));

            // Now that we have an updated temporary file, rename the source file to .FSF and rename the
            // temp file to .TXT.
            if (File.Exists(BackupFileName))
            {
                _fileInfor = new FileInfo(BackupFileName);
                try
                {
                    _fileInfor.Attributes = FileAttributes.Archive;
                    _fileInfor.Delete();
                }
                catch (Exception e)
                {
                    throw (e);

                }
            }

            // Rename new file to backup and temp to new file.
            try
            {
                File.Move(OriginalFileName, BackupFileName);
            }
            catch
            {
                throw (new Exception("Problem making backup of serialized " + OriginalFileName + "."));
            }
            //if (rename (OriginalFileName, BackupFileName) != 0)
            //    throw(new Exception("Problem making backup of serialized " + OriginalFileName + ".");

            try
            {
                File.Move(TempFileName, OriginalFileName);
            }
            catch
            {
                throw (new Exception("Problem copying temp to " + OriginalFileName + "."));
            }
            //if (rename (TempFileName, OriginalFileName) != 0)
            //     throw(new Exception("Problem copying temp to " + OriginalFileName + ".");

            BogueFile.WriteLine(DCount + " Domain Serial Numbers generated. [" + DomainSN.RemainingSN() + "]");

        }
    }
}
