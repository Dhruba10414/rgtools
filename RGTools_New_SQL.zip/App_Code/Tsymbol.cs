using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using NaturalNumericSort;

namespace RGTools_New
{
    enum SymbolType { SymDomain, SymSubQuestion, SymNamedVariable, SymQuestion, SymInternalVariable };

    class TSymbol
    {
        public enum Type {None=0, Defined=1, Referenced=2, Both=3};

        private string m_SymbolName; // Name of the symbol.
        private SymbolType m_SType;    // Type of symbol, variable or label.
        private TSymbol.Type m_States;
        private long m_InternalSN;
        private long m_PermanentSN;
        private long m_ModuleSN;

        private static long m_SNCounter;

        // Init.  Initialize the symbol entry.  This method takes the following parameters:
        //
        //     pName        string      (Passed) Variable or Label name.
        //     pSType       SymbolType  (Passed) Symbol type, either SymLabel or SymVariable.
        //     pSDefCode    int         (Passed) Definition code.  Set to variable number for
        //                              variables and statement number for labels.
        //     pReferenced  bool        (Passed) Whether the symbol has been referenced or not.
        // 
        public TSymbol(string pName, SymbolType pSType, TSymbol.Type pStates, long pModuleSN)
        {
            m_SymbolName = pName;
            m_SType = pSType;
            m_States = pStates;
            if (pName == "SYSTEM")
            {
                m_InternalSN = 0;
                m_PermanentSN = 0;
            }
            else
            {
                m_InternalSN = IncSNcounter();// ++m_SNCounter;
                m_PermanentSN = -1;
            }
            m_ModuleSN = pModuleSN;
            RetiredQuestionSN = "";
        }

          //TSymbol ( string& pName, SymbolType pSType = SymInternalVariable, long pStates = 0,
          //      long pModuleSN = 0);
        public TSymbol(string pName)
        {
            m_SymbolName = pName;
            m_SType = SymbolType.SymInternalVariable;
            m_States = TSymbol.Type.None;
            if (pName == "SYSTEM")
            {
                m_InternalSN = 0;
                m_PermanentSN = 0;
            }
            else
            {
                m_InternalSN = IncSNcounter();// ++m_SNCounter;
                m_PermanentSN = -1;
            }
            m_ModuleSN = 0;

        }
        public TSymbol(string pName, SymbolType pSType)
        {
            m_SymbolName = pName;
            m_SType = pSType;
            m_States = TSymbol.Type.None;
            if (pName == "SYSTEM")
            {
                m_InternalSN = 0;
                m_PermanentSN = 0;
            }
            else
            {
                m_InternalSN = IncSNcounter();// ++m_SNCounter;
                m_PermanentSN = -1;
            }
            m_ModuleSN = 0;
        }
        private long IncSNcounter()
        {
            if (m_SNCounter >= 0)
            {
                return ++m_SNCounter;
            }
            else
            {
                return --m_SNCounter;
            }
        }
        //public static void SetBaseSN(long BaseSN) 
        //{ 
        //    m_SNCounter = BaseSN; 
        //}
        public string RetiredQuestionSN { get; set; }
        public static long BaseSN
        {
            set
            {
                m_SNCounter = value;
            }
            get
            {
                return m_SNCounter;
            }
        }
        public void SetPermanentSN(long pSerialNumber) 
        {
            if (m_PermanentSN < 0)
                m_PermanentSN = pSerialNumber;
            else
                throw (new Exception("Internal Error: Object " + this.m_SymbolName + " has been assigned multiple serial numbers."));
        }// throw (xmsg);
        public long GetPermanentSN()
        {
            switch (m_SType)
            {
                case SymbolType.SymDomain:
                case SymbolType.SymSubQuestion:
                case SymbolType.SymQuestion:
                    if (m_PermanentSN < 0)
                        throw (new Exception("Internal Error: Permanent Serial Number not assigned for " + m_SymbolName + "."));
                    else
                        return m_PermanentSN;

                case SymbolType.SymNamedVariable:
                case SymbolType.SymInternalVariable:
                default:
                    return m_InternalSN;
            }
        }// throw (xmsg);
        public long PermanentSN
        {
            set
            {
                //if (value.ToString().IndexOf("29")>-1 )
                //{
                //    string s = "";
                //}

                if (m_PermanentSN < 0)
                    m_PermanentSN = value;
                else
                    throw (new Exception("Internal Error: Object " + this.m_SymbolName + " has been assigned multiple serial numbers."));
            }
            get
            {
                switch (m_SType)
                {
                    case SymbolType.SymDomain:
                    case SymbolType.SymSubQuestion:
                    case SymbolType.SymQuestion:
                        //if (m_PermanentSN < 0)
                        //    throw (new Exception("Internal Error: Permanent Serial Number not assigned for " + m_SymbolName + "."));
                        //else
                        return m_PermanentSN;
                    case SymbolType.SymNamedVariable:
                    case SymbolType.SymInternalVariable:
                    default:
                        return m_InternalSN;
                }
            }
        }
        public TSymbol.Type State
        {
            set
            {
                m_States |= value;
            }
            get
            {
                return m_States;
            }
        }
        public void SetState(TSymbol.Type pState)
        {
            m_States |= pState;
        }
        public void SetModuleSN(long pModuleSN) 
        { 
            m_ModuleSN = pModuleSN; 
        }
        public long GetModuleSN() { return m_ModuleSN; }
        public long ModuleSN
        {
            set
            {
                m_ModuleSN = value;
            }
            get
            {
                return m_ModuleSN;
            }
        }
        public long GetInternalSN() { return m_InternalSN; }
        public long InternalSN
        {
            get
            {
                return m_InternalSN;
            }
        }
        public SymbolType GetSymbolType() { return m_SType; }
        public SymbolType symbolType
        {
            get
            {
                return m_SType;
            }
        }
        public string GetSymbolName() { return m_SymbolName; }
        public string SymbolName
        {
            get
            {
                return m_SymbolName;
            }
        }
        public bool IsReferenced
        {
            get
            {
                //return m_States & Referenced ? true : false; 
                switch (m_States)
                {
                    case TSymbol.Type.None:
                    case TSymbol.Type.Defined:
                        return false;
                    case TSymbol.Type.Both:
                    case TSymbol.Type.Referenced:
                        return true;
                    default:
                        return false;
                }
            }
        }
        public bool IsDefined
        {
            get
            {
                //return m_States & Defined ? true : false
                switch (m_States)
                {
                    case TSymbol.Type.None:
                    case TSymbol.Type.Referenced:
                        return false;
                    case TSymbol.Type.Both:
                    case TSymbol.Type.Defined:
                        return true;
                    default:
                        return false;
                }
            }
        }

        public static bool operator ==(TSymbol symbol1, TSymbol symbol2)
        {
            if (IsNull(symbol1) && IsNull(symbol2))
            {
                return true;
            }
            else if (IsNull(symbol1) || IsNull(symbol2))
            {
                return false;
            }
            else
            {
                return symbol1.m_SymbolName == symbol2.m_SymbolName ? true : false;
            }
        }
        public static bool operator !=(TSymbol symbol1, TSymbol symbol2)
        {
            if (IsNull(symbol1) && IsNull(symbol2))
            {
                return false;
            }
            else if (IsNull(symbol1) || IsNull(symbol2))
            {
                return true;
            }
            else
            {
                return symbol1.m_SymbolName != symbol2.m_SymbolName ? true : false;
            }
        }

        public static bool operator <(TSymbol symbol1, TSymbol symbol2)
        { 
            return symbol1.ModuleSN < symbol2.ModuleSN ? true : false; 
        }
        public static bool operator >(TSymbol symbol1, TSymbol symbol2)
        { 
            return symbol1.ModuleSN > symbol2.ModuleSN ? true : false; 
        }

        public override bool Equals(object symbol)
        {
            if (IsNull(symbol as TSymbol))
            {
                return false;
            }
            else
            {
                return this.m_SymbolName == (symbol as TSymbol).m_SymbolName ? true : false;
            }
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public static bool IsNull(TSymbol symbol)
        {
            return TSymbol.Equals(symbol, null);
        }

    }

    class TSymbolTable : List<TSymbol>
    {
        public TStrList WarningList = new TStrList();   // List of symbol table warning messages.

        public TSymbolTable()
        {
            //TISArrayAsVector<TSymbol>(100,0,100) {} // ructor
        }

        public TSymbol AddSymbol(string pName, SymbolType pSType, TSymbol.Type pStates, long pModuleSN) 
        {
            //long pS = Find(&TSymbol(pName));

            TSymbol pS =FindFirst(new TSymbol(pName));

            //debug and test. Jun 25, 2008
            //if(TSymbol.IsNull(pS))
            if (pS==null)
            {
                TSymbol pNewSymbol = new TSymbol(pName, pSType, pStates, pModuleSN);
                base.Add(pNewSymbol);
                //SortSymbol();

                return pNewSymbol;
            }
            else if (pS.symbolType != pSType)
            {
                string msg = "Warning: Symbol " + pName + " was defined in more than one way.";
                WarningList.Add(msg);

                throw (new Exception(msg));
            }
            else if (pS.symbolType == SymbolType.SymDomain)
            {
                string msg = "Domain " + pName + " was defined more than once.";
                throw (new Exception(msg));
            }
            else
                return pS;
        }// throw (xmsg);

        // GenerateVariable. This function returns the name of a label.  Generated labels are numbered
        //  sequentially from 1 and are in the form LABELnnn.  If a particular label already exists
        //  in the symbol table, the label counter is incremented until it can be found. Returns
        //  a newly allocated string.
        static long VariableCount = 0;
        public string GenerateVariable(long CurrentModuleSN)
        {
            string NewVariable;
            VariableCount++;

            StringBuilder a=new StringBuilder();
            a.Append("VAR" + VariableCount.ToString());
            NewVariable = a.ToString();

            AddSymbol(NewVariable, SymbolType.SymInternalVariable, TSymbol.Type.Defined | TSymbol.Type.Referenced, CurrentModuleSN);

            return NewVariable;
        }

        // CheckForWarnings.  Generate a possible list of warnings. Currently the only thing checked is whether
        //  the symbols have been referenced or not.
        public void CheckForWarnings()
        {
            for (int i = 0; i < base.Count; i++)
            {
                TSymbol p = base[i];
                switch (p.symbolType)
                {
                    case SymbolType.SymNamedVariable:
                    case SymbolType.SymSubQuestion:
                        if (!p.IsReferenced)
                        {
                            string msg = "Warning: You set the variable " + p.SymbolName + " but never referenced it.";
                            WarningList.Add(msg);
                        }
                        else if (!p.IsDefined)
                        {
                            string msg = "Warning: You referenced the variable " + p.SymbolName + " but never set it.";
                            WarningList.Add(msg);
                        }                       
                        break;
                    default:
                        break;
                }
            }
        }
        public void Dump(StreamWriter swOFile)
        {
            for (int i = 0; i < base.Count; i++)
            {
                TSymbol pS = base[i];
                swOFile.WriteLine(pS.SymbolName + " " + pS.symbolType + " D:"
                      + pS.IsDefined.ToString() + " R:" + pS.IsReferenced.ToString());
            }
        }

        private static TSymbol _symbol = null;
        private static bool match(TSymbol symbol)
        {
            if ((symbol.SymbolName == _symbol.SymbolName) &&
                ((symbol.symbolType == _symbol.symbolType) ||
                    (_symbol.symbolType==SymbolType.SymInternalVariable)))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public TSymbol FindFirst(TSymbol symbol)
        {
            _symbol = symbol;

            return base.Find(match);
           
        }
        private static int CompareTSymbol(TSymbol symbol1, TSymbol symbol2)
        {
            if (symbol1 == null)
            {
                if (symbol2 == null)
                {
                    return 0;
                }
                else
                {
                    return -1;
                }
            }
            else
            {
                if (symbol2 == null)
                {
                    return 1;
                }
                else
                {
                    //return UTIL.CmpareString(symbol1.SymbolName, symbol2.SymbolName);
                    return string.Compare(symbol1.SymbolName, symbol2.SymbolName, StringComparison.Ordinal);
                    //return StringLogicalComparer.Compare(symbol1.SymbolName, symbol2.SymbolName);
                }
            }
        }
        internal void SortSymbol()
        {
            base.Sort(CompareTSymbol);
        }

    }

}
