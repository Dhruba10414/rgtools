﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace RGTools_New
{
    class ImportExport : DataSql
    {
        private string[] tablenames = 
        { 
            "version",
            "module",
            "moduleversion",
            "domainstructure",
            "blob",
            "question",
            "qdlink",
            "qslink",
            "applicabilityvariable",
            "screengoal",
            "templaterule",
            "rgsection",
            "rgkeyword",
            "qrlink",
            "rgtoc",
            "state",
            "stateversion",
            "sdvlink",
            "statedomainstructure",
            "qdstatelink",
            "qcountState",
            "statesection",
            "statemodule",
            "questionbody",
            "blobstate",
            "aw_hyperlink",
            "aw_infoonly"                                     
        }; 

        private frmMain _main = null;

        public ImportExport(frmMain Main)
            : base(Main.SQLServer, "master", Main.SQLUser, Main.SQLPW)
        {
            _main = Main;
            //callBack += new DataSql.Display(sybase_callBack);
            checkCancel += new DataSql.IsCancel(isCancel);

        }
        internal bool isCancel()
        {
            return _main.cancelPressed;
        }
        private bool CheckForCancel
        {
            get
            {
                return _main.cancelPressed;
            }
        }

        public void LoadSybaseData()
        {
            try
            {
                Open();

                CreateNewDB(_main.ImportedDBName);

                RunSQL("use " + _main.ImportedDBName);
                RunSQL(Query.CreateSQLTables, true, true);

                //skip table version 161.dat
                for (int i = 162; i < 188; i++)
                {
                    if (CheckForCancel)
                    {
                        break;
                    }

                    string file_path = Path.Combine(_main.txtImDataPath.Text, i.ToString().Trim() + ".dat");

                    if (!File.Exists(file_path))
                    {
                        _main.lblImMsg.Text = "Not including all dat files!";
                        return;
                    }

                    _main.OutMsg(PageType.ImportExport, "Importing table " + tablenames[i - 161] +
                            " from file " + file_path + " ...\r\n");
                    LoadTextToTable_full(file_path, tablenames[i - 161]);
                }

                RunSQL(Query.CreateConstrains, true);
            }
            catch (Exception e)
            {
                ErrorThrow(e.Message);
            }
            finally
            {
                Close();
            }
        }

        private void ErrorThrow(string message)
        {
            if (message != string.Empty)
            {
                _main.OutMsg(PageType.ImportExport, message + ".\r\n");
                _main.processFailed = true;
            }
        }

        public void UnloadToSybaseData()
        {
            try
            {
                Open();

                RunSQL("use " + _main.SQLDB, true);

                for (int i = 161; i < 188; i++)
                {
                    if (CheckForCancel)
                    {
                        break;
                    } 
                    
                    string file_path = Path.Combine(_main.txtExDataPath.Text, i.ToString().Trim() + ".dat");

                    _main.OutMsg(PageType.ImportExport, "Exporting table " + tablenames[i - 161] +
                            " to file " + file_path + " ...\r\n");
                    UnloadTableToText(file_path, tablenames[i - 161]);
                }

            }
            catch(Exception e)
            {
                ErrorThrow(e.Message);
            }
            finally
            {
                Close();
            }
        }
    }
}
