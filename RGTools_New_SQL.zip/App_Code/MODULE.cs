using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace RGTools_New
{
    class MODULE
    {
        public static long GetModuleSN(string pInputPath) //throw (xmsg)
        {
            // First try to open the input file.
            string FileName = pInputPath + @"\MODULE.TXT";
            StreamReader ModuleFile = null;

            try
            {
                ModuleFile = new StreamReader(FileName, Encoding.Default);
            }
            catch
            {
                //if (!ModuleFile)
                throw (new Exception("Could not open " + FileName));
            }

            //char[] iline = new char[500];

            long ModuleSN = -1;

            // Loop through the input, discarding comments and sorting commands from content.
            string InputLine = string.Empty;
            while ((InputLine = ModuleFile.ReadLine()) != null)
            {
                // Read in a line from the input file and increment the counter.
                //string InputLine = iline;

                // Ignore comments.
                if (InputLine.Length <= 8) continue;
                if (InputLine.Substring(0, 8) != "MODULESN") continue;

                InputLine=InputLine.Remove(0, 8);
                InputLine = InputLine.Trim(new char[]{' '});
                if (InputLine.Substring(0, 1) != "=") continue;
                InputLine=InputLine.Remove(0, 1);
                InputLine = InputLine.Trim(new char[]{' '});
                ModuleSN = long.Parse(InputLine);
                break;
            }

            ModuleFile.Close();

            //if (ModuleSN < 0)
            //    throw (new Exception("Could not find MODULESN = in " + FileName));

            return ModuleSN;
        }

        public static string GetModuleName(string pInputPath) //throw (xmsg)
        {
            // First try to open the input file.
            string FileName = (pInputPath + @"\DOMAIN.TXT");
            StreamReader DomainFile = null;
            try
            {
                DomainFile = new StreamReader(FileName, Encoding.Default);
            }
            catch
            {
                throw (new Exception("Could not open " + FileName));
            }

            //char[] iline = new char[500];

            string ModuleName = "";

            // Loop through the input, discarding comments and sorting commands from content.
            string InputLine = string.Empty;
            while ((InputLine = DomainFile.ReadLine()) != null)
            {
                // Read in a line from the input file and increment the counter.
                //string InputLine = iline;

                // Ignore comments.
                if ((InputLine.Length > 0) && (InputLine.Substring(0, 1) == "*")) continue;

                int iPos = InputLine.IndexOf("SYSTEM");
                if (iPos == -1) continue;

                InputLine=InputLine.Remove(0, iPos + 6);
                iPos = InputLine.IndexOf(',');
                if (iPos == -1)
                    throw (new Exception("Comma not following SYSTEM in " + FileName));

                InputLine=InputLine.Remove(0, iPos + 1);
                InputLine = InputLine.Trim(new char[]{' '});

                // Name is most of the string.
                ModuleName = InputLine.Substring(1, InputLine.Length - 2);
                break;
            }

            DomainFile.Close();

            if (ModuleName == "")
                throw (new Exception("Could not find SYSTEM in " + FileName));

            return ModuleName;
        }
    }
}
