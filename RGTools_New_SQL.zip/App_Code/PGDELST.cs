//----------------------------------------------------------------------------
//  Project RGTools
//  Dakota Software Corporation
//  Copyright � 1997. All Rights Reserved.
//  FILE:    pgdelst.h
//  AUTHOR:  Marc CHANTEGREIL
//
//  OVERVIEW
//  ~~~~~~~~
//  Class definition for TPageDelState (TPageWithDB).
//
//----------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Text;
//using ODBCMngr;
using System.IO;
using System.Data.SqlClient;

//******************************************************************
//**//// TPageDelState ////////////////////////////////////////////////
//******************************************************************
namespace RGTools_New
{
    class TPageDelState
    {

        string __SQLV_pgdelst_24 = null;// "drop table State";//"DELETE FROM State";
        string __SQLV_pgdelst_26 = null;//"drop table StateModule";
        string __SQLV_pgdelst_28 = null;//"drop table StateDomainStructure";
        string __SQLV_pgdelst_30 = null;//"drop table SDVLink";
        string __SQLV_pgdelst_32 = null;//"drop table StateVersion";
        string __SQLV_pgdelst_34 = null;//"drop table BlobState";
        string __SQLV_pgdelst_36 = "DELETE FROM QRLink WHERE QuestionSN >= 1000000000";
        string __SQLV_pgdelst_38 = null;//"drop table QDStateLink";
        string __SQLV_pgdelst_40 = "DELETE FROM Question WHERE QuestionSN >= 1000000000";
        string __SQLV_pgdelst_42 = "DELETE FROM QuestionBody WHERE QuestionBodySN >= 1000000000";
        string __SQLV_pgdelst_44 = "DELETE FROM RGKeyWord WHERE ReferenceSN >= 1000000000";
        string __SQLV_pgdelst_46 = "DELETE FROM RGSection WHERE SectionSN >= 1000000000";
        string __SQLV_pgdelst_48 = null;//"drop table QCountState";
        string __SQLV_pgdelst_50 = null;//"drop table StateSection";
 
        string __SQLV_pgdelst_54 = null;
        string __SQLV_pgdelst_56 = null;
        string __SQLV_pgdelst_58 = null;
        string __SQLV_pgdelst_59 = null;
        string __SQLV_pgdelst_60 = null;
        string __SQLV_pgdelst_62 = null;
        string __SQLV_pgdelst_64 = null;
        string __SQLV_pgdelst_66 = null;
        string __SQLV_pgdelst_67 = null;
        string __SQLV_pgdelst_68 = null;
        string __SQLV_pgdelst_70 = null;

        private frmMain _main = null;
        string SQL = string.Empty;

        DataSql sqlbase = null;
        SqlTransaction transaction = null;

        public TPageDelState(frmMain Main)
        {
            _main = Main;
            sqlbase = new DataSql(_main.txtDelStServer.Text, _main.txtDelStDB.Text, _main.DelStateUser, _main.DelStateUser);
            sqlbase.callBack += new DataSql.Display(sybase_callBack);
            sqlbase.checkCancel += new DataSql.IsCancel(IsCancel);

            __SQLV_pgdelst_24 = Query.DeleteSQLTables[20]; // "drop table State";//"DELETE FROM State";
            __SQLV_pgdelst_26 = Query.DeleteSQLTables[21]; // "drop table StateModule";
            __SQLV_pgdelst_28 = Query.DeleteSQLTables[26]; //"drop table StateDomainStructure";
            __SQLV_pgdelst_30 = Query.DeleteSQLTables[19]; //"drop table SDVLink";
            __SQLV_pgdelst_32 = Query.DeleteSQLTables[23]; //"drop table StateVersion";
            __SQLV_pgdelst_34 = Query.DeleteSQLTables[4]; //"drop table BlobState";
            __SQLV_pgdelst_36 = "DELETE FROM QRLink WHERE QuestionSN >= 1000000000";
            __SQLV_pgdelst_38 = Query.DeleteSQLTables[10]; //"drop table QDStateLink";
            __SQLV_pgdelst_40 = "DELETE FROM Question WHERE QuestionSN >= 1000000000";
            __SQLV_pgdelst_42 = "DELETE FROM QuestionBody WHERE QuestionBodySN >= 1000000000";
            __SQLV_pgdelst_44 = "DELETE FROM RGKeyWord WHERE ReferenceSN >= 1000000000";
            __SQLV_pgdelst_46 = "DELETE FROM RGSection WHERE SectionSN >= 1000000000";
            __SQLV_pgdelst_48 = Query.DeleteSQLTables[8]; //"drop table QCountState";
            __SQLV_pgdelst_50 = Query.DeleteSQLTables[22]; //"drop table StateSection";

            __SQLV_pgdelst_54 =Query.CreateSQLTables[23]; //"CREATE TABLE \"DBA\".\"State\"(" +
            __SQLV_pgdelst_56 = Query.CreateSQLTables[25];//"CREATE TABLE \"DBA\".\"StateModule\"(" +
            __SQLV_pgdelst_58 = Query.CreateSQLTables[27];//"CREATE TABLE \"DBA\".\"StateDomainStructure\"(" +
            __SQLV_pgdelst_59 = Query.CreateSQLTables[28];//"CREATE TABLE \"DBA\".\"StateDomainStructure\"(" +
            __SQLV_pgdelst_60 = Query.CreateSQLTables[26];//"CREATE TABLE \"DBA\".\"SDVLink\"(" +
            __SQLV_pgdelst_62 = Query.CreateSQLTables[24];//"CREATE TABLE \"DBA\".\"StateVersion\"(" +
            __SQLV_pgdelst_64 = Query.CreateSQLTables[7];//"CREATE TABLE \"DBA\".\"BlobState\"(" +
            __SQLV_pgdelst_66 = Query.CreateSQLTables[29];//"CREATE TABLE \"DBA\".\"QDStateLink\"(" +
            __SQLV_pgdelst_67 = Query.CreateSQLTables[30];//"CREATE TABLE \"DBA\".\"QDStateLink\"(" +
            __SQLV_pgdelst_68 = Query.CreateSQLTables[31];//"CREATE TABLE \"DBA\".\"QCountState\"(" +
            __SQLV_pgdelst_70 = Query.CreateSQLTables[32];//"CREATE TABLE \"DBA\".\"StateSection\"(" +

        }
        internal bool IsCancel()
        {
            return _main.cancelPressed;
        }
        private bool CheckForCancel
        {
            get
            {
                return _main.cancelPressed;
            }
        }

        public void DoProcess()
        {
            string[] SQL = new string[70];
            string[] MSG = new string[70];

            SQL[22] = __SQLV_pgdelst_24;
            MSG[22] = "Deleting the Table State.\r\n";

            SQL[24] = __SQLV_pgdelst_26;
            MSG[24] = "Deleting the Table StateModule.\r\n";

            SQL[26] = __SQLV_pgdelst_28;
            MSG[26] = "Deleting the Table StateDomainStructure.\r\n";

            SQL[28] = __SQLV_pgdelst_30;
            MSG[28] = "Deleting the Table SDVLink.\r\n";

            SQL[30] = __SQLV_pgdelst_32;
            MSG[30] = "Deleting the Table StateVersion.\r\n";

            SQL[32] = __SQLV_pgdelst_34;
            MSG[32] = "Deleting the Table BlobState.\r\n";

            SQL[34] = __SQLV_pgdelst_36;
            MSG[34] = "Deleting the Table QRLink.\r\n";

            SQL[36] = __SQLV_pgdelst_38;
            MSG[36] = "Deleting the Table QDStateLink.\r\n";

            SQL[38] = __SQLV_pgdelst_40;
            MSG[38] = "Deleting the Table Question.\r\n";

            SQL[40] = __SQLV_pgdelst_42;
            MSG[40] = "Deleting the Table QuestionBody.\r\n";

            SQL[42] = __SQLV_pgdelst_44;
            MSG[42] = "Deleting the Table RGKeyWord.\r\n";

            SQL[44] = __SQLV_pgdelst_46;
            MSG[44] = "Deleting the Table RGSection.\r\n";

            SQL[46] = __SQLV_pgdelst_48;
            MSG[46] = "Deleting the Table QCountState.\r\n";

            SQL[48] = __SQLV_pgdelst_50;
            MSG[48] = "Deleting the Table StateSection.\r\n";

            SQL[52] = __SQLV_pgdelst_54;
            MSG[52] = "Creating empty table State.\r\n";

            SQL[54] = __SQLV_pgdelst_56;
            MSG[54] = "Creating empty table StateModule.\r\n";

            SQL[56] = __SQLV_pgdelst_58;
            MSG[56] = "Creating empty table StateDomainStructure.\r\n";

            SQL[58] = __SQLV_pgdelst_60;
            MSG[58] = "Creating empty table SDVLink.\r\n";

            SQL[60] = __SQLV_pgdelst_62;
            MSG[60] = "Creating empty table StateVersion.\r\n";

            SQL[62] = __SQLV_pgdelst_64;
            MSG[62] = "Creating empty table BlobState.\r\n";

            SQL[64] = __SQLV_pgdelst_66;
            MSG[64] = "Creating empty table QDStateLink.\r\n";

            SQL[66] = __SQLV_pgdelst_68;
            MSG[66] = "Creating empty table QCountState.\r\n";

            SQL[68] = __SQLV_pgdelst_70;
            MSG[68] = "Creating empty table StateSection.\r\n";

            try
            {
                sqlbase.Open();
                transaction = sqlbase.BeginTransaction();

                string ret = sqlbase.RunSQL(Query.DeleteConstrains, MSG, true, true);
                if (ret != string.Empty)
                {
                    ErrorThrow(ret);
                    transaction.Rollback();
                    return;
                }

                ret = sqlbase.RunSQL(SQL, MSG, true, true);

                if (ret != string.Empty)
                {
                    ErrorThrow(ret);
                    transaction.Rollback();

                    return;
                }

                ret = sqlbase.RunSQL(Query.CreateConstrains, MSG, true, true);
                if (ret != string.Empty)
                {
                    ErrorThrow(ret);
                    transaction.Rollback();
                    return;
                }
                    
                if (!sqlbase.RunError && !CheckForCancel)
                {
                   
                    transaction.Commit();
                }
                else
                {
                    //_main.originalPathForCurrentDB = string.Empty;
                    _main.OutMsg(PageType.DeleteState, "The database " + _main.txtDelStDB.Text.Trim() + " has not been changed.\r\n");
                    transaction.Rollback();
                }

             
            }
            catch (Exception e)
            {
                //transaction.Rollback();
                ErrorThrow(e.Message);
            }
            finally
            {
                sqlbase.Close();
            }
        }

        private void ErrorThrow(string message)
        {
            if (message != string.Empty)
            {
                _main.OutMsg(PageType.DeleteState, message + ".\r\n");
                _main.processFailed = true;
            }
        }

        private void sybase_callBack(string message)
        {
            _main.OutMsg(PageType.DeleteState, message);
        }


    }
}

