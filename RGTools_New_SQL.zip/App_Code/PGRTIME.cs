//----------------------------------------------------------------------------
//  Project RGTools
//  Dakota Software Corporation
//  Copyright � 1997. All Rights Reserved.
//  FILE:    pgrtime.h
//  AUTHOR:  Marc CHANTEGREIL
//
//  OVERVIEW
//  ~~~~~~~~
//  Class definition for TPageRTime (TPageWithDB).
//
//----------------------------------------------------------------------------

//******************************************************************
//**//// TPageRTime ////////////////////////////////////////////////
//******************************************************************

using System;
using System.Collections.Generic;
using System.Text;
using ODBCMngr;
using System.IO;
namespace RGTools_New
{

    class TPageRTime
    {
        static string __SQLV_PGRTIME_2 = "DROP TABLE DomainStructure";
        static string __SQLV_PGRTIME_3 = "DROP TABLE QDLink";
        static string __SQLV_PGRTIME_4 = "DROP TABLE QSlink";
        static string __SQLV_PGRTIME_5 = "DROP TABLE ApplicabilityVariable";
        static string __SQLV_PGRTIME_6 = "DROP TABLE TemplateRule";
        static string __SQLV_PGRTIME_7 = "DROP TABLE aw_Hyperlink";
        static string __SQLV_PGRTIME_8 = "DROP TABLE aw_InfoOnly";
        static string __SQLV_PGRTIME_9 = "ALTER TABLE ScreenGoal            DELETE UNIQUE (ModuleSN, \"ModuleVersionSN\", \"ApplicSN\")";
        static string __SQLV_PGRTIME_10 = "ALTER TABLE QRLink               DELETE UNIQUE (QuestionSN, \"ReferenceSN\")";
        static string __SQLV_PGRTIME_11 = "ALTER TABLE StateDomainStructure DELETE UNIQUE (StateVersionSN, \"ModuleSN\", \"ModuleVersionSN\", \"ChildOrder\", \"ParentSN\")";
        static string __SQLV_PGRTIME_12 = "ALTER TABLE QDStateLink          DELETE UNIQUE (StateSN, \"StateVersionSN\", \"StateDomainSN\", \"QuestionSN\")";
        static string __SQLV_PGRTIME_13 = "ALTER TABLE ModuleVersion        DELETE FOREIGN KEY Module";
        static string __SQLV_PGRTIME_14 = "ALTER TABLE ScreenGoal           DELETE FOREIGN KEY ModuleVersion";
        static string __SQLV_PGRTIME_15 = "ALTER TABLE RGKeyWord            DELETE FOREIGN KEY Module";
        static string __SQLV_PGRTIME_16 = "ALTER TABLE RGKeyWord            DELETE FOREIGN KEY RGSection";
        static string __SQLV_PGRTIME_17 = "ALTER TABLE QRLink               DELETE FOREIGN KEY Question";
        static string __SQLV_PGRTIME_18 = "ALTER TABLE RGTOC                DELETE FOREIGN KEY RGSection";
        static string __SQLV_PGRTIME_19 = "ALTER TABLE RGTOC                DELETE FOREIGN KEY Module";
        static string __SQLV_PGRTIME_20 = "ALTER TABLE SDVLink              DELETE FOREIGN KEY StateVersion";
        static string __SQLV_PGRTIME_21 = "ALTER TABLE StateDomainStructure DELETE FOREIGN KEY SDVLink";
        static string __SQLV_PGRTIME_22 = "ALTER TABLE StateDomainStructure DELETE FOREIGN KEY ModuleVersion";
        static string __SQLV_PGRTIME_23 = "ALTER TABLE QDStateLink          DELETE FOREIGN KEY State";
        static string __SQLV_PGRTIME_24 = "ALTER TABLE QDStateLink          DELETE FOREIGN KEY SDVLink";
        static string __SQLV_PGRTIME_25 = "ALTER TABLE QCountState          DELETE FOREIGN KEY State";
        static string __SQLV_PGRTIME_26 = "ALTER TABLE QCountState          DELETE FOREIGN KEY SDVLink";
        static string __SQLV_PGRTIME_27 = "ALTER TABLE StateModule          DELETE FOREIGN KEY ModuleVersion";
        static string __SQLV_PGRTIME_28 = "ALTER TABLE StateModule          DELETE FOREIGN KEY StateVersion";
        static string __SQLV_PGRTIME_29 = "ALTER TABLE StateSection         DELETE FOREIGN KEY StateVersion";
        static string __SQLV_PGRTIME_30 = "DROP OPTIMIZER STATISTICS";
        static string __SQLV_PGRTIME_31 = "COMMIT WORK";

        private frmMain _main = null;
        string SQL = string.Empty;
        DataSql sqlbase = null;

        public TPageRTime(frmMain Main)
        {
            _main = Main;
            sqlbase = new DataSql(_main.SQLServer, _main.SQLDB, _main.SQLUser, _main.SQLDB);
            sqlbase.callBack += new DataSql.Display(sybase_callBack);
        }

        public void DoProcess()
        {
            string[] SQL = new string[30];
            string[] MSG = new string[30];

            // We must call first the base class method.

            //--------------------------------------------------------------
            SQL[0] = __SQLV_PGRTIME_2;
            MSG[0] = "Dropping the Table DomainStructure.\r\n";

            SQL[1] = __SQLV_PGRTIME_3;
            MSG[1] = "Dropping the Table QDLink.\r\n";

            SQL[2] = __SQLV_PGRTIME_4;
            MSG[2] = "Dropping the Table QSLink.\r\n";

             SQL[3] = __SQLV_PGRTIME_5;
             MSG[3] = "Dropping the Table ApplicabilityVariable.\r\n";

             SQL[4] = __SQLV_PGRTIME_6;
             MSG[4] = "Dropping the Table TemplateRule.\r\n";

             SQL[5] = __SQLV_PGRTIME_7;
             MSG[5] = "Dropping the Table aw_Hyperlink.\r\n";

             SQL[6] = __SQLV_PGRTIME_8;
             MSG[6] = "Dropping the Table aw_InfoOnly.\r\n";

             SQL[7] = __SQLV_PGRTIME_9;
             MSG[7] = "Deleting unused UNIQUE constraints.\r\n";

             SQL[8] = __SQLV_PGRTIME_10;
             MSG[8] = string.Empty;

             SQL[9] = __SQLV_PGRTIME_11;
             MSG[9] = string.Empty;

             SQL[10] = __SQLV_PGRTIME_12;
             MSG[10] = string.Empty;

             SQL[11] = __SQLV_PGRTIME_13;
             MSG[11] = "Deleting unused FOREIGN KEYS.\r\n";

             SQL[12] = __SQLV_PGRTIME_14;
             MSG[12] = string.Empty;

             SQL[13] = __SQLV_PGRTIME_15;
             MSG[13] = string.Empty;

             SQL[14] = __SQLV_PGRTIME_16;
             MSG[14] = string.Empty;

             SQL[15] = __SQLV_PGRTIME_17;
             MSG[15] = string.Empty;

             SQL[16] = __SQLV_PGRTIME_18;
             MSG[16] = string.Empty;

             SQL[17] = __SQLV_PGRTIME_19;
             MSG[17] = string.Empty;

             SQL[18] = __SQLV_PGRTIME_20;
             MSG[18] = string.Empty;

             SQL[19] = __SQLV_PGRTIME_21;
             MSG[19] = string.Empty;

             SQL[20] = __SQLV_PGRTIME_22;
             MSG[20] = string.Empty;

             SQL[21] = __SQLV_PGRTIME_23;
             MSG[21] = string.Empty;

             SQL[22] = __SQLV_PGRTIME_24;
             MSG[22] = string.Empty;

             SQL[23] = __SQLV_PGRTIME_25;
             MSG[23] = string.Empty;

             SQL[24] = __SQLV_PGRTIME_26;
             MSG[24] = string.Empty;

             SQL[25] = __SQLV_PGRTIME_27;
             MSG[25] = string.Empty;

             SQL[26] = __SQLV_PGRTIME_28;
             MSG[26] = string.Empty;

             SQL[27] = __SQLV_PGRTIME_29;
             MSG[27] = string.Empty;

             SQL[28] = __SQLV_PGRTIME_30;
             MSG[28] = string.Empty;

             SQL[29] = __SQLV_PGRTIME_31;
             MSG[29] = string.Empty;

             //string ret = sybase.RunSQL(SQL, MSG);
             //string ret = sqlbase.RunSQL(SQL, MSG, false);
             //if (ret != string.Empty)
             //{
             //    ErrorThrow(ret);
             //}

             //if (!sybase.RunError)
             //{
             //    _main.OutMsg(PageType.RunTimeCreation, "Do an Unload/Reload of the Database to minimize the size.\r\n");
             //}
             //else
             //{
             //    _main.OutMsg(PageType.RunTimeCreation, "The database " + _main.txtRunTimeCreationDB.Text.Trim() + " has not been changed.\r\n");
             //}
         }

         private void ErrorThrow(string message)
         {
             if (message != string.Empty)
             {
                 _main.OutMsg(PageType.RunTimeCreation, message + ".\r\n");
                 _main.processFailed = true;
             }
         }

         private void sybase_callBack(string message)
         {
             _main.OutMsg(PageType.RunTimeCreation, message);
         }

    }
}
