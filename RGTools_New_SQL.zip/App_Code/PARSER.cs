using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Diagnostics;

namespace RGTools_New
{
    enum ParseResult { ParseOK, ParseDone, ParseFail }

    class TParser
    {
        public TRuleList RuleList = new TRuleList();     // list of quadruples.

        private TTokenPump TokenStream = new TTokenPump(); // Label counter.
        private TParserFood Meal = null;//new TParserFood();        // Prescanned document
        private TDomainTable DomainTable = null;

        private string LastQuestion = string.Empty;
        private string LastDomain = string.Empty;
        private string LastSubQuestion = string.Empty;
        private bool InSubQuestion = false;
        private long CurrentModuleSN = 0;

        private string m_sSNDir;

        public TParser(string SNDir)
        {
            m_sSNDir = SNDir;
            Meal = null;

            // And we are going to start on the first statement.
            LastQuestion = string.Empty;
            LastDomain = string.Empty;
            LastSubQuestion = string.Empty;
            InSubQuestion = false;
        }

        public void DigestQDOC(TParserFood QDOC, TDomainTable pDomainTable, StreamWriter Bogue) // throw (xmsg)
        {
            long CountOK = 0;
            long CountDone = 0;
            long CountFail = 0;

            CurrentModuleSN = 0;

            DomainTable = pDomainTable;
            Meal = QDOC;

            //#29231-3
            //The domain statement for this domain USWQ:C.ENP.97  has been removed from the question file which should 
            //generate a warning message in the BuildREM step that indicates the domain USWQ:C.ENP.97 was set but never 
            //referenced and a bad link on the abridged question USWQTIER.00.09.C. 
            List<string> lstDomInQuestion = new List<string>();
            
            foreach (TRuleStatement rule in Meal.RuleList)
            {               
                if (rule.Class == TRuleStatement.RuleClassType.Rule)
                {
                    if (rule.Line.IndexOf("DOMAIN ", 0) == 0)
                    {
                        lstDomInQuestion.Add(rule.Line.Substring(7).Trim());
                    }
                    else if (rule.Line.IndexOf("DOMAIN ", 0) > 0)
                    {
                        lstDomInQuestion.Add(rule.Line.Trim());
                    }
                }
            }

            bool IsFound = false;
            foreach (TDomain dom in DomainTable)
            {
                if (dom.IsMarked)
                {
                    continue;
                }

                IsFound = false;
                foreach (string name in lstDomInQuestion)
                {
                    if (dom.DomainName == name)
                    {
                        dom.IsReferenced = true;
                        break;
                    }
                    else if (name.IndexOf("DOMAIN " + dom.DomainName + ",") > -1)
                    {
                        IsFound = true;
                    }
                    else if (name.IndexOf("DOMAIN " + dom.DomainName) > -1)
                    {
                        if (name.Substring(name.IndexOf(dom.DomainName)) == dom.DomainName)
                        {
                            IsFound = true;
                        }
                    }
                }

                if (!IsFound && !dom.IsReferenced)
                {
                    dom.IsReferenced = true;
                }               
            }

            string strWarning = "";

            //Testing RGTools V 3.0.0.14 and have detected many more false positives than had been anticipated. 
            //There are additional conditions that need to be identified to implement this error checking step correctly. 
            //Therefore I am asking the code for detecting this specific error be removed for now until Regulatory can identify and better define all the conditions necessary to only find the instances where there is a true error that needs to be fixed. 
            //For now we can continue to identify this error manually in the product as we have in the past. We can add automatic identification of this error to a future revision of RGTools.

            //foreach (TDomain dom in DomainTable)
            //{
            //    if (!dom.IsReferenced && !dom.IsMarked)
            //    {
            //        strWarning += "Warning: You set the Domain  " + dom.DomainName + ", but never referenced it." + Environment.NewLine;
            //    }
            //}


            // Now go through and parse all the statements.
            for (int CurrentStatement = 0; CurrentStatement < Meal.RuleList.Count; CurrentStatement++)
            {
                TRuleStatement pRS = Meal.RuleList[CurrentStatement];

                switch (pRS.Class)
                {
                        case TRuleStatement.RuleClassType.Rule:
                        {
                            string SaveLine = pRS.Line;
                            //SpewStatement(Bogue, pRS.InputLineNumber, ref  pRS.Line);
                            TokenStream.Load(ref pRS.Line);
                            //TokenStream.Dump();

                            switch (Statement())
                            {
                                case ParseResult.ParseOK:
                                    if (TokenStream.TokenType == TTokenType.OutOfTokens)
                                        CountDone++;
                                    else
                                        CountOK++;
                                    break;

                                case ParseResult.ParseDone:
                                    CountDone++;
                                    break;

                                case ParseResult.ParseFail:
                                    CountFail++;
                                    Bogue.WriteLine("Question ID:  " + LastQuestion);
                                    SpewStatement(Bogue, pRS.InputLineNumber, ref  SaveLine);
                                    break;
                            }

                            // Dump any notes gathered through the parsing process.
                            TokenStream.NoteList.DumpAll(Bogue);
                            break;
                        }

                    case TRuleStatement.RuleClassType.QuestionID:
                        //  Bogue.WriteLine(endl + "Question ID:  " + pRS.Line  );
                        LastQuestion = pRS.Line;

                        //long SQOffset = Meal.SymbolTable.FindFirst (new TSymbol (LastQuestion, SymbolType.SymInternalVariable,  0, 0));
                        TSymbol SQOffset = Meal.SymbolTable.FindFirst(new TSymbol(LastQuestion));

                        //debug and check if found, Jun 25, 2008
                        UTIL.Assert(SQOffset != null, "Assertion Failed: SQOffset != null!");

                        //Meal.SymbolTable[SQOffset].SetModuleSN (CurrentModuleSN);
                        SQOffset.ModuleSN = CurrentModuleSN;
                        string What = (InSubQuestion) ? LastSubQuestion : LastDomain;
                        TSymbol DOffset = Meal.SymbolTable.FindFirst(new TSymbol(What));

                        //if DOffset== null, test
                        UTIL.Assert(DOffset != null, "Assertion Failed: DOffset != null!");


                        // Look for the question in the question list
                        TQData QOffset = Meal.FindFirstTQData(new TQData(LastQuestion));

                        UTIL.Assert(QOffset != null, "Assertion Failed: QOffset != null!");
                        //Test and debug here

                        QOffset.DomainSymbol = DOffset;
                        break;
                }
            }

            Meal.SymbolTable.CheckForWarnings();
            Meal.SymbolTable.WarningList.DumpAll(Bogue);
            //    Bogue.WriteLine("Ok:" + CountOK + "  Done:" + CountDone + "   Fail:" + CountFail  );

            QDOC.SymbolTable.SortSymbol();

            //   Meal.SymbolTable.Dump (Bogue);
            if (CountFail > 0 || strWarning.Length > 0)
            {
                Bogue.WriteLine(strWarning);
                throw (new Exception("There were errors parsing QUESTION.TXT"));
            }
            else
                Bogue.WriteLine("QUESTION.TXT parsed successfully.");
        }

        public void GenerateApplicabilityVariables(string OutputDirectory)
        {
            StreamWriter oFile = CreateStream(OutputDirectory + "\\APPVAR.REM");

            for (int i = 0; i < Meal.SymbolTable.Count; i++)
            {
                TSymbol pS = Meal.SymbolTable[i];

                // Only output if referenced or a named variable. (CSB bug fix)
                if (pS.IsReferenced || pS.symbolType == SymbolType.SymNamedVariable)
                {
                    // CSB new. If this is the system domain, don't output it.
                    if (pS.InternalSN == 0)
                    {
                        continue;
                    }

                    oFile.Write(pS.InternalSN.ToString() + ",");

                    switch (pS.symbolType)
                    {
                        case SymbolType.SymInternalVariable:
                            oFile.Write("'I',");
                            break;

                        case SymbolType.SymNamedVariable:
                            oFile.Write("'N',");
                            break;

                        case SymbolType.SymDomain:
                            oFile.Write("'D',");
                            break;

                        case SymbolType.SymQuestion:
                            oFile.Write("'Q',");
                            break;

                        case SymbolType.SymSubQuestion:
                            oFile.Write("'S',");
                            break;
                    }
                    oFile.Write(pS.PermanentSN + ",");
                    if (pS.SymbolName == "SYSTEM")
                    {
                        oFile.Write("'A',");
                    }
                    else
                    {
                        oFile.Write("'U',");
                    }
                    oFile.WriteLine(pS.ModuleSN);
                }
            }

            oFile.Close();
        }// throw (xmsg){}

        public void GenerateNamedVariables(string OutputDirectory)
        {
            StreamWriter oFile = CreateStream(OutputDirectory + "\\NAMEDVAR.REM");

            for (int i = 0; i < Meal.SymbolTable.Count; i++)
            {
                TSymbol pS = Meal.SymbolTable[i];
                if (pS.symbolType == SymbolType.SymNamedVariable)
                {
                    oFile.WriteLine(pS.InternalSN + ",'" + pS.SymbolName + "'");
                }
            }

            oFile.Close();
        }// throw (xmsg){}

        public void GenerateQuestions(string OutputDirectory, StreamWriter Bogue)
        {
            // Instead of starting sequence count at zero, start from the module SN.
            long SQCount = CurrentModuleSN;
            long HLCount = 1000;

            StreamWriter qfile = CreateStream(OutputDirectory + "\\QUESTION.REM");

            StreamWriter qbfile = CreateStream(OutputDirectory + "\\QSTBODY.REM");

            StreamWriter qsnfile = CreateStream(OutputDirectory + "\\QUEST-SN.TXT");

            StreamWriter hlkfile = CreateStream(OutputDirectory + "\\HLINK.REM");

            StreamWriter QDFile = CreateStream(OutputDirectory + "\\QDLINK.REM");

            StreamWriter QSFile = CreateStream(OutputDirectory + "\\QSLINK.REM");
            StreamWriter RQSFile = CreateStream(OutputDirectory + "\\RETIREDQUET.REM");


            bool HasErrors = false;
            List<TSymbol> lstTsbl = new List<TSymbol>();
            for (int i = 0; i < Meal.SymbolTable.Count; i++)
            {
                TSymbol pS = Meal.SymbolTable[i];

                if (pS.symbolType == SymbolType.SymQuestion)
                {
                    lstTsbl.Add(pS);
                }

            }
            for (int i = 0; i < Meal.SymbolTable.Count; i++)
            {
                TSymbol pS = Meal.SymbolTable[i];

                if (pS.symbolType == SymbolType.SymQuestion)
                {
                    bool AnyList = false;

                    TQData pQ = Meal.FindFirstTQData(new TQData(pS.SymbolName));

                    UTIL.Assert(pQ != null, "Assertion Failed: pQ != null!");

                    // Extract any list questions.
                    string QText = pQ.QText;
                    string Base = string.Empty;
                    string Note = string.Empty;
                    string ListAnswer = string.Empty;

                    int Pos;

                    while (true)
                    {
                        if ((Pos = QText.IndexOfAny(new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' })) == 0)
                        {
                            if (AnyList)
                            {
                                //ListAnswer += @"\x7F"; // Asc (127)
                                ListAnswer += ASCIIEncoding.Default.GetString(new byte[] { 0X7f });
                            }
                            else
                            {
                                AnyList = true;
                            }

                            if ((Pos = QText.IndexOf(@"\n\n")) == -1)
                            {
                                ListAnswer += QText;
                                break;
                            }
                            else
                            {
                                ListAnswer += QText.Substring(0, Pos);
                                QText = QText.Remove(0, Pos);
                            }
                        }
                        else
                        {
                            if ((Pos = QText.IndexOf(@"\n\n")) == -1)
                            {
                                if (QText.Length > 0)
                                {
                                    if (AnyList)
                                    {
                                        if (Note.Length > 0)
                                            Note += @"\n\n";
                                        Note += QText;
                                    }
                                    else
                                    {
                                        if (Base.Length > 0)
                                            Base += @"\n\n";
                                        Base += QText;
                                    }
                                }
                                break;
                            }

                            if (Pos > 0)
                            {
                                if (AnyList)
                                {
                                    if (Note.Length > 0)
                                        Note += @"\n\n";
                                    Note += QText.Substring(0, Pos/*+4*/);
                                }
                                //else if (QText.IndexOf("~~~~~") != -1)
                                //{
                                //    Pos = QText.IndexOf("~~~~~");
                                //    if (Note.Length > 0)
                                //        Note += "\\n\\n";

                                //    Note += QText.Substring(Pos + 5);

                                //    if (Base.Length > 0)
                                //        Base += "\\n\\n";

                                //    Base += QText.Substring(0, Pos/*+4*/);
                                //}
                                else
                                {
                                    if (Base.Length > 0)
                                        Base += @"\n\n";
                                    Base += QText.Substring(0, Pos/*+4*/);
                                }
                            }
                            QText = QText.Remove(0, Pos + 4);
                        }
                    }

                    if (pQ.WSerialNumber != string.Empty)
                    {
                        if (pQ.RetiredQuestionSN != string.Empty)
                        {
                            RQSFile.WriteLine(pQ.WSerialNumber + "," + pQ.RetiredQuestionSN + ",'" + pQ.QID + "',0,0");
                        }

                        qsnfile.WriteLine(pS.InternalSN.ToString() + "," + pQ.WSerialNumber + "," + pQ.QID);
                        //bool haslink = false;
                        for (int j = 0; j < pQ.Links.Count; j++)
                        {
                            //hlkfile + pQ.Links[i]   +  endl;
                            string linkstr = pQ.Links[j];
                            bool haslink = true;
                            int pos = linkstr.IndexOf(';');

                            //? pos=-1? Jun 25, 2008
                            string text = linkstr.Substring(0, pos);
                            text = text.Trim(new char[]{' '});
                            linkstr = linkstr.Remove(0, pos + 1);
                            pos = text.IndexOf("'");
                            while (pos != -1)
                            {
                                //how to implement Replace in C#? July 3rd
                                text = text.Replace("'", "''");
                                pos = text.IndexOf("'", pos + 2);
                            }

                            while (haslink && linkstr.Length > 1)
                            {
                                string copy = linkstr;
                                string alink = string.Empty;

                                pos = linkstr.IndexOf(';');
                                if (pos == -1)
                                {
                                    haslink = false;
                                    pos = linkstr.Length;
                                    alink = linkstr.Substring(0, pos);
                                }
                                else
                                {
                                    alink = linkstr.Substring(0, pos);
                                    linkstr = linkstr.Remove(0, pos + 1);
                                }
                                //string alink = linkstr.Substring(0, pos);
                                //linkstr = linkstr.Remove(0, pos + 1);
                                alink = alink.Trim(new char[]{' '});

                                pos = alink.Length;
                                string include = "F";
                                if (alink[pos - 1] == 'T' && alink[pos - 2] == '/')
                                {
                                    include = "T";
                                    alink = alink.Substring(0, pos - 2);
                                }
                                else if (alink[pos - 1] == 'F' && alink[pos - 2] == '/')
                                {
                                    include = "F";
                                    alink = alink.Substring(0, pos - 2);
                                }

                                //here no one parameter ructor of TDomain, how to do finding? Jun 28, 2008
                                TDomain Offset = DomainTable.FindFirst(new TDomain(alink));

                                if (Offset == null)
                                {
                                    HasErrors = true;
                                    Bogue.WriteLine(pQ.QID.ToString() + " has a bad link line: '"
                                       + pQ.Links[j].ToString() + "' unknow link: '" + alink + "'");
                                }
                                else
                                {
                                    //string dsn = (DomainTable)[Offset].GetPermanentSN();
                                    string dsn = Offset.PermanentSN;
                                    long msn = Offset.ModuleSN;

                                    //hlkfile.WriteLine(pQ.WSerialNumber.ToString() + ",'" + text + "',"
                                    //    + HLCount.ToString() + "," + "D" + "," + dsn.ToString() + ","
                                    //    + msn + "," + include);

                                    if (text.Length > 66)
                                    {
                                        text = text.Substring(0, 66);
                                    }

                                    hlkfile.WriteLine(pQ.WSerialNumber.ToString() + ",'" + text + "',"
                                            + HLCount.ToString() + "," + "'D'" + "," + dsn.ToString() + ","
                                            + msn + ",'" + include + "'");

                                }
                            }
                            HLCount++;
                        }

                    }
                    else
                    {
                        HasErrors = true;
                        Bogue.WriteLine(pQ.QID + " is missing the Windows serial number.");
                    }

                    // QUESTION.REM    QuestionSn, RFValue
                    qfile.Write(pS.PermanentSN + ",");
                    switch (pQ.RedFlagTrigger)
                    {
                        case 'Y': qfile.WriteLine("1");
                            break;

                        case 'N': qfile.WriteLine("2");
                            break;

                        default: qfile.WriteLine("0");
                            break;
                    }
                    //qfile.WriteLine();

                    qbfile.Write(pS.PermanentSN.ToString() + ",'" + Base + "','" + Note + "','"
                            + ListAnswer + "',");

                    // add the data type
                    if (pQ.SingleSelect)
                        qbfile.WriteLine("'S'");
                    else
                        if (pS.SymbolName[0] == 'M')
                            qbfile.WriteLine("'M'");
                        else
                            if (AnyList)
                                qbfile.WriteLine("'L'");
                            else
                                qbfile.WriteLine("'B'");
                    //qbfile.WriteLine();

                    // Look for non-messages which are not referenced and also don't have
                    // RFPotential.
                    if ((pS.SymbolName[0] != 'M') && (pQ.RedFlagTrigger == ' ') && !pS.IsReferenced)
                    {
                        HasErrors = true;
                        Bogue.WriteLine("Confused question ->" + pS.SymbolName);
                    }

                    // If there's a red flag trigger or it's a message(?) add it to QDLink
                    if ((pS.SymbolName[0] == 'M') || (pQ.RedFlagTrigger != ' ') ||
                        (pQ.SubQuestionSymbol.Length > 0))
                    {
                        UTIL.Assert(pQ.DomainSymbol != null, "Assertion Failed: pQ.DomainSymbol != null!");

                        (DomainTable.FindFirst(new TDomain(pQ.DomainSymbol.SymbolName))).IncQuestionCount();
                        QDFile.Write(pS.InternalSN + "," + pQ.DomainSymbol.PermanentSN + "," + pS.PermanentSN + ",");
                        if (pQ.SubQuestionSymbol.Length > 0)
                        {
                            SQCount++;
                            QDFile.Write(SQCount.ToString());

                            // Spew out the questions
                            long QDSeq = 1;
                            int _pos;
                            string ts = pQ.SubQuestionSymbol;
                            string piece;

                            while (ts.Length != 0)
                            {
                                if ((_pos = ts.IndexOf('|')) == -1)
                                {
                                    piece = ts;
                                    ts = string.Empty;
                                }
                                else
                                {
                                    piece = ts.Substring(0, _pos);
                                    ts = ts.Remove(0, _pos + 1);
                                }

                                //long SQDOffset = Meal.SymbolTable.FindFirst (&TSymbol (piece));
                                TSymbol SQDOffset = Meal.SymbolTable.FindFirst(new TSymbol(piece));

                                UTIL.Assert(SQDOffset != null, "Assertion Failed: SQDOffset != null!");
                                QSFile.WriteLine(SQCount.ToString() + "," + SQDOffset.PermanentSN.ToString() + ","
                                     + QDSeq.ToString() + "," + GlobalStructures.ModuleSN.ToString());
                                QDSeq++;
                            };


                        }
                        else
                        {
                            QDFile.Write("-1");
                        }

                        QDFile.WriteLine("," + GlobalStructures.ModuleSN.ToString());
                    }

                    // We don't need some of the question info, so get rid of it.
                    pQ.QText = string.Empty;
                }
            }

            qfile.Close();
            qbfile.Close();
            qsnfile.Close();
            hlkfile.Close();
            QDFile.Close();
            QSFile.Close();
            RQSFile.Close();

            if (HasErrors)
            {
                throw (new Exception("There were errors Generating Questions."));
            }
        }// throw (xmsg){}
        //  bool GenerateAnswers ( string OutputDirectory, StreamWriter& Bogue);

        private ParseResult Statement()
        {
            string CondVariable = string.Empty;
            TSymbol pS;

            //switch (TokenStream.Peek())
            switch (TokenStream.TokenType)
            {
                case TTokenType.tokIF:
                    {
                        // Skip past the if token.
                        TokenStream++;

                        bool SimpleExpression = (TokenStream.TokenType == TTokenType.tokRList);

                        // Generate the conditional expression.
                        if (Expression(ref CondVariable) == ParseResult.ParseFail)
                        {
                            return ParseResult.ParseFail;
                        }

                        switch (TokenStream.TokenType)    //.Peek()
                        {
                            case TTokenType.tokSET:
                                return SetStatement(CondVariable, SimpleExpression);
                            case TTokenType.tokCOMPLETE:
                                {
                                    // Skip past the complete token.
                                    TokenStream++;

                                    if (TokenStream.Peek() != TTokenType.tokDOMAIN)
                                    {
                                        TokenStream.SaveError("Unknown COMPLETE statement.");
                                        return ParseResult.ParseFail;
                                    }

                                    TokenStream++;
                                    if (TokenStream.Peek() != TTokenType.tokSymbol)
                                    {
                                        TokenStream.SaveError("Expecting variable name after DOMAIN");
                                        return ParseResult.ParseFail;
                                    }
                                    TSymbol pSymbol = LookupCurrentTokenSymbol();
                                    if (pSymbol == null)
                                    {
                                        StringBuilder msg = new StringBuilder();
                                        msg.Append("Can't find a definition for " + TokenStream.CurrentToken.TokenName
                                            + " in the domain file." + Environment.NewLine);
                                        TokenStream.SaveError(msg.ToString());
                                        return ParseResult.ParseFail;
                                    }
                                    else if (pSymbol.symbolType != SymbolType.SymDomain)
                                    {
                                        StringBuilder msg = new StringBuilder();
                                        msg.Append("You can't redefine " + TokenStream.CurrentToken.TokenName + ". ["
                                            + pSymbol.symbolType + ']' + Environment.NewLine);
                                        TokenStream.SaveError(msg.ToString());
                                        return ParseResult.ParseFail;
                                    }

                                    //*CSB     RuleList.Add (new TSetComplete (CurrentModuleSN, pSymbol.GetSymbolName(), CondVariable));
                                    return ParseResult.ParseOK;
                                }

                            default:
                                {
                                    StringBuilder a = new StringBuilder();
                                    a.Append("Unknown IF type." + Environment.NewLine);
                                    TokenStream.SaveError(a.ToString());
                                    return ParseResult.ParseFail;
                                }
                        }
                    }

                case TTokenType.tokFORMAT:
                    {
                        // Skip past the FORMAT token.
                        TokenStream++;

                        if (TokenStream.Peek() != TTokenType.tokLIST)
                        {
                            TokenStream.SaveError("Unknown format statement.");
                            return ParseResult.ParseFail;
                        }

                        // Mark this question as a single select
                        if (LastQuestion == string.Empty)
                        {
                            TokenStream.SaveError("There is no current question for this statement!");
                            return ParseResult.ParseFail;
                        }

                        TQData QOffset = Meal.FindFirstTQData(new TQData(LastQuestion));
                        UTIL.Assert(QOffset != null, "Assertion Failed: QOffset != null!");

                        QOffset.SingleSelect = true;

                        return ParseResult.ParseOK;
                    }

                case TTokenType.tokSUBQUESTION:
                    {
                       // look for question name. Set current subquestion on
                        TokenStream++;
                        if (TokenStream.TokenType != TTokenType.tokSymbol)
                        {
                            TokenStream.SaveError("Expecting a subquestion name.");
                            return ParseResult.ParseFail;
                        }

                        pS = LookupCurrentTokenSymbol();
                        if (pS == null)
                        {
                            try
                            {
                                pS = Meal.SymbolTable.AddSymbol(TokenStream.CurrentToken.TokenName,
                                        SymbolType.SymSubQuestion, TSymbol.Type.Referenced, CurrentModuleSN);  //
                            }
                            catch (Exception e)
                            {
                                TokenStream.SaveError(e.Message);
                                return ParseResult.ParseFail;
                            }
                        }
                        else
                        {
                            if (pS.symbolType != SymbolType.SymSubQuestion)
                            {
                                TokenStream.SaveError("Expecting a subquestion name.");
                                return ParseResult.ParseFail;
                            }
                            else
                            {
                                pS.State = TSymbol.Type.Referenced;
                            }
                        }
                        // We can only get here if we 'defined' the symbol. In this case, we want to generate
                        // a unique serial number for the subquestion domain.
                        TDomainSN DomainSN = new TDomainSN(m_sSNDir);
                        pS.PermanentSN = DomainSN.AllocateSN();

                        // Add link into domain table
                        LastSubQuestion = TokenStream.CurrentToken.TokenName;
                        DomainTable.AddSubQuestionDomain(LastSubQuestion, LastDomain, CurrentModuleSN);

                        TokenStream++;

                        if (InSubQuestion)
                        {
                            TokenStream.SaveError("Embedded SUBQUESTIONs are not allowed.");
                            return ParseResult.ParseFail;
                        }
                        else
                        {
                            InSubQuestion = true;
                        }

                        return ParseResult.ParseOK;
                    }

                case TTokenType.tokDOMAIN:
                    if (InSubQuestion)
                    {
                        TokenStream.SaveError("You can't change domains within a SUBQUESTION block.");
                        return ParseResult.ParseFail;
                    }

                    // look for domain name. Set the current domain on.
                    TokenStream++;
                    if (TokenStream.TokenType != TTokenType.tokSymbol)
                    {
                        TokenStream.SaveError("Expecting a domain name.");
                        return ParseResult.ParseFail;
                    }

                    if ((pS = LookupCurrentTokenSymbol()) == null)
                    {
                        TokenStream.SaveError("Domain not defined.");
                        return ParseResult.ParseFail;
                    }
                    else
                    {
                        if (pS.symbolType == SymbolType.SymDomain)
                        {
                            pS.State = TSymbol.Type.Defined;
                            LastDomain = pS.SymbolName;

                            // If the serial number and the module SN of this domain are the same, it is a module!
                            if (pS.PermanentSN == pS.ModuleSN)
                            {
                                CurrentModuleSN = pS.ModuleSN;
                            }
                        }
                        else
                        {
                            TokenStream.SaveError("Expecting a domain name.");
                            return ParseResult.ParseFail;
                        }
                    }

                    TokenStream++;
                    return ParseResult.ParseOK;

                case TTokenType.tokEND:
                    // if SubQuestion turn of sub question, else error.
                    TokenStream++;
                    if (TokenStream.Peek() == TTokenType.tokSUBQUESTION)
                    {
                        TokenStream++;
                        if (InSubQuestion)
                        {
                            InSubQuestion = false;
                            return ParseResult.ParseOK;
                        }
                        else
                        {
                            TokenStream.SaveError("END SUBQUESTION with no corresponding SUBQUESTION.");
                            return ParseResult.ParseFail;
                        }
                    }
                    else
                    {
                        TokenStream.SaveError("Expecting SUBQUESTION keyword.");
                        return ParseResult.ParseFail;
                    }

                default:
                    {
                        StringBuilder a = new StringBuilder();
                        a.Append("Unknown statement type." + Environment.NewLine);
                        TokenStream.SaveError(a.ToString());
                        return ParseResult.ParseFail;
                    }
            }
        }

        private TSymbol LookupCurrentTokenSymbol()
        {
            //long Offset;

            // See if the symbol can be found in the symbol table.
            TSymbol Offset = Meal.SymbolTable.FindFirst(new TSymbol(TokenStream.CurrentToken.TokenName));
            //return (Offset == -1) ? null : Meal.SymbolTable[Offset];
            return Offset;
        }
        private ParseResult SetStatement(string CondVariable, bool SubQuestionAllowed)
        {
            if (TokenStream.TokenType != TTokenType.tokSET)   //.Peek()
            {
                TokenStream.SaveError("Expecting a SET statement following an IF condition");
                TokenStream.Dump();
                return ParseResult.ParseFail;
            }

            do
            {
                TSymbol pSymbol;
                TokenStream++;

                switch (TokenStream.TokenType)
                {
                    case TTokenType.tokVARIABLE:
                        TokenStream++;
                        if (TokenStream.TokenType != TTokenType.tokSymbol)
                        {
                            TokenStream.SaveError("Expecting variable name after VARIABLE");
                            return ParseResult.ParseFail;
                        }
                        pSymbol = LookupCurrentTokenSymbol();
                        if (pSymbol == null)
                            Meal.SymbolTable.AddSymbol(TokenStream.CurrentToken.TokenName, SymbolType.SymNamedVariable, TSymbol.Type.Defined, CurrentModuleSN);
                        else if (pSymbol.GetSymbolType() == SymbolType.SymNamedVariable)
                            pSymbol.SetState(TSymbol.Type.Defined);
                        else
                        {
                            string msg;
                            msg = "You can't redefine " + TokenStream.CurrentToken.GetName() + "." + Environment.NewLine;// ends;
                            TokenStream.SaveError(msg);
                            return ParseResult.ParseFail;
                        }

                        RuleList.Add(new TSet(CurrentModuleSN, TokenStream.CurrentToken.TokenName, CondVariable));
                        break;

                    case TTokenType.tokDOMAIN:
                        TokenStream++;
                        if (TokenStream.TokenType != TTokenType.tokSymbol)
                        {
                            TokenStream.SaveError("Expecting variable name after DOMAIN");
                            return ParseResult.ParseFail;
                        }
                        pSymbol = LookupCurrentTokenSymbol();
                        if (pSymbol == null)
                        {
                            string msg;
                            msg = "Can't find a definition for " + TokenStream.CurrentToken.GetName()
                                + " in the domain file." + Environment.NewLine;// ends;
                            TokenStream.SaveError(msg);
                            return ParseResult.ParseFail;
                        }
                        else if (pSymbol.symbolType != SymbolType.SymDomain)
                        {
                            string msg;
                            msg = "You can't redefine " + TokenStream.CurrentToken.GetName() + ". ["
                                + pSymbol.GetSymbolType() + ']' + Environment.NewLine;// +ends;
                            TokenStream.SaveError(msg);
                            return ParseResult.ParseFail;
                        }

                        RuleList.Add(new TSet(CurrentModuleSN, pSymbol.SymbolName, CondVariable));
                        break;

                    case TTokenType.tokSUBQUESTION:
                        {
                            if (!SubQuestionAllowed)
                            {
                                TokenStream.SaveError("Complex conditions are not allowed in setting SUBQUESTIONs.");
                                return ParseResult.ParseFail;
                            }

                            TokenStream++;
                            if (TokenStream.Peek() != TTokenType.tokSymbol)
                            {
                                TokenStream.SaveError("Expecting subquestion name after SUBQUESTION.");
                                return ParseResult.ParseFail;
                            }
                            pSymbol = LookupCurrentTokenSymbol();
                            if (pSymbol == null)
                                Meal.SymbolTable.AddSymbol(TokenStream.CurrentToken.GetName(), SymbolType.SymSubQuestion, TSymbol.Type.Defined, CurrentModuleSN); //
                            else
                                if (pSymbol.GetSymbolType() == SymbolType.SymSubQuestion)
                                {
                                    pSymbol.SetState(TSymbol.Type.Referenced);

                                }
                                else
                                {
                                    string msg = "You can't redefine " + TokenStream.CurrentToken.GetName() + "." + Environment.NewLine;// ends;
                                    TokenStream.SaveError(msg);
                                    return ParseResult.ParseFail;
                                }

                            // Set the trigger question
                            TQData QOffset = Meal.FindFirstTQData(new TQData(LastQuestion));
                            UTIL.Assert(QOffset != null, "Assertion Failed: QOffset != null!");
                            if (QOffset.SubQuestionSymbol.Length == 0)
                                QOffset.SubQuestionSymbol = TokenStream.CurrentToken.GetName();
                            else
                                QOffset.SubQuestionSymbol += '|' + TokenStream.CurrentToken.GetName();

                            RuleList.Add(new TSet(CurrentModuleSN, TokenStream.CurrentToken.GetName(), CondVariable));
                            break;
                        }

                    default:
                        TokenStream.Dump();
                        TokenStream.SaveError("Confused question.");
                        //TokenStream.SaveError("Expecting a DOMAIN, VARIABLE, or SUBQUESTION statement.");
                        return ParseResult.ParseFail;
                }

                TokenStream++;

            } while (TokenStream.TokenType == TTokenType.tokComma);

            if (TokenStream.TokenType != TTokenType.OutOfTokens)
            {
                TokenStream.Dump();
                TokenStream.SaveError("Junk following SET statement");
                return ParseResult.ParseFail;
            }
            else
            {
                return ParseResult.ParseOK;
            }
        }
        private ParseResult Expression(ref string CondVariable)
        {
            return (Term(ref CondVariable) == ParseResult.ParseFail) ? ParseResult.ParseFail : CheckOrCondition(ref CondVariable);
        }
        private ParseResult CheckOrCondition(ref string CondVariable)
        {
            if ((TokenStream.TokenType == TTokenType.tokOR) || (TokenStream.TokenType == TTokenType.tokForcedOR))
            {
                string CondVariable2 = string.Empty;
                TTokenType OrType = TokenStream.Peek();

                TokenStream++;
                if (Term(ref CondVariable2) == ParseResult.ParseFail)
                {
                    return ParseResult.ParseFail;
                }
                else
                {
                    string NewCond = Meal.SymbolTable.GenerateVariable(CurrentModuleSN);
                    switch (OrType)
                    {
                        case TTokenType.tokOR:
                            RuleList.Add(new TOr(CurrentModuleSN, NewCond, CondVariable, CondVariable2));
                            break;

                        case TTokenType.tokForcedOR:
                            RuleList.Add(new TForcedOr(CurrentModuleSN, NewCond, CondVariable, CondVariable2));
                            break;
                    }
                    CondVariable = NewCond;
                    return CheckOrCondition(ref CondVariable);
                }
            }
            else
                return ParseResult.ParseOK;
        }
        private ParseResult Term(ref string CondVariable)
        {
           return (Factor(ref CondVariable) == ParseResult.ParseFail) ? ParseResult.ParseFail : CheckAndCondition(ref CondVariable);
        }
        private ParseResult CheckAndCondition(ref string CondVariable)
        {
            if (TokenStream.TokenType == TTokenType.tokAND)
            {
                string CondVariable2 = string.Empty;

                TokenStream++;
                if (Factor(ref CondVariable2) == ParseResult.ParseFail)
                {
                    return ParseResult.ParseFail;
                }
                else
                {
                    string NewCond = Meal.SymbolTable.GenerateVariable(CurrentModuleSN);
                    RuleList.Add(new TAnd(CurrentModuleSN, NewCond, CondVariable, CondVariable2));
                    CondVariable = NewCond;
                    return CheckAndCondition(ref CondVariable);
                }
            }
            else
                return ParseResult.ParseOK;
        }
        // Factor. This function handles parsing factors. This method takes the following
        // parameters:
        //
        //     CondVariable    string   (Returned) Condition set by this factor.
        //
        private ParseResult Factor(ref string CondVariable)
        {
            switch (TokenStream.TokenType)  //.Peek()
            {
                case TTokenType.tokSymbol:
                    {
                        TSymbol pS;
                        if ((pS = LookupCurrentTokenSymbol()) == null)
                        {
                            Meal.SymbolTable.AddSymbol(TokenStream.CurrentToken.GetName(), SymbolType.SymNamedVariable,
                                TSymbol.Type.Referenced, CurrentModuleSN);
                            CondVariable = TokenStream.CurrentToken.TokenName;//GetName();
                            TokenStream++;
                            return ParseResult.ParseOK;
                        }
                        else
                        {
                            pS.State = TSymbol.Type.Referenced;
                        }

                        if (pS.symbolType == SymbolType.SymQuestion)
                        {

                            // Now looking down stream for IS .
                            TokenStream++;
                            switch (TokenStream.TokenType)  //.Peek()
                            {

                                case TTokenType.tokIS:
                                    // Advance to the next TTokenType.token.
                                    TokenStream++;

                                    // Condition list should be next. (Note: This function sets SLabel and FLabel.
                                    return ConditionList(pS.SymbolName, ref CondVariable);

                                default:
                                    TokenStream.SaveError("Question ID must be followed by IS.");
                                    return ParseResult.ParseFail;

                            }
                        }
                        else
                        {
                            CondVariable = pS.SymbolName;
                            TokenStream++;
                            return ParseResult.ParseOK;
                        }

                    }

                case TTokenType.tokLeftParen:
                    // Nothing special has to be generated for parenthesis.  By the
                    // structure of the language, simply parsing for parenthesis
                    // causes evaluation to occur in the proper order.

                    // Advance to the next TTokenType.token.
                    TokenStream++;

                    // Now parse the expression condtion.
                    if (Expression(ref CondVariable) == ParseResult.ParseFail)
                    {
                        return ParseResult.ParseFail;
                    }
                    else
                    {
                        if (TokenStream.Peek() != TTokenType.tokRightParen)
                        {
                            TokenStream.SaveError("Missing right )");
                            return ParseResult.ParseFail;
                        }

                        // Toss away the closing parenthesis.
                        TokenStream++;
                        return ParseResult.ParseOK;
                    }

                case TTokenType.tokNOT:
                    // Advance to the next TTokenType.token.
                    TokenStream++;

                    // Grab a factor.
                    if (Factor(ref CondVariable) == ParseResult.ParseFail)
                    {
                        return ParseResult.ParseFail;
                    }
                    else
                    {
                        string NewCond = Meal.SymbolTable.GenerateVariable(CurrentModuleSN);
                        RuleList.Add(new TNot(CurrentModuleSN, NewCond, CondVariable));
                        CondVariable = NewCond;
                        return ParseResult.ParseOK;
                    }

                default:
                    {
                        // If none of the above are specified, we should have a condition list of the type
                        //  [YNP].  The nil value is passed for the symbol, which signfies that the condition
                        //  list applies to the current question.
                        if (LastQuestion == "")
                        {
                            TokenStream.SaveError("Tried to reference current question when there was none.");
                            return ParseResult.ParseFail;
                        }

                        TSymbol Offset = Meal.SymbolTable.FindFirst(new TSymbol(LastQuestion));

                        UTIL.Assert(Offset != null, "Assertion Failed: Offset != null!");
                        //Meal.SymbolTable[Offset].SetState (TSymbol::Referenced);
                        Offset.State = TSymbol.Type.Referenced;

                        return ConditionList(LastQuestion, ref  CondVariable);
                    }
            }
        }
        private ParseResult ConditionList(string QuestionID, ref string CondVariable)
        {
            // If the next TTokenType.token is not a response list, we have failed.
            //if (TokenStream.Peek() != TTokenType.tokRList)
            if (TokenStream.TokenType != TTokenType.tokRList)
            {
                TokenStream.SaveError("Missing Response List.");
                return ParseResult.ParseFail;
            }

            // Now retrieve the response list and extract it from the bounding brackets.
            string TStr = TokenStream.CurrentToken.TokenName;
            TStr = TStr.Substring(1, TStr.Length - 2);

            // Look for a number list first.
            if (TStr.IndexOfAny(new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' }) != -1)
            {
                // This is a number case.
                long Number = long.Parse(TStr);//);
                if (Number == 0)
                {
                    TokenStream.SaveError("Number response is in error.");
                    return ParseResult.ParseFail;
                }

                // Now generate the actual production.
                CondVariable = Meal.SymbolTable.GenerateVariable(CurrentModuleSN);
                RuleList.Add(new TIFENumber(CurrentModuleSN, CondVariable, QuestionID, Number));

            }
            else
            {
                if (UTIL.find_first_not_of(TStr, new char[] { 'Y', 'N', 'A' }) == -1)
                {
                    // Now generate the actual production.
                    CondVariable = Meal.SymbolTable.GenerateVariable(CurrentModuleSN);
                    RuleList.Add(new TIFEAnswer(CurrentModuleSN, CondVariable, QuestionID, TStr));
                }
                else
                {
                    // We have a real error.
                    TokenStream.SaveError("Matching response must be Y, N, A, or a number.");
                    return ParseResult.ParseFail;
                }
            }

            // Get the next TTokenType.token on the stream.
            TokenStream++;

            return ParseResult.ParseOK;
        }

        private void SpewStatement(StreamWriter swEfile, long LineNumber, ref string OutputLine)
        {
            string Extract;
            string OLCopy;
            int IClip;
            bool FirstLine = true;

            // Make a copy of the output line to fiddle with.
            OLCopy = OutputLine;

            while (OLCopy.Length > 0)
            {
                IClip = WrapOffset(OLCopy, 70);

                Extract = OLCopy.Substring(0, IClip);
                OLCopy = OLCopy.Remove(0, IClip);
                OLCopy = OLCopy.Trim(new char[]{' '});
                if (FirstLine)
                {
                    FirstLine = false;
                    swEfile.WriteLine("  " + LineNumber + " " + Extract);
                }
                else
                    swEfile.WriteLine("        " + Extract);
            }
        }

        // WrapOffset.  This function returns the position of the last character before a space for the
        //  specified width.   This function takes the following parameters:
        //
        //       TStr   string    (Passed) String to check.
        //       Width  int       (Passed) Clip width.
        //
        int WrapOffset(string TStr, int Width)
        {
            if (TStr.Length <= Width)
            {
                return TStr.Length;
            }
            else
            {
                if (Width > 0)
                {
                    for (int i = Width - 1; i >= 0; i--)
                    {
                        if (TStr[i] == ' ')
                            return i;
                    }
                    return Width;
                }
                else
                {
                    return 0;
                }
            }
        }

        private StreamWriter CreateStream(string OutputDirectory)
        {
            string ts = OutputDirectory;
            StreamWriter oFile = null;

            try
            {
                //oFile = new StreamWriter(ts);
                oFile = new StreamWriter(ts, false, Encoding.Default);
            }
            catch (Exception e)
            {
                throw (new Exception(e.Message + Environment.NewLine + "Could not create " + ts + "."));
            }

            return oFile;
        }
    }

}
