using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Diagnostics;
using NaturalNumericSort;

namespace RGTools_New
{

    class TQData
    {
        private string _QID;
        private string _Title;
        private string _QText;
        private string _SubQuestionSymbol;
        private string _WSerialNumber;
        private bool _SingleSelect;
        private TStrList _References;
        private TStrList _Links;
        private char _RedFlagTrigger;
        private TSymbol _DomainSymbol;

        public TQData(string pQID)
        {
            _QID = pQID;
            _Title = string.Empty;
            _QText = string.Empty;
            _RedFlagTrigger = ' ';
            _References = new TStrList(false);
           
            _Links = new TStrList(false);
            _DomainSymbol = null;
            _SubQuestionSymbol = (string.Empty);
            _WSerialNumber = (string.Empty);
            _SingleSelect = (false);

            RetiredQuestionSN = "";
        }

        public string RetiredQuestionSN { get; set; }
        public string QID
        {
            get
            {
                return _QID;
            }
            set
            {
                _QID = value;
            }
        }
        public string Title
        {
            get
            {
                return _Title;
            }
            set
            {
                _Title = value;
            }
        }
        public string QText
        {
            get
            {
                return _QText;
            }
            set
            {
                _QText = value;
            }
        }
        public string SubQuestionSymbol
        {
            get
            {
                return _SubQuestionSymbol;
            }
            set
            {
                _SubQuestionSymbol = value;
            }
        }
        public string WSerialNumber
        {
            get
            {
                return _WSerialNumber;
            }
            set
            {
                _WSerialNumber = value;
            }
        }

        public bool SingleSelect
        {
            get
            {
                return _SingleSelect;
            }
            set
            {
                _SingleSelect = value;
            }
        }
        public TStrList References
        {
            get
            {
                return _References;
            }
            set
            {
                _References = value;
            }
        }
        public TStrList Links
        {
            get
            {
                return _Links;
            }
            set
            {
                _Links = value;
            }
        }
        public char RedFlagTrigger
        {
            get
            {
                return _RedFlagTrigger;
            }
            set
            {
                _RedFlagTrigger = value;
            }
        }
        public TSymbol DomainSymbol
        {
            get
            {
                return _DomainSymbol;
            }
            set
            {
                _DomainSymbol = value;
            }
        }

        public static bool operator ==(TQData data1, TQData data2)
        {
            if (IsNull(data1) && IsNull(data2))
            {
                return true;
            }
            else if (IsNull(data1) || IsNull(data2))
            {
                return false;
            }
            else
            {
                return data1.QID == data2.QID ? true : false;
            }
        }
        //public static bool operator <(TQData data1, TQData data2)
        //{ return data1.QID < data2.QID ? true : false; }
        public static bool operator !=(TQData data1, TQData data2)
        {
            if (IsNull(data1) && IsNull(data2))
            {
                return false;
            }
            else if (IsNull(data1) || IsNull(data2))
            {
                return true;
            }
            else
            {
                return data1.QID != data2.QID ? true : false;
            }
        }
        //public static bool operator >(TQData data1, TQData data2)
        //{ return data1.QID > data2.QID ? true : false; }
        public static bool IsNull(TQData data)
        {
            return TQData.Equals(data, null);
        }
        public override bool Equals(object data)
        {
            if (IsNull(data as TQData))
            {
                return false;
            }
            else
            {
                return this.QID == (data as TQData).QID ? true : false;
            }
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }

    class TRuleStatement
    {
        public string Line;              // Text of input line.
        public long InputLineNumber;  // What line of the input file was this grabbed from? //
        public enum RuleClassType { Rule, QuestionID }
        public RuleClassType Class;

        public TRuleStatement(string pLine, long pInputLineNumber, RuleClassType pClass)
        {
            Line = pLine;
            InputLineNumber = pInputLineNumber;
            Class = pClass;
        } // ructor

        public static bool operator ==(TRuleStatement statement1, TRuleStatement statement2)
        {
            if (IsNull(statement1) && IsNull(statement2))
            {
                return true;
            }
            else if (IsNull(statement1) || IsNull(statement2))
            {
                return false;
            }
            else
            {
                return statement1.Line == statement2.Line ? true : false;
            }
        }
        public static bool operator !=(TRuleStatement statement1, TRuleStatement statement2)
        {
            if (IsNull(statement1) && IsNull(statement2))
            {
                return false;
            }
            else if (IsNull(statement1) || IsNull(statement2))
            {
                return true;
            }
            else
            {
                return statement1.Line != statement2.Line ? true : false;
            }
        }
        public static bool IsNull(TRuleStatement statement)
        {
            return TRuleStatement.Equals(statement, null);
        }

        public override bool Equals(object statement)
        {
            if (IsNull(statement as TRuleStatement))
            {
                return false;
            }
            else
            {
                return this.Line == (statement as TRuleStatement).Line ? true : false;
            }
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

    }

    class TParserFood
    {
        public List<TRuleStatement> RuleList = new List<TRuleStatement>();   // Collection of rules to be parsed.
        public TSymbolTable SymbolTable = new TSymbolTable();  // Symbol table
        public List<TQData> QuestionList = new List<TQData>(); // List of question data

        public TParserFood() // ructor
        {
        }
        // Init.  Create a new meal for the parser.  This function fails if it can't open the
        //  Question Document.
        public void Load(string InputPath)
        {
            TSymbol pCurrentSymbol = null;
            string InputLine;       // Input line.
            long LineCount = 0;              // Count of the number of input lines.
            //char iline[200];
            TQData pQ = null;
            string CurrentBlock = string.Empty;
            bool LastLineBlank = false;
            long ParagraphCount = 0;

            // Used to monitor we have the right numbers of K, # or F Lines between two E Lines.
            bool KLine = false;
            bool SLine = false;
            bool FLine = false;
            bool GLine = false;

            string errMsg = "";

            // First try to open the input and output files.
            string QInputName = InputPath + @"\QUESTION.TXT";
            StreamReader QIFile = null;
            try
            {
                QIFile = new StreamReader(QInputName, Encoding.Default);
            }
            catch
            {
                throw (new Exception("Could not open " + QInputName + "."));
            }
            // Loop through the input questions file, adding questions and associated flow to the data
            //  structure, while building the symbol table.  Additionally, copy the question document
            //  stripped of flow to an output file.

            //while (QIFile.getline(iline,200)) 
            while ((InputLine = QIFile.ReadLine()) != null)
            {
                // Read in a line from the input file and increment the counter.
                //InputLine = iline;
                LineCount++;               

                if ((InputLine.Length == 0) || (InputLine[0] == ' '))
                {
                    // special question text processing.
                    if (pQ == null) continue;

                    // is it a blank line?
                    int Offset =UTIL.find_first_not_of(InputLine,new char[]{' '});
                    if (Offset == -1)
                    {
                        // blank
                        if (LastLineBlank) continue;

                        CurrentBlock = SUTIL.PrepareASCIIString(SUTIL.CompressSpaces(CurrentBlock));
                        switch (ParagraphCount)
                        {
                            case 0:
                                break;

                            case 1:
                                Offset = UTIL.BackScan(CurrentBlock);
                                if (Offset != -1)
                                {
                                    CurrentBlock=CurrentBlock.Remove(0, Offset + 1);
                                    CurrentBlock = CurrentBlock.Trim(new char[]{' '}); ;
                                }
                                pQ.Title = CurrentBlock;
                                break;

                            case 2:
                                pQ.QText = CurrentBlock;
                                break;

                            default:
                                pQ.QText += "\\n\\n" + CurrentBlock;
                                break;
                        }
                        CurrentBlock = "";
                        ParagraphCount++;
                        LastLineBlank = true;
                    }
                    else
                    {
                        // Check to see if the inputline status with DOMAIN, SUBQUESTION, or END. If
                        // it does, it is in error as these specific cases are now disallowed. If they
                        // occur, they are invariably caused by missing @.
                        //string Play = (InputLine=InputLine.Trim(new char[]{' '}));
                        string Play = (InputLine.Trim(new char[]{' '}));
                        int iBlank;
                        if ((iBlank = Play.IndexOf(' ')) != -1)
                        {
                            Play=Play.Remove(iBlank);
                        }

                        if ((Play == "END") || (Play == "DOMAIN") || (Play == "SUBQUESTION"))
                        {
                            string ts = "Error: END/DOMAIN/SUBQUESTION not allowed at start of question text. See Line " +
                                     LineCount.ToString() + "." + Environment.NewLine;

                            //string ts (sTemp.str());
                            //delete [] sTemp.str();
                            throw (new Exception(ts));
                        }

                        // not blank
                        CurrentBlock += " " + InputLine;
                        LastLineBlank = false;
                    }
                    continue;
                }
                else if ((ParagraphCount > 1) && (pQ != null) && !LastLineBlank && (CurrentBlock.Length > 0))
                {
                    CurrentBlock =SUTIL.PrepareASCIIString(SUTIL.CompressSpaces(CurrentBlock));
                    switch (ParagraphCount)
                    {
                        case 2:
                            pQ.QText = CurrentBlock;
                            break;

                        default:
                            pQ.QText += "\\n\\n" + CurrentBlock;
                            break;
                    }
                    CurrentBlock = "";
                }

                switch (InputLine[0])
                {

                    case 'K':
                        {            // Start a new question.

                            if (InputLine.Substring(1, 1) != " ")
                            {
                                //throw (new Exception("Wrong KLink format at line " + LineCount.ToString() + " in " + QInputName));
                                errMsg += "Wrong KLink format at line " + LineCount.ToString() + " in " + QInputName + Environment.NewLine;
                                continue;
                            }

                            // Check unique KLine.
                            if (KLine)
                            {
                                //throw (new Exception("Duplicate KLine at line " + LineCount.ToString() + " in " + QInputName));
                                errMsg += "Duplicate KLine at line " + LineCount.ToString() + " in " + QInputName + Environment.NewLine;
                                continue;
                            }

                            KLine = true;

                            // Calculate what the key value is.
                            string SymbolName = InputLine.Substring(1);
                            SymbolName = SymbolName.Trim(new char[]{' '});

                            // Reset text block tools
                            CurrentBlock = "";
                            LastLineBlank = false;
                            ParagraphCount = 0;

                            // Eliminate junk questions
                            if ((SymbolName == "FACILITY") || (SymbolName == "MATERIALS") || (SymbolName == "NO_AUDIT") ||
                            (SymbolName == "END_AUDIT") || (SymbolName == "GENERATE") || (InputLine.IndexOf("ZZZZ") != -1) ||
                            (InputLine.IndexOf("zzzz") != -1) || (SymbolName[0] == 'N'))
                            {
                                //throw (new Exception("Can't Process. Old format QUESTION.TXT."));
                                errMsg += "Can't Process. Old format QUESTION.TXT." + Environment.NewLine;
                                continue;
                            }

                            // Allocate a new flow element and insert it into the flow list.
                            RuleList.Add(new TRuleStatement(SymbolName, LineCount, TRuleStatement.RuleClassType.QuestionID));

                            // Insert this symbol into the symbol table.
                            pCurrentSymbol = SymbolTable.AddSymbol(SymbolName, SymbolType.SymQuestion, TSymbol.Type.Defined, 0);

                            pQ = new TQData(SymbolName);
                            QuestionList.Add(pQ);

                            //SortTQData();
                            break;
                        }
                    case 'G':
                        {
                            if (InputLine.Substring(1, 1) != " ")
                            {
                                errMsg += "Wrong G Line format at line " + LineCount.ToString() + " in " + QInputName + Environment.NewLine;
                                continue;
                            }

                            // Check unique G Line.
                            if (GLine)
                            {
                                errMsg += "Duplicate G Line at line " + LineCount.ToString() + " in " + QInputName + Environment.NewLine;
                                continue;
                            }
                            GLine = true;

                            if (pQ == null) continue;
                            InputLine = InputLine.Remove(0, 2);
                            InputLine = InputLine.Trim(new char[] { ' ' }); ;
                            pQ.RetiredQuestionSN = InputLine;
                            if (pCurrentSymbol != null)
                                try
                                {
                                    pCurrentSymbol.RetiredQuestionSN = InputLine;
                                }
                                catch (Exception e)
                                {
                                    //throw new Exception(e.Message + " Input line: " + InputLine + " on Line " + LineCount + " in Question.txt");
                                    errMsg += e.Message + " Input line: " + InputLine + " on Line " + LineCount + " in Question.txt" + Environment.NewLine;
                                    continue;
                                }

                            break;
                        }
                    case '@':
                        {            
                            // General statement.
                            if (InputLine[1] != ' ')
                            {
                                //throw (new Exception("Wrong @Line format at line " + LineCount.ToString() + " in " + QInputName));
                                errMsg += "Wrong @Line format at line " + LineCount.ToString() + " in " + QInputName + Environment.NewLine;
                                continue;
                            }

                            // Add to the command table of the current flow statement.
                            string InputString = InputLine.Substring(1);
                            InputString = InputString.Trim(new char[]{' '}); ;

                            // If this is a @DOS statement, set marker and continue.
                            if (InputString == "DOS")
                            {
                                //throw (new Exception("Can't Process. Old format QUESTION.TXT."));
                                errMsg += "Can't Process. Old format QUESTION.TXT." + Environment.NewLine;
                                continue;
                            }
                            // Look for continuation lines.
                            if (InputString.Substring(InputString.Length - 1, 1) == "!")
                            {
                                // Trim off end point and init the string.
                                InputString=InputString.Remove(InputString.Length - 1);

                                // Keep getting subsequent lines and append them to the input line.
                                //while (QIFile.getline(iline,200)) 
                                while ((InputLine = QIFile.ReadLine()) != null)
                                {
                                    //InputLine = iline;
                                    LineCount++;
                                    InputLine = InputLine.Trim(new char[]{' '});

                                    if (InputLine.Length == 0) break;

                                    if (InputLine.Substring(InputLine.Length - 1, 1) == "!")
                                    {
                                        InputLine=InputLine.Remove(InputLine.Length - 1);
                                        InputString = InputString + ' ' + InputLine;
                                    }
                                    else
                                    {
                                        InputString = InputString + ' ' + InputLine;
                                        break;
                                    }
                                }
                            }

                            RuleList.Add(new TRuleStatement(InputString, LineCount, TRuleStatement.RuleClassType.Rule));
                            break;
                        }
                    case 'X':
                    case 'R':
                        {            // Reference determination.

                            if (InputLine.Substring(1, 1) != " ")
                            {
                                //throw (new Exception("Wrong RLine format at line " + LineCount.ToString() + " in " + QInputName));
                                errMsg += "Wrong RLine format at line " + LineCount.ToString() + " in " + QInputName + Environment.NewLine;
                                continue;
                            }

                            if (pQ == null) continue;

                            int Offset = InputLine.IndexOf(' ');

                            if (Offset == -1) continue;

                            InputLine=InputLine.Remove(0, Offset + 1);
                            InputLine = InputLine.Trim(new char[]{' '}); ;
                            pQ.References.Add(InputLine);
                            break;
                        }


                    case 'L':
                        {            // Link determination.

                            if (InputLine.Substring(1, 1) != " ")
                            {
                                //throw (new Exception("Wrong LLine format at line " + LineCount.ToString() + " in " + QInputName));
                                errMsg += "Wrong LLine format at line " + LineCount.ToString() + " in " + QInputName + Environment.NewLine;
                                continue;
                            }

                            if (pQ == null) continue;
                            int Offset = InputLine.IndexOf(' ');
                            if (Offset == -1) continue;
                            InputLine=InputLine.Remove(0, Offset + 1);
                            InputLine = InputLine.Trim(new char[]{' '}); ;
                            pQ.Links.Add(InputLine);
                            break;
                        }

                    case '#':
                        {            // Serial Number determination

                            if (InputLine.Substring(1, 1) != " ")
                            {
                                //throw (new Exception("Wrong #Line format at line " + LineCount.ToString() + " in " + QInputName));
                                errMsg += "Wrong #Line format at line " + LineCount.ToString() + " in " + QInputName + Environment.NewLine;
                                continue;
                            }

                            // Check unique #Line.
                            if (SLine)
                            {
                                //throw (new Exception("Duplicate #Line at line " + LineCount.ToString() + " in " + QInputName));
                                errMsg += "Duplicate #Line at line " + LineCount.ToString() + " in " + QInputName + Environment.NewLine;
                                continue;
                            }
                            SLine = true;

                            if (pQ == null) continue;
                            InputLine=InputLine.Remove(0, 2);
                            InputLine = InputLine.Trim(new char[]{' '}); ;
                            pQ.WSerialNumber = InputLine;
                            if (pCurrentSymbol!=null)
                                try
                                {
                                    pCurrentSymbol.PermanentSN = long.Parse(InputLine);
                                }
                                catch (Exception e)
                                {
                                    //throw new Exception(e.Message + " Input line: " + InputLine + " on Line " + LineCount + " in Question.txt");
                                    errMsg += e.Message + " Input line: " + InputLine + " on Line " + LineCount + " in Question.txt" + Environment.NewLine;
                                    continue;
                                }
                            break;
                        }

                    case 'F':
                        {            // Red flag determination.

                            if (InputLine.Substring(1, 1) != " ")
                            {
                                //throw (new Exception("Wrong FLine format at line " + LineCount.ToString() + " in " + QInputName));
                                errMsg += "Wrong FLine format at line " + LineCount.ToString() + " in " + QInputName + Environment.NewLine;
                                continue;
                            }

                            // Check unique FLine.
                            if (FLine)
                            {
                                //throw (new Exception("Duplicate FLine at line " + LineCount.ToString() + " in " + QInputName));
                                errMsg += "Duplicate FLine at line " + LineCount.ToString() + " in " + QInputName + Environment.NewLine;
                                continue;
                            }

                            FLine = true;

                            if (pQ == null) continue;

                            InputLine=InputLine.Remove(0, 1);
                            InputLine = InputLine.Trim(new char[]{' '}); ;
                            UTIL.Assert(InputLine.Length > 0, "InputLine.Length > 0!");

                            pQ.RedFlagTrigger = InputLine[0];
                            break;
                        }

                    case 'E':
                        {            // End of question.

                            if (InputLine.Length > 1 && InputLine.Substring(1, 1) != " ")
                            {
                                //throw (new Exception("Wrong ELine format at line " + LineCount.ToString() + " in " + QInputName));

                                errMsg += "Duplicate FLine at line " + LineCount.ToString() + " in " + QInputName + Environment.NewLine;                               
                            }

                            // Check we got a KLine and a #Line.
                            if (KLine == false)
                            {
                                //throw (new Exception("Missing KLine at line " + LineCount.ToString() + " in " + QInputName));
                                errMsg += "Missing KLine at line " + LineCount.ToString() + " in " + QInputName + Environment.NewLine;
                                                          }
                            if (SLine == false)
                            {
                                //throw (new Exception("Missing #Line at line " + LineCount.ToString() + " in " + QInputName));
                                errMsg += "Missing #Line at line " + LineCount.ToString() + " in " + QInputName + Environment.NewLine;
                            }

                            KLine = false;
                            SLine = false;
                            FLine = false;
                            GLine = false;

                            pQ = null;
                            break;
                        } 

                    default: break;
                }

            }

            // Close the question file.
            QIFile.Close();
            SortTQData();
            SymbolTable.SortSymbol();

            if (errMsg != "")
            {
                throw (new Exception(errMsg));
            }
        }// throw (xmsg);

        public void Dump(string OutputFileName) 
        {
            StreamWriter Ofile=null;

            // Open the output file.
            //Ofile.open(OutputFileName);
            try
            {
                //Ofile = new StreamWriter(OutputFileName);
                Ofile = new StreamWriter(OutputFileName, false, Encoding.Default);
            }
            catch
            {
                throw (new Exception("Could not create " + OutputFileName + "."));
            }
            // Now dump the symbol table.
            Ofile.WriteLine();
            Ofile.WriteLine("Symbol Table");//  );

            for (int i = 0; i < SymbolTable.Count; i++)
            {
                TSymbol Symbol = SymbolTable[i];
                Ofile.Write("<" + Symbol.SymbolName.ToString() + "> ");
                switch (Symbol.symbolType)
                {
                    case SymbolType.SymDomain:
                        Ofile.WriteLine("Domain       "  );
                        break;

                    case SymbolType.SymSubQuestion:
                        Ofile.WriteLine("SubQuestion  "  );
                        break;

                    case SymbolType.SymNamedVariable:
                        Ofile.WriteLine("NVariable    "  );
                        break;

                    case SymbolType.SymInternalVariable:
                        Ofile.WriteLine("IVariable    "  );
                        break;

                    case SymbolType.SymQuestion:
                        Ofile.WriteLine("Question     "  );
                        break;

                    default:
                        break;
                }
            }

            // First, output the parser food. 
            Ofile.WriteLine();
            Ofile.WriteLine("Statements");
            for (int i = 0; i < RuleList.Count; i++)
            {
                Ofile.Write(" " + RuleList[i]  );
            }

            // Close the output file.
            Ofile.Close();
        }// throw (xmsg);

        private static TQData _data = null;
        private static bool matchData(TQData data)
        {
            if (data.QID == _data.QID)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public TQData FindFirstTQData(TQData data)
        {
            _data = data;

            return QuestionList.Find(matchData);
        }

        private static int CompareTQData(TQData data1, TQData data2)
        {            
            if (data1 == null)
            {
                if (data2 == null)
                {
                    // If x is null and y is null, they're
                    // equal. 
                    return 0;
                }
                else
                {
                    // If x is null and y is not null, y
                    // is greater. 
                    return -1;
                }
            }
            else
            {
                // If x is not null...
                //
                if (data2 == null)
                // ...and y is null, x is greater.
                {
                    return 1;
                }
                else
                {

                    //return UTIL.CmpareString(data1.QID, data2.QID);
                    //return string.Compare(data1.QID, data2.QID, StringComparison.Ordinal);
                    return StringLogicalComparer.Compare(data1.QID, data2.QID);
                }
            }
        }
        internal void SortTQData()
        {
            QuestionList.Sort(CompareTQData);
        }
    }
}
