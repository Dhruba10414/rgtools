﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace RGTools_New
{
    public class DoubleBufferedTableLayout : TableLayoutPanel
    {
        public DoubleBufferedTableLayout()
        {
            // this.DoubleBuffered = true;

            // or

            SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
            UpdateStyles();
        }
    }
}
