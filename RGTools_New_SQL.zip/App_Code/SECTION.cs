using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Diagnostics;
using NaturalNumericSort;
using System.Xml;
using System.Data;
using System.Data.SqlClient;

namespace RGTools_New
{
    class TSectionOffset
    {
        //friend class TSection;

        private long m_Offset;
        private TSection m_Section;

        public TSectionOffset(TSection pSection, long pOffset)  // Can only be invoked by TSection
        {
            m_Offset = pOffset;
            m_Section = pSection;
        }

        public TSectionOffset(TSection pSection)  // Can only be invoked by TSection
        {
            m_Offset = 0;
            m_Section = pSection;
        }

        public void SetOffset(long pOffset) { m_Offset = pOffset; }
        public long GetOffset() { return m_Offset; }
        public long Offset
        {
            get
            {
                return m_Offset;
            }
            set
            {
                m_Offset = value;
            }
        }
        public TSection GetSection() { return m_Section; }
        public TSection Section
        {
            get
            { return m_Section; }
        }

        public static bool operator ==(TSectionOffset section1, TSectionOffset section2)
        {
            if (IsNull(section1) && IsNull(section2))
            {
                return true;
            }
            else if (IsNull(section1) || IsNull(section2))
            {
                return false;
            }
            else
            {
                return (section1.m_Offset == section2.m_Offset) ? true : false;
            }
        }
        public static bool operator !=(TSectionOffset section1, TSectionOffset section2)
        {
            if (IsNull(section1) && IsNull(section2))
            {
                return false;
            }
            else if (IsNull(section1) || IsNull(section2))
            {
                return true;
            }
            else
            {
                return (section1.m_Offset != section2.m_Offset) ? true : false;
            }
        }
        public static bool IsNull(TSectionOffset section)
        {
            return TSectionOffset.Equals(section, null);
        }
        public override bool Equals(object offset)
        {
            if (IsNull(offset as TSectionOffset))
            {
                return false;
            }
            else
            {
                return this.m_Offset == (offset as TSectionOffset).m_Offset ? true : false;
            }
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }

    class TSection : TTextBlock
    {
        private long m_SectionID;
        string m_Title;
        List<TSectionOffset> m_OffsetMap = new List<TSectionOffset>();//=new LinkedList<TSectionOffset>();
        bool m_Continued;
        TSectionList m_SectionList;

        public TSection(TSectionList pSectionList, string pTitle)
        {
            m_SectionList = pSectionList;
            m_Title = pTitle;
            m_Continued = false;
            m_SectionID = 0;
        }

        public void SetSectionID(long pSectionID) 
        { 
            m_SectionID = pSectionID;
        }
        public long GetSectionID() { return m_SectionID; }
        public long SectionID
        {
            set
            { 
                m_SectionID = value;
            }
            get
            {
                return m_SectionID;
            }
        }

        public void SetTitle(string pTitle) { m_Title = pTitle; }
        public string GetTitle() { return m_Title; }
        public string Title
        {
            get
            {
                return m_Title;
            }
            set
            {
                m_Title = value;
            }
        }
        public void SetContinued() { m_Continued = true; }
        public bool IsContinued() { return m_Continued; }
        public bool Continued
        {
            get
            {
                return m_Continued;
            }
            set
            {
                m_Continued = value;
            }
        }
        public long GetGroupLatestDate()
        {
            if (IsContinued())
            {

                // Look up this section, assert if none found.
                int nOffset;
                for (nOffset = 0; nOffset < m_SectionList.Count; nOffset++)
                {
                    if (this == m_SectionList[nOffset])
                        break;
                }
                UTIL.Assert(nOffset < m_SectionList.Count, "Assertion Failed: nOffset < m_SectionList.Count!");

                long NewestDate = 0;
                for (; nOffset < m_SectionList.Count; nOffset++)
                {
                    TSection pSection = m_SectionList[nOffset];
                    if (pSection.GetLatestDate() > NewestDate)
                        NewestDate = pSection.LatestDate;
                    if (!pSection.IsContinued()) break;

                }
                return NewestDate;
            }
            else
                return GetLatestDate();
        }

        public TSectionOffset CreateSectionOffset()
        {
            TSectionOffset pSectionOffset = new TSectionOffset(this, GetParagraphCount());
            UTIL.Assert(pSectionOffset != null, "Assertion Failed: pSectionOffset != null!");
            return pSectionOffset;
        }

        public static bool operator ==(TSection section1, TSection section2)
        {
            if (IsNull(section1) && IsNull(section2))
            {
                return true;
            }
            else if (IsNull(section1) || IsNull(section2))
            {
                return false;
            }
            else
            {
                return (section1.m_SectionID == section2.m_SectionID) ? true : false;
            }
        }
        public static bool operator !=(TSection section1, TSection section2)
        {
            if (IsNull(section1) && IsNull(section2))
            {
                return false;
            }
            else if (IsNull(section1) || IsNull(section2))
            {
                return true;
            }
            else
            {
                return (section1.m_SectionID != section2.m_SectionID) ? true : false;
            }
        }
        public static bool IsNull(TSection section)
        {
            return TSection.Equals(section, null);
        }
        public override bool Equals(object section)
        {
            if (IsNull(section as TSection))
            {
                return false;
            }
            else
            {
                return this.m_SectionID == (section as TSection).m_SectionID ? true : false;
            }
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

    }

    class TSectionList : List<TSection>
    {
        frmMain _main = null;

        public frmMain MainForm
        {
            set
            {
                _main = value;
            }
        }

        private TSection m_LastSectionCreated;

        public TSectionList()
        {
            m_LastSectionCreated = null;
        }

        public TSection CreateSection(string pTitle, int pPosition)
        {
            if (base.Count > 0)
            {
                GetCurrentSection().SetDate(0);
            }

            m_LastSectionCreated = new TSection(this, pTitle);
            UTIL.Assert(m_LastSectionCreated != null, "Assertion Failed: m_LastSectionCreated != null!");
            if (pPosition < 0)
                Add(m_LastSectionCreated);
            else
            {
                Insert(pPosition, m_LastSectionCreated);
            }

            return m_LastSectionCreated;
        }
        public TSection CreateSection(string pTitle)
        {
            return CreateSection(pTitle, -1);
        }
        public TSection CreateSection()
        {
            return CreateSection(string.Empty, -1);
        }

        public void SequenceSections()
        {
            long SectionID = GlobalStructures.GetModuleSN();

            //SortTSection();
            for (int i = 0; i < base.Count; i++)
            {
                base[i].SectionID = SectionID + i;
            }


        }

        public TSection GetCurrentSection()
        { return m_LastSectionCreated; }

        public void GenerateSQL(string PathName, RGKeywordList rKeywordList)
        {
            string ts = PathName + "\\RGSECT.REM";

            FileStream oFile;
            try
            {
                oFile = new FileStream(ts, FileMode.Create, FileAccess.Write);
            }
            catch//(Exception e)
            {
                throw (new Exception("Could not open " + ts));
            }

            byte[] buffer = null;
            string strData = string.Empty;

            for (int i = 0; i < base.Count; i++)
            {
                TSection pSection = base[i];

                // Structure of the output file is:
                // ModuleSN, SectionSN, Sequence, Heading, TextBlock, TagDateBlock (date/start/length)*


                //oFile.Write(GlobalStructures.ModuleSN.ToString() + ",");
                strData = GlobalStructures.ModuleSN.ToString() + ",";
                buffer = Encoding.Default.GetBytes(strData);
                oFile.Write(buffer, 0, strData.Length);

                //oFile.Write(pSection.SectionID.ToString() + ",");
                strData = pSection.SectionID.ToString() + ",";
                buffer = Encoding.Default.GetBytes(strData);
                oFile.Write(buffer, 0, strData.Length);

                //oFile.Write(i + ",'");
                strData = i + ",'";
                buffer = Encoding.Default.GetBytes(strData);
                oFile.Write(buffer, 0, strData.Length);

                ////oFile.Write(SUTIL.PrepareASCIIString(pSection.Title) + "',");
                //strData = SUTIL.PrepareASCIIString(pSection.Title) + "',";
                //buffer = Encoding.Default.GetBytes(strData);
                //oFile.Write(SUTIL.PrepareASCIIString(pSection.Title) + "',");
                string heading = SUTIL.PrepareASCIIString(pSection.Title);
                if (heading.Length > 120)
                {
                    heading = heading.Substring(0, 120);
                }
                strData = heading + "',";
                buffer = Encoding.Default.GetBytes(strData);

                oFile.Write(buffer, 0, strData.Length);

                // Now the text block
                //oFile.Write("'" + SUTIL.PrepareASCIIString(pSection.Text) + "',");
                strData = "'" + SUTIL.PrepareASCIIString(pSection.Text) + "',";
                buffer = Encoding.Default.GetBytes(strData);
                oFile.Write(buffer, 0, strData.Length);


                // Now the change map
                TChangeList changeList = pSection.ChangeList;
                StringBuilder sb = new StringBuilder();
                sb.Append("'");
                foreach (TChange change in changeList)
                {
                    byte[] bVal = IntToArray(change.Date);
                    for (int _i = 0; _i < bVal.Length; _i++)
                    {
                        sb.Append(@"\x");
                        sb.Append(CVTHEX.ByteToHex(bVal[_i]));
                    }
                    bVal = IntToArray(change.Offset);
                    for (int _i = 0; _i < bVal.Length; _i++)
                    {
                        sb.Append(@"\x");
                        sb.Append(CVTHEX.ByteToHex(bVal[_i]));
                    }
                    bVal = IntToArray(change.Length);
                    for (int _i = 0; _i < bVal.Length; _i++)
                    {
                        sb.Append(@"\x");
                        sb.Append(CVTHEX.ByteToHex(bVal[_i]));
                    }
                }

                sb.Append("'" + Environment.NewLine);
                buffer = Encoding.Default.GetBytes(sb.ToString());
                oFile.Write(buffer, 0, sb.Length);

            }

            oFile.Close();

            long[] asn ={11570,
                    21156,
                    33778,
                    50552,
                    60532,
                    70636,
                    81870,
                    100422,
                    120332,
                    142862,
                    160514,
                    191854,
                    222562};
            //foreach (long sn in asn)
            //{
            //    if (sn == GlobalStructures.ModuleSN)
            //    {

            //        GenerateSQLHTMLToDB(rKeywordList);
            //    }
            //}

            if (_main != null && _main.BuildForIphone)
            {
                foreach (ModuleListItem moduleItem in _main.selPhoneModules)
                {
                    if ((long)moduleItem.ModuleSN == GlobalStructures.ModuleSN)
                    {
                        GenerateSQLHTMLToDB1(rKeywordList);
                    }
                }
            }
        }

        private byte[] IntToArray(int iVal)
        {

            byte[] b = new byte[4];
            b[0] = (byte)(iVal);
            iVal >>= 8;
            b[1] = (byte)(iVal);
            iVal >>= 8;
            b[2] = (byte)(iVal);
            iVal >>= 8;
            b[3] = (byte)(iVal);

            return b;
        }

        public TSection SplitSection(TSection pSection)
        {
            UTIL.Assert(pSection != null, "Assertion Failed: pSection != null!");

            // Look up section, assert if none found.
            int nOffset = -1;
            for (int i = base.Count-1; i >=0; i--)
            {
                if (pSection.Title == base[i].Title)
                {
                    nOffset = i;
                    break;
                }
            }

            UTIL.Assert(nOffset < base.Count, "Assertion Failed: TOffset != null!");
            pSection.SetContinued();
            return CreateSection(pSection.GetTitle(), nOffset + 1);
        }

        private static int CompareTKey(TSection section1, TSection section2)
        {
            if (section1 == null)
            {
                if (section2 == null)
                {
                    return 0;
                }
                else
                {
                    return -1;
                }
            }
            else
            {
                if (section2 == null)
                {
                    return 1;
                }
                else
                {
                    return StringLogicalComparer.Compare(section1.Title, section2.Title);
                }
            }
        }
        internal void SortTSection()
        {
            base.Sort(CompareTKey);
        }

        public static int CmpareString(string str1, string str2)
        {
            string[] _arr1 = str1.Split(new char[] { '.', ' ' });
            string[] _arr2 = str2.Split(new char[] { '.', ' ' });
            int _len = _arr1.Length > _arr2.Length ? _arr2.Length : _arr1.Length;

            for(int i=0; i<_len;i++)
            {
                try
                {
                    int val1 = int.Parse(_arr1[i]);
                    int val2 = int.Parse(_arr2[i]);

                    if (val1 == val2)
                    {
                        continue;
                    }

                    if (val1 > val2)
                    {
                        return 1;
                    }
                    else
                    {
                        return -1;
                    }
                }
                catch
                {
                    break;
                }
            }

            return string.Compare(str1, str2, StringComparison.Ordinal);

        }

        protected string fixQueyParameter(string Param)
        {
            return Param.Replace("'", "''");
        }
        internal void GenerateSQLHTMLToDB(RGKeywordList rKeywordList)
        {
            string dakrefconnstring = "packet size=4096;user id=sa;PASSWORD=;data source=PMELZER-PC;persist security info=False;initial catalog=DAKREF-TEMP";
            SqlConnection _conn = new SqlConnection(dakrefconnstring);
            string SQL = "If not exists (SELECT name FROM dbo.sysobjects where name = 'rgsectionHtml') " +
                    "CREATE TABLE [dbo].rgsectionHtml( " +
                    "[SectionSN] [int] NOT NULL, " +
                    "[ModuleSN] [int] NULL, " +
                    "[Heading] [varchar](120) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, " +
                    "[TextBlock] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL, " +
                    "[Sequence] [int] NULL " +
                    ") ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]";

            SqlCommand myCommand = new SqlCommand(SQL, _conn);
            myCommand.CommandType = CommandType.Text;

            _conn.Open();

            int ret = 0;
            try
            {
                ret = myCommand.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string s = e.Message;
            }

            SQL = "delete from rgsectionHtml where moduleSN=" + GlobalStructures.ModuleSN.ToString();
            myCommand = new SqlCommand(SQL, _conn);
            myCommand.CommandType = CommandType.Text;

            try
            {
                ret = myCommand.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string s = e.Message;
            }

            for (int i = 0; i < base.Count; i++)
            {
                TSection pSection = base[i];

                StringBuilder sbHtml = new StringBuilder();

                sbHtml.Append(@"<!DOCTYPE html PUBLIC ""-//W3C//DTD XHTML 1.0 Transitional//EN"" ""http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"">");
                sbHtml.Append(@"<html xmlns=""http://www.w3.org/1999/xhtml"">");
                sbHtml.Append(@"<head><title>");
                sbHtml.Append(pSection.Title);
                sbHtml.Append("</title><script type='text/javascript'>function load(){window.location.href='######';}</script></head><body onload='load()'>");
                //sbHtml.Append("</title><script type='text/javascript'>function load(){alert('Page is loaded(2010-06-08)');window.location.href='######';}</script></head><body onload='load()'>");
                //sbHtml.Append("</title></head><body onload='load()'>");

                // Structure of the output file is:
                // ModuleSN, SectionSN, Sequence, Heading, TextBlock, TagDateBlock (date/start/length)*
                BlockDetail lastDetail = null;

                //foreach (BlockDetail bDetail in pSection)
                for (int j = 0; j < pSection.Count; j++)
                {
                    BlockDetail bDetail = pSection[j];

                    long referenceSN = -1;

                    if (bDetail.Type == BlockType.KEY)
                    {
                        if (bDetail.Key != string.Empty)
                        {
                            if ((bDetail.Key.ToUpper().IndexOf(" FR", 2) != -1) || (bDetail.Key.ToUpper().IndexOf(" CFR", 2) != -1))
                            {
                                referenceSN = rKeywordList.FindReferenceSN(GlobalStructures.ModuleSN, pSection.SectionID, bDetail.Key);

                                if (GlobalStructures.ModuleSN == 11570)
                                {
                                    referenceSN += 1000000;
                                }
                                sbHtml.Append(@"<div class=""key"">");
                                sbHtml.Append(@"<a  href='http://research.dakotasoft.com/center/dakwebcenter.asp?L=R&CITATION=" +
                                        bDetail.Key + @"' name='" + referenceSN.ToString() + @"'>");
                                sbHtml.Append(bDetail.Key);
                                sbHtml.Append("</a></div>");
                            }
                            else
                            {
                                referenceSN = rKeywordList.FindReferenceSN(GlobalStructures.ModuleSN, pSection.SectionID, bDetail.Key);

                                if (GlobalStructures.ModuleSN == 11570)
                                {
                                    referenceSN += 1000000;
                                }

                                sbHtml.Append(@"<div class=""key"">");
                                //sbHtml.Append(@"<aaaa name=""" + referenceSN.ToString() + @"""><b>");
                                sbHtml.Append(@"<a name=""" + referenceSN.ToString() + @"""><b>");
                                sbHtml.Append(bDetail.Key);
                                sbHtml.Append("<b></a></div>");
                            }
                        }
                        else
                        {
                            switch (bDetail.Indent)
                            {
                                case RGTokenType.tokA:
                                case RGTokenType.OutOfTokens:
                                    sbHtml.Append(@"<div class=""IndA"">");
                                    break;
                                case RGTokenType.tokB:
                                    sbHtml.Append(@"<div class=""IndB"">");
                                    break;
                                case RGTokenType.tokOFF:
                                    sbHtml.Append(@"</div>");
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                    else if (bDetail.Type == BlockType.DEF)
                    {
                        if (bDetail.Key != string.Empty)
                        {
                            if (lastDetail != null)
                            {
                                if (lastDetail.IndentStatus == RGTokenType.tokB)
                                {
                                    if (!lastDetail.tokBOnly)
                                    {
                                        sbHtml.Append(@"</div>");
                                    }
                                    sbHtml.Append(@"</div>");
                                }

                                if (lastDetail.IndentStatus == RGTokenType.tokA)
                                {
                                    sbHtml.Append(@"</div>");
                                }
                            }

                            referenceSN = rKeywordList.FindReferenceSN(GlobalStructures.ModuleSN, pSection.SectionID, bDetail.Key);

                            sbHtml.Append(@"<div class=""def"">");
                            sbHtml.Append(@"<a name=" + referenceSN.ToString() + ">");
                            sbHtml.Append(bDetail.Key);
                            sbHtml.Append("</a></div>");
                        }
                        else
                        {
                            switch (bDetail.Indent)
                            {
                                case RGTokenType.tokA:
                                case RGTokenType.OutOfTokens:
                                    sbHtml.Append(@"<div class=""IndA"">");
                                    break;
                                case RGTokenType.tokB:
                                    sbHtml.Append(@"<div class=""IndB"">");
                                    break;
                                case RGTokenType.tokOFF:
                                    sbHtml.Append(@"</div>");
                                    break;
                                default:
                                    break;
                            }
                        }
                    }

                    if (bDetail.Indent == RGTokenType.tokTABLE)
                    {
                        if (bDetail.Text != string.Empty)
                        {
                            sbHtml.Append(@"<pre>");
                            sbHtml.Append(bDetail.Text);
                            sbHtml.Append("</pre>");
                        }
                    }
                    else
                    {
                        if (bDetail.Caption != string.Empty || bDetail.Text != string.Empty)
                        {
                            sbHtml.Append(@"<div class=""desc"">");
                            if (bDetail.Caption != string.Empty)
                            {
                                sbHtml.Append(bDetail.Caption + "<BR>");
                            }
                            if (bDetail.SubHeader != string.Empty)
                            {
                                sbHtml.Append(bDetail.SubHeader + "<BR>");
                            }
                            if (bDetail.Text != string.Empty)
                            {
                                sbHtml.Append(bDetail.Text);
                            }
                            sbHtml.Append("</div>");
                        }
                    }

                    lastDetail = bDetail;
                }

                sbHtml.Append(@"</body></html>");
                SQL = "INSERT INTO [DAKREF-TEMP].[dbo].[rgsectionHtml] " +
                       "([SectionSN] " +
                       ",[ModuleSN] " +
                       ",[Heading] " +
                       ",[TextBlock] " +
                       ",[Sequence]) " +
                        "VALUES (" +
                       pSection.SectionID.ToString() +
                       "," + GlobalStructures.ModuleSN.ToString() +
                       ",'" + fixQueyParameter(SUTIL.PrepareASCIIString(pSection.Title)) +
                       "','" + fixQueyParameter(sbHtml.ToString()) +
                       "'," + pSection.SectionID.ToString() + ")";

                myCommand = new SqlCommand(SQL, _conn);
                myCommand.CommandType = CommandType.Text;

                try
                {
                    ret = myCommand.ExecuteNonQuery();
                }
                catch (Exception e)
                {
                    string s = e.Message;
                }
            }

            _conn.Close();
        }

        internal void GenerateSQLHTMLToDB1(RGKeywordList rKeywordList)
        {
            string dakrefconnstring = null;
            if (_main.IPhoneUser == "") 
            {
                dakrefconnstring = "packet size=4096;data source=" + _main.txtIPhoneServer.Text +
                        ";Integrated Security=SSPI;initial catalog=" + _main.txtIPhoneDB.Text;
            }
            else
            {
                dakrefconnstring = "packet size=4096;user id=" + _main.IPhoneUser +
                        ";PASSWORD=" + _main.IPhonePW + ";data source=" + _main.txtIPhoneServer.Text +
                        ";persist security info=False;initial catalog=" + _main.txtIPhoneDB.Text;
            }

            SqlConnection _conn = new SqlConnection(dakrefconnstring);

            string SQL = "If not exists (SELECT name FROM dbo.sysobjects where name = 'rgsectionHtml') " +
                    "CREATE TABLE [dbo].rgsectionHtml( " +
		            "[SectionSN] [int] NOT NULL, " +
		            "[ModuleSN] [int] NULL, " +
		            "[Heading] [varchar](120) COLLATE SQL_Latin1_General_CP1_CI_AS NULL, " +
		            "[TextBlock] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NULL, " +
		            "[Sequence] [int] NULL " +
	                ") ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]";

            SqlCommand myCommand = new SqlCommand(SQL, _conn);
            myCommand.CommandType = CommandType.Text;

            _conn.Open();

            int ret = 0;
            try
            {
                ret = myCommand.ExecuteNonQuery();
            }
            catch(Exception e)
            {
                string s = e.Message;
            }

            SQL = "delete from rgsectionHtml where moduleSN=" + GlobalStructures.ModuleSN.ToString();
            myCommand = new SqlCommand(SQL, _conn);
            myCommand.CommandType = CommandType.Text;

            try
            {
                ret = myCommand.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                string s = e.Message;
            }

            for (int i = 0; i < base.Count; i++)
            {
                TSection pSection = base[i];

                StringBuilder sbHtml = new StringBuilder();

                sbHtml.Append(@"<!DOCTYPE html PUBLIC ""-//W3C//DTD XHTML 1.0 Transitional//EN"" ""http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"">");
                sbHtml.Append(@"<html xmlns=""http://www.w3.org/1999/xhtml"">");
                sbHtml.Append(@"<head><title>");
                sbHtml.Append(pSection.Title);
                sbHtml.Append("</title><script type='text/javascript'>function load(){window.location.href='######';}</script><style type='text/css'>BODY{}.IndA{    MARGIN-LEFT: 25px}.IndB{    MARGIN-LEFT: 50px}.Head{    FONT-WEIGHT: bold}.Section{    FONT-WEIGHT: normal}.NoInd{    MARGIN-LEFT: 0px}.RTable{    FONT-FAMILY: Courier}H2{    TEXT-TRANSFORM: uppercase;}</style></head><body onload='load()'>");
                //sbHtml.Append("</title><script type='text/javascript'>function load(){window.location.href='######';}</script></head><body onload='load()'>");
                //sbHtml.Append("</title><script type='text/javascript'>function load(){alert('Page is loaded(2010-06-08)');window.location.href='######';}</script></head><body onload='load()'>");
                //sbHtml.Append("</title></head><body onload='load()'>");

                // Structure of the output file is:
                // ModuleSN, SectionSN, Sequence, Heading, TextBlock, TagDateBlock (date/start/length)*
                BlockDetail lastDetail = null;

                //foreach (BlockDetail bDetail in pSection)
                for (int j = 0; j < pSection.Count; j++)
                {
                    //if (j == 9)
                    //{
                    //    string s = "";
                    //}
                    BlockDetail bDetail = pSection[j];
                    try
                    {
                        long referenceSN = -1;

                        if (bDetail.Type == BlockType.KEY)
                        {
                            if (bDetail.Key != string.Empty)
                            {
                                if ((bDetail.Key.Length>5 &&( bDetail.Key.ToUpper().IndexOf(" FR", 2) != -1) || (bDetail.Key.ToUpper().IndexOf(" CFR", 2) != -1)))
                                {
                                    referenceSN = rKeywordList.FindReferenceSN(GlobalStructures.ModuleSN, pSection.SectionID, bDetail.Key);

                                    if (GlobalStructures.ModuleSN == 11570)
                                    {
                                        referenceSN += 1000000;
                                    }
                                    sbHtml.Append(@"<div class=""key"">");
                                    sbHtml.Append(@"<a  href='http://research.dakotasoft.com/center/dakwebcenter.asp?L=R&CITATION=" +
                                            bDetail.Key + @"' name='" + referenceSN.ToString() + @"'>");
                                    sbHtml.Append(bDetail.Key);
                                    sbHtml.Append("</a></div>");
                                }
                                else
                                {
                                    referenceSN = rKeywordList.FindReferenceSN(GlobalStructures.ModuleSN, pSection.SectionID, bDetail.Key);

                                    if (GlobalStructures.ModuleSN == 11570)
                                    {
                                        referenceSN += 1000000;
                                    }

                                    sbHtml.Append(@"<div class=""key"">");
                                    //sbHtml.Append(@"<aaaa name=""" + referenceSN.ToString() + @"""><b>");
                                    sbHtml.Append(@"<a name=""" + referenceSN.ToString() + @"""><b>");
                                    sbHtml.Append(bDetail.Key);
                                    sbHtml.Append("<b></a></div>");
                                }
                            }
                            else
                            {
                                switch (bDetail.Indent)
                                {
                                    case RGTokenType.tokA:
                                    case RGTokenType.OutOfTokens:
                                        sbHtml.Append(@"<div class=""IndA"">");
                                        break;
                                    case RGTokenType.tokB:
                                        sbHtml.Append(@"<div class=""IndB"">");
                                        break;
                                    case RGTokenType.tokOFF:
                                        sbHtml.Append(@"</div>");
                                        break;
                                    default:
                                        break;
                                }
                            }
                        }
                        else if (bDetail.Type == BlockType.DEF)
                        {
                            if (bDetail.Key != string.Empty)
                            {
                                if (lastDetail != null)
                                {
                                    if (lastDetail.IndentStatus == RGTokenType.tokB)
                                    {
                                        if (!lastDetail.tokBOnly)
                                        {
                                            sbHtml.Append(@"</div>");
                                        }
                                        sbHtml.Append(@"</div>");
                                    }

                                    if (lastDetail.IndentStatus == RGTokenType.tokA)
                                    {
                                        sbHtml.Append(@"</div>");
                                    }
                                }

                                referenceSN = rKeywordList.FindReferenceSN(GlobalStructures.ModuleSN, pSection.SectionID, bDetail.Key);

                                sbHtml.Append(@"<div class=""def"">");
                                sbHtml.Append(@"<a name=" + referenceSN.ToString() + ">");
                                sbHtml.Append(bDetail.Key);
                                sbHtml.Append("</a></div>");
                            }
                            else
                            {
                                switch (bDetail.Indent)
                                {
                                    case RGTokenType.tokA:
                                    case RGTokenType.OutOfTokens:
                                        sbHtml.Append(@"<div class=""IndA"">");
                                        break;
                                    case RGTokenType.tokB:
                                        sbHtml.Append(@"<div class=""IndB"">");
                                        break;
                                    case RGTokenType.tokOFF:
                                        sbHtml.Append(@"</div>");
                                        break;
                                    default:
                                        break;
                                }
                            }
                        }
                    }
                    catch// (Exception e)
                    {
                        //throw (e);
                    }
                    if (bDetail.Indent == RGTokenType.tokTABLE)
                    {
                        if (bDetail.Text != string.Empty)
                        {
                            sbHtml.Append(@"<pre>");
                            sbHtml.Append(bDetail.Text);
                            sbHtml.Append("</pre>");
                        }
                    }
                    else
                    {
                        if (bDetail.Caption != string.Empty || bDetail.Text != string.Empty)
                        {
                            sbHtml.Append(@"<div class=""desc"">");
                            if (bDetail.Caption != string.Empty)
                            {
                                sbHtml.Append(bDetail.Caption + "<BR>");
                            }
                            if (bDetail.SubHeader != string.Empty)
                            {
                                sbHtml.Append(bDetail.SubHeader + "<BR>");
                            }
                            if (bDetail.Text != string.Empty)
                            {
                                sbHtml.Append(bDetail.Text);
                            }
                            sbHtml.Append("</div>");
                        }
                    }

                    lastDetail = bDetail;
                }

                sbHtml.Append(@"</body></html>");
                SQL = "INSERT INTO [dbo].[rgsectionHtml] " +
                       "([SectionSN] " +
                       ",[ModuleSN] " +
                       ",[Heading] " +
                       ",[TextBlock] " +
                       ",[Sequence]) " +
                        "VALUES (" +
                       pSection.SectionID.ToString() +
                       "," + GlobalStructures.ModuleSN.ToString() +
                       ",'" + fixQueyParameter(SUTIL.PrepareASCIIString(pSection.Title)) +
                       "','" + fixQueyParameter(sbHtml.ToString()) +
                       "'," + pSection.SectionID.ToString() + ")";

                myCommand = new SqlCommand(SQL, _conn);
                myCommand.CommandType = CommandType.Text;

                try
                {
                    ret = myCommand.ExecuteNonQuery();
                }
                catch (Exception e)
                {
                    string s = e.Message;
                }
            }

            _conn.Close();
        }
        internal void GenerateSQLHTML(string PathName)
        {
            string ts = PathName + "\\RGSECTHTML.XML";
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.OmitXmlDeclaration = true;
            XmlWriter writer = XmlWriter.Create(ts, settings);
            //XmlTextWriter writer = new XmlTextWriter(ts, Encoding.Default);

            writer.WriteRaw("<?xml version=\"1.0\" encoding=\"utf-8\" ?>");
            writer.WriteComment("Created @" + DateTime.Now.ToString());
            writer.WriteStartElement("Root");
            
            for (int i = 0; i < base.Count; i++)
            {
                TSection pSection = base[i];

                StringBuilder sbHtml = new StringBuilder();

                sbHtml.Append(@"<!DOCTYPE html PUBLIC ""-//W3C//DTD XHTML 1.0 Transitional//EN"" ""http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"">");
                sbHtml.Append(@"<html xmlns=""http://www.w3.org/1999/xhtml"">");
                sbHtml.Append(@"<head><title>");
                sbHtml.Append(pSection.Title);
                sbHtml.Append("</title></head><body>");


                // Structure of the output file is:
                // ModuleSN, SectionSN, Sequence, Heading, TextBlock, TagDateBlock (date/start/length)*
                BlockDetail lastDetail = null;

                //foreach (BlockDetail bDetail in pSection)
                for (int j = 0; j < pSection.Count; j++)
                {
                    BlockDetail bDetail = pSection[j];

                    if (bDetail.Type == BlockType.KEY)
                    {
                        if (bDetail.Key != string.Empty)
                        {
                            sbHtml.Append(@"<div class=""key"">");
                            sbHtml.Append(@"<a  href='http://research.dakotasoft.com/center/dakwebcenter.asp?L=R&CITATION=" +
                                    bDetail.Key + "' name='" + pSection.SectionID.ToString() + "'>");
                            sbHtml.Append(bDetail.Key);
                            sbHtml.Append("</a></div>");
                        }
                        else
                        {
                            switch (bDetail.Indent)
                            {
                                case RGTokenType.tokA:
                                case RGTokenType.OutOfTokens:
                                    sbHtml.Append(@"<div class=""IndA"">");
                                    break;
                                case RGTokenType.tokB:
                                    sbHtml.Append(@"<div class=""IndB"">");
                                    break;
                                case RGTokenType.tokOFF:
                                    sbHtml.Append(@"</div>");
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                    else if (bDetail.Type == BlockType.DEF)
                    {
                        if (bDetail.Key != string.Empty)
                        {
                            if (lastDetail != null)
                            {
                                if (lastDetail.IndentStatus == RGTokenType.tokB)
                                {
                                    if (!lastDetail.tokBOnly)
                                    {
                                        sbHtml.Append(@"</div>");
                                    }
                                    sbHtml.Append(@"</div>");
                                }

                                if (lastDetail.IndentStatus == RGTokenType.tokA)
                                {
                                    sbHtml.Append(@"</div>");
                                }
                            }

                            sbHtml.Append(@"<div class=""def"">");
                            sbHtml.Append(@"<a  name=" + pSection.SectionID.ToString() + ">");
                            sbHtml.Append(bDetail.Key);
                            sbHtml.Append("</a></div>");
                        }
                        else
                        {
                            switch (bDetail.Indent)
                            {
                                case RGTokenType.tokA:
                                case RGTokenType.OutOfTokens:
                                    sbHtml.Append(@"<div class=""IndA"">");
                                    break;
                                case RGTokenType.tokB:
                                    sbHtml.Append(@"<div class=""IndB"">");
                                    break;
                                case RGTokenType.tokOFF:
                                    sbHtml.Append(@"</div>");
                                    break;
                                default:
                                    break;
                            }
                        }
                    }

                    if (bDetail.Indent == RGTokenType.tokTABLE)
                    {
                        if (bDetail.Text != string.Empty)
                        {
                            sbHtml.Append(@"<pre>");
                            sbHtml.Append(bDetail.Text);
                            sbHtml.Append("</pre>");
                        }
                    }
                    else
                    {
                        if (bDetail.Caption != string.Empty || bDetail.Text != string.Empty)
                        {
                            sbHtml.Append(@"<div class=""desc"">");
                            if (bDetail.Caption != string.Empty)
                            {
                                sbHtml.Append(bDetail.Caption + "<BR>");
                            }
                            if (bDetail.SubHeader != string.Empty)
                            {
                                sbHtml.Append(bDetail.SubHeader + "<BR>");
                            }
                            if (bDetail.Text != string.Empty)
                            {
                                sbHtml.Append(bDetail.Text);
                            }
                            sbHtml.Append("</div>");
                        }
                    }

                    lastDetail = bDetail;
                }

                sbHtml.Append(@"</body></html>");

                writer.WriteStartElement("SECTION");
                writer.WriteAttributeString("SectionSN", pSection.SectionID.ToString());
                writer.WriteAttributeString("ModuleSN", GlobalStructures.ModuleSN.ToString());
                writer.WriteStartElement("HEADING");
                writer.WriteCData(SUTIL.PrepareXMLtring(pSection.Title));
                writer.WriteFullEndElement();
                writer.WriteStartElement("TEXTBOOK");
                writer.WriteCData(SUTIL.PrepareXMLtring(sbHtml.ToString()));
                writer.WriteFullEndElement();

                writer.WriteFullEndElement();
            }
            writer.WriteFullEndElement();
            writer.Close();
        }

        internal void GenerateSQLHTMLToFile(string PathName, RGKeywordList rKeywordList)
        {
            string ts = Path.Combine(PathName, "IPHONERGSECT.REM");

            StreamWriter wrRGSect = null;
            try
            {
                wrRGSect = new StreamWriter(ts, false, Encoding.Default); ;
            }
            catch
            {
                throw (new Exception("Could not create IPHONERGSECT.REM file."));
            }


            for (int i = 0; i < base.Count; i++)
            {
                TSection pSection = base[i];

                StringBuilder sbHtml = new StringBuilder();

                sbHtml.Append(@"<!DOCTYPE html PUBLIC ""-//W3C//DTD XHTML 1.0 Transitional//EN"" ""http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"">");
                sbHtml.Append(@"<html xmlns=""http://www.w3.org/1999/xhtml"">");
                sbHtml.Append(@"<head><title>");
                sbHtml.Append(pSection.Title);
                sbHtml.Append("</title><script type='text/javascript'>function load(){window.location.href='######';}</script></head><body onload='load()'>");


                // Structure of the output file is:
                // ModuleSN, SectionSN, Sequence, Heading, TextBlock, TagDateBlock (date/start/length)*
                BlockDetail lastDetail = null;

                //foreach (BlockDetail bDetail in pSection)
                for (int j = 0; j < pSection.Count; j++)
                {
                    //if (j == 9)
                    //{
                    //    string s = "";
                    //}
                    BlockDetail bDetail = pSection[j];
                    try
                    {
                        long referenceSN = -1;

                        if (bDetail.Type == BlockType.KEY)
                        {
                            if (bDetail.Key != string.Empty)
                            {
                                if ((bDetail.Key.Length > 5 && (bDetail.Key.ToUpper().IndexOf(" FR", 2) != -1) || (bDetail.Key.ToUpper().IndexOf(" CFR", 2) != -1)))
                                {
                                    referenceSN = rKeywordList.FindReferenceSN(GlobalStructures.ModuleSN, pSection.SectionID, bDetail.Key);

                                    if (GlobalStructures.ModuleSN == 11570)
                                    {
                                        referenceSN += 1000000;
                                    }
                                    sbHtml.Append(@"<div class=""key"">");
                                    sbHtml.Append(@"<a  href='http://research.dakotasoft.com/center/dakwebcenter.asp?L=R&CITATION=" +
                                            bDetail.Key + @"' name='" + referenceSN.ToString() + @"'>");
                                    sbHtml.Append(bDetail.Key);
                                    sbHtml.Append("</a></div>");
                                }
                                else
                                {
                                    referenceSN = rKeywordList.FindReferenceSN(GlobalStructures.ModuleSN, pSection.SectionID, bDetail.Key);

                                    if (GlobalStructures.ModuleSN == 11570)
                                    {
                                        referenceSN += 1000000;
                                    }

                                    sbHtml.Append(@"<div class=""key"">");
                                    //sbHtml.Append(@"<aaaa name=""" + referenceSN.ToString() + @"""><b>");
                                    sbHtml.Append(@"<a name=""" + referenceSN.ToString() + @"""><b>");
                                    sbHtml.Append(bDetail.Key);
                                    sbHtml.Append("<b></a></div>");
                                }
                            }
                            else
                            {
                                switch (bDetail.Indent)
                                {
                                    case RGTokenType.tokA:
                                    case RGTokenType.OutOfTokens:
                                        sbHtml.Append(@"<div class=""IndA"">");
                                        break;
                                    case RGTokenType.tokB:
                                        sbHtml.Append(@"<div class=""IndB"">");
                                        break;
                                    case RGTokenType.tokOFF:
                                        sbHtml.Append(@"</div>");
                                        break;
                                    default:
                                        break;
                                }
                            }
                        }
                        else if (bDetail.Type == BlockType.DEF)
                        {
                            if (bDetail.Key != string.Empty)
                            {
                                if (lastDetail != null)
                                {
                                    if (lastDetail.IndentStatus == RGTokenType.tokB)
                                    {
                                        if (!lastDetail.tokBOnly)
                                        {
                                            sbHtml.Append(@"</div>");
                                        }
                                        sbHtml.Append(@"</div>");
                                    }

                                    if (lastDetail.IndentStatus == RGTokenType.tokA)
                                    {
                                        sbHtml.Append(@"</div>");
                                    }
                                }

                                referenceSN = rKeywordList.FindReferenceSN(GlobalStructures.ModuleSN, pSection.SectionID, bDetail.Key);

                                sbHtml.Append(@"<div class=""def"">");
                                sbHtml.Append(@"<a name=" + referenceSN.ToString() + ">");
                                sbHtml.Append(bDetail.Key);
                                sbHtml.Append("</a></div>");
                            }
                            else
                            {
                                switch (bDetail.Indent)
                                {
                                    case RGTokenType.tokA:
                                    case RGTokenType.OutOfTokens:
                                        sbHtml.Append(@"<div class=""IndA"">");
                                        break;
                                    case RGTokenType.tokB:
                                        sbHtml.Append(@"<div class=""IndB"">");
                                        break;
                                    case RGTokenType.tokOFF:
                                        sbHtml.Append(@"</div>");
                                        break;
                                    default:
                                        break;
                                }
                            }
                        }
                    }
                    catch// (Exception e)
                    {
                        //throw (e);
                    }
                    if (bDetail.Indent == RGTokenType.tokTABLE)
                    {
                        if (bDetail.Text != string.Empty)
                        {
                            sbHtml.Append(@"<pre>");
                            sbHtml.Append(bDetail.Text);
                            sbHtml.Append("</pre>");
                        }
                    }
                    else
                    {
                        if (bDetail.Caption != string.Empty || bDetail.Text != string.Empty)
                        {
                            sbHtml.Append(@"<div class=""desc"">");
                            if (bDetail.Caption != string.Empty)
                            {
                                sbHtml.Append(bDetail.Caption + "<BR>");
                            }
                            if (bDetail.SubHeader != string.Empty)
                            {
                                sbHtml.Append(bDetail.SubHeader + "<BR>");
                            }
                            if (bDetail.Text != string.Empty)
                            {
                                sbHtml.Append(bDetail.Text);
                            }
                            sbHtml.Append("</div>");
                        }
                    }

                    lastDetail = bDetail;
                }

                sbHtml.Append(@"</body></html>");

                wrRGSect.WriteLine(pSection.SectionID.ToString() +
                       "," + GlobalStructures.ModuleSN.ToString() +
                       ",'" + fixQueyParameter(SUTIL.PrepareASCIIString(pSection.Title)) +
                       "','" + fixQueyParameter(sbHtml.ToString()) +
                       "'," + pSection.SectionID.ToString());

            }

            wrRGSect.Close();
        }

    }
}
