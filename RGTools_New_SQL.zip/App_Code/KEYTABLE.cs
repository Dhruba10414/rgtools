// KEYTABLE.H  Copyright (c) 1997, Dakota Software Corporation. All rights reserved.

using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace RGTools_New
{
    class TLongArray : List<long>
    {
        public TLongArray()
        { }
    }

    class TCitation
    {
        private string m_Citation;
        TLongArray m_QuestionSN = new TLongArray();
        long m_ReferenceOffset;

        public TCitation(string pCitation)
        {
            m_Citation = pCitation;
            m_ReferenceOffset = 0L;
        }

        public string Citation
        {
            get
            {
                return m_Citation;
            }
        }
        public static bool operator ==(TCitation Other1, TCitation Other2)
        { return (Other1.m_Citation == Other2.m_Citation);}
        public static bool operator !=(TCitation Other1, TCitation Other2)
        { return (Other1.m_Citation != Other2.m_Citation); }
        //public static bool operator <(TCitation Other1, TCitation Other2)
        //{ return (Other1.m_Citation < Other2.m_Citation); }
        //public static bool operator >(TCitation Other1, TCitation Other2)
        //{ return (Other1.m_Citation > Other2.m_Citation) ; }
        public override bool Equals(object obj)
        {
            if (TCitation.Equals((obj as TCitation),null))
            {
                return false;
            }
            else
            {

                return this.m_Citation == ((TCitation)(obj)).m_Citation;
            }
        }
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public long GetQuestionCount() { return m_QuestionSN.Count; }
        public string GetCitation() { return m_Citation; }
        public long GetReferenceOffset() { return m_ReferenceOffset; }

        public void AddQuestionSN(long QuestionSN) { m_QuestionSN.Add(QuestionSN); }
        public void SetReferenceOffset(long ReferenceOffset) { m_ReferenceOffset = ReferenceOffset; }
    }

    class TCitationList : List<TCitation>
    {
        public TCitationList()
        { }

        void AddReference(string Citation, long QuestionSN)
        {
            _citation = new TCitation(Citation);
            TCitation pCitation = base.Find(match);
            if (pCitation!=null)
            {
                pCitation.AddQuestionSN(QuestionSN);
            }
            else
            {
                pCitation = new TCitation(Citation);
                pCitation.AddQuestionSN(QuestionSN);
                
                Add(pCitation);
            }
        }
        bool Load(string QInputName, StreamWriter Bogue)
        {

            // First try to open the input file.
            StringReader QIFile = null;
            try
            {
                QIFile = new StringReader(QInputName);
            }
            catch
            {
                Bogue.WriteLine("Could not open " + QInputName + ".");
            }

            string InputLine;
            char[] iline = new char[500];
            long CurrentSN = 0L;

            // Loop through the input, discarding comments and sorting commands from content.
            while ((InputLine=QIFile.ReadLine())!=null)
            {
                // Look for serial numbers and reference lines.
                if (InputLine.Length > 2)
                {
                    switch (InputLine[0])
                    {
                        case '*':
                            if (InputLine[1] == '%')
                            {
                                InputLine.Remove(0, 2);
                                InputLine = InputLine.Trim(new char[]{' '});
                                CurrentSN = long.Parse(InputLine);// atol(InputLine.c_str());
                            }
                            break;
                        case 'X':
                        case 'R':
                            {
                                int iPos = InputLine.IndexOf(" ");
                                UTIL.Assert(iPos != -1, "Assertion Failed: iPos != -1!");

                                InputLine.Remove(0, iPos);
                                InputLine = InputLine.Trim(new char[]{' '});
                                AddReference(InputLine, CurrentSN);
                            }
                            break;
                        default:
                            break;
                    }
                }
            }

            QIFile.Close();
            return true;
        }

        private static TCitation _citation = null;
        private static bool match(TCitation citation)
        {
            return (_citation.Citation == citation.Citation);
        }
    }
}
