using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Diagnostics;

namespace RGTools_New
{
    class TRefLib
    {
        long MAX_TITLE = 110;
        long SHRT_MAX = 32767;

        private TTOC m_TOC = new TTOC();
        private TKeyList m_KeyList = new TKeyList();
        internal TSectionList m_SectionList = new TSectionList();
        private TGlossary m_Glossary = new TGlossary();

        public TRefLib() { }

        public void Build(frmMain _main, TParseDoc pParseDoc, StreamWriter BogueFile)
        {
            TKeyTempList KeyTempList = new TKeyTempList();
            TKey pCurrentKey = null;

            pParseDoc.CurrentLinePos = -1;

            m_SectionList.CreateSection();  // Make sure we start with a section

            bool BugFree = true;
            TParseLine pLine;
            bool InterveningStuff = false;
            do
            {
                try
                {
                    switch (pParseDoc.LineClassType) //.Peek()
                    {
                        case TParseLine.LineClass.lcText:
                            InterveningStuff = true;
                            BuildText(m_SectionList.GetCurrentSection(), pParseDoc);
                            ////test1();
                            break;
                        case TParseLine.LineClass.lcSection:
                            //Create a new section
                            pCurrentKey = null;
                            KeyTempList.Clear();

                            m_SectionList.GetCurrentSection().SetDate(0);
                            BuildSection(pParseDoc);
                            break;

                        case TParseLine.LineClass.lcSubHeader:
                            InterveningStuff = true;
                            BuildSubHeader(m_SectionList.GetCurrentSection(), pParseDoc);
                            break;

                        case TParseLine.LineClass.lcCaption:
                            InterveningStuff = true;
                            BuildCaption(m_SectionList.GetCurrentSection(), pParseDoc);
                            break;

                        case TParseLine.LineClass.lcList:
                            InterveningStuff = true;
                            BuildList(pCurrentKey, m_SectionList.GetCurrentSection(), pParseDoc);
                            break;

                        case TParseLine.LineClass.lcEndList:
                            InterveningStuff = true;
                            pLine = pParseDoc.GetLine();
                            throw (new Exception("END LIST without corresponding LIST"));

                        case TParseLine.LineClass.lcTable:
                            InterveningStuff = true;
                            BuildTable(pCurrentKey, m_SectionList.GetCurrentSection(), pParseDoc);
                            break;

                        case TParseLine.LineClass.lcEndTable:
                            InterveningStuff = true;
                            pLine = pParseDoc.GetLine();
                            throw (new Exception("END TABLE without corresponding LIST"));

                        case TParseLine.LineClass.lcIndent:
                            InterveningStuff = true;
                            BuildIndent(m_SectionList.GetCurrentSection(), pParseDoc);
                            break;

                        case TParseLine.LineClass.lcBreak:
                            {
                                pLine = pParseDoc.GetLine();
                                if (m_SectionList.GetCurrentSection().GetLength() == 0)
                                    throw (new Exception("Spurious BREAK statement"));
                                int LastDate = m_SectionList.GetCurrentSection().GetLatestDate();
                                if (LastDate > 0)
                                {
                                    m_SectionList.GetCurrentSection().SetDate(LastDate);
                                }
                                m_SectionList.SplitSection(m_SectionList.GetCurrentSection());
                                if (LastDate > 0)
                                {
                                    m_SectionList.GetCurrentSection().SetDate(LastDate);
                                }
                            }
                            break;

                        case TParseLine.LineClass.lcKey:
                            {
                                //If this is a blank key, or there has been intervening stuff since
                                //the last key definition, clear the keylist and start again.
                                if ((pCurrentKey == null) || InterveningStuff)
                                {
                                    KeyTempList.Clear();
                                    InterveningStuff = false;
                                }

                                pLine = pParseDoc.GetLine();

                                m_SectionList.GetCurrentSection().SetDate(0);
                                pCurrentKey = new TKey(pLine.Text);
                                pCurrentKey.SetSectionOffset(m_SectionList.GetCurrentSection().CreateSectionOffset());
                                m_KeyList.Add(pCurrentKey);
                                m_SectionList.GetCurrentSection().SetBold(true);
                                m_SectionList.GetCurrentSection().Append(pLine.GetText());
                                m_SectionList.GetCurrentSection().SetBold(false);
                                m_SectionList.GetCurrentSection().NewLine();
                                KeyTempList.Add(pCurrentKey);

                                //Added on Dec 11, 2009
                                BlockDetail detail = new BlockDetail(pLine.Text, BlockType.KEY);
                                if (m_SectionList.GetCurrentSection().CurrentBlockDetail != null)
                                {
                                    detail.IndentStatus = m_SectionList.GetCurrentSection().CurrentBlockDetail.IndentStatus;
                                    detail.tokBOnly = m_SectionList.GetCurrentSection().CurrentBlockDetail.tokBOnly;
                                }
                                //if (pLine.Text == @"NESHAP Source Category Schedule")
                                //{
                                //    string s = SUTIL.PrepareXMLtring("SSS");
                                //}

                                m_SectionList.GetCurrentSection().AddBlockDetail(detail);

                            }
                            break;

                        case TParseLine.LineClass.lcDefinition:
                            m_SectionList.GetCurrentSection().SetDate(0);
                            pCurrentKey = null;
                            KeyTempList.Clear();
                            BuildDefinition(pParseDoc);
                           
                            break;

                        case TParseLine.LineClass.lcDate:
                            InterveningStuff = true;
                            BuildDate(pCurrentKey, pParseDoc);
                            break;

                        case TParseLine.LineClass.EndOfFile:
                            break;

                        default:
                            InterveningStuff = true;
                            string ts = UTIL.LineClassToString(pParseDoc.LineClassType);
                            pLine = pParseDoc.GetLine(); //***CSB temp
                            ts = pLine.GetText();
                            throw (new Exception(ts));
                            //break;
                    }
                }
                catch (Exception e)
                {
                    if (_main.isAutoProcess)
                    {
                        if (e.Message.Substring(0, 1) == "*")
                        {
                            BogueFile.WriteLine(e.Message + " on line " + pParseDoc.GetCurrentLine() + " in RefLib.txt.");                            
                        }
                        else
                        {
                            BogueFile.WriteLine(e.Message + " on line " + pParseDoc.GetCurrentLine() + " in RefLib.txt.");
                            BugFree = false;
                        }
                    }
                    else
                    {
                        BogueFile.WriteLine(e.Message + " on line " + pParseDoc.GetCurrentLine() + " in RefLib.txt.");
                        BugFree = false; 
                        break;
                    }
                }
            } while (pParseDoc.LineClassType != TParseLine.LineClass.EndOfFile);

            //qbfile.Close();

            KeyTempList.Clear();

            try
            {
                BuildGlossary();
            }
            catch (Exception e)
            {
                _main.OutMsg(PageType.BuildREM, e.Message);
                BogueFile.WriteLine(e.Message + ".");
                BugFree = false;
            }

            BugFree = BugFree && m_TOC.Validate(BogueFile);

            m_KeyList.SortKey();

            if (!BugFree)
            {
                throw (new Exception("There were problems in the Reference Library."));
            }
        }// throw (xmsg);

        public void GenerateSQL(string PathName, StreamWriter BogueFile)
        {
            bool BugFree = true;
            try
            {
                RGKeywordList listKeyword = new RGKeywordList();

                m_SectionList.SequenceSections();
                m_TOC.GenerateSQL(PathName);
                m_KeyList.GenerateSQL(PathName, BogueFile, listKeyword);
                m_SectionList.GenerateSQL(PathName, listKeyword);

                //Output the TOC structure to the Bogue File.
                m_TOC.DumpTOC(BogueFile);
            }
            catch (Exception e)
            {
                BogueFile.WriteLine(e.Message);
                BugFree = false;
            }

            if (!BugFree)
            {
                throw (new Exception("There were problems in the Reference Library."));
            }
        }
        // throw (xmsg);

        private void BuildDate(TTextBlock pBlock, TParseDoc pParseDoc)
        {
            //test1();
            TParseLine pLine = pParseDoc.GetLine();
            int pDate = ParseDate(pLine.GetText());
            //test1();

            pBlock.SetDate(pDate);

            if (pBlock.CurrentBlockDetail != null)
            {
                pBlock.CurrentBlockDetail.Date = pDate;
            }
        }
        private void BuildDate(TKey pCurrentKey, TParseDoc pParseDoc)
        {
            TParseLine pLine = pParseDoc.GetLine();

            int pDate = ParseDate(pLine.Text);
            m_SectionList.GetCurrentSection().SetDate(pDate);
            if (pCurrentKey != null)
            {
                if (pCurrentKey.RevDate < pDate)
                {
                    pCurrentKey.RevDate = pDate;
                }
            }

            if (m_SectionList.GetCurrentSection().CurrentBlockDetail != null)
            {
                m_SectionList.GetCurrentSection().CurrentBlockDetail.Date = pDate;
            }
        }
        private void BuildText(TTextBlock pBlock, TParseDoc pParseDoc)
        {
            TParseLine pLine = pParseDoc.GetLine();

            string ts = (pLine.Text);
            ts = ts.Trim(new char[]{' '});
            if (ts.Length == 0)
            {
                pBlock.NewLine();
                pBlock.NewLine();
            }
            else
            {
                if (pBlock.CleanTermination())
                    pBlock.Append(ts);
                else
                    pBlock.Append(" " + ts);
            }

            if (pBlock.CurrentBlockDetail != null)
            {
                if (ts.Length == 0)
                {
                    pBlock.CurrentBlockDetail.Text += "<BR>";
                }
                else
                {
                    if (pBlock.CleanTermination())
                        pBlock.CurrentBlockDetail.Text += ts;
                    else
                        pBlock.CurrentBlockDetail.Text += " " + ts;
                }
            }
        }
        private void BuildDefinition(TParseDoc pParseDoc)
        {
            TParseLine pLine = pParseDoc.GetLine();
            TDefinition pDefinition = new TDefinition(pLine.Text, pLine.LineNumber);

            m_Glossary.Add(pDefinition);

            // Set definition
            //GlobalStructures.SetDefinitionActive();
            GlobalStructures.DefinitionActive = true;

            bool FirstKey = true;
            do
            {
                //long num = pParseDoc.Line.LineNumber;
                if (FirstKey)
                    FirstKey = false;
                else
                {
                    pLine = pParseDoc.GetLine();
                    pDefinition.AddKey(pLine.GetText(), pLine.LineNumber);


                }

                pDefinition.SetBold(true);
                pDefinition.Append(pLine.Text);
                pDefinition.SetBold(false);
                pDefinition.NewLine();

                //Added on Dec 14, 2009
                //if (pLine.Text == @"""Volatile organic compounds""")
                //{
                //    string s = SUTIL.PrepareXMLtring("SSS");
                //}
                pDefinition.AddBlockDetail(new BlockDetail(pLine.Text, BlockType.DEF));


            } while (pParseDoc.LineClassType == TParseLine.LineClass.lcDefinition);


            // Now process
            bool Loop = true;
            while (Loop)
            {
                //long num = pParseDoc.Line.LineNumber;
                switch (pParseDoc.LineClassType)
                {
                    case TParseLine.LineClass.lcText:
                        BuildText(pDefinition, pParseDoc);
                        //test1();
                        break;

                    case TParseLine.LineClass.lcSection:
                    case TParseLine.LineClass.lcBreak:
                    case TParseLine.LineClass.lcKey:
                    case TParseLine.LineClass.lcDefinition:
                    case TParseLine.LineClass.EndOfFile:
                        Loop = false;
                        //test1();
                        break;

                    case TParseLine.LineClass.lcSubHeader:
                        BuildSubHeader(pDefinition, pParseDoc);
                        //test1();
                        break;

                    case TParseLine.LineClass.lcCaption:
                        BuildCaption(pDefinition, pParseDoc);
                        //test1();
                        break;

                    case TParseLine.LineClass.lcList:

                        BuildList(null, pDefinition, pParseDoc);  //***CSB NULL
                        break;

                    case TParseLine.LineClass.lcEndList:
                        pLine = pParseDoc.GetLine();
                        throw (new Exception("END LIST without corresponding LIST"));

                    case TParseLine.LineClass.lcTable:
                        BuildTable(null, pDefinition, pParseDoc);  //***CSB NULL
                        break;

                    case TParseLine.LineClass.lcEndTable:
                        pLine = pParseDoc.GetLine();

                        throw (new Exception("END TABLE without corresponding LIST"));

                    case TParseLine.LineClass.lcIndent:
                        BuildIndent(pDefinition, pParseDoc);
                        break;

                    case TParseLine.LineClass.lcDate:
                        BuildDate(pDefinition, pParseDoc);
                        break;

                    default:
                        UTIL.Assert(false, "Assertion Failed: pParseDoc.LineClassType not existing!");
                        break;
                }
            }

            pDefinition.SetDate(0);
            pDefinition.SetIndent(1);

            GlobalStructures.ClearDefinitionActive();
        }
        private void BuildTable(TKey pKey, TTextBlock pBlock, TParseDoc pParseDoc)
        {
            // Pull in the table definition line.
            TParseLine pLine = pParseDoc.GetLine();
           
            // Set definition
            GlobalStructures.SetTableActive();

            pBlock.NewLine();
            pBlock.SetFixed(true);

            BlockDetail oldDetail = pBlock.CurrentBlockDetail;
            BlockType _btype = BlockType.None;
            if (oldDetail != null)
            {
                _btype = oldDetail.Type;
            }
            pBlock.AddBlockDetail(new BlockDetail(string.Empty, _btype, RGTokenType.tokTABLE));
            // Now process
            bool Loop = true;
            while (Loop)
            {
                //switch (pParseDoc.Peek())
                switch (pParseDoc.LineClassType)
                {
                    case TParseLine.LineClass.lcText:
                        pLine = pParseDoc.GetLine();
                        if (pLine.GetText().Trim(new char[]{' '}).Length > 0)
                            pBlock.Append(pLine.GetText());
                        pBlock.NewLine();

                        pBlock.CurrentBlockDetail.Text += pLine.Text + "<BR>";
                        break;
                    case TParseLine.LineClass.lcEndTable:
                        pLine = pParseDoc.GetLine();

                        pBlock.AddBlockDetail(new BlockDetail(string.Empty, _btype));

                        Loop = false;
                        break;

                    case TParseLine.LineClass.lcDate:
                        if (pKey != null)
                            BuildDate(pKey, pParseDoc);
                        else
                            BuildDate(pBlock, pParseDoc);
                        break;
                    case TParseLine.LineClass.lcIndent:
                    case TParseLine.LineClass.lcSection:
                    case TParseLine.LineClass.lcBreak:
                    case TParseLine.LineClass.lcKey:
                    case TParseLine.LineClass.lcDefinition:
                    case TParseLine.LineClass.EndOfFile:
                    case TParseLine.LineClass.lcSubHeader:
                    case TParseLine.LineClass.lcEndList:
                    case TParseLine.LineClass.lcCaption:
                    case TParseLine.LineClass.lcList:
                    case TParseLine.LineClass.lcTable:
                        throw (new Exception(UTIL.LineClassToString(pParseDoc.LineClassType) + " is not allowed within a TABLE"));
                }
            }

            pBlock.SetFixed(false);
            pBlock.NewLine();
            GlobalStructures.ClearTableActive();
        }
        private void BuildList(TKey pKey, TTextBlock pBlock, TParseDoc pParseDoc)
        {
            //test1();
            // Pull in the table definition line.
            TParseLine pLine = pParseDoc.GetLine();

            // There may be some indent information.
            string ts = pLine.GetText();

            switch (Rgtoken.GetRGToken(ref ts))
            {
                case RGTokenType.OutOfTokens:
                    pBlock.SetIndent(2);  //***CSB or should it keep whatever indent in going?
                    pBlock.AddBlockDetail(new BlockDetail(RGTokenType.tokA));
                    break;

                case RGTokenType.tokINDENT:
                    switch (Rgtoken.GetRGToken(ref ts))
                    {
                        case RGTokenType.OutOfTokens:
                        case RGTokenType.tokA:
                            pBlock.SetIndent(2);
                            pBlock.AddBlockDetail(new BlockDetail(RGTokenType.tokA));
                            break;

                        case RGTokenType.tokB:
                            pBlock.SetIndent(3);
                            pBlock.AddBlockDetail(new BlockDetail(RGTokenType.tokB));
                            break;

                        case RGTokenType.tokOFF:
                            pBlock.SetIndent(1);
                            pBlock.AddBlockDetail(new BlockDetail(RGTokenType.tokOFF));
                            break;

                        default:
                            //test1();
                            throw (new Exception("Unknown INDENT parameter"));
                    }
                    //test1();
                    break;

                default:
                    //test1();
                    throw (new Exception("LIST has an unknown parameter"));
            }

            // Set definition
            GlobalStructures.SetListActive();

            pBlock.NewLine();
            pBlock.NewLine();

            pBlock.CurrentBlockDetail.Text += "<BR><BR>";

            // Now process
            bool Loop = true;
            while (Loop)
            {
                switch (pParseDoc.LineClassType)
                {
                    case TParseLine.LineClass.lcText:
                        pLine = pParseDoc.GetLine();
                        pBlock.Append(pLine.GetText().Trim(new char[]{' '}));
                        pBlock.NewLine();
                        pBlock.CurrentBlockDetail.Text += pLine.Text + "<BR>";
                        break;

                    case TParseLine.LineClass.lcEndList:
                        pLine = pParseDoc.GetLine();
                        Loop = false;
                        break;

                    case TParseLine.LineClass.lcIndent:

                        BuildIndent(pBlock, pParseDoc);
                        break;

                    case TParseLine.LineClass.lcDate:
                        if (pKey != null)
                        {
                            BuildDate(pKey, pParseDoc);
                        }
                        else
                        {
                            BuildDate(pBlock, pParseDoc);
                        }
                        break;

                    case TParseLine.LineClass.lcSection:
                    case TParseLine.LineClass.lcBreak:
                    case TParseLine.LineClass.lcKey:
                    case TParseLine.LineClass.lcDefinition:
                    case TParseLine.LineClass.EndOfFile:
                    case TParseLine.LineClass.lcSubHeader:
                    case TParseLine.LineClass.lcEndTable:
                    case TParseLine.LineClass.lcCaption:
                    case TParseLine.LineClass.lcList:
                    case TParseLine.LineClass.lcTable:
                        //test1();
                        throw (new Exception(UTIL.LineClassToString(pParseDoc.LineClassType) + " is not allowed within a LIST"));
                }
            }

            pBlock.NewLine();
            pBlock.NewLine();
            pBlock.SetIndent(1);
            pBlock.AddBlockDetail(new BlockDetail(RGTokenType.tokOFF));
            pBlock.CurrentBlockDetail.Text += "<BR>";
            GlobalStructures.ClearListActive();
            //test1();
        }
        private void BuildSubHeader(TTextBlock pBlock, TParseDoc pParseDoc)
        {
            // Pull in the subheader definition line.
            TParseLine pLine = pParseDoc.GetLine();

            pBlock.Append(pLine.GetText());
            pBlock.NewLine();

            if (pBlock.CurrentBlockDetail != null)
            {
                pBlock.CurrentBlockDetail.SubHeader = pLine.Text;
            }
        }
        private void BuildCaption(TTextBlock pBlock, TParseDoc pParseDoc)
        {
            // Pull in the caption definition line.
            TParseLine pLine = pParseDoc.GetLine();

            // Caption is in upper case.
            string ts = (pLine.GetText());

            ts = ts.ToUpper();
            pBlock.Append(ts);
            pBlock.NewLine();

            if (pBlock.CurrentBlockDetail != null)
            {
                pBlock.CurrentBlockDetail.Caption = pLine.Text;
            }
        }
        private void BuildIndent(TTextBlock pBlock, TParseDoc pParseDoc)
        {
            // Pull in the Indent definition line.
            TParseLine pLine = pParseDoc.GetLine();

            string ts = (pLine.GetText());

            switch (Rgtoken.GetRGToken(ref ts))
            {
                case RGTokenType.tokA:
                case RGTokenType.tokINDENT:
                case RGTokenType.OutOfTokens:
                    pBlock.SetIndent(2);
                    pBlock.AddBlockDetail(new BlockDetail(RGTokenType.tokA));
                    break;
                case RGTokenType.tokB:
                    pBlock.AddBlockDetail(new BlockDetail(RGTokenType.tokB));
                    pBlock.SetIndent(3);
                    break;
                case RGTokenType.tokOFF:
                    pBlock.AddBlockDetail(new BlockDetail(RGTokenType.tokOFF));
                    pBlock.SetIndent(1);
                    break;

                default:
                    throw (new Exception("Unknown INDENT parameter"));
            }
        }
        private void BuildSection(TParseDoc pParseDoc)
        {
            // Finish the old section and allocate a new one. Date is already handled.
            // The key must also be finished so we need to calculate the rev date for the key.
            TParseLine pLine = pParseDoc.GetLine();
            string ParseLine = pLine.Text;//.GetText();

            // Grab the level specifier.
            int iPos = ParseLine.IndexOf("]");
            if (iPos == -1)
                throw (new Exception("SECTION command missing [nn] specifier"));
            if ((iPos == 0) || (ParseLine[0] != '['))
                throw (new Exception("SECTION command missing starting ["));
            string Level = ParseLine.Substring(1, iPos - 1);
            Level = Level.Trim(new char[]{' '});
            ParseLine=ParseLine.Remove(0, iPos + 1);
            ParseLine = ParseLine.Trim(new char[]{' '});
            if (ParseLine.Length == 0)
                throw (new Exception("SECTION command missing title"));
            if (ParseLine.Length > MAX_TITLE)
                throw (new Exception("SECTION title is too long"));

            // Add to table of contents as well.
            TTOCEntry pTOCEntry = new TTOCEntry(Level, ParseLine);
            UTIL.Assert(pTOCEntry != null, "Assertion Failed: pTOCEntry != null!");
            m_TOC.Add(pTOCEntry);

            if (Level.Length > 0)
            {
                m_SectionList.CreateSection(Level + " " + ParseLine);
                //qbfile.WriteLine(line.LineNumber.ToString() + "," + line.LineType.ToString() + "," + line.Text);
            }
            TSection pSection = m_SectionList.GetCurrentSection();
            UTIL.Assert(pSection != null, "Assertion Failed: pSection != null!");  //*** throw later.

            TSectionOffset pSectionOffset = pSection.CreateSectionOffset();
            pTOCEntry.SetSectionOffset(pSectionOffset); //*** Default should be added in ructor.

            if (Level.Length == 0)
            {
                //    pSection.SetBold (true);
                pSection.Append(ParseLine);
                //    pSection.SetBold (false);
                pSection.NewLine();
                pSection.NewLine();
            }

        }
        private void BuildGlossary()
        {
            string strErrMsg = "";

            // Assemble to definitions to form the glossary (may need to insert sections)
            UTIL.Assert(m_SectionList.Count > 0, "Assertion Failed: m_SectionList.Count > 0!");
            TSection pSection = m_SectionList[0];

            pSection.SetTitle("1.0 Glossary - " + GlobalStructures.GetModuleName());
            m_TOC[0].SetSectionOffset(pSection.CreateSectionOffset());

            m_Glossary.SortDefinition();

            foreach (TDefinition pDefinition in m_Glossary)
            {
                // Create a new section if appending this definition would increase the
                // section size past the maximum length.
                try
                {
                    if (pSection.Length + pDefinition.Length > SHRT_MAX)
                    {
                        pSection = m_SectionList.SplitSection(pSection);
                    }

                    // Add all the keys for this definition.
                    TSectionOffset pSectionOffset = pSection.CreateSectionOffset();
                    TStringList KeyList = pDefinition.GetKeyList();
                    for (int i = 0; i < KeyList.Count; i++)
                    {
                        TKey pKey = new TKey(KeyList[i]);
                        pKey.SetSectionOffset(pSectionOffset);
                        pKey.RevDate = pDefinition.LatestDate;
                        try
                        {
                            m_KeyList.Add(pKey);
                        }
                        catch (Exception eee)
                        {
                            throw (new Exception(eee.Message + " at line " + KeyList.LineNumbers[i].ToString()+" in REFLIB.TXT"));
                        }
                    }

                    pSection.Append(pDefinition as TTextBlock); // slice the definition

                    foreach (BlockDetail detail in pDefinition)
                    {
                        pSection.Add(detail);
                    }
                }
                catch (Exception ee)
                {
                    strErrMsg += ee.Message;// +Environment.NewLine;              
                }
            }

            if (strErrMsg.Length > 0)
            {
                throw (new Exception(strErrMsg));
            }
        }

        private int ParseDate(string sDate)// throw (xmsg)
        {
            sDate = sDate.Trim(new char[]{' '});
            if (sDate.EndsWith("/"))
            {
                sDate = sDate.Substring(0, sDate.Length - 1);
            }

            sDate = sDate.ToUpper();
            if (sDate == "DEFAULT") return 0;

            // Now parse date as mm/dd/yy
            int iPos = UTIL.find_first_not_of(sDate, new char[] { '/', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' });
            if (iPos != -1)
                throw (new Exception("Invalid date"));
            iPos = sDate.IndexOf("/");
            if ((iPos == -1) || (iPos == 0))
                throw (new Exception("Invalid date"));
            string sMonth = sDate.Substring(0, iPos);
            sDate=sDate.Remove(0, iPos + 1);
            if (sDate.Length == 0)
                throw (new Exception("Invalid date"));

            iPos = sDate.IndexOf("/");
            if ((iPos == -1) || (iPos == 0))
                throw (new Exception("Invalid date"));
            string sDay = sDate.Substring(0, iPos);
            sDate=sDate.Remove(0, iPos + 1);
            string sYear = sDate;

            int Month = int.Parse(sMonth);
            if ((Month < 1) || (Month > 12))
                throw (new Exception("Invalid month"));
            int Day = int.Parse(sDay);
            if ((Day < 1) || (Day > 31))
                throw (new Exception("Invalid day"));
            int Year = int.Parse(sYear);
            if (Year < 90)
                Year += 2000;
            else if (Year > 99)
                throw (new Exception("Bad Year"));
            else
                Year += 1900;

            return Year * 10000 + Month * 100 + Day;
        }
    }

    class TKeyTempList : List<TKey>
    {
        public TKeyTempList() { }
        public new void Clear()
        {
            // If there is nothing to do, just return.
            if (base.Count == 0) return;

            // If there is more than one item percolate the dates from last to first.
            if (base.Count > 1)
            {
                long MasterDate = base[base.Count - 1].GetRevDate();
                if (MasterDate > 0)
                {
                    for (int i = 0; i < base.Count - 1; i++)
                    {
                        base[i].RevDate = MasterDate;
                    }
                }
            }
            base.Clear();
        }

    }
}
