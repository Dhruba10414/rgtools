/*  Project RGTools
    Copyright (c) 1997 Copyright Dakota Software Corporation All Rights Reserved.
    FILE:    SQLMODUL.H
    AUTHOR:  Marc CHANTEGREIL
    OVERVIEW
    ========
    Class definition for the management of the Module database.
    Essentially, this class contains a set of CSQLSet derived class.
    The Data Members of the CSQLSet Derived classes are protected. To get or set these data members, use the methods.
*/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace RGTools_New
{
    public enum EnumAction { GET = 1, PUT };

    //***************************************************************************
    //**///////////////////// CMModuleSet ///////////////////////////////////////
    //***************************************************************************
    class CMModuleSet : CSQLSet
    {
        
        // Data Members
        protected long m_lModuleSN = -1;           // Serial Number.
        protected string m_sModuleName = string.Empty;          // Name.

        //********** Constructors, Destructors ************************************
        public CMModuleSet(string Table)
                : base(Table)
        {
            m_sListField = "ModuleSN, ModuleName";

            SelectAllBase();
        }
       
        public CMModuleSet(string Table, bool NeedQuery)
            : base(Table)
        {
            m_sListField = "ModuleSN, ModuleName";

            if (NeedQuery)
            {
                SelectAllBase();
            }
        }
        ~CMModuleSet() { }
        //********** Public Properties Methods ************************************
        public long GetModuleSN() { return m_lModuleSN; }
        public string GetModuleName() { return m_sModuleName; }

        public long ModuleSN
        {
            get
            {
                return m_lModuleSN;
            }
        }

        public string ModuleName
        {
            get
            {
                return m_sModuleName;
            }
        }
        //********** Public Query Methods *****************************************
        //public EnumSQLError SelectSN(long ModuleSN)
        //{
        //    string Query = ("SELECT " + m_sListField + " FROM module WHERE ModuleSN = " + (ModuleSN));

        //    return SelectUniqueQuery(Query);
        //}
        public EnumSQLError SelectSNDS(long ModuleSN)
        {
            //string Query = ("SELECT " + m_sListField + " FROM module WHERE ModuleSN = " + (ModuleSN));

            //return SelectUniqueQueryDS(Query);
            return SelectUniqueQueryDS(m_sListField, "ModuleSN = " + ModuleSN, "ModuleName");
        }
       
        // Select an identified Module.
        //public void SelectAll()
        //{
        //    string Query = ("SELECT " + m_sListField + " FROM module ORDER BY ModuleSN");//where ModuleSN>0
        //    base.BeginQuery(Query);
        //}

        private void SelectAllBase()
        {
            string Query = ("SELECT " + m_sListField + " FROM module ORDER BY ModuleSN");//where ModuleSN>0
            base.BeginQueryBase(Query);
        }
        
        //call by getdninfo
        public void SelectAllNoSystem()
        {
            string Query = ("SELECT " + m_sListField + " FROM module WHERE ModuleSN > 0 ORDER BY ModuleSN");//where ModuleSN>0
            base.BeginQuery(Query);
        }
     
        // Select all the modules.
        //********** Overridables Methods *****************************************
        public virtual new void ClearAllFields()
        {
            m_lModuleSN = -1;
            m_sModuleName = "";
            base.ClearAllFields();
        }
        internal override void ExchangeData(EnumAction Action)
        {
            ExchangeField(Action, 0, ref m_lModuleSN);
            ExchangeField(Action, 1, ref  m_sModuleName);
        }
        internal override void ExchangeDataDS(EnumAction Action)
        {
            ExchangeFieldDS(Action, 0, ref m_lModuleSN);
            ExchangeFieldDS(Action, 1, ref  m_sModuleName);
        }

        protected virtual new short GetFieldCount() { return 2; }
    }

    //***************************************************************************
    //**///////////////////// CMModuleVersionSet ////////////////////////////////
    //***************************************************************************
    class CMModuleVersionSet : CSQLSet
    {
        // Data Members
        protected long m_lModuleSN = -1;
        protected short m_iModuleVersionSN = -1;    // The current version.
        protected string m_sVersionName = "";        // Name.
        protected long m_lResearchDate = -1;

        public CMModuleVersionSet(string Table)
                : base(Table)
        {
            ClearAllFields();
            m_sListField = "ModuleSN, ModuleVersionSN, VersionName, DAResearchDate";

            SelectAllBase();
        }
        ~CMModuleVersionSet() { }
        //********** Public Properties Methods ************************************
        public long GetModuleSN() { return m_lModuleSN; }
        public short GetModuleVersionSN() { return m_iModuleVersionSN; }
        public string GetVersionName() { return m_sVersionName; }
        public long GetResearchDate() { return m_lResearchDate; }

        public void PutModuleVersionSN(short ModuleVersionSN) { m_iModuleVersionSN = ModuleVersionSN; }
        public void PutVersionName(string VersionName) { m_sVersionName = VersionName; }

        public long ModuleSN
        {
            get
            {
                return m_lModuleSN;
            }
        }
        public short ModuleVersionSN
        {
            get
            { 
                return m_iModuleVersionSN; 
            }
            set
            {
                m_iModuleVersionSN = value;
            }
        }
        public string VersionName
        {
            get
            {
                return m_sVersionName;
            }
            set
            {
                m_sVersionName = value;
            }
        }
        public long ResearchDate
        {
            get
            {
                return m_lResearchDate;
            }
        }

        ////********** Public Query Methods *****************************************
        //public EnumSQLError SelectSN(long ModuleSN, short VersionSN)
        //{
        //    string Query = "SELECT " + m_sListField + " FROM ModuleVersion WHERE ModuleSN = " + (ModuleSN.ToString()) +
        //         " AND ModuleVersionSN = ";//+ (ModuleVersionSN));
        //    return SelectUniqueQuery(Query);
        //}

        // Select an identified Module for a given version
        //public void SelectForModule(long ModuleSN)
        //{
        //    string Query = ("SELECT " + m_sListField + " FROM ModuleVersion WHERE ModuleSN = " + (ModuleSN) +
        //                  " ORDER BY ModuleVersionSN");
        //    base.BeginQuery(Query);
        //}
        public void SelectForModuleDS(long ModuleSN)
        {
            base.BeginQueryDS(m_sListField, "ModuleSN = " + ModuleSN, "ModuleVersionSN");
        }
        //public void SelectForModuleDsc(long ModuleSN)   //for merge DB?
        //{
        //    string Query = ("SELECT " + m_sListField + " FROM ModuleVersion WHERE ModuleSN = " + (ModuleSN) +
        //                  " ORDER BY ModuleVersionSN DESC");
        //    base.BeginQuery(Query);
        //}
        //public void SelectAll()
        //{
        //    string Query = ("SELECT " + m_sListField + " FROM ModuleVersion ORDER BY ModuleVersionSN");
        //    base.BeginQuery(Query);
        //}
        //public void SelectAllDsc()
        //{
        //    string Query = ("SELECT " + m_sListField + " FROM ModuleVersion ORDER BY ModuleVersionSN DESC");
        //    base.BeginQuery(Query);
        //}
        private void SelectAllBase()
        {
            string Query = ("SELECT " + m_sListField + " FROM ModuleVersion order by ModuleSN, ModuleVersionSN");
            base.BeginQueryBase(Query);
        }

        //using by merge
        public void SelectDAResearchDateVersion()
        {
            string Query = "SELECT Max(ModuleSN), Max(ModuleVersionSN), Max(VersionName), DAResearchDate " +
                             "FROM ModuleVersion WHERE DAResearchDate > 0 GROUP BY DAResearchDate " +
                             "ORDER BY DAResearchDate Desc";
            base.BeginQuery(Query);
        }

        //********** Overridables Methods *****************************************
        public virtual new void ClearAllFields()
        {
            m_lModuleSN = -1;
            m_iModuleVersionSN = -1;
            m_sVersionName = "";
            m_lResearchDate = -1;
            base.ClearAllFields();
        }
        internal override void ExchangeData(EnumAction Action)
        {
            ExchangeField(Action, 0, ref m_lModuleSN);
            ExchangeField(Action, 1, ref m_iModuleVersionSN);
            ExchangeField(Action, 2, ref m_sVersionName);
            ExchangeField(Action, 3, ref m_lResearchDate);
        }
        internal override void ExchangeDataDS(EnumAction Action)
        {
            ExchangeFieldDS(Action, 0, ref m_lModuleSN);
            ExchangeFieldDS(Action, 1, ref m_iModuleVersionSN);
            ExchangeFieldDS(Action, 2, ref m_sVersionName);
            ExchangeFieldDS(Action, 3, ref m_lResearchDate);
        }
        protected virtual new short GetFieldCount() { return 4; }
    }

    //***************************************************************************
    //**///////////////////// CMRetiredQuestSet ////////////////////////////////
    //***************************************************************************
    class CMRetiredQuestSet : CSQLSet
    {
        // Data Members
        protected long m_lNewQuestionSN = -1;
        protected long m_lOldQuestionSN = -1;

        public CMRetiredQuestSet(string Table)
            : base(Table)
        {
            ClearAllFields();
            m_sListField = "NewQuestionSN, OldQuestionSN";

            SelectAllBase();
        }
        ~CMRetiredQuestSet() { }
        //********** Public Properties Methods ************************************
        public long NewQuestionSN { get { return m_lNewQuestionSN; } }
        public long OldQuestionSN { get { return m_lOldQuestionSN; } }

        private void SelectAllBase()
        {
            string Query = ("SELECT " + m_sListField + " FROM RetiredQuest");
            base.BeginQueryBase(Query);
        }

        //********** Overridables Methods *****************************************
        public virtual new void ClearAllFields()
        {
            m_lNewQuestionSN = -1;
            m_lOldQuestionSN = -1;

            base.ClearAllFields();
        }

        internal override void ExchangeData(EnumAction Action)
        {
            ExchangeField(Action, 0, ref m_lNewQuestionSN);
            ExchangeField(Action, 1, ref m_lOldQuestionSN);
        }
        internal override void ExchangeDataDS(EnumAction Action)
        {
            ExchangeFieldDS(Action, 0, ref m_lNewQuestionSN);
            ExchangeFieldDS(Action, 1, ref m_lOldQuestionSN);
        }
        protected virtual new short GetFieldCount() { return 4; }
    }

    //***************************************************************************
    //**///////////////////// CMDomainSet ///////////////////////////////////////
    //***************************************************************************
    class CMDomainSet : CSQLSet
    {
        // Data Members
        protected long m_lDomainSN = -1;          // Serial Number.
        protected long m_lModuleSN = -1;
        protected short m_iModuleVersionSN = -1;
        protected string m_sHeading = "";          // node domain name.
        protected string m_bSubQuestion = "Y";       // Is this domain defined for subquestion?
        protected string m_bMarked = "N";
        protected long m_lParentSN = -1;

        //public CMDomainSet(string Table)
        //        : base(Table)
        //{
        //    m_sListField = "DomainSN, ModuleSN, ModuleVersionSN, Heading, SubQuestion, Marked, ParentSN, ChildOrder";

        //    //SelectAllBase();
        //}
        public CMDomainSet(string Table, string ModuleSN)
            : base(Table)
        {
            m_sListField = "DomainSN, ModuleSN, ModuleVersionSN, Heading, SubQuestion, Marked, ParentSN, ChildOrder";

            SelectAllBase(ModuleSN);
        }
        public CMDomainSet(string Table,  string ModuleSN, string ModuleVersionSN)
                : base(Table)
        {
            m_sListField = "DomainSN, ModuleSN, ModuleVersionSN, Heading, SubQuestion, Marked, ParentSN, ChildOrder";

            SelectAllBase(ModuleSN, ModuleVersionSN);
        }
        ~CMDomainSet() { }
        //********** Public Properties Methods ************************************
        public long GetDomainSN() { return m_lDomainSN; }
        public long GetModuleSN() { return m_lModuleSN; }
        public short GetModuleVersionSN() { return m_iModuleVersionSN; }
        public string GetHeading() { return m_sHeading; }
        public bool GetSubQuestion() { return m_bSubQuestion == "Y"; }
        public bool GetMarked() { return m_bMarked == "Y"; }
        public long GetParentSN() { return m_lParentSN; }

        //********** Public Query Methods *****************************************
        internal void SelectAllBase()
        {
            string Query = ("SELECT " + m_sListField + " FROM DomainStructure order by DomainSN, ModuleSN, ModuleVersionSN");
            base.BeginQueryBase(Query);
        }
        internal void SelectAllBase(string ModuleSN)
        {
            string Query = ("SELECT " + m_sListField + " FROM DomainStructure where ModuleSN=" +
                    ModuleSN + " order by DomainSN, ModuleVersionSN");
            base.BeginQueryBase(Query);
        }
        internal void SelectAllBase(string ModuleSN, string ModuleVersionSN)
        {
            string Query = ("SELECT " + m_sListField + " FROM DomainStructure where ModuleSN=" +
                    ModuleSN + " and ModuleVersionSN = " + ModuleVersionSN + " order by ParentSN, ChildOrder");
            base.BeginQueryBase(Query);
        }

        internal void SelectForModuleDS(long ModuleSN, long ModuleVersionSN)
        {
            if (ModuleSN >= 0)
            {
                base.BeginQueryDS(m_sListField, "ModuleSN = " + ModuleSN +
                        " AND ModuleVersionSN = " + ModuleVersionSN, "ParentSN, ChildOrder");
            }
            else
            {
                base.BeginQueryDS(m_sListField, "ModuleSN = " + ModuleSN +
              " AND ModuleVersionSN = " + ModuleVersionSN, "ParentSN desc, ChildOrder desc");
            }
        }
      
        public void SelectChildDS(long DomainSN, long ModuleVersionSN)
        {
            BeginQueryDS(m_sListField, "ParentSN = " + DomainSN +
                    " AND ModuleVersionSN = " + ModuleVersionSN, "ChildOrder");
        }

        //********** Pure Virtual Methods *****************************************
        public virtual new void ClearAllFields()
        {
            m_lDomainSN = -1;
            m_lModuleSN = -1;
            m_iModuleVersionSN = -1;
            m_sHeading = "";
            m_bSubQuestion = "Y";
            m_bMarked = "N";
            m_lParentSN = -1;
            base.ClearAllFields();
        }     // Also a public method
        internal override void ExchangeData(EnumAction Action)
        {
            ExchangeField(Action, 0, ref m_lDomainSN);
            ExchangeField(Action, 1, ref m_lModuleSN);
            ExchangeField(Action, 2, ref m_iModuleVersionSN);
            ExchangeField(Action, 3, ref m_sHeading);
            ExchangeField(Action, 4, ref m_bSubQuestion);
            ExchangeField(Action, 5, ref m_bMarked);
            ExchangeField(Action, 6, ref m_lParentSN);
        }
        internal override void ExchangeDataDS(EnumAction Action)
        {
            ExchangeFieldDS(Action, 0, ref m_lDomainSN);
            ExchangeFieldDS(Action, 1, ref m_lModuleSN);
            ExchangeFieldDS(Action, 2, ref m_iModuleVersionSN);
            ExchangeFieldDS(Action, 3, ref m_sHeading);
            ExchangeFieldDS(Action, 4, ref m_bSubQuestion);
            ExchangeFieldDS(Action, 5, ref m_bMarked);
            ExchangeFieldDS(Action, 6, ref m_lParentSN);
        }
        protected new short GetFieldCount() { return 7; }
    }

    //***************************************************************************
    //**///////////////////// CMRGKeyWordSet ////////////////////////////////////
    //***************************************************************************
    class CMRGKeyWordSetDomain : CSQLSet
    {
        // Data Members
        protected long m_lReferenceSN = -1;
        protected string m_sKeyWord = "";
        protected long m_lTagDate = 0;

        public CMRGKeyWordSetDomain(string Table)
            : base(Table)
        {
            SelectAllBase();
        }
        public CMRGKeyWordSetDomain(string Table,  string ModuleSN)
                : base(Table)
        {
            SelectAllBase(ModuleSN);
        }
        public CMRGKeyWordSetDomain(string Table,  string ModuleSN, string ModuleVersionSN)
                : base(Table)
        {
            SelectAllBase(ModuleSN, ModuleVersionSN);
        }
        ~CMRGKeyWordSetDomain() { }
        //********** Public Properties Methods ************************************
        public long GetReferenceSN() { return m_lReferenceSN; }
        public string GetKeyWord() { return m_sKeyWord; }
        public long GetTagDate() { return m_lTagDate; }

        // All the References for a ModuleSN.
        public void SelectForDomainDS(long DomainSN)
        {
            base.BeginQueryDS("ReferenceSN, KeyWord, TagDate", "DomainSN = " + DomainSN.ToString(), "KeyWord");
        }

        internal void SelectAllBase()
        {
            string Query = "SELECT max(RGKeyWord.ReferenceSN) as ReferenceSN, KeyWord Collate SQL_Latin1_General_CP1_CS_AS as KeyWord, Max(TagDate) as TagDate, DomainSN" +
                        " FROM QDLink inner JOIN QRLink " +
                        " on QDLink.QuestionSN=QRLink.QuestionSN " +
                        " inner JOIN RGKeyWord" +
                        " on RGKeyWord.ReferenceSN=QRLink.ReferenceSN " +
                        " GROUP BY KeyWord Collate SQL_Latin1_General_CP1_CS_AS,DomainSN ORDER BY KeyWord Collate SQL_Latin1_General_CP1_CS_AS, DomainSN";
            base.BeginQueryBase(Query);
        }
        internal void SelectAllBase(string ModuleSN)
        {
            string Query = "SELECT max(RGKeyWord.ReferenceSN) as ReferenceSN, KeyWord Collate SQL_Latin1_General_CP1_CS_AS as KeyWord, Max(TagDate) as TagDate ,DomainSN" +
                        " FROM QDLink inner JOIN QRLink " +
                        " on QDLink.QuestionSN=QRLink.QuestionSN " +
                        " inner JOIN RGKeyWord " +
                        " on RGKeyWord.ReferenceSN=QRLink.ReferenceSN " +
                        " where RGKeyWord.ModuleSN=" + ModuleSN +
                        " GROUP BY KeyWord Collate SQL_Latin1_General_CP1_CS_AS,DomainSN ORDER BY KeyWord Collate SQL_Latin1_General_CP1_CS_AS, DomainSN";

            base.BeginQueryBase(Query);
        }
        internal void SelectAllBase(string ModuleSN, string ModuleVersionSN)
        {
            string Query = "SELECT max(RGKeyWord.ReferenceSN) as ReferenceSN, KeyWord Collate SQL_Latin1_General_CP1_CS_AS as KeyWord, Max(TagDate) as TagDate ,DomainSN" +
                        " FROM QDLink inner JOIN QRLink " +
                        " on QDLink.QuestionSN=QRLink.QuestionSN " +
                        " inner JOIN RGKeyWord " +
                        " on RGKeyWord.ReferenceSN=QRLink.ReferenceSN " +
                        " where QDLink.ModuleSN=" + ModuleSN +
                        " and QDLink.ModuleVersionSN=" + ModuleVersionSN + 
                        " GROUP BY KeyWord Collate SQL_Latin1_General_CP1_CS_AS,DomainSN ORDER BY KeyWord Collate SQL_Latin1_General_CP1_CS_AS,DomainSN";

            base.BeginQueryBase(Query);
        }//where RGKeyWord.modulesn=11570
        //********** Overridables Methods *****************************************
        internal override void ExchangeDataDS(EnumAction Action)
        {
            ExchangeFieldDS(Action, 0, ref m_lReferenceSN);
            ExchangeFieldDS(Action, 1, ref m_sKeyWord);
            ExchangeFieldDS(Action, 2, ref m_lTagDate);
        }
        public virtual new void ClearAllFields()
        {
            m_lReferenceSN = -1;
            m_sKeyWord = "";
            m_lTagDate = 0;
            base.ClearAllFields();
        }
        public virtual new short GetFieldCount() { return 3; }
    }
    class CMRGKeyWordSetQuestion : CSQLSet
    {
        // Data Members
        protected long m_lReferenceSN = -1;
        protected string m_sKeyWord = "";
        protected long m_lTagDate = 0;

        public CMRGKeyWordSetQuestion(string Table)
            : base(Table)
        {
            m_sListField = "RGKeyWord.ReferenceSN as ReferenceSN, KeyWord, TagDate, QuestionSN, SEQUENCE";

            SelectAllBase();
        }
        public CMRGKeyWordSetQuestion(string Table, string ModuleSN)
            : base(Table)
        {
            m_sListField = "RGKeyWord.ReferenceSN as ReferenceSN, KeyWord, TagDate, QuestionSN, SEQUENCE";

            SelectAllBase(ModuleSN);
        }
        public CMRGKeyWordSetQuestion(string Table, long QuestionSN)
            : base(Table)
        {
            m_sListField = "RGKeyWord.ReferenceSN as ReferenceSN, KeyWord, TagDate, QuestionSN, SEQUENCE";

            SelectAllBase(QuestionSN);
        }
        public CMRGKeyWordSetQuestion(string Table,  string ModuleSN, string ModuleVersionSN)
            : base(Table)
        {
            m_sListField = "RGKeyWord.ReferenceSN as ReferenceSN, KeyWord, TagDate, QuestionSN,SEQUENCE";

            SelectAllBase(ModuleSN, ModuleVersionSN);
        }
        ~CMRGKeyWordSetQuestion() { }
        //public CMRGKeyWordSetQuestion(string Table, string DSN, string User, string PassWord, long QuestionSN)
        //    : base(null, Table, DSN, User, PassWord)
        //{
        //    m_sListField = "RGKeyWord.ReferenceSN as ReferenceSN, KeyWord, TagDate, QuestionSN";

        //    SelectAllBase(QuestionSN);
        //}
        //********** Public Properties Methods ************************************
        internal void SelectAllBase()
        {
            string Query = "SELECT " + m_sListField +
                " FROM QRLink inner JOIN RGKeyWord " +
                " on RGKeyWord.ReferenceSN=QRLink.ReferenceSN "+
                " order by QuestionSN";

            base.BeginQueryBase(Query);
        }
        internal void SelectAllBase(string ModuleSN)
        {
            string Query = "SELECT " + m_sListField +
                " FROM QRLink inner JOIN RGKeyWord " +
                " on RGKeyWord.ReferenceSN=QRLink.ReferenceSN " +
                " where ModuleSN=" + ModuleSN;// +" order by QuestionSN";

            base.BeginQueryBase(Query);
        }
        internal void SelectAllBase(string ModuleSN, string ModuleVersionSN)
        {
            string Query = "SELECT RGKeyWord.ReferenceSN as ReferenceSN, KeyWord, TagDate, QRLink.QuestionSN as QuestionSN, SEQUENCE" +
                    " FROM QDLink INNER JOIN QRLink  on QDLink .QuestionSN = QRLink.QuestionSN "+
                    " INNER JOIN RGKeyWord on QRLink.ReferenceSN = RGKeyWord.ReferenceSN where QDLink.ModuleSN=" +
                    ModuleSN + " and ModuleVersionSN = " + ModuleVersionSN + " order by QuestionSN";

//            SELECT RGKeyWord.ReferenceSN as ReferenceSN, KeyWord, TagDate, QRLink.QuestionSN as QuestionSN 
//FROM QDLink INNER JOIN QRLink 
//on QDLink .QuestionSN = QRLink.QuestionSN 
//KEY JOIN RGKeyWord 
//where QDLink.ModuleSN=11570 and ModuleVersionSN = 0 
//order by QuestionSN

            base.BeginQueryBase(Query);
        }
        internal void SelectAllBase(long QuestionSN)
        {
            string Query = "SELECT " + m_sListField + 
                    " FROM QRLink inner JOIN RGKeyWord "+
                    " on RGKeyWord.ReferenceSN=QRLink.ReferenceSN " +
                    " where QuestionSN=" + QuestionSN.ToString() + " order by ModuleSN";

            base.BeginQueryBase(Query);
        }
        public long GetReferenceSN() { return m_lReferenceSN; }
        public string GetKeyWord() { return m_sKeyWord; }
        public long GetTagDate() { return m_lTagDate; }
        //********** Public Properties Methods ************************************
        public void SelectForQuestionDS(long QuestionSN)
        {
            BeginQueryDS("ReferenceSN, KeyWord, TagDate", "QuestionSN = " + QuestionSN.ToString(), "");
        }
        public void SelectForQuestion (long QuestionSN)
        {
            string Query = "SELECT " + m_sListField +
                    " FROM QRLink inner JOIN RGKeyWord " +
                    " on RGKeyWord.ReferenceSN=QRLink.ReferenceSN " +
                    " WHERE QuestionSN = " + QuestionSN.ToString();

            BeginQuery(Query);
        }
        //********** Overridables Methods *****************************************
        internal override void ExchangeData(EnumAction Action)
        {
            ExchangeField(Action, 0, ref m_lReferenceSN);
            ExchangeField(Action, 1, ref m_sKeyWord);
            ExchangeField(Action, 2, ref m_lTagDate);
        }
        internal override void ExchangeDataDS(EnumAction Action)
        {
            ExchangeFieldDS(Action, 0, ref m_lReferenceSN);
            ExchangeFieldDS(Action, 1, ref m_sKeyWord);
            ExchangeFieldDS(Action, 2, ref m_lTagDate);
        }
        public virtual new void ClearAllFields()
        {
            m_lReferenceSN = -1;
            m_sKeyWord = "";
            m_lTagDate = 0;
            base.ClearAllFields();
        }
        public virtual new short GetFieldCount() { return 3; }
    }
    class CMRGKeyWordSetModule : CSQLSet
    {
        // Data Members
        protected long m_lReferenceSN = -1;
        protected string m_sKeyWord = "";
        protected long m_lTagDate = 0;

        public CMRGKeyWordSetModule(string Table)
            : base(Table)
        {
            m_sListField = "ReferenceSN, KeyWord, TagDate, ModuleSN";
        }
        public CMRGKeyWordSetModule(string Table,  string ModuleSN)
            : base(Table)
        {
            m_sListField = "ReferenceSN, KeyWord, TagDate, ModuleSN";

            SelectAllBase(ModuleSN);
        }
        ~CMRGKeyWordSetModule() { }
        //********** Public Properties Methods ************************************
        public long GetReferenceSN() { return m_lReferenceSN; }
        public string GetKeyWord() { return m_sKeyWord; }
        public long GetTagDate() { return m_lTagDate; }

        public string KeyWord
        {
            get
            {
                return m_sKeyWord;
            }
        }
        public long ReferenceSN
        {
            get
            {
                return m_lReferenceSN;
            }
        }
        public long TagDate
        {
            get
            {
                return m_lTagDate;
            }
        }

        //********** Public Query Methods *****************************************
        public void SelectForModuleDS(long ModuleSN)
        {
            base.BeginQueryDS(m_sListField, "ModuleSN = " + ModuleSN, "KeyWord");
        }

        //private void SelectAllBase()
        //{
        //    string Query = "SELECT " + m_sListField + " FROM RGKeyWord ORDER BY KeyWord";
        //    base.BeginQueryBase(Query);
        //}
        internal void SelectAllBase(string ModuleSN)
        {
            string Query = "SELECT " + m_sListField + " FROM RGKeyWord where ModuleSN=" +
                    ModuleSN + " ORDER BY KeyWord";

            base.BeginQueryBase(Query);
        }

        internal void SelectAllDesc()
        {
            string Query = "SELECT " + m_sListField + " FROM RGKeyWord ORDER BY ReferenceSN DESC";
            BeginQuery(Query);
        }

        //********** Overridables Methods *****************************************
        internal override void ExchangeData(EnumAction Action)
        {
            ExchangeField(Action, 0, ref m_lReferenceSN);
            ExchangeField(Action, 1, ref m_sKeyWord);
            ExchangeField(Action, 2, ref m_lTagDate);
        }
        internal override void ExchangeDataDS(EnumAction Action)
        {
            ExchangeFieldDS(Action, 0, ref m_lReferenceSN);
            ExchangeFieldDS(Action, 1, ref m_sKeyWord);
            ExchangeFieldDS(Action, 2, ref m_lTagDate);
        }
        public virtual new void ClearAllFields()
        {
            m_lReferenceSN = -1;
            m_sKeyWord = "";
            m_lTagDate = 0;
            base.ClearAllFields();
        }
        public virtual new short GetFieldCount() { return 3; }
    }

    //***************************************************************************
    //**///////////////////// CMApplicVarSet ////////////////////////////////////
    //***************************************************************************
    class CMApplicVarSet : CSQLSet
    {
        // Data Members
        protected long m_lApplicSN = -1;
        protected string m_eAClass = "D";           // Enum Type doesn't exist in WATCOM SQL.
        protected long m_lASN = -1;
        protected string m_eApplicability = "U";

        public CMApplicVarSet(string Table)
            : base(Table)
        {
            m_sListField = "ApplicSN, AClass, ASN, Applicability, ModuleSN, ModuleVersionSN";

            SelectAllBase();
        }
        public CMApplicVarSet(string Table,  string ModuleSN)
            : base(Table)
        {
            m_sListField = "ApplicSN, AClass, ASN, Applicability, ModuleSN, ModuleVersionSN";

            SelectAllBase(ModuleSN);
        }
        public CMApplicVarSet(string Table,  string ModuleSN, string ModuleVersionSN)
            : base(Table)
        {
            m_sListField = "ApplicSN, AClass, ASN, Applicability, ModuleSN, ModuleVersionSN";

            SelectAllBase(ModuleSN, ModuleVersionSN);
        }
        ~CMApplicVarSet() { }
        //********** Public Properties Methods ************************************
        public long GetApplicSN() { return m_lApplicSN; }
        public long GetASN() { return m_lASN; }
        public char GetAClass() { return m_eAClass[0]; }
        public char GetApplicability() { return m_eApplicability[0]; }

        //********** Public Query Methods *****************************************
        internal void SelectAllBase()
        {
            string Query = ("SELECT " + m_sListField + " FROM ApplicabilityVariable order by ModuleSN");

            base.BeginQueryBase(Query);
        }
        internal void SelectAllBase(string ModuleSN)
        {
            string Query = ("SELECT " + m_sListField + " FROM ApplicabilityVariable where ModuleSN=" +
                    ModuleSN + " order by ModuleVersionSN");

            base.BeginQueryBase(Query);
        }
        internal void SelectAllBase(string ModuleSN, string ModuleVersionSN)
        {
            string Query = ("SELECT " + m_sListField + " FROM ApplicabilityVariable where ModuleSN=" +
                    ModuleSN + " and ModuleVersionSN=" + ModuleVersionSN + " order by ModuleVersionSN");

            base.BeginQueryBase(Query);
        }
        public void SelectForModuleDS(long ModuleSN, short ModuleVersionSN)
        {
            base.BeginQueryDS(m_sListField, "ModuleSN = " + ModuleSN +
                        " AND ModuleVersionSN = " + ModuleVersionSN.ToString(), "ApplicSN");

        }
        //public void SelectForModule(long ModuleSN, short ModuleVersionSN)
        //{
        //    string Query = ("SELECT " + m_sListField + " FROM ApplicabilityVariable WHERE ModuleSN = " + (ModuleSN) +
        //                " AND ModuleVersionSN = " + (ModuleVersionSN.ToString()) + " ORDER BY ApplicSN");
        //    BeginQuery(Query);
        //}

        //********** Overridables Methods *****************************************
        internal override void ExchangeDataDS(EnumAction Action)
        {
            ExchangeFieldDS(Action, 0, ref m_lApplicSN);
            ExchangeFieldDS(Action, 1, ref m_eAClass);
            ExchangeFieldDS(Action, 2, ref m_lASN);
            ExchangeFieldDS(Action, 3, ref m_eApplicability);
        }
        internal override void ExchangeData(EnumAction Action)
        {
            ExchangeField(Action, 0, ref m_lApplicSN);
            ExchangeField(Action, 1, ref m_eAClass);
            ExchangeField(Action, 2, ref m_lASN);
            ExchangeField(Action, 3, ref m_eApplicability);
        }
        public virtual new void ClearAllFields()
        {
            m_lApplicSN = -1;
            m_eAClass = "D";
            m_lASN = -1;
            m_eApplicability = "U";
            base.ClearAllFields();
        }
        public virtual new short GetFieldCount() { return 4; }
      
    }
    class CMApplicVarSetPure : CSQLSet
    {
        // Data Members
        protected long m_lApplicSN = -1;
        protected string m_eAClass = "D";          // Enum Type doesn't exist in WATCOM SQL.
        protected long m_lASN = -1;
        protected string m_eApplicability = "U";

        //public CMApplicVarSetPure(string Table, string DSN, string User, string PassWord)
        //    : base(null, Table, DSN, User, PassWord)
        //{
        //    m_sListField = "ApplicSN, AClass, ASN, Applicability, ModuleSN, ModuleVersionSN";

        //    SelectAllBase();
        //}
        //public CMApplicVarSetPure(string Table,  string ModuleSN)
        //    : base(Table)
        //{
        //    m_sListField = "ApplicSN, AClass, ASN, Applicability, ModuleSN, ModuleVersionSN";

        //    SelectAllBase(ModuleSN);
        //}
        public CMApplicVarSetPure(string Table,  string ModuleSN, string ModuleVersionSN)
            : base(Table)
        {
            m_sListField = "ApplicSN, AClass, ASN, Applicability, ModuleSN, ModuleVersionSN";

            SelectAllBase(ModuleSN, ModuleVersionSN);
        }
        public CMApplicVarSetPure(string Table, string ModuleVersionSN)
            : base(Table)
        {
            m_sListField = "ApplicSN, AClass, ASN, Applicability, ModuleSN, ModuleVersionSN";

            SelectAllBase(ModuleVersionSN);
        }
        ~CMApplicVarSetPure() { }

        //********** Public Properties Methods ************************************
        public long GetApplicSN() { return m_lApplicSN; }
        public long GetASN() { return m_lASN; }
        public char GetAClass() { return m_eAClass[0]; }
        public char GetApplicability() { return m_eApplicability[0]; }

        //********** Public Query Methods *****************************************
        internal void SelectAllBase()
        {
            string Query = "SELECT " + m_sListField + " FROM ApplicabilityVariable " +
                    "WHERE AClass = 'Q' AND NOT EXISTS (SELECT QuestionSN FROM QDLink " +
                    "WHERE QDLink.ModuleSN = ApplicabilityVariable.ModuleSN " +
                    "AND QDLink.ModuleVersionSN = ApplicabilityVariable.ModuleVersionSN " +
                    "AND QDLink.QuestionSN = ApplicabilityVariable.ASN) ORDER BY ApplicSN";

            base.BeginQueryBase(Query);
        }
        //internal void SelectAllBase(string ModuleSN)
        //{
        //    string Query = "SELECT " + m_sListField + " FROM ApplicabilityVariable " +
        //            "WHERE AClass = 'Q' AND ModuleSN=" + ModuleSN + " AND NOT EXISTS (SELECT QuestionSN FROM QDLink " +
        //            "WHERE QDLink.ModuleSN = " + ModuleSN +
        //            "AND QDLink.ModuleVersionSN = ApplicabilityVariable.ModuleVersionSN " +
        //            "AND QDLink.QuestionSN = ApplicabilityVariable.ASN) ORDER BY ApplicSN";

        //    base.BeginQueryBase(Query);
        //}
        internal void SelectAllBase(string ModuleVersionSN)
        {
            string Query = "SELECT " + m_sListField + " FROM ApplicabilityVariable " +
                    " WHERE AClass = 'Q' AND ApplicabilityVariable.ModuleVersionSN=" + ModuleVersionSN + " AND NOT EXISTS (SELECT QuestionSN FROM QDLink " +
                    " WHERE QDLink.ModuleVersionSN = " + ModuleVersionSN +
                    " AND QDLink.ModuleVersionSN = ApplicabilityVariable.ModuleVersionSN " +
                    " AND QDLink.QuestionSN = ApplicabilityVariable.ASN) ORDER BY ApplicSN";

            base.BeginQueryBase(Query);
        }
        internal void SelectAllBase(string ModuleSN, string ModuleVersionSN)
        {
            string Query = "SELECT " + m_sListField + " FROM ApplicabilityVariable " +
                    " WHERE AClass = 'Q' AND ModuleSN=" + ModuleSN + " AND ModuleVersionSN=" + ModuleVersionSN + 
                    " AND NOT EXISTS (SELECT QuestionSN FROM QDLink " +
                    " WHERE QDLink.ModuleSN = " + ModuleSN + "  and QDLink.ModuleVersionSN = " + ModuleVersionSN +
                    " AND QDLink.ModuleVersionSN = ApplicabilityVariable.ModuleVersionSN " +
                    " AND QDLink.QuestionSN = ApplicabilityVariable.ASN) ORDER BY ApplicSN";

            base.BeginQueryBase(Query);
        }  //public void SelectForModuleDS(long ModuleSN, short ModuleVersionSN)
         //public void SelectForModule(long ModuleSN, short ModuleVersionSN)
        //{
        //    string Query = ("SELECT " + m_sListField + " FROM ApplicabilityVariable WHERE ModuleSN = " + (ModuleSN) +
        //                " AND ModuleVersionSN = " + (ModuleVersionSN.ToString()) + " ORDER BY ApplicSN");
        //    BeginQuery(Query);
        //}
        // The Applicability Variables for a ModuleSN.
        //public void SelectPureForModule(long ModuleSN, short ModuleVersionSN)
        //{
        //    string Query = ("SELECT " + m_sListField + " FROM ApplicabilityVariable WHERE ModuleSN = " + (ModuleSN.ToString()) +
        //             " AND ModuleVersionSN = " + (ModuleVersionSN.ToString()) + " AND AClass = 'Q'" +
        //             " AND NOT EXISTS (SELECT QuestionSN FROM QDLink WHERE QDLink.ModuleSN = " + (ModuleSN.ToString()) +
        //             " AND QDLink.ModuleVersionSN = " + (ModuleVersionSN.ToString()) +
        //             " AND QDLink.QuestionSN = ApplicabilityVariable.ASN) ORDER BY ApplicSN");
        //    BeginQuery(Query);
        //}
        public void SelectPureForModuleDS(long ModuleSN, short ModuleVersionSN)
        {
            this.BeginQueryDS(m_sListField, "ModuleSN = " + ModuleSN.ToString() +
                     " AND ModuleVersionSN = " + ModuleVersionSN.ToString(), "ApplicSN");
        }
        public void SelectPureForModuleDS(long ModuleSN)
        {
            this.BeginQueryDS(m_sListField, "ModuleSN = " + ModuleSN.ToString(), "ApplicSN");
        }

        //********** Overridables Methods *****************************************
        internal override void ExchangeDataDS(EnumAction Action)
        {
            ExchangeFieldDS(Action, 0, ref m_lApplicSN);
            ExchangeFieldDS(Action, 1, ref m_eAClass);
            ExchangeFieldDS(Action, 2, ref m_lASN);
            ExchangeFieldDS(Action, 3, ref m_eApplicability);
        }
        internal override void ExchangeData(EnumAction Action)
        {
            ExchangeField(Action, 0, ref m_lApplicSN);
            ExchangeField(Action, 1, ref m_eAClass);
            ExchangeField(Action, 2, ref m_lASN);
            ExchangeField(Action, 3, ref m_eApplicability);
        }
        public virtual new void ClearAllFields()
        {
            m_lApplicSN = -1;
            m_eAClass = "D";
            m_lASN = -1;
            m_eApplicability = "U";
            base.ClearAllFields();
        }
        public virtual new short GetFieldCount() { return 4; }

    }

    //***************************************************************************
    //**///////////////////// CMTemplateRuleSet ////////////////////////////////
    //***************************************************************************
    class CMTemplateRuleSet : CSQLSet
    {
        // Data Members
        protected long m_lRuleSN = -1;
        protected long m_lSetSN = -1;   
        protected long m_eOp = -1;              // Enum Type doesn't exist in WATCOM SQL.
        protected long m_lCompASN = -1;
        protected long m_lCompBSN = -1;

        public CMTemplateRuleSet(string Table)
            : base(Table)
        {
            m_sListField = "RuleSN, SetSN, Op, CompASN, CompBSN, ModuleSN, ModuleVersionSN";

            SelectAllBase();
        }
        public CMTemplateRuleSet(string Table,  string ModuleSN)
            : base(Table)
        {
            m_sListField = "RuleSN, SetSN, Op, CompASN, CompBSN, ModuleSN, ModuleVersionSN";

            SelectAllBase(ModuleSN);
        }
        public CMTemplateRuleSet(string Table,  string ModuleSN, string ModuleVersionSN)
            : base(Table)
        {
            m_sListField = "RuleSN, SetSN, Op, CompASN, CompBSN, ModuleSN, ModuleVersionSN";

            SelectAllBase(ModuleSN, ModuleVersionSN);
        }
        ~CMTemplateRuleSet() { }
        //********** Public Properties Methods ************************************
        public long GetRuleSN() { return m_lRuleSN; }
        public long GetSetSN() { return m_lSetSN; }
        public long GetCompASN() { return m_lCompASN; }
        public long GetCompBSN() { return m_lCompBSN; }
        public long GetOp() { return m_eOp; }

        //********** Public Query Methods *****************************************
        //public void SelectForModule(long ModuleSN, short ModuleVersionSN)
        //{
        //    string Query = ("SELECT " + m_sListField + " FROM TemplateRule WHERE ModuleSN = " + (ModuleSN.ToString()) +
        //             " AND ModuleVersionSN = " + (ModuleVersionSN.ToString()) + " ORDER BY SetSN");
        //    BeginQuery(Query);
        //}  // All the Template Rules for a ModuleSN.
        public void SelectForModuleDS(long ModuleSN, short ModuleVersionSN)
        {
            base.BeginQueryDS(m_sListField, "ModuleSN = " + ModuleSN.ToString() +
                     " AND ModuleVersionSN = " + ModuleVersionSN.ToString(), "SetSN");

        }  
        internal void SelectAllBase()
        {
            string Query = ("SELECT " + m_sListField + " FROM TemplateRule order by ModuleSN, ModuleVersionSN ");
            base.BeginQueryBase(Query);
        }
        internal void SelectAllBase(string ModuleSN)
        {
            string Query = ("SELECT " + m_sListField + " FROM TemplateRule where ModuleSN="
                    + ModuleSN + " order by ModuleVersionSN");
            base.BeginQueryBase(Query);
        }
        internal void SelectAllBase(string ModuleSN, string ModuleVersionSN)
        {
            string Query = ("SELECT " + m_sListField + " FROM TemplateRule where ModuleSN="
                    + ModuleSN + "and ModuleVersionSN = " + ModuleVersionSN + " order by SetSN");
            base.BeginQueryBase(Query);
        }
      
        //********** Overridables Methods *****************************************
        internal override void ExchangeData(EnumAction Action)
        {
            ExchangeField(Action, 0, ref m_lRuleSN);
            ExchangeField(Action, 1, ref m_lSetSN);
            ExchangeField(Action, 2, ref m_eOp);
            ExchangeField(Action, 3, ref m_lCompASN);
            ExchangeField(Action, 4, ref m_lCompBSN);
        }
        internal override void ExchangeDataDS(EnumAction Action)
        {
            ExchangeFieldDS(Action, 0, ref m_lRuleSN);
            ExchangeFieldDS(Action, 1, ref m_lSetSN);
            ExchangeFieldDS(Action, 2, ref m_eOp);
            ExchangeFieldDS(Action, 3, ref m_lCompASN);
            ExchangeFieldDS(Action, 4, ref m_lCompBSN);
        }
        public virtual new void ClearAllFields()
        {
            m_lRuleSN = -1;
            m_lSetSN = -1;
            //m_eOp = 1;
            m_lCompASN = -1;
            m_lCompBSN = -1;
            base.ClearAllFields();
        }
        public virtual new short GetFieldCount() { return 5; }
      
    }

    //***************************************************************************
    //**///////////////////// CMQuestionSet /////////////////////////////////////
    //***************************************************************************
    class CMQuestionSet : CSQLSet
    {
        public enum QType { DTMessage, DTBooleanList, DTBoolean, DTSingleSelect, DTTextEntry, DTNumeric, DTGLRState };

        // Data Members
        protected long m_lQuestionSN = -1;          // Serial Number.
        protected string m_sStdText = "";
        protected string m_sListAnswer = "";
        protected string m_sNoteText=string.Empty;
        protected int m_iRFValue = -1;
        protected string m_eDataType = "L";
        protected string m_sRGKeyWordList=string.Empty;       // Exist, only for inactive questions.
        protected long m_lProperties = 0;
        protected TypeSet m_eTypeSet;             // enum {TypeSet.NormalSet for all the fields; MiniSet for QuestionSN and Properties }.

        public long ModuleSN = -1;
        //********** Constructors, Destructors ************************************
        public CMQuestionSet(string Table, 
                    TypeSet eTypeSet, string ModuleSN, string ModuleVersionSN)
            : base(Table)
        {
            m_eTypeSet = eTypeSet;
            m_sListField = "Question.QuestionSN as QuestionSN, Properties";
            if (m_eTypeSet == TypeSet.NormalSet)
            {
                m_sListField += ", RFValue, DataType";
            }

            SelectAllBase(ModuleSN, ModuleVersionSN);
        }

        public CMQuestionSet(string Table,  TypeSet eTypeSet, string ModuleSN)
            : base(Table)
        {
            m_eTypeSet = eTypeSet;
            m_sListField = "Question.QuestionSN as QuestionSN, Properties";
            if (m_eTypeSet == TypeSet.NormalSet)
            {
                m_sListField += ", RFValue, DataType";
            }

            SelectAllBase(ModuleSN);
        }
        public CMQuestionSet(string Table, string DSN, string User, string PassWord, TypeSet eTypeSet)
            : base(null, Table, DSN, User, PassWord)
        {
            m_eTypeSet = eTypeSet;
            m_sListField = "Question.QuestionSN as QuestionSN, Properties";
            if (m_eTypeSet == TypeSet.NormalSet)
            {
                m_sListField += ", RFValue, DataType";
            }

            SelectAllBase();
        }
        public CMQuestionSet(string Table)
            : base(Table)
        {
            m_eTypeSet = TypeSet.NormalSet;
            m_sListField = "QuestionSN, Properties";
            if (m_eTypeSet == TypeSet.NormalSet)
            {
                m_sListField += ", RFValue, DataType";
            }

            SelectAllBase();
        }
        public CMQuestionSet(string Table, string DSN, string User, string PassWord, bool blQueyRun)
            : base(null, Table, DSN, User, PassWord)
        {
            m_eTypeSet = TypeSet.NormalSet;
            m_sListField = "QuestionSN, Properties";
            
            if (!blQueyRun)
            {
                return;
            }

            if (m_eTypeSet == TypeSet.NormalSet)
            {
                m_sListField += ", RFValue, DataType";
            }

            SelectAllBase();
        }
        ~CMQuestionSet() { }
        //********** Public Properties Methods ************************************
        public long GetQuestionSN() { return m_lQuestionSN; }
        public string GetStdText() { return m_sStdText; }
        public string GetListAnswer() { return m_sListAnswer; }
        public string GetNoteText() { return m_sNoteText; }
        public int GetRFValue() { return m_iRFValue; }
        public string GetRGKeyWordList() { return m_sRGKeyWordList; }
        public long GetProperties() { return m_lProperties; }

        public QType GetDataType()
        {
            switch (m_eDataType)
            {
                case "M": return QType.DTMessage;
                case "L": return QType.DTBooleanList;
                case "B": return QType.DTBoolean;
                case "S": return QType.DTSingleSelect;
                case "T": return QType.DTTextEntry;
                case "N": return QType.DTNumeric;
                case "G": return QType.DTGLRState;
            }
            return QType.DTBoolean;    // Default value.
        }

        //********** Public Query Methods *****************************************
        public EnumSQLError SelectSNDS(long QuestionSN)
        {
            string BigQuery = m_sListField;
            if (m_eTypeSet == TypeSet.NormalSet)
            {
                BigQuery += ", StdText, NoteText, ListAnswer, RGKeyWordList ";
            }

            return SelectUniqueQueryDS(BigQuery, "QuestionSN = " + QuestionSN.ToString(), string.Empty);
        }

        internal void SelectAllBase()
        {
            string BigQuery = m_sListField;
            if (m_eTypeSet == TypeSet.NormalSet)
            {
                BigQuery += ", StdText, NoteText, ListAnswer, RGKeyWordList ";
            }

            string Query = ("SELECT " + BigQuery +
                    " FROM Question inner JOIN QuestionBody " +
                    " on Question.QuestionBodySN=QuestionBody.QuestionBodySN "+
                    " order by QuestionSN");

            base.BeginQueryBase(Query, true);
        }
        internal void SelectAllBase(string ModuleSN)
        {
            string BigQuery = m_sListField;
            if (m_eTypeSet == TypeSet.NormalSet)
            {
                BigQuery += ", StdText, NoteText, ListAnswer, RGKeyWordList ";
            }

            string Query = ("SELECT " + BigQuery +
                    " FROM QDLink INNER JOIN Question on QDLink.QuestionSN=Question .QuestionSN " +
                    " inner JOIN QuestionBody " +
                    " on Question.QuestionBodySN=QuestionBody.QuestionBodySN " +
                    " where ModuleSN=" + ModuleSN + " order by QuestionSN");

            base.BeginQueryBase(Query);
        }
        internal void SelectAllBase(string ModuleSN, string ModuleVersionSN)
        {
            string BigQuery = m_sListField;
            if (m_eTypeSet == TypeSet.NormalSet)
            {
                BigQuery += ", StdText, NoteText, ListAnswer, RGKeyWordList ";
            }

            string Query = ("SELECT " + BigQuery +
                    " FROM QDLink INNER JOIN Question on QDLink.QuestionSN=Question .QuestionSN " +
                    " inner JOIN QuestionBody "+
                    " on Question.QuestionBodySN=QuestionBody.QuestionBodySN " +
                    " where ModuleSN=" + ModuleSN +
                    " And ModuleVersionSN = " + ModuleVersionSN + " order by QuestionSN");

            base.BeginQueryBase(Query);
        }

        public virtual new void ClearAllFields()
        {
            m_lQuestionSN = -1;
            m_lProperties = 0;
            m_sStdText = "";
            m_sListAnswer = "";
            m_sRGKeyWordList = "";
            m_iRFValue = -1;
            m_eDataType = "L";// CMQuestionSet.QType.DTBooleanList;
            base.ClearAllFields();
        }
        internal override void ExchangeData(EnumAction Action)
        {
            ExchangeField(Action, 0, ref m_lQuestionSN);
            ExchangeField(Action, 1, ref m_lProperties);
            if (m_eTypeSet == TypeSet.NormalSet)
            {
                ExchangeField(Action, 2, ref m_iRFValue);
                ExchangeField(Action, 3, ref m_eDataType);

                ExchangeField(Action, 4, ref m_sStdText);
                ExchangeField(Action, 5, ref m_sNoteText);
                ExchangeField(Action, 6, ref m_sListAnswer);
                ExchangeField(Action, 7, ref m_sRGKeyWordList);
            }
        }
        internal override void ExchangeDataDS(EnumAction Action)
        {
            ExchangeFieldDS(Action, 0, ref m_lQuestionSN);
            ExchangeFieldDS(Action, 1, ref m_lProperties);
            if (m_eTypeSet == TypeSet.NormalSet)
            {
                ExchangeFieldDS(Action, 2, ref m_iRFValue);
                ExchangeFieldDS(Action, 3, ref m_eDataType);

                ExchangeFieldDS(Action, 4, ref m_sStdText);
                ExchangeFieldDS(Action, 5, ref m_sNoteText);
                ExchangeFieldDS(Action, 6, ref m_sListAnswer);
                ExchangeFieldDS(Action, 7, ref m_sRGKeyWordList);
            }
        }
        protected new virtual short GetFieldCount() { return (short)((m_eTypeSet == TypeSet.NormalSet) ? 4 : 2); }
    }

    //***************************************************************************
    //**///////////////////// CMQuestionBodySet /////////////////////////////////
    //***************************************************************************
    class CMQuestionBodySet : CSQLSet
    {
        // Data Members
        protected long m_lQuestionBodySN = -1;          // Serial Number.

        //********** Constructors, Destructors ************************************
        public CMQuestionBodySet(string Table) : base(Table)
        {
            m_sListField = "QuestionBodySN";
        }
      
        //********** Public Properties Methods ************************************
        public long GetQuestionBodySN() { return m_lQuestionBodySN; }
        ~CMQuestionBodySet() { }
        //********** Public Query Methods *****************************************
        //public void SelectAll()
        //{
        //    string Query = ("SELECT " + m_sListField + " FROM QuestionBody ORDER BY QuestionBodySN");
        //    BeginQuery(Query);
        //}
        public void SelectAllDesc()
        {
            string Query = ("SELECT " + m_sListField + " FROM QuestionBody ORDER BY QuestionBodySN DESC");
            BeginQuery(Query);
        }
        //********** Overridables Methods *****************************************
        public virtual new void ClearAllFields()
        {
            m_lQuestionBodySN = -1;
            base.ClearAllFields();
        }
        internal override void ExchangeData(EnumAction Action)
        {
            ExchangeField(Action, 0, ref m_lQuestionBodySN);
        }
        //internal override void ExchangeDataDS(EnumAction Action)
        //{
        //    ExchangeFieldDS(Action, 0, ref m_lQuestionBodySN);
        //}
 
        protected virtual new short GetFieldCount() { return 1; }
      
    }

    //***************************************************************************
    //**///////////////////// CMQDLinkSet ///////////////////////////////////////
    //***************************************************************************
    class CMQDLinkSet : CSQLSet
    {
        // Data Members
        protected long m_lDomainSN = -1;
        protected long m_lQSSN = -1;
        protected long m_lQuestionSN = -1;

        //********** Constructors, Destructors ************************************
        public CMQDLinkSet(string Table)
            : base(Table)

        {
            m_sListField = "DomainSN, QSSN, QuestionSN, ModuleVersionSN, QDOrder, ModuleSN";
        }
        //public CMQDLinkSet(string Table,  string ModuleSN)
        //    : base(Table)

        //{
        //    m_sListField = "DomainSN, QSSN, QuestionSN, ModuleVersionSN, QDOrder, ModuleSN";

        //    SelectAllBase(ModuleSN);
        //}
        public CMQDLinkSet(string Table,  string ModuleSN, string ModuleVersionSN)
            : base(Table)

        {
            m_sListField = "DomainSN, QSSN, QuestionSN, ModuleVersionSN, QDOrder, ModuleSN";

            SelectAllBase(ModuleSN, ModuleVersionSN);
        }

        public CMQDLinkSet(string Table, string ModuleVersionSN)
            : base(Table)
        {
            m_sListField = "DomainSN, QSSN, QuestionSN, ModuleVersionSN, QDOrder, ModuleSN";

            SelectAllBase(ModuleVersionSN);
        }

        ~CMQDLinkSet() { }
        //********** Public Properties Methods ************************************
        public long GetDomainSN() { return m_lDomainSN; }
        public long GetQSSN() { return m_lQSSN; }
        public long GetQuestionSN() { return m_lQuestionSN; }

        //********** Public Query Methods *****************************************
        //public void SelectForDomain(long DomainSN, short ModuleVersionSN)
        //{
        //    string Query = ("SELECT " + m_sListField + " FROM QDLink WHERE DomainSN = " + (DomainSN.ToString()) +
        //                " AND ModuleVersionSN = " + (ModuleVersionSN.ToString()) + " ORDER BY QDOrder");
        //    BeginQuery(Query);
        //}
        public void SelectForDomainDS(long DomainSN, short ModuleVersionSN)
        {
            this.BeginQueryDS(m_sListField, "DomainSN = " + DomainSN.ToString() +
                    " AND ModuleVersionSN = " + ModuleVersionSN.ToString(), "QDOrder");
        }
        
        // All the answers for a domainSN.
        //public void SelectForModule(long ModuleSN, short ModuleVersionSN)
        //{
        //    string Query = ("SELECT " + m_sListField + " FROM QDLink WHERE ModuleSN = " + (ModuleSN.ToString()) +
        //               " AND ModuleVersionSN = " + (ModuleVersionSN.ToString()) + " ORDER BY QuestionSN");
        //    BeginQuery(Query);
        //}
        public void SelectForModuleDS(long ModuleSN, short ModuleVersionSN)
        {
            base.BeginQueryDS(m_sListField, "ModuleSN = " + ModuleSN.ToString() +
                    " AND ModuleVersionSN = " + ModuleVersionSN.ToString(), "QuestionSN");
        }
        public void SelectForModuleDS(long ModuleSN)
        {
            base.BeginQueryDS(m_sListField, "ModuleSN = " + ModuleSN.ToString(), "QuestionSN");
        }
        internal void SelectAllBase()
        {
            string Query = ("SELECT " + m_sListField + " FROM QDLink order by ModuleSN, ModuleVersionSN, DomainSN, QDOrder");
            base.BeginQueryBase(Query);
        }
        //internal void SelectAllBase(string ModuleSN)
        //{
        //    string Query = ("SELECT " + m_sListField + " FROM QDLink where ModuleSN=" + ModuleSN
        //            + " order by ModuleVersionSN, DomainSN, QDOrder");
        //    base.BeginQueryBase(Query);
        //}
        internal void SelectAllBase(string ModuleVersionSN)
        {
            string Query = ("SELECT " + m_sListField + " FROM QDLink where ModuleVersionSN=" + ModuleVersionSN
                    + " order by ModuleVersionSN, DomainSN, QDOrder");
            base.BeginQueryBase(Query);
        }
        internal void SelectAllBase(string ModuleSN, string ModuleVersionSN)
        {
            string Query = ("SELECT " + m_sListField + " FROM QDLink where ModuleSN=" + ModuleSN
                    + " and ModuleVersionSN=" + ModuleVersionSN + " order by DomainSN, QDOrder");
            base.BeginQueryBase(Query);
        }
        //********** Overridables Methods *****************************************
        internal override void ExchangeData(EnumAction Action)
        {
            ExchangeField(Action, 0, ref m_lDomainSN);
            ExchangeField(Action, 1, ref m_lQSSN);
            ExchangeField(Action, 2, ref m_lQuestionSN);
        }
        internal override void ExchangeDataDS(EnumAction Action)
        {
            ExchangeFieldDS(Action, 0, ref m_lDomainSN);
            ExchangeFieldDS(Action, 1, ref m_lQSSN);
            ExchangeFieldDS(Action, 2, ref m_lQuestionSN);
        }
        public virtual new void ClearAllFields()
        {
            m_lDomainSN = -1;
            m_lQSSN = -1;
            m_lQuestionSN = -1;
            base.ClearAllFields();
        }
        public virtual new short GetFieldCount() { return 3; }
    }

    //***************************************************************************
    //**///////////////////// CMQSLinkSet ///////////////////////////////////////
    //***************************************************************************
    class CMQSLinkSet : CSQLSet
    {
        // Data Members
        protected long m_lSubQuestionDomainSN = -1;

        //********** Constructors, Destructors ************************************
        public CMQSLinkSet(string Table)
            : base(Table)

        {
            m_sListField = "SubQuestionDomainSN,QSSN,ModuleSN,QSOrder,ModuleVersionSN";

            //SelectAllBase();
        }
        public CMQSLinkSet(string Table, string ModuleSN)
            : base(Table)

        {
            m_sListField = "SubQuestionDomainSN,QSSN,ModuleSN,QSOrder,ModuleVersionSN";

            SelectAllBase(ModuleSN);
        }
        ~CMQSLinkSet() { }
        //********** Public Properties Methods ************************************
        public long GetSubQuestionDomainSN() { return m_lSubQuestionDomainSN; }

        //********** Public Query Methods *****************************************
        public void SelectSN(long QSSN, long ModuleSN, short ModuleVersionSN)
        {
            string Query = ("SELECT " + m_sListField + " FROM QSLink WHERE QSSN = " + (QSSN.ToString()) +
                        " AND ModuleSN = " + (ModuleSN.ToString()) +
                        " AND ModuleVersionSN = " + (ModuleVersionSN.ToString()) + " ORDER BY QSOrder");
            BeginQuery(Query);

        }
        public void SelectSNDS(long QSSN, long ModuleSN, short ModuleVersionSN)
        {
            BeginQueryDS(m_sListField, "QSSN = " + QSSN.ToString() + " AND ModuleSN = " + ModuleSN.ToString() +
                        " AND ModuleVersionSN = " + ModuleVersionSN.ToString(), "QSOrder");

        }
        //private void SelectAllBase()
        //{
        //    string Query = ("SELECT " + m_sListField + " FROM QSLink order by QSSN,ModuleSN,QSOrder,ModuleVersionSN");
        //    base.BeginQueryBase(Query);
        //}
        internal void SelectAllBase(string ModuleSN)
        {
            string Query = ("SELECT " + m_sListField + " FROM QSLink where ModuleSN=" +
                    ModuleSN + " order by QSSN,QSOrder,ModuleVersionSN");
            base.BeginQueryBase(Query);
        }

        // All the SubQuestionDomainSN for a QSSN.

        //********** Overridables Methods *****************************************
        internal override void ExchangeData(EnumAction Action)
        {
            ExchangeField(Action, 0, ref m_lSubQuestionDomainSN);
        }
        internal override void ExchangeDataDS(EnumAction Action)
        {
            ExchangeFieldDS(Action, 0, ref m_lSubQuestionDomainSN);
        }
 
        public virtual new void ClearAllFields()
        {
            m_lSubQuestionDomainSN = -1;
            base.ClearAllFields();
        }
        public virtual new short GetFieldCount() { return 1; }
    }

    //***************************************************************************
    //**///////////////////// CMStateSet ////////////////////////////////////////
    //***************************************************************************
    class CMStateSet : CSQLSet
    {
        // Data Members
        protected short m_iStateSN= -1;           // Serial Number.
        protected string m_sStateName= "";         // Name.
        protected string m_sStatePostal= "";
        protected short m_iMasterModuleID = 0;     // the 3 following fields are used for licensing.
        protected short m_iMasterGroupID = 0;
        protected short m_iMasterClassID = 0;

        //********** Constructors, Destructors ************************************
        public CMStateSet(string Table)
            : base(Table)

        {
            m_sListField = "StateSN, StateName, PostalCode, MasterModuleID, MasterGroupID, MasterClassID";

            SelectAllBase();
        }
        ~CMStateSet() { }
        //********** Public Properties Methods ************************************
        private void SelectAllBase()
        {
            string Query = ("SELECT " + m_sListField + " FROM State  ORDER BY StateName");

            base.BeginQueryBase(Query);
        }

        public short GetStateSN() { return m_iStateSN; }
        public string GetStateName() { return m_sStateName; }
        public string GetStatePostal() { return m_sStatePostal; }
        public short GetMasterModuleID() { return m_iMasterModuleID; }
        public short GetMasterGroupID() { return m_iMasterGroupID; }
        public short GetMasterClassID() { return m_iMasterClassID; }

        //********** Public Query Methods *****************************************
        //public EnumSQLError SelectSN(short StateSN)
        //{
        //    string Query = ("SELECT " + m_sListField + " FROM State WHERE StateSN = " + (StateSN.ToString()));
        //    return SelectUniqueQuery(Query);
        //}
        public EnumSQLError SelectSNDS(string StateSN)
        {
            //string Query = ("SELECT " + m_sListField + " FROM State WHERE StateSN = " + (StateSN.ToString()));
            return SelectUniqueQueryDS(m_sListField,"StateSN = " + StateSN,"");
        }
        // Select an identified State.
        public EnumSQLError SelectForPostalCode(string PostalCode)
        {
            //string Query = ("SELECT " + m_sListField + " FROM State WHERE PostalCode = '" + PostalCode + "'");
            //return SelectUniqueQueryDS(Query);
            return SelectUniqueQueryDS(m_sListField, "PostalCode = '" + PostalCode + "'", "");
        }
        public void SelectAll()
        {
            string Query = ("SELECT " + m_sListField + " FROM State ORDER BY StateName");
            base.BeginQuery(Query);
        }// Select all the states.
        public void SelectAllDS()
        {
            //string Query = ("SELECT " + m_sListField + " FROM State ORDER BY StateName");
            base.BeginQueryDS(m_sListField, "", "StateName");
        }// Select all the states.
        //public void SelectAllDesc()
        //{
        //    string Query = ("SELECT " + m_sListField + " FROM State ORDER BY StateName");
        //    BeginQuery(Query);
        //}// Select all the states.

        //********** Overridables Methods *****************************************
        public virtual new void ClearAllFields()
        {
            m_iStateSN = -1;
            m_sStateName = "";
            m_sStatePostal = "";
            m_iMasterModuleID = 0;
            m_iMasterGroupID = 0;
            m_iMasterClassID = 0;
            base.ClearAllFields();
        }
        internal override void ExchangeData(EnumAction Action)
        {
            ExchangeField(Action, 0, ref m_iStateSN);
            ExchangeField(Action, 1, ref  m_sStateName);
            ExchangeField(Action, 2, ref m_sStatePostal);
            ExchangeField(Action, 3, ref m_iMasterModuleID);
            ExchangeField(Action, 4, ref m_iMasterGroupID);
            ExchangeField(Action, 5, ref m_iMasterClassID);
        }
        internal override void ExchangeDataDS(EnumAction Action)
        {
            ExchangeFieldDS(Action, 0, ref m_iStateSN);
            ExchangeFieldDS(Action, 1, ref  m_sStateName);
            ExchangeFieldDS(Action, 2, ref m_sStatePostal);
            ExchangeFieldDS(Action, 3, ref m_iMasterModuleID);
            ExchangeFieldDS(Action, 4, ref m_iMasterGroupID);
            ExchangeFieldDS(Action, 5, ref m_iMasterClassID);
        }
        protected virtual new short GetFieldCount() { return 6; }

    }

    //***************************************************************************
    //**///////////////////// CMStateVersionSet /////////////////////////////////
    //***************************************************************************
    class CMStateVersionSet : CSQLSet
    {
       
        // Data Members
        protected short m_iStateVersionSN = -1;          // Serial Number.
 
        //********** Constructors, Destructors ************************************
        public CMStateVersionSet(string Table)
            : base(Table)

        {
            m_sListField = "StateVersionSN";
            SelectAllBase();
        }
        ~CMStateVersionSet() { }
        //********** Public Properties Methods ************************************
        private void SelectAllBase()
        {
            string Query = ("SELECT " + m_sListField + " FROM StateVersion ORDER BY StateVersionSN");

            base.BeginQueryBase(Query);
        }

        //********** Public Properties Methods ************************************
        public short GetStateVersionSN() { return m_iStateVersionSN; }

        //********** Public Query Methods *****************************************
        //public void SelectAll()
        //{
        //    string Query = ("SELECT " + m_sListField + " FROM StateVersion ORDER BY StateVersionSN");
        //    base.BeginQuery(Query);
        //}// Select all the states.
        public void SelectAllDS()
        {
            //string Query = ("SELECT " + m_sListField + " FROM StateVersion ORDER BY StateVersionSN");
            base.BeginQueryDS(m_sListField, "", "StateVersionSN");
        }
        // Select all the states.
        public void SelectAllDesc()
        {
            string Query = ("SELECT " + m_sListField + " FROM StateVersion ORDER BY StateVersionSN DESC");
            base.BeginQuery(Query);
        }// Select all the states.
        //********** Overridables Methods *****************************************
        public virtual new void ClearAllFields()
        {
            m_iStateVersionSN = -1;
            base.ClearAllFields();
        }

        internal override void ExchangeData(EnumAction Action)
        {
            ExchangeField(Action, 0, ref m_iStateVersionSN);
        }
        internal override void ExchangeDataDS(EnumAction Action)
        {
            ExchangeFieldDS(Action, 0, ref m_iStateVersionSN);
        }

        protected virtual new short GetFieldCount() { return 1; }
    }

    //***************************************************************************
    //**///////////////////// CMStateSectionSet /////////////////////////////////
    //***************************************************************************
    class CMStateSectionSet : CSQLSet
    {

        // Data Members
        protected short m_iStateSN = -1;
        protected long m_lSDomainSN = -1;      // The state domain.
        protected long m_lSectionSN = -1;
        protected string m_sHeading = string.Empty;
        protected long m_lTagDate = 0;

        //********** Constructors, Destructors ************************************
        public CMStateSectionSet(string Table)
            : base(Table)
        {
            m_sListField = "StateSN, StateDomainSN, RGSection.SectionSN, Heading, StateSection.TagDate as TagDate";
        }
        ~CMStateSectionSet() { }
        //********** Public Properties Methods ************************************
        public short GetStateSN() { return m_iStateSN; }
        public long GetSDomainSN() { return m_lSDomainSN; }
        public long GetSectionSN() { return m_lSectionSN; }
        public string GetHeading() { return m_sHeading; }
        public long GetTagDate() { return m_lTagDate; }
        // List of the fields for the Select statement.

        //********** Public Query Methods *****************************************
        // Select all the Sections for a state.
        public EnumSQLError SelectForDomainAndStateDS(short StateSN, short StateVersionSN, long DomainSN)
        {
            return SelectUniqueQueryDS("StateSN, StateDomainSN, SectionSN, Heading, TagDate",
                        "StateSN = " + StateSN + " AND StateVersionSN = " + StateVersionSN +
                         " AND StateDomainSN = " + DomainSN, "");
        }

        //for merge usage
        public void SelectForStateAndVersion(int StateSN, int StateVersionSN)
        {
            string Query = ("SELECT Max(StateSN), Max(StateDomainSN), Max(RGSection.SectionSN), Max(Heading),") +
                    " Max(StateSection.TagDate) FROM StateSection inner JOIN RGSection " +
                    " on StateSection.SectionSN=RGSection.SectionSN " +
                    " WHERE StateSN = " + (StateSN.ToString()) + " AND StateVersionSN = " + (StateVersionSN.ToString()) +
                    " GROUP BY StateSection.SectionSN";
            BeginQuery(Query);
        }

        //********** Overridables Methods *****************************************
        public virtual new void ClearAllFields()
        {
            m_iStateSN = -1;
            m_lSDomainSN = -1;
            m_lSectionSN = -1;
            m_lTagDate = 0;
            base.ClearAllFields();
        }
        internal override void ExchangeData(EnumAction Action)
        {
            ExchangeField(Action, 0, ref m_iStateSN);
            ExchangeField(Action, 1, ref m_lSDomainSN);
            ExchangeField(Action, 2, ref m_lSectionSN);
            ExchangeField(Action, 3, ref m_sHeading);
            ExchangeField(Action, 4, ref m_lTagDate);
        }
        internal override void ExchangeDataDS(EnumAction Action)
        {
            ExchangeFieldDS(Action, 0, ref m_iStateSN);
            ExchangeFieldDS(Action, 1, ref m_lSDomainSN);
            ExchangeFieldDS(Action, 2, ref m_lSectionSN);
            ExchangeFieldDS(Action, 3, ref m_sHeading);
            ExchangeFieldDS(Action, 4, ref m_lTagDate);
        }

        protected virtual new short GetFieldCount() { return 5; }
    }

    class CMStateSectionSetForState : CSQLSet
    {
       
        // Data Members
        protected short m_iStateSN = -1;
        protected long m_lSDomainSN = -1;      // The state domain.
        protected long m_lSectionSN = -1;
        protected string m_sHeading=string.Empty;
        protected long m_lTagDate = 0;

        //********** Constructors, Destructors ************************************
        //public CMStateSectionSetForState(string Table, string DSN, string User, string PassWord)
        //    : base(null, Table, DSN, User, PassWord)
        //{
        //    //m_sListField = "StateSN, StateDomainSN, RGSection.SectionSN, Heading, StateSection.TagDate as TagDate";

        //    SelectAllBase();
        //}
        public CMStateSectionSetForState(string Table)
            : base(Table)

        {
            //m_sListField = "StateSN, StateDomainSN, RGSection.SectionSN, Heading, StateSection.TagDate as TagDate";

            //SelectAllBase(StateSN);
        }
        ~CMStateSectionSetForState()
        {
        }


        public void SelectAllBase(string StateSN)
        {
            string Query = "SELECT StateSN, Max(StateDomainSN) as StateDomainSN, "
                    + " Max(RGSection.SectionSN) as SectionSN, Max(Heading) as Heading,"
                    + " Max(StateSection.TagDate) as TagDate, RGSection.Sequence as Sequence "
                    + " FROM StateSection inner JOIN RGSection "
                    + " on StateSection.SectionSN=RGSection.SectionSN "
                    + " WHERE StateSN = " + StateSN
                    + " GROUP BY StateSN,Sequence ORDER BY StateSN,Sequence";

            base.BeginQueryBase(Query);
        }

        //********** Public Properties Methods ************************************
        public short GetStateSN() { return m_iStateSN; }
        public long GetSDomainSN() { return m_lSDomainSN; }
        public long GetSectionSN() { return m_lSectionSN; }
        public string GetHeading() { return m_sHeading; }
        public long GetTagDate() { return m_lTagDate; }
        // List of the fields for the Select statement.

        //********** Public Query Methods *****************************************
        // Select all the Sections for a state.
        public void SelectForStateDS(short StateSN)
        {
            this.BeginQueryDS(m_sListField, "StateSN = " + StateSN, "Sequence");
        }

        //********** Overridables Methods *****************************************
        public virtual new void ClearAllFields()
        {
            m_iStateSN = -1;
            m_lSDomainSN = -1;
            m_lSectionSN = -1;
            m_lTagDate = 0;
            m_sHeading = string.Empty;
            base.ClearAllFields();
        }
        internal override void ExchangeData(EnumAction Action)
        {
            ExchangeField(Action, 0, ref m_iStateSN);
            ExchangeField(Action, 1, ref m_lSDomainSN);
            ExchangeField(Action, 2, ref m_lSectionSN);
            ExchangeField(Action, 3, ref m_sHeading);
            ExchangeField(Action, 4, ref m_lTagDate);
        }
        internal override void ExchangeDataDS(EnumAction Action)
        {
            ExchangeFieldDS(Action, 0, ref m_iStateSN);
            ExchangeFieldDS(Action, 1, ref m_lSDomainSN);
            ExchangeFieldDS(Action, 2, ref m_lSectionSN);
            ExchangeFieldDS(Action, 3, ref m_sHeading);
            ExchangeFieldDS(Action, 4, ref m_lTagDate);
        }

        protected virtual new short GetFieldCount() { return 5; }
    }

    class CMStateSectionSetForDomainAndState : CSQLSet
    {
        // Data Members
        protected short m_iStateSN = -1;
        protected long m_lSDomainSN = -1;      // The state domain.
        protected long m_lSectionSN = -1;
        protected string m_sHeading = string.Empty;
        protected long m_lTagDate = 0;

        //********** Constructors, Destructors ************************************
        public CMStateSectionSetForDomainAndState(string Table) : base(Table)
        {
            m_sListField = "StateSN, StateDomainSN, RGSection.SectionSN as SectionSN, Heading, StateSection.TagDate as TagDate, StateVersionSN";

            //SelectAllBase();
        }

        ~CMStateSectionSetForDomainAndState() { }

        public void SelectAllBase(int StateVersionSN)
        {
            string Query = "SELECT " + m_sListField + 
                    " FROM StateSection inner JOIN RGSection " +
                    " on StateSection.SectionSN=RGSection.SectionSN " +
                    " where StateVersionSN=" + StateVersionSN.ToString() + 
                    " order by StateSN, StateVersionSN, StateDomainSN";

            base.BeginQueryBase(Query);
        }
        private void SelectAllBase()
        {
            string Query = "SELECT " + m_sListField +
                    " FROM StateSection inner JOIN RGSection " +
                    " on StateSection.SectionSN=RGSection.SectionSN " +
                    " order by StateSN, StateVersionSN, StateDomainSN";

            base.BeginQueryBase(Query);
        }

        //********** Public Properties Methods ************************************
        public short GetStateSN() { return m_iStateSN; }
        public long GetSDomainSN() { return m_lSDomainSN; }
        public long GetSectionSN() { return m_lSectionSN; }
        public string GetHeading() { return m_sHeading; }
        public long GetTagDate() { return m_lTagDate; }
        // List of the fields for the Select statement.

        //********** Public Query Methods *****************************************
        // Select all the Sections for a state.
        public EnumSQLError SelectForDomainAndStateDS(string StateSN, string StateVersionSN, string DomainSN)
        {
            return SelectUniqueQueryDS("StateSN, StateDomainSN, SectionSN, Heading, TagDate",
                        "StateSN = " + StateSN + " AND StateVersionSN = " + StateVersionSN +
                         " AND StateDomainSN = " + DomainSN, "");
        }

        //********** Overridables Methods *****************************************
        public virtual new void ClearAllFields()
        {
            m_iStateSN = -1;
            m_lSDomainSN = -1;
            m_lSectionSN = -1;
            m_lTagDate = 0;
            base.ClearAllFields();
        }
        internal override void ExchangeData(EnumAction Action)
        {
            ExchangeField(Action, 0, ref m_iStateSN);
            ExchangeField(Action, 1, ref m_lSDomainSN);
            ExchangeField(Action, 2, ref m_lSectionSN);
            ExchangeField(Action, 3, ref m_sHeading);
            ExchangeField(Action, 4, ref m_lTagDate);
        }
        internal override void ExchangeDataDS(EnumAction Action)
        {
            ExchangeFieldDS(Action, 0, ref m_iStateSN);
            ExchangeFieldDS(Action, 1, ref m_lSDomainSN);
            ExchangeFieldDS(Action, 2, ref m_lSectionSN);
            ExchangeFieldDS(Action, 3, ref m_sHeading);
            ExchangeFieldDS(Action, 4, ref m_lTagDate);
        }

        protected virtual new short GetFieldCount() { return 5; }
    }

    //***************************************************************************
    //**///////////////////// CMQDStateLinkSet //////////////////////////////////
    //***************************************************************************
    class CMQDStateLinkSet : CSQLSet
    {
       
        // Data Members
        protected long m_lSDomainSN = -1;     // The state domain.
        protected long m_lQuestionSN = -1;
        protected long m_lProperties = 0;
        protected short m_iStateVersionSN = -1;

        //********** Constructors, Destructors ************************************
        public CMQDStateLinkSet(string Table)
            : base(Table)
        {
            m_sListField = "StateDomainSN, QDStateLink.QuestionSN as QuestionSN, Properties, StateVersionSN ,StateSN";
        }
        ~CMQDStateLinkSet() { }
        //public CMQDStateLinkSet(string Table, string DSN, string User, string PassWord, string StateSN)
        //    : base(null, Table, DSN, User, PassWord)
        //{
        //    //m_sListField = "StateDomainSN, QuestionSN, Properties, StateVersionSN ,StateSN";
        //    m_sListField = "StateDomainSN, Question.QuestionSN as QuestionSN, Properties, StateVersionSN ,StateSN";
        //    //SelectAllBase(StateSN);
        //}
        public CMQDStateLinkSet(string Table, string DSN, string User, string PassWord, int StateVersionSN)
            : base(null, Table, DSN, User, PassWord)
        {
            m_sListField = "StateDomainStructure.StateDomainSN as StateDomainSN, Question.QuestionSN as QuestionSN, " +
                    "QuestionBody.Properties as Properties, QDStateLink.StateVersionSN as StateVersionSN,StateSN, " +
                    "ModuleSN,ModuleVersionSN as ModuleVersionSN";
            //SelectAllBase(StateVersionSN);
        }

        public void SelectAllBase(int StateVersionSN)
        {
            m_sListField = "StateDomainStructure.StateDomainSN as StateDomainSN, Question.QuestionSN as QuestionSN, " +
                    "QuestionBody.Properties as Properties, QDStateLink.StateVersionSN as StateVersionSN,StateSN, " +
                    "ModuleSN,ModuleVersionSN as ModuleVersionSN";

            string Query = ("SELECT " + m_sListField +
                            " FROM StateDomainStructure inner JOIN QDStateLink" +
                            " on QDStateLink.StateDomainSN = StateDomainStructure.StateDomainSN " +
                            " inner JOIN Question " +
                            " on QDStateLink.QuestionSN = Question.QuestionSN " +
                            " inner JOIN QuestionBody" +
                            " on Question.QuestionBodySN=QuestionBody.QuestionBodySN " +
                            " WHERE StateDomainStructure.StateVersionSN = " + StateVersionSN.ToString() +
                            " AND   QDStateLink.StateVersionSN = " + StateVersionSN.ToString());
            base.BeginQueryBase(Query);
        }

        //********** Public Properties Methods ************************************
        public long GetSDomainSN() { return m_lSDomainSN; }
        public long GetQuestionSN() { return m_lQuestionSN; }
        public long GetProperties() { return m_lProperties; }
        public short GetStateVersionSN() { return m_iStateVersionSN; }

        //********** Public Query Methods *****************************************
        // Select all the questions for a given state.
        public void SelectForStateDesc(int StateSN)
        {
            string Query = ("SELECT " + m_sListField + " FROM QDStateLink inner JOIN Question "+
                    " on Question.QuestionSN=QDStateLink.QuestionSN "+
                    " inner JOIN QuestionBody on Question.QuestionBodySN=QuestionBody.QuestionBodySN " +
                    "WHERE StateSN = " + (StateSN) + " ORDER BY StateVersionSN DESC");
            BeginQuery(Query);
        }
        // Select all the questions for a given state.
        public void SelectForModuleAndStateDS(string ModuleSN, string ModuleVersionSN, string StateVersionSN, string StateSN)
        {
            BeginQueryDS("StateDomainSN, QuestionSN, Properties, StateVersionSN",
                    " StateVersionSN = " + StateVersionSN +
                    " AND ModuleSN = " + ModuleSN +
                    " AND ModuleVersionSN = " + ModuleVersionSN +
                    " AND StateSN = " + StateSN +
                    " AND StateVersionSN = " + StateVersionSN, "StateDomainSN,QuestionSN");
        }
        public void SelectForStateAndVersionDS(int StateVersionSN)
        {
            BeginQueryDS("", "StateVersionSN = " + StateVersionSN.ToString(), "StateDomainSN,QuestionSN");
        }
        public void SelectForStateAndVersion(int StateSN, int StateVersionSN)
        {
            string Query = ("SELECT " + m_sListField + " FROM QDStateLink inner JOIN Question "+
                    " on Question.QuestionSN=QDStateLink.QuestionSN " +
                    " inner JOIN QuestionBody " +
                    " on Question.QuestionBodySN=QuestionBody.QuestionBodySN " +
                    "WHERE StateSN = " + (StateSN.ToString()) + " AND StateVersionSN = " + (StateVersionSN.ToString()));
            BeginQuery(Query);
        }
        //********** Overridables Methods *****************************************
        public virtual new void ClearAllFields()
        {
            m_lSDomainSN = -1;
            m_lQuestionSN = -1;
            m_lProperties = 0;
            m_iStateVersionSN = -1;
            base.ClearAllFields();
        }
        internal override void ExchangeData(EnumAction Action)
        {
            ExchangeField(Action, 0, ref m_lSDomainSN);
            ExchangeField(Action, 1, ref m_lQuestionSN);
            ExchangeField(Action, 2, ref m_lProperties);
            ExchangeField(Action, 3, ref m_iStateVersionSN);
        }
        internal override void ExchangeDataDS(EnumAction Action)
        {
            ExchangeFieldDS(Action, 0, ref m_lSDomainSN);
            ExchangeFieldDS(Action, 1, ref m_lQuestionSN);
            ExchangeFieldDS(Action, 2, ref m_lProperties);
            ExchangeFieldDS(Action, 3, ref m_iStateVersionSN);
        }
        protected virtual new short GetFieldCount() { return 4; }
    }

    //***************************************************************************
    //**///////////////////// CMQCountStateSet //////////////////////////////////
    //***************************************************************************
    class CMQCountStateSet : CSQLSet
    {
        // Data Members
        protected short m_iStateSN = -1;
        protected string m_sStateName = "";

        //********** Constructors, Destructors ************************************
        public CMQCountStateSet(string Table) : base(Table)
        {
            m_sListField = "QCountState.StateSN, StateName";
        }
        //public CMQCountStateSet(string Table, string DSN, string User, string PassWord, string StateSN)
        //    : base(null, Table, DSN, User, PassWord)
        //{
        //    m_sListField = "QCountState.StateSN, StateName";
        //    SelectAllBase(StateSN);
        //}
        ~CMQCountStateSet() { }

        public void SelectAllBase(int StateVersionSN)
        {
            string Query = ("SELECT DISTINCT " + m_sListField + " FROM QCountState inner JOIN State " +
                    " on QCountState.StateSN=State.StateSN " +
                    " WHERE StateVersionSN = " + (StateVersionSN.ToString()) + " ORDER BY StateName");

            base.BeginQueryBase(Query);
        }
        //********** Public Properties Methods ************************************
        public short GetStateSN() { return m_iStateSN; }
        public string GetStateName() { return m_sStateName; }

        //********** Public Query Methods *****************************************
        public void SelectForStateVersionDS(string StateVersionSN)
        {
            this.BeginQueryDS("StateSN, StateName", "StateVersionSN = " + StateVersionSN, "StateName");
        }

        //********** Overridables Methods *****************************************
        public virtual new void ClearAllFields()
        {
            m_iStateSN = -1;
            m_sStateName = "";
            base.ClearAllFields();
        }

        internal override void ExchangeData(EnumAction Action)
        {
            ExchangeField(Action, 0, ref m_iStateSN);
            ExchangeField(Action, 1, ref m_sStateName);
        }
        internal override void ExchangeDataDS(EnumAction Action)
        {
            ExchangeFieldDS(Action, 0, ref m_iStateSN);
            ExchangeFieldDS(Action, 1, ref m_sStateName);
        }

        protected virtual new short GetFieldCount() { return 2; }
    }

    //***************************************************************************
    //**///////////////////// CMStateModuleSet //////////////////////////////////
    //***************************************************************************
    class CMStateModuleSet : CSQLSet
    {
        // Data Members
        protected int m_lModuleSN = -1;
        protected short m_iModuleVersionSN = -1;
        protected short m_iStateVersionSN = -1;

        //********** Constructors, Destructors ************************************
        public CMStateModuleSet(string Table)
            : base(Table)
        {
            m_sListField = "ModuleSN, ModuleVersionSN, StateVersionSN";
            SelectAllBase();
        }
       
        ~CMStateModuleSet()
        {
        }
        public void SelectForStateVersionDS(int StateVersionSN)
        {
            this.BeginQueryDS(m_sListField, "StateVersionSN = " + StateVersionSN, "ModuleSN");
        }
        private void SelectAllBase()
        {
            string Query = ("SELECT DISTINCT " + m_sListField + " FROM StateModule order by moduleversionsn,modulesn");

            base.BeginQueryBase(Query);
        }
        //********** Public Properties Methods ************************************
        public int GetModuleSN() { return m_lModuleSN; }
        public short GetModuleVersionSN() { return m_iModuleVersionSN; }
        public short GetStateVersionSN() { return m_iStateVersionSN; }

        //********** Public Query Methods *****************************************
         public void SelectForStateVersionDS(string StateVersionSN)
        {
            //string Query = ("SELECT " + m_sListField + " FROM StateModule WHERE StateVersionSN = " + (StateVersionSN.ToString()));
            BeginQueryDS(m_sListField, "StateVersionSN = " + StateVersionSN, "");
        }

        //********** Overridables Methods *****************************************
        public virtual new void ClearAllFields()
        {
            m_lModuleSN = -1;
            m_iModuleVersionSN = -1;
            m_iStateVersionSN = -1;
            base.ClearAllFields();
        }
        internal override void ExchangeData(EnumAction Action)
        {
            ExchangeField(Action, 0, ref m_lModuleSN);
            ExchangeField(Action, 1, ref m_iModuleVersionSN);
            ExchangeField(Action, 2, ref m_iStateVersionSN);
        }
        internal override void ExchangeDataDS(EnumAction Action)
        {
            ExchangeFieldDS(Action, 0, ref m_lModuleSN);
            ExchangeFieldDS(Action, 1, ref m_iModuleVersionSN);
            ExchangeFieldDS(Action, 2, ref m_iStateVersionSN);
        }

        protected virtual new short GetFieldCount() { return 3; }
    }

    //***************************************************************************
    //**///////////////////// CMBlobSet /////////////////////////////////////////
    //***************************************************************************

    class CMBlobSet : CSQLSet
    {
        public enum BlobClass
        {
            BlobDomain = 1, BlobRules, BlobAppVar, BlobRGKeyWordModule, BlobRGKeyWordDomain,
            BlobRGKeyWordDomainRecursive, BlobQDLink, BlobQMLink, BlobStateTOC
        };
        //protected string m_sListField = string.Empty;      // List of the fields for the Select statement.
        // Data Members

        protected short m_iClass = -1;

        //********** Constructors, Destructors ************************************
        public CMBlobSet(string Table)
            : base(Table)

        {
            m_sListField = "Class,SN,ModuleVersionSN";

            //SelectAllBase();
        }

        public CMBlobSet(string Table, string ModuleSN)
            : base(Table)

        {
            m_sListField = "Class,SN,ModuleVersionSN";

            SelectAllBase(ModuleSN);
        }
        //public CMBlobSet(string Table, string DSN, string User, string PassWord, string ModuleSN, string ModuleVersionSN)
        //    : base(null, Table, DSN, User, PassWord)
        //{
        //    m_sListField = "Class,SN,ModuleVersionSN";

        //    SelectAllBase(ModuleSN, ModuleVersionSN);
        //}
        ~CMBlobSet() { }
        //********** Public Query Methods *****************************************
        //public void SelectForModule(BlobClass Class, long ModuleSN, short ModuleVersionSN)
        //{
        //    string Query = ("SELECT " + m_sListField + " FROM Blob WHERE SN = " + (ModuleSN.ToString()) +
        //                  " AND ModuleVersionSN = " + (ModuleVersionSN.ToString()) + " AND Class = " + ((int)(Class)).ToString());
        //    BeginQuery(Query);
        //}    // Select for a class, ModuleSN + VersionSN.
        public void SelectForModuleDS(BlobClass Class, long ModuleSN, short ModuleVersionSN)
        {
            base.BeginQueryDS(m_sListField, "SN = " + ModuleSN.ToString() +
                    " AND ModuleVersionSN = " + ModuleVersionSN.ToString() + " AND Class = " 
                    + (int)(Class), string.Empty);
        }

        //private void SelectAllBase()
        //{
        //    string Query = ("SELECT " + m_sListField + " FROM Blob order by Class,SN,ModuleVersionSN");
        //    base.BeginQueryBase(Query);
        //}
        internal void SelectAllBase(string ModuleSN)
        {
            string Query = ("SELECT " + m_sListField + " FROM Blob where SN = " + ModuleSN + " order by Class,SN,ModuleVersionSN");
            base.BeginQueryBase(Query);
        }
        //internal void SelectAllBase(string ModuleSN, string ModuleVersionSN)
        //{
        //    string Query = ("SELECT " + m_sListField + " FROM Blob where SN = " + ModuleSN +
        //            " and ModuleVersionSN= " + ModuleVersionSN + " order by Class, SN");
        //    base.BeginQueryBase(Query);
        //}

        //********** Overridables Methods *****************************************
        //internal override void ExchangeData(EnumAction Action)
        //{
        //    ExchangeField(Action, 0, ref m_iClass);
        //}
        internal override void ExchangeDataDS(EnumAction Action)
        {
            ExchangeFieldDS(Action, 0, ref m_iClass);
        }

        public virtual new void ClearAllFields()
        {
            m_iClass = -1;
            base.ClearAllFields();
        }
        public virtual new short GetFieldCount() { return 1; }
    }

    //***************************************************************************
    //**///////////////////// CMBlobStateSet ////////////////////////////////////
    //***************************************************************************
    class CMBlobStateSet : CSQLSet
    {
        // Data Members
        public enum BlobClass { BlobSection = 1, BlobQDStateLink };

        protected int m_iClass = -1;

        //********** Constructors, Destructors ************************************
        public CMBlobStateSet(string Table)
            : base(Table)

        {
            m_sListField = "Class, StateSN, StateVersionSN, ModuleSN, ModuleVersionSN, Sequence";
        }
  

        ~CMBlobStateSet()
        {
        }
 
        public void SelectAllBase(int StateVersionSN)
        {
            string Query = ("SELECT " + m_sListField + " FROM BlobState where StateVersionSN=" +
                    StateVersionSN.ToString() + " order by Sequence");

            base.BeginQueryBase(Query);
        }

        //********** Public Query Methods *****************************************
        //public void SelectForStateAndModule(int Class, int StateSN, int StateVersionSN, long ModuleSN, int ModuleVersionSN)
        //{
        //    string Query = ("SELECT " + m_sListField + " FROM BlobState WHERE StateSN = " + (StateSN.ToString()) +
        //                 " AND StateVersionSN = " + (StateVersionSN.ToString()) + " AND ModuleSN = " + (ModuleSN.ToString()) +
        //                 " AND ModuleVersionSN = " + (ModuleVersionSN.ToString()) + " AND Class = " + (Class.ToString()) +
        //                 " ORDER BY Sequence");
        //    BeginQueryBase(Query);
        //}
        public void SelectForStateAndModuleDS(int Class, string StateSN, string StateVersionSN, string ModuleSN, string ModuleVersionSN)
        {
            this.BeginQueryDS(m_sListField, "StateSN = " + StateSN +
                         " AND StateVersionSN = " + StateVersionSN + " AND ModuleSN = " + ModuleSN +
                         " AND ModuleVersionSN = " + ModuleVersionSN + " AND Class = " + Class, "Sequence");
        }
        //********** Overridables Methods *****************************************
        //protected  virtual void ExchangeData (EnumAction Action, DataRow Row);
        public virtual new void ClearAllFields()
        {
            m_iClass = -1;
            base.ClearAllFields();
        }

        public virtual new short GetFieldCount() { return 1; }

        internal override void ExchangeDataDS(EnumAction Action)
        {
            ExchangeFieldDS(Action, 0, ref m_iClass);
        }

    }

}
