//----------------------------------------------------------------------------
//  Project RGTools
//  Dakota Software Corporation
//  Copyright � 1997. All Rights Reserved.
//  FILE:    pgblobit.h
//  AUTHOR:  Marc CHANTEGREIL
//
//  OVERVIEW
//  ~~~~~~~~
//  Class definition for TPageBlobit (TPageWithDB).
//
//----------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using NaturalNumericSort;
//using ODBCMngr;
using System.Windows.Forms;
//using System.Data.Odbc;
using System.Data;
using System.Data.SqlClient;

namespace RGTools_New
{
    using ReferenceTableType = List<TRefItem>;
    class TRefItem
    {
        // Data members.
        protected string m_sReferenceName;
        protected long m_lReferenceSN;
        protected long m_lTagDate;

        // ructors, Destructors.
        public TRefItem(string ReferenceName, long ReferenceSN, long TagDate)
        {
            m_sReferenceName = ReferenceName;
            m_lReferenceSN = ReferenceSN;
            m_lTagDate = TagDate;
        }
        protected TRefItem(TRefItem Other)
        {
            m_sReferenceName = Other.m_sReferenceName;
            m_lReferenceSN = Other.m_lReferenceSN;
            m_lTagDate = Other.m_lTagDate;
        }

        //static public bool operator ==(TRefItem c1, TRefItem c2)
        //{
        //    return c1.m_sReferenceName.ToLower() == c2.m_sReferenceName.ToLower();
        //}
        //static public bool operator !=(TRefItem c1, TRefItem c2)
        //{
        //    return c1.m_sReferenceName.ToLower() != c2.m_sReferenceName.ToLower();
        //}
        static public bool operator ==(TRefItem c1, TRefItem c2)
        {
            return c1.m_sReferenceName == c2.m_sReferenceName;
        }
        static public bool operator !=(TRefItem c1, TRefItem c2)
        {
            return c1.m_sReferenceName != c2.m_sReferenceName;
        }
        public override bool Equals(object obj)
        {
            if (TRefItem.Equals((obj as TRefItem), null))
            {
                return false;
            }
            else
            {
                return m_sReferenceName == ((TRefItem)obj).m_sReferenceName;
            }
        }
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public string GetReferenceName() { return m_sReferenceName; }
        public string ReferenceName
        {
            get
            {
                return m_sReferenceName;
            }
        }

        public long GetReferenceSN() { return m_lReferenceSN; }
        public long ReferenceSN
        {
            get
            {
                return m_lReferenceSN;
            }
        }
        public long GetTagDate() { return m_lTagDate; }
        public long TagDate
        {
            get
            {
                return m_lTagDate;
            }
        }

        public void PutReferenceName(string ReferenceName) { m_sReferenceName = ReferenceName; }
    }


    //******************************************************************
    //**//// TPageBlobit ///////////////////////////////////////////////
    //******************************************************************
    class TPageBlobit
    {
        // Data members
        const string __SQLV_pgblobit_2 = "CREATE INDEX I1 ON DomainStructure (ParentSN, ChildOrder)";
        const string __SQLV_pgblobit_3 = "DELETE FROM Blob";
        const string __SQLV_pgblobit_4 = "DELETE FROM BlobState";
        const string __SQLV_pgblobit_5 = "DROP INDEX I1 ON DomainStructure";
        const string __SQLV_pgblobit_101 = "DELETE FROM Blob WHERE (Class = 5 OR Class = 6) AND SN in ";
 
        const string __find_duplicate_domainSN = "SELECT distinct domainsn FROM DomainStructure d1 " +
                " where 1 < (select count(*) from DomainStructure d2 " +
                " where d1.domainsn  = d2.domainsn and d1.moduleversionsn=d2.moduleversionsn )";

        private frmMain _main = null;
        internal string DBName = string.Empty;
        internal string DBDir = string.Empty;
        internal PageType pgType = PageType.BlobsCreation;
        internal RadioButton rdoAllBlobs = null;

        bool m_bFullRebuild = false; // true if all blobs to rebuild.
        //bool m_bIndexI1 = false;     // to control the presence (or not) of the temporary index (clean-up issue)..
        SqlTransaction transaction = null;

        DataSql sqlbase = null;
        public TPageBlobit(frmMain Main)
        {
            _main = Main;
            sqlbase = new DataSql(_main.txtBlobsServer.Text, _main.txtBlobsDB.Text, _main.BlobUser, _main.BlobPW);
            DBName=_main.txtBlobsDB.Text.Trim();
            pgType = PageType.BlobsCreation;
            rdoAllBlobs = _main.optAllTheBlobs;
       }
        public TPageBlobit(frmMain Main, RadioButton rdoButton)
        {
            _main = Main;
            sqlbase = new DataSql(_main.SQLServer, _main.SQLDB, _main.SQLUser, _main.SQLPW);

            pgType = PageType.AutoProcess;
            rdoAllBlobs = rdoButton;
        }

        private string CheckDBName(string FileName)
        {
            if (FileName == string.Empty)
            {
                return string.Empty;
            }

            string ParentDir = Path.GetDirectoryName(FileName);// GetParentPath (ModuleName));

            if (ParentDir != string.Empty)
            {
                if (!Directory.Exists(ParentDir))
                {
                    return string.Empty;
                }
            }
            else
            {
                return Path.Combine(DBDir, FileName);
            }

            return FileName;
        }
        internal void DoProcess()
        {
            sqlbase.Open();
            transaction = sqlbase.BeginTransaction();

            DataSet ds = sqlbase.GetDataSet(__find_duplicate_domainSN);

            if (ds == null)
            {
                ErrorThrow("Error raised when running a query!");
                return;
            }

            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                _main.DisplayData(ds, PageType.BlobsCreation);

                ErrorThrow("The db " + DBName + " has duplicate domain SN!");
                return;
            }
            // Create Index to speed up the process.
            //m_bIndexI1 = false;

            //EXEC SQL EXECUTE IMMEDIATE 'CREATE INDEX I1 ON DomainStructure (ParentSN, ChildOrder)';
            sqlbase.RunSQL(__SQLV_pgblobit_2, true);

            //***MJC: For now, I don't know yet a way to test if an index is present in a database.
            //m_bIndexI1 = true;

            m_bFullRebuild = this._main.optAllTheBlobs.Checked;
            if (!CheckForCancel && rdoAllBlobs.Checked)
            {
                sqlbase.RunSQL(__SQLV_pgblobit_3, true);
                sqlbase.RunSQL(__SQLV_pgblobit_4, true);

                // We don't do a COMMIT WORK here, to give the user a longer time to cancel without any impact on the database.
                if (CheckForCancel)
                {
                    transaction.Rollback();
                    sqlbase.Close();
                    return;
                }
            }

            try
            {
                if (CheckForCancel)
                {
                    transaction.Rollback();
                    sqlbase.Close();
                    return;
                }

                BlobDomain();
                GC.Collect();

                if (CheckForCancel)
                {
                    transaction.Rollback();
                    sqlbase.Close();
                    return;
                }
                
                BlobRule();
                GC.Collect();

                if (CheckForCancel)
                {
                    transaction.Rollback();
                    sqlbase.Close();
                    return;
                }

                BlobAppVar();
                GC.Collect();

                if (CheckForCancel)
                {
                    transaction.Rollback();
                    sqlbase.Close();
                    return;
                }

                BlobRef();
                GC.Collect();

                if (CheckForCancel)
                {
                    transaction.Rollback();
                    sqlbase.Close();
                    return;
                }

                BlobQDLink();
                GC.Collect();

                if (CheckForCancel)
                {
                    transaction.Rollback();
                    sqlbase.Close();
                    return;
                }

                BlobState();
                GC.Collect();

                if (CheckForCancel)
                {
                    transaction.Rollback();
                    sqlbase.Close();
                    return;
                }

                LoadData();

                sqlbase.RunSQL(__SQLV_pgblobit_5, true);

                transaction.Commit();
            }
            catch (Exception e)
            {
                //_main.OutMsg(pgType, e.Message + ".\r\n");
                //transaction.Rollback();
                ErrorThrow(e.Message);
            }
            finally
            {
                sqlbase.Close();
            }
        }

        protected void BlobDomain()
        {
            _main.OutMsg(pgType, "Building Blobs for Domains(" + DateTime.Now.ToLongTimeString() + ").\r\n");


            // Declaration of database objects.
            CMModuleSet MModule = new CMModuleSet("Module");
            CMModuleVersionSet MModuleVersion = new CMModuleVersionSet("ModuleVersion");

            long ModuleSN;
            short ModuleVersionSN;
            short LastModuleVersionSN;

            const short LenHeading = 80;                   // Length for e domain heading.
            const short SizeChunk = LenHeading + 34;      // Size of one piece (one domain) of the blob.

            // Open the output file
            string FileName = Path.Combine(_main.toolSheet.TempDir, "BlobDom.Asc");
            if (File.Exists(FileName))
            {
                File.Delete(FileName);
            }
            StreamWriter ofDomain = null;
            try
            {
                ofDomain = new StreamWriter(FileName, false, Encoding.Default);
            }
            catch(Exception e)
            {
                throw (new Exception("Can't create " + FileName + Environment.NewLine + e.Message));
            }

            CMBlobSet MBlob = null;
            CMQSLinkSet MQSLink  = null;

            CMDomainSet MDomain = null;
            CMQDLinkSet MQDLink = null;
            CMQDLinkSet MQDLinkSub = null;

            CMRGKeyWordSetQuestion MRGKeyWord = null;
            CMQuestionSet MQuestion = null;


            while (MModule.FetchNextDS() == EnumSQLError.DB_NOERROR && !CheckForCancel)
            {
                ModuleSN = MModule.GetModuleSN();
                if (ModuleSN == 0) continue;   // No blobs for system module.

                if (MBlob == null)
                {
                    MBlob = new CMBlobSet("Blob", ModuleSN.ToString());
                }
                else
                {
                    MBlob.SelectAllBase(ModuleSN.ToString());
                }

                if (MQSLink == null)
                {
                    MQSLink = new CMQSLinkSet("QSLink", ModuleSN.ToString());
                }
                else
                {
                    MQSLink.SelectAllBase(ModuleSN.ToString());
                }

                MModuleVersion.SelectForModuleDS(ModuleSN);
                // Find the last VersionSN.  We want to compute tagdate only for the last VersionSN.
                if (MModuleVersion.FetchLastDS() != EnumSQLError.DB_NOERROR)
                {
                    ofDomain.Close();
                    throw (new Exception("Cannot access to the last version for " + MModule.GetModuleName()));
                }

                LastModuleVersionSN = MModuleVersion.GetModuleVersionSN();
                MModuleVersion.FetchAbsolute(0);

                while (MModuleVersion.FetchNextDS() == EnumSQLError.DB_NOERROR && !CheckForCancel)
                {                    
                    //_main.OutMsg(pgType, DateTime.Now.ToLongTimeString() + ".1\r\n");
                    ModuleVersionSN = MModuleVersion.GetModuleVersionSN();

                    // First, see if we need to rebuild or not.
                    if (!m_bFullRebuild)
                    {
                        // In Partial Rebuild, See if there is a blob record for this ModuleSN + ModuleVersionSN.
                        MBlob.SelectForModuleDS(CMBlobSet.BlobClass.BlobDomain, ModuleSN, ModuleVersionSN);


                        if (MBlob.FetchNextDS() == EnumSQLError.DB_NOERROR) continue;    // Blob already there.
                    }

                    _main.OutMsg(pgType, "   " + MModule.GetModuleName().Trim() + " (" + ModuleVersionSN.ToString() + ")");


                    if (MDomain == null)
                    {
                        MDomain = new CMDomainSet("DomainStructure",
                                    ModuleSN.ToString(), ModuleVersionSN.ToString());
                    }
                    else
                    {
                        MDomain.SelectAllBase(ModuleSN.ToString(), ModuleVersionSN.ToString());
                    }

                    if (MQDLink == null)
                    {
                        MQDLink = new CMQDLinkSet("QDLink",
                                    ModuleSN.ToString(), ModuleVersionSN.ToString());
                    }
                    else
                    {
                        MQDLink.SelectAllBase(ModuleSN.ToString(), ModuleVersionSN.ToString());
                    }

                    if (MQDLinkSub == null)
                    {
                        MQDLinkSub = new CMQDLinkSet("QDLink");
                    }
                    MQDLinkSub.CopyData(MQDLink);

                    if (MRGKeyWord == null)
                    {
                        MRGKeyWord = new CMRGKeyWordSetQuestion("RGKeyWord",
                              ModuleSN.ToString(), ModuleVersionSN.ToString());
                    }
                    else
                    {
                        MRGKeyWord.SelectAllBase(ModuleSN.ToString(), ModuleVersionSN.ToString());
                    }

                    if (MQuestion == null)
                    {
                        MQuestion = new CMQuestionSet("Question",
                                TypeSet.MiniSet, ModuleSN.ToString(), ModuleVersionSN.ToString());
                    }
                    else
                    {
                        MQuestion.SelectAllBase(ModuleSN.ToString(), ModuleVersionSN.ToString());
                    }

                    // Select all the Domains for this module.
                    int iCount = 0;   // Total number of Domains.
                    int jCount = 0;   // Number of domains for the current blob.
                    int jCount2 = 0;

                    int Sequence = 0;
                    bool NewBlob = true;

                    //MDomain.SelectForModuleDS(ModuleSN, ModuleVersionSN);
                    while (MDomain.FetchNextDS() == EnumSQLError.DB_NOERROR && !CheckForCancel)
                    {
                        if (NewBlob)
                        {
                            ofDomain.Write(((int)(CMBlobSet.BlobClass.BlobDomain)).ToString() + "," + ModuleSN.ToString()
                                    + "," + ModuleVersionSN.ToString() + "," + Sequence.ToString() + ",'");
                            NewBlob = false;
                            jCount = 0;
                        }

                        // Print a dot every 100 domains processed.
                        jCount++;
                        if (iCount++ % 300 == 0)
                        {
                            _main.OutMsg(pgType, ".");
                            jCount2++;

                            if (jCount2 > 170)
                            {
                                jCount2 = 0;
                                _main.OutMsg(pgType, Environment.NewLine);

                            }
                        }

                        // Output the current Domain.
                        ofDomain.Write(CVTHEX.LongToHex(MDomain.GetDomainSN()));

                        string Heading = MDomain.GetHeading();
                        // Double the quotes.
                        char c;
                        int i = 0;
                        while (i < Math.Min(LenHeading, (short)Heading.Length))
                        {
                            c = Heading[i];
                            if (c == '\'')
                            {
                                ofDomain.Write("''");
                            }
                            else
                            {
                                ofDomain.Write(c);
                            }
                            i++;
                        }
                        //assert (i == Math.Min (LenHeading, (short)Heading.length ()));
                        // string pad with spaces.
                        while (i < LenHeading)
                        {
                            ofDomain.Write(" ");
                            i++;
                        }

                        // Select all the questions related with the current domain and Compute the number
                        // and TagDate of GMP questions and the number and TagDate of Proposed Rule Questions.
                        // and the number and TagDate of ABridged Questions.
                        int QCount = 0;
                        int GMPCount = 0;
                        int PRuleCount = 0;
                        long OtherTagDate = 0;
                        long GMPTagDate = 0;
                        long PRuleTagDate = 0;

                        MQDLink.SelectForDomainDS(MDomain.GetDomainSN(), ModuleVersionSN);

                        while (MQDLink.FetchNextDS() == EnumSQLError.DB_NOERROR && !CheckForCancel)
                        {
                            //if (MQuestion.SelectSNDS(MQDLink.GetQuestionSN()) != EnumSQLError.DB_NOERROR)
                            if (MQuestion.SelectSNDS(MQDLink.GetQuestionSN()) == EnumSQLError.DB_NOTFOUND)
                            {
                                ofDomain.Close();
                                throw (new Exception("Question " + MQDLink.GetQuestionSN().ToString() +
                                            " missing in the Question Table."));
                            }
                            QCount++;
                            if ((MQuestion.GetProperties() & 1)==1)
                            {
                                GMPCount++;
                            }
                            else if ((MQuestion.GetProperties() & 2)==2)
                            {
                                PRuleCount++;
                            }

                            // Compute the TagDates (only for the last ModuleVersionSN).
                            if (ModuleVersionSN == LastModuleVersionSN)
                            {
                                MRGKeyWord.SelectForQuestionDS(MQDLink.GetQuestionSN());

                                while (MRGKeyWord.FetchNextDS() == EnumSQLError.DB_NOERROR && !CheckForCancel)
                                {
                                    if ((MQuestion.GetProperties() & 1)==1)
                                    {
                                        // GMP Question.
                                        GMPTagDate =Math.Max(GMPTagDate, MRGKeyWord.GetTagDate());
                                    }
                                    else
                                    {
                                        if ((MQuestion.GetProperties() & 2)==2)
                                            // Proposed Rule Question.
                                            PRuleTagDate = Math.Max(PRuleTagDate, MRGKeyWord.GetTagDate());
                                        else
                                            // Other Question.
                                            OtherTagDate = Math.Max(OtherTagDate, MRGKeyWord.GetTagDate());
                                    }
                                }

                                // Look if subquestion.
                                if (MQDLink.GetQSSN() != -1)
                                {
                                    // There is subquestion related.

                                    MQSLink.SelectSNDS(MQDLink.GetQSSN(), ModuleSN, ModuleVersionSN);
                                    //_main.OutMsg(pgType, MQSLink.elapsedTime + "\r\n");
                                    while (MQSLink.FetchNextDS() == EnumSQLError.DB_NOERROR && !CheckForCancel)
                                    {

                                        // Get the questions related with this subdomain.
                                        long SubDomainSN = MQSLink.GetSubQuestionDomainSN();

                                        MQDLinkSub.SelectForDomainDS(SubDomainSN, ModuleVersionSN);



                                        while (MQDLinkSub.FetchNextDS() == EnumSQLError.DB_NOERROR && !CheckForCancel)
                                        {

                                            //if (MQuestion.SelectSNDS(MQDLinkSub.GetQuestionSN()) != EnumSQLError.DB_NOERROR)
                                            if (MQuestion.SelectSNDS(MQDLinkSub.GetQuestionSN()) == EnumSQLError.DB_NOTFOUND)
                                            {
                                                ofDomain.Close();
                                                throw (new Exception("Question " + MQDLinkSub.GetQuestionSN().ToString() +
                                                            " missing in the Question Table"));
                                            }

                                            MRGKeyWord.SelectForQuestionDS(MQDLinkSub.GetQuestionSN());
                                            while (MRGKeyWord.FetchNextDS() == EnumSQLError.DB_NOERROR && !CheckForCancel)
                                            {
                                                if ((MQuestion.GetProperties() & 1)==1)
                                                    // GMP Question.
                                                    GMPTagDate = Math.Max(GMPTagDate, MRGKeyWord.GetTagDate());
                                                else
                                                    if ((MQuestion.GetProperties() & 2)==2)
                                                        // Proposed Rule Question.
                                                        PRuleTagDate = Math.Max(PRuleTagDate, MRGKeyWord.GetTagDate());
                                                    else
                                                        // Other Question.
                                                        OtherTagDate = Math.Max(OtherTagDate, MRGKeyWord.GetTagDate());
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        ofDomain.Write(CVTHEX.LongToHex(QCount));
                        if (MDomain.GetSubQuestion())
                        {
                            ofDomain.Write('Y');
                        }
                        else
                        {
                            ofDomain.Write('N');
                        }
                        if (MDomain.GetMarked())
                        {
                            ofDomain.Write('Y');
                        }
                        else
                        {
                            ofDomain.Write('N');
                        }

                        ofDomain.Write(CVTHEX.LongToHex(MDomain.GetParentSN())
                            + CVTHEX.LongToHex(GMPCount)
                            + CVTHEX.LongToHex(PRuleCount)
                            //+ CVTHEX.LongToHex (ABCount)
                            + CVTHEX.LongToHex(GMPTagDate)
                            + CVTHEX.LongToHex(PRuleTagDate)
                            + CVTHEX.LongToHex(OtherTagDate));


                        // Check for the size of the blob.
                        if ((jCount + 1) * SizeChunk > 65000)
                        {
                            NewBlob = true;
                            Sequence++;
                            jCount = 0;
                            ofDomain.WriteLine("'");  // Close the current blob.
                        }

                    }
                     
                    if (!CheckForCancel)
                    {
                        if (iCount > 0)
                        {
                            ofDomain.WriteLine("'");
                            _main.OutMsg(pgType, " " + iCount.ToString() + " domains.\r\n");
                        }
                    }
                }
            }

            ofDomain.Close();

            //if (!CheckForCancel)
            //{
            //    FileInfo fInfo1 = new FileInfo(FileName);
            //    if (fInfo1.Length > 0)
            //    {
            //        // There is something to load.
            //        _main.OutMsg(pgType, "Loading data into the database.\r\n");

            //        sqlbase.LoadTextToTable(FileName, "Blob");
            //     //   string h_FileName = "LOAD TABLE Blob FROM '" + FileName + "'";

            //     //   //EXEC SQL EXECUTE IMMEDIATE :h_FileName;
            //     //sqlbase.RunSQL(h_FileName);

   
            //        SetHasChanged(true);
            if (!CheckForCancel)
            {
                _main.OutMsg(pgType, "Blobs for Domains completed.\r\n\r\n");
            }
            //    }
            //}
        }
        protected void BlobRule()
        {
            _main.OutMsg(pgType, "Building Blobs for Rules(" + DateTime.Now.ToLongTimeString() + ").\r\n");

            // Declaration of database objects.
            CMModuleSet MModule = new CMModuleSet("Module");
            CMModuleVersionSet MModuleVersion = new CMModuleVersionSet("ModuleVersion");

            long ModuleSN;                       // The current Module.
            short ModuleVersionSN;
            const short SizeChunk = 20;

            // Open the output file.
            string FileName = Path.Combine(_main.toolSheet.TempDir, "BlobRule.Asc");
            if (File.Exists(FileName))
            {
                File.Delete(FileName);
            }

            StreamWriter ofBlobRule = null;

            try
            {
                ofBlobRule = new StreamWriter(FileName, false, Encoding.Default);
            }
            catch(Exception e)
            {
                throw (new Exception("Can't create " + FileName + Environment.NewLine + e.Message));
            }

            CMTemplateRuleSet MRule = null;

            // For each Module, read its rules, and build the blob.
            while (MModule.FetchNextDS() == EnumSQLError.DB_NOERROR && !CheckForCancel)
            {
                ModuleSN = MModule.GetModuleSN();
                if (ModuleSN == 0) continue;    // No blobs for system.

                CMBlobSet MBlob = new CMBlobSet("Blob", ModuleSN.ToString());

                MModuleVersion.SelectForModuleDS(ModuleSN);
                while (MModuleVersion.FetchNextDS() == EnumSQLError.DB_NOERROR && !CheckForCancel)
                {

                    ModuleVersionSN = MModuleVersion.GetModuleVersionSN();

                    // First, see if we need to rebuild or not.
                    if (!m_bFullRebuild)
                    {
                        // In Partial Rebuild, See if there is a blob record for this ModuleSN + ModuleVersionSN.
                        MBlob.SelectForModuleDS(CMBlobSet.BlobClass.BlobRules, ModuleSN, ModuleVersionSN);
                        if (MBlob.FetchNextDS() == EnumSQLError.DB_NOERROR) continue;    // Blob already there.
                    }

                    _main.OutMsg(pgType, "   " + MModule.GetModuleName().Trim() + " (" + ModuleVersionSN.ToString() + ")");

                    // Select all the Rules for this module (ordered by SetSN).
                    if (MRule == null)
                    {
                        MRule = new CMTemplateRuleSet("TemplateRule", ModuleSN.ToString(), ModuleVersionSN.ToString());
                    }
                    else
                    {
                        MRule.SelectAllBase(ModuleSN.ToString(), ModuleVersionSN.ToString());
                    }

                    short iCount = 0;
                    int jCount2 = 0;
                    //MRule.SelectForModuleDS(ModuleSN, ModuleVersionSN);
                    while (MRule.FetchNextDS() == EnumSQLError.DB_NOERROR && !CheckForCancel)
                    {

                        if (iCount == 0)
                        {
                            ofBlobRule.Write((int)(CMBlobSet.BlobClass.BlobRules) + "," + ModuleSN + "," + ModuleVersionSN + ",0,'");
                        }

                        // Display a dot every 100 rules processed.
                        if (iCount++ % 300 == 0)
                        { 
                            _main.OutMsg(pgType, ".");
                            jCount2++;

                            if (jCount2 > 170)
                            {
                                jCount2 = 0;
                                _main.OutMsg(pgType, Environment.NewLine);

                            }
                        }

                        // Output the current Rule.
                        ofBlobRule.Write(CVTHEX.LongToHex(MRule.GetRuleSN()) + CVTHEX.LongToHex(MRule.GetSetSN())
                              + CVTHEX.LongToHex(MRule.GetOp())
                                       + CVTHEX.LongToHex(MRule.GetCompASN()) + CVTHEX.LongToHex(MRule.GetCompBSN()));
                    }
                    if (!CheckForCancel)
                    {
                        if (iCount > 0)
                        {
                            ofBlobRule.WriteLine("'");
                            _main.OutMsg(pgType, " " + iCount.ToString() + " rules.\r\n");
                        }
                        // Check the size of the blob.
                        CheckSizeBlob(iCount, SizeChunk);
                    }
                }
            }

            ofBlobRule.Close();

            //if (!CheckForCancel)
            //{

            //    if (UTIL.FileSize(FileName) > 0)
            //    {
            //        // There is something to load.
            //        _main.OutMsg(pgType, "Loading data into the database.\r\n");
            //        sqlbase.LoadTextToTable(FileName, "Blob");
            //        //string h_FileName = "LOAD TABLE Blob FROM '" + FileName + "'";

            //        ////EXEC SQL EXECUTE IMMEDIATE :h_FileName;
            //        //sybase.RunSQL(h_FileName);


            //        SetHasChanged(true);
            //    }

            if (!CheckForCancel)
            { 
                _main.OutMsg(pgType, "Blobs for Rules completed.\r\n\r\n"); 
            }
            //}
        }
        protected void BlobAppVar()
        {
            _main.OutMsg(pgType, "Building Blobs for Applicability Variables(" + DateTime.Now.ToLongTimeString() + ").\r\n");

            // Declaration of database objects.
            CMModuleSet MModule = new CMModuleSet("Module");
            CMModuleVersionSet MModuleVersion = new CMModuleVersionSet("ModuleVersion");

            long ModuleSN;
            short ModuleVersionSN;
            const short SizeChunk = 10;      // Size of one piece of the blob.

            // Open the output file
            string FileName = Path.Combine(_main.toolSheet.TempDir, "BlobVar.Asc");
            if (File.Exists(FileName))
            {
                File.Delete(FileName);
            }

            StreamWriter ofBlobVar = null;

            try
            {
                ofBlobVar = new StreamWriter(FileName, false, Encoding.Default);
            }
            catch(Exception e)
            {
                throw (new Exception("Can't create " + FileName + Environment.NewLine + e.Message));
            }

            CMBlobSet MBlob = null;
            CMApplicVarSet MAppVar = null;

            // For each Module, read its App. Var., and build the blob.
            while (MModule.FetchNextDS() == EnumSQLError.DB_NOERROR && !CheckForCancel)
            {
                ModuleSN = MModule.GetModuleSN();

                if (MBlob == null)
                {
                    MBlob = new CMBlobSet("Blob", ModuleSN.ToString());
                }
                else
                {
                    MBlob.SelectAllBase(ModuleSN.ToString());
                }

                MModuleVersion.SelectForModuleDS(ModuleSN);
                while (MModuleVersion.FetchNextDS() == EnumSQLError.DB_NOERROR && !CheckForCancel)
                {
                    ModuleVersionSN = MModuleVersion.GetModuleVersionSN();

                    // First, see if we need to rebuild or not.
                    if (!m_bFullRebuild)
                    {
                        // In Partial Rebuild, See if there is a blob record for this ModuleSN + ModuleVersionSN.
                        MBlob.SelectForModuleDS(CMBlobSet.BlobClass.BlobAppVar, ModuleSN, ModuleVersionSN);
                        if (MBlob.FetchNextDS() == EnumSQLError.DB_NOERROR) continue;    // Blob already there.
                    }

                    if (MAppVar == null)
                    {
                        MAppVar = new CMApplicVarSet("ApplicabilityVariable",
                                  ModuleSN.ToString(),
                                ModuleVersionSN.ToString());
                    }
                    else
                    {
                        MAppVar.SelectAllBase(ModuleSN.ToString(), ModuleVersionSN.ToString());
                    }

                    _main.OutMsg(pgType, "   " + MModule.GetModuleName().Trim() + " (" + ModuleVersionSN.ToString() + ")");

                    // Select all the App. Var. for this module (ordered by ApplicSN).
                    short iCount = 0;
                    int jCount2 = 0;
                    MAppVar.SelectForModuleDS(ModuleSN, ModuleVersionSN);
                    while (MAppVar.FetchNextDS() == EnumSQLError.DB_NOERROR && !CheckForCancel)
                    {
                        if (iCount == 0)
                        {
                            ofBlobVar.Write((int)(CMBlobSet.BlobClass.BlobAppVar) + "," + ModuleSN + "," + ModuleVersionSN + ",0,'");
                        }

                        // Display a dot every 100 applicability variable processed.
                        if (iCount++ % 300 == 0)
                        {
                            _main.OutMsg(pgType, ".");
                            jCount2++;

                            if (jCount2 > 170)
                            {
                                jCount2 = 0;
                                _main.OutMsg(pgType, Environment.NewLine);

                            }
                        }

                        // Output the current Applicability Variable.
                        ofBlobVar.Write(CVTHEX.LongToHex(MAppVar.GetApplicSN()) + MAppVar.GetAClass()
                             + CVTHEX.LongToHex(MAppVar.GetASN()) + MAppVar.GetApplicability());
                    }
                    if (!CheckForCancel)
                    {
                        if (iCount > 0)
                        {
                            ofBlobVar.WriteLine("'");
                            _main.OutMsg(pgType, " " + iCount.ToString() + " applicability variables.\r\n");
                        }
                        // Check the size of the blob.
                        CheckSizeBlob(iCount, SizeChunk);
                    }
                }
            }
            ofBlobVar.Close();

            //if (!CheckForCancel)
            //{

            //    if (UTIL.FileSize(FileName) > 0)
            //    {

            //        // There is something to load.
            //        _main.OutMsg(pgType, "Loading data into the database.\r\n");
            //        //string h_FileName = "LOAD TABLE Blob FROM '" + FileName + "'";

            //        sqlbase.LoadTextToTable(FileName, "Blob");

            //        SetHasChanged(true);
            //    }

            if (!CheckForCancel)
            { 
                _main.OutMsg(pgType, "Blobs for Applicability Variables completed.\r\n\r\n"); 
            }
            //}

        }
        protected void BlobRef()
        {
            _main.OutMsg(pgType, "Building Blobs for References(" + DateTime.Now.ToLongTimeString() + ").\r\n");

            // Declaration of database objects.
            CMModuleSet MModule = new CMModuleSet("Module");
            CMModuleVersionSet MModuleVersion = new CMModuleVersionSet("ModuleVersion");

            ReferenceTableType TListRef = new ReferenceTableType();//100, 0, 1000);
            TLongArray TListParent = new TLongArray();// (15, 0, 1);

            TRefItem pSearch = new TRefItem("", 0, 0);

            // Open the output files
            string FileNameRefM = Path.Combine(_main.toolSheet.TempDir, "BlobRefM.Asc");
            UTIL.RemoveFile(FileNameRefM);

            FileStream ofRefBlobM = null;
            try
            {
                ofRefBlobM = new FileStream(FileNameRefM, FileMode.Create, FileAccess.Write);
            }
            catch(Exception e)
            {
                throw (new Exception("Can't create " + FileNameRefM + Environment.NewLine + e.Message));
            }

            string FileNameRefD = Path.Combine(_main.toolSheet.TempDir, "BlobRefD.Asc");
            UTIL.RemoveFile(FileNameRefD);

            FileStream ofRefBlobD = null;
            try
            {
                ofRefBlobD = new FileStream(FileNameRefD, FileMode.Create, FileAccess.Write);
            }
            catch(Exception e)
            {
                throw (new Exception("Can't create " + FileNameRefD + Environment.NewLine + e.Message));
            }

            long ModuleSN;
            long DomainSN;
            long ModuleVersionSN;
            long SNStartForRGKeyWord = 1000000000L;     // RGKeyword SN for states.

            CMBlobSet MBlob = null;
            CMRGKeyWordSetModule MRGKeyWord = null;
            CMRGKeyWordSetDomain MRGKeyWordDM = null;
            CMDomainSet MDomainChild = null;
            CMDomainSet MDomain = null;

            while (MModule.FetchNextDS() == EnumSQLError.DB_NOERROR && !CheckForCancel)
            {
                ModuleSN = MModule.GetModuleSN();

                //if (ModuleSN == 550000)
                //{
                //    string str = "";
                //}
                if (ModuleSN == 0) continue;   // No blobs for system module.

                // First, see if we need to rebuild or not.
                if (!m_bFullRebuild)
                {
                    if (MBlob == null)
                    {
                        MBlob = new CMBlobSet("Blob", ModuleSN.ToString());
                    }
                    else
                    {
                        MBlob.SelectAllBase(ModuleSN.ToString());
                    }
                    // In Partial Rebuild, See if there is a blob record for this ModuleSN + ModuleVersionSN.
                    MBlob.SelectForModuleDS(CMBlobSet.BlobClass.BlobRGKeyWordModule, ModuleSN, -1);
                    if (MBlob.FetchNextDS() == EnumSQLError.DB_NOERROR) continue;    // Blob already there.
                }

                _main.OutMsg(pgType, "   " + MModule.GetModuleName().Trim());

                // Select all the References for this module.
                int iCount = 0;
                int jCount2 = 0;
                if (MRGKeyWord == null)
                {
                    MRGKeyWord = new CMRGKeyWordSetModule("RGKeyWord", ModuleSN.ToString());
                }
                else
                {
                    MRGKeyWord.SelectAllBase(ModuleSN.ToString());
                }

                while (MRGKeyWord.FetchNextDS() == EnumSQLError.DB_NOERROR && !CheckForCancel)
                {
                    if (MRGKeyWord.GetReferenceSN() < SNStartForRGKeyWord)
                    {
                        // Don't output the States references (these are CA: Table ..).
                        // Concatenate the current Reference in the Blob Ref.

                        // Display a dot every 100 references processed.
                        if (iCount++ % 300 == 0)
                        {
                            _main.OutMsg(pgType, ".");
                            jCount2++;

                            if (jCount2 > 170)
                            {
                                jCount2 = 0;
                                _main.OutMsg(pgType, Environment.NewLine);

                            }
                        }

                        //if (MRGKeyWord.KeyWord.ToLower().IndexOf("discharge of storm water") > -1)
                        //{
                        //    string s = "";
                        //}

                        TListRef.Add(new TRefItem(MRGKeyWord.GetKeyWord(), MRGKeyWord.GetReferenceSN(), MRGKeyWord.GetTagDate()));
                    }
                }


                if (CheckForCancel) break;

                TListRef.Sort(CompareTRefItem);
                // Output the references.
                if (TListRef.Count > 0)
                {
                    OutputListRef(ofRefBlobM, ModuleSN, TListRef, (int)CMBlobSet.BlobClass.BlobRGKeyWordModule);
                }
                _main.OutMsg(pgType, " " + iCount.ToString() + " references.\r\n");

                MModuleVersion.SelectForModuleDS(ModuleSN);
                if (MModuleVersion.FetchLastDS() != EnumSQLError.DB_NOERROR)
                {
                    ErrorThrow("Cannot access to the last version for " + MModule.GetModuleName());
                    return;
                }
                ModuleVersionSN = MModuleVersion.GetModuleVersionSN();

                if (MRGKeyWordDM == null)
                {
                    MRGKeyWordDM = new CMRGKeyWordSetDomain("RGKeyWord",
                             ModuleSN.ToString());
                }
                else
                {
                    MRGKeyWordDM.SelectAllBase(ModuleSN.ToString());
                }

                if (MDomainChild == null)
                {
                    MDomainChild = new CMDomainSet("Domain", ModuleSN.ToString(), ModuleVersionSN.ToString());
                }
                else
                {
                    MDomainChild.SelectAllBase(ModuleSN.ToString(), ModuleVersionSN.ToString());
                }

                if (MDomain == null)
                {
                    MDomain = new CMDomainSet("Domain", ModuleSN.ToString());
                }
                else
                {
                    MDomain.SelectAllBase(ModuleSN.ToString());
                }

                if (!m_bFullRebuild)
                {
                    // In Partial Rebuild, delete first all the blobs for the previous ModuleVersionSN.
                    // To do this, we get all the domains related with this ModuleSN + ModuleVersionSN and delete the blobs
                    // (class 5 and 6) for these domains.
                    //if (MModuleVersion.FetchPrior() == EnumSQLError.DB_NOERROR)
                    if (MModuleVersion.FetchPriorDS() == EnumSQLError.DB_NOERROR)
                    {

                        //EXEC SQL BEGIN DECLARE SECTION;
                        long h_DomainSN;

                        //EXEC SQL END DECLARE SECTION;
                        MDomain.SelectForModuleDS(ModuleSN, MModuleVersion.GetModuleVersionSN());
                        StringBuilder sbDomain = new StringBuilder();
                        sbDomain.Append("(");
                        while (MDomain.FetchNextDS() == EnumSQLError.DB_NOERROR && CheckForCancel == false)
                        {
                            h_DomainSN = MDomain.GetDomainSN();
                            sbDomain.Append(MDomain.GetDomainSN().ToString() + ",");
                        }

                        string SNs = sbDomain.ToString();
                        if (SNs.EndsWith(","))
                        {
                            SNs = SNs.Substring(0, SNs.Length - 1) + ")";
                            sqlbase.RunSQL(__SQLV_pgblobit_101 + SNs, true);
                        }
                    }
                }

                if (CheckForCancel) break;

                // For each Domain of the current module, read its references and build the blobs.
                _main.OutMsg(pgType, "   " + MModule.GetModuleName().Trim());

                iCount = 0;
                jCount2 = 0;
                MDomain.SelectForModuleDS(ModuleSN, ModuleVersionSN);
                while (MDomain.FetchNextDS() == EnumSQLError.DB_NOERROR && !CheckForCancel)
                {
                    // Display a dot every 100 domains.
                    if (iCount++ % 300 == 0)
                    {
                        _main.OutMsg(pgType, ".");
                        jCount2++;

                        if (jCount2 > 170)
                        {
                            jCount2 = 0;
                            _main.OutMsg(pgType, Environment.NewLine);

                        }
                    }

                    // Don't get the list of references for a subquestion domain (will be merged with its parent domain).
                    if (MDomain.GetSubQuestion()) continue;

                    DomainSN = MDomain.GetDomainSN();

                    //if (DomainSN == 231006659)
                    //{
                    //    string s = "";
                    //}

                    //assert (TListRef.GetItemsInContainer () == 0);
                    if (ModuleSN != 0 && MDomain.GetParentSN() == 0)
                    {
                        // Level 1 Domain.
                        TListParent.Add(DomainSN);
                    }

                    int jCount = 0;

                    // Select all the References for this domain.
                    //TListRef.Clear();
                    GetListRefDomain(DomainSN, ModuleVersionSN, TListRef, ref jCount, MRGKeyWordDM, MDomainChild, pSearch, false);
                    if (CheckForCancel) break;

                    TListRef.Sort(CompareTRefItem);
                    // Output the list of the references for the current domain.
                    OutputListRef(ofRefBlobD, DomainSN, TListRef, (int)CMBlobSet.BlobClass.BlobRGKeyWordDomain);

                    // if the current domain is level 2, create a blob for all its hierarchy.
                    if (UTIL.ListLongFind(TListParent, MDomain.GetParentSN()))
                    {
                        jCount = 0;
                        //TListRef.Clear();
                        GetListRefDomain(DomainSN, ModuleVersionSN, TListRef, ref jCount, MRGKeyWordDM, MDomainChild, pSearch, true);
                        if (CheckForCancel) break;

                        TListRef.Sort(CompareTRefItem);
                        OutputListRef(ofRefBlobD, DomainSN, TListRef, (int)CMBlobSet.BlobClass.BlobRGKeyWordDomainRecursive);
                    }
                }

                if (!CheckForCancel)
                {
                    _main.OutMsg(pgType, " " + iCount.ToString() + " domains.\r\n");
                }
            }
            ofRefBlobM.Close();
            ofRefBlobD.Close();

            //if (!CheckForCancel)
            //{
            //    if (UTIL.FileSize(FileNameRefM) > 0 || UTIL.FileSize(FileNameRefD) > 0)
            //    {
            //        _main.OutMsg(pgType, "Loading data into the database.\r\n");
            //        // There is something to load.
            //        sqlbase.LoadTextToTable(FileNameRefM, "Blob");

            //        sqlbase.LoadTextToTable(FileNameRefD, "Blob");

            //        SetHasChanged(true);
            //    }

            if (!CheckForCancel)
            {
                _main.OutMsg(pgType, "Blobs for References completed.\r\n\r\n");
            }
            //}
        }
        protected void BlobQDLink()
        {
            const short SizeChunkQDLD = 8;      // Size of one piece of the blob.
            _main.OutMsg(pgType, "Building Blobs for Question/Domain Linkages(" + DateTime.Now.ToLongTimeString() + ").\r\n");

            const short SizeChunkQDLM = 16;     // Size of one piece of the blob.

            // Declaration of database objects.
            CMModuleSet MModule = new CMModuleSet("Module");
            CMModuleVersionSet MModuleVersion = new CMModuleVersionSet("ModuleVersion");

            // Open the output files
            string FileNameQDLM = Path.Combine(_main.toolSheet.TempDir, "BlobQDLM.Asc");
            UTIL.RemoveFile(FileNameQDLM);

            FileStream ofQDLinkM = null;
            try
            {
                ofQDLinkM = new FileStream(FileNameQDLM, FileMode.Create, FileAccess.Write);
            }
            catch(Exception e)
            {
                throw (new Exception("Can't create " + FileNameQDLM + Environment.NewLine + e.Message));
            }

            string FileNameQDLD = Path.Combine(_main.toolSheet.TempDir, "BlobQdlD.Asc");
            UTIL.RemoveFile(FileNameQDLD);

            FileStream ofQDLinkD = null;
            try
            {
                ofQDLinkD = new FileStream(FileNameQDLD, FileMode.Create, FileAccess.Write);
            }
            catch(Exception e)
            {
                throw (new Exception("Can't create " + FileNameQDLD+Environment.NewLine+e.Message));
            }

            // Output The list of QuestionSN (compliances questions) for each module.
            long ModuleSN;
            short ModuleVersionSN;
            short LastModuleVersionSN;

            long DomainSN;

            byte[] buffer = null;
            string strData = string.Empty;

            CMBlobSet MBlob = null;
            CMRGKeyWordSetQuestion MRGKeyWord = null;
            CMQSLinkSet MQSLink = null;

            CMQDLinkSet MQDLink = null;
            CMQuestionSet MQuestion = null;

            CMQDLinkSet MQDLinkSub = null;
            CMDomainSet MDomain = null;
            CMApplicVarSetPure MApplicVar = null;

            while (MModule.FetchNextDS() == EnumSQLError.DB_NOERROR && !CheckForCancel)
            {
                ModuleSN = MModule.GetModuleSN();
                if (ModuleSN == 0) continue;   // No blobs for system.

                string SN = ModuleSN.ToString();

                if (MBlob == null)
                {
                    MBlob = new CMBlobSet("Blob", SN);
                }
                else
                {
                    MBlob.SelectAllBase(SN);
                }

                if (MRGKeyWord == null)
                {
                    MRGKeyWord = new CMRGKeyWordSetQuestion("RGKeyWord", SN);
                }
                else
                {
                    MRGKeyWord.SelectAllBase(SN);
                }

                if (MQSLink == null)
                {
                    MQSLink = new CMQSLinkSet("QSLink", SN);
                }
                else
                {
                    MQSLink.SelectAllBase(SN);
                }

                MModuleVersion.SelectForModuleDS(ModuleSN);
                // Find the last VersionSN.  We want to compute tagdate only for the last VersionSN.
                if (MModuleVersion.FetchLastDS() != EnumSQLError.DB_NOERROR)
                {
                    _main.OutMsg(pgType, "Cannot access to the last version for " + MModule.GetModuleName().Trim());
                }
                LastModuleVersionSN = MModuleVersion.GetModuleVersionSN();

                MModuleVersion.FetchAbsolute(0);   // position before the first row.
                while (MModuleVersion.FetchNextDS() == EnumSQLError.DB_NOERROR && !CheckForCancel)
                {
                    ModuleVersionSN = MModuleVersion.GetModuleVersionSN();

                    // First, see if we need to rebuild or not.
                    if (!m_bFullRebuild)
                    {
                        // In Partial Rebuild, See if there is a blob record for this ModuleSN + ModuleVersionSN.
                        MBlob.SelectForModuleDS(CMBlobSet.BlobClass.BlobQMLink, ModuleSN, ModuleVersionSN);
                        if (MBlob.FetchNextDS() == EnumSQLError.DB_NOERROR) continue;   // blob already there.
                    }

                    if (MQDLink == null)
                    {
                        MQDLink = new CMQDLinkSet("QDLink",
                                SN, ModuleVersionSN.ToString());
                    }
                    else
                    {
                        MQDLink.SelectAllBase(SN, ModuleVersionSN.ToString());
                    }

                    if (MQuestion == null)
                    {
                        MQuestion = new CMQuestionSet("Question",
                                  TypeSet.MiniSet, SN, ModuleVersionSN.ToString());
                    }
                    else
                    {
                        MQuestion.SelectAllBase(SN, ModuleVersionSN.ToString());
                    }

                    if (MQDLinkSub == null)
                    {
                        MQDLinkSub = new CMQDLinkSet("QDLink");
                    }
                    MQDLinkSub.CopyData(MQDLink);

                    if (MDomain == null)
                    {
                        MDomain = new CMDomainSet("Domain",
                                  SN, ModuleVersionSN.ToString());
                    }
                    else
                    {
                        MDomain.SelectAllBase(SN, ModuleVersionSN.ToString());
                    }

                    if (MApplicVar == null)
                    {
                        MApplicVar = new CMApplicVarSetPure("ApplicabilityVariable", SN, ModuleVersionSN.ToString());
                    }
                    else
                    {
                        MApplicVar.SelectAllBase(SN, ModuleVersionSN.ToString());
                    }
                    _main.OutMsg(pgType, "   " + MModule.GetModuleName().Trim() + " (" + ModuleVersionSN.ToString() + ")");

                    // Select all the QDLink for this module (ordered by QuestionSN).
                    short iCount = 0;
                    int jCount2 = 0;
                    MQDLink.SelectForModuleDS(ModuleSN, ModuleVersionSN);
                    while (MQDLink.FetchNextDS() == EnumSQLError.DB_NOERROR && !CheckForCancel)
                    {
                        if (iCount == 0)
                        {
                            strData = ((int)(CMBlobSet.BlobClass.BlobQMLink)).ToString() + "," +
                                    ModuleSN.ToString() + "," + ModuleVersionSN.ToString() + ",0,'";
                            buffer = Encoding.Default.GetBytes(strData);
                            ofQDLinkM.Write(buffer, 0, strData.Length);
                        }
                        // Display a dot every 100 questions processed.
                        if (iCount++ % 300 == 0)
                        {
                            _main.OutMsg(pgType, ".");
                            jCount2++;

                            if (jCount2 > 170)
                            {
                                jCount2 = 0;
                                _main.OutMsg(pgType, Environment.NewLine);

                            }
                        }

                        // Output the current QDLink.
                        strData = CVTHEX.LongToHex(MQDLink.GetDomainSN());
                        buffer = Encoding.Default.GetBytes(strData);
                        ofQDLinkM.Write(buffer, 0, strData.Length);

                        strData = CVTHEX.LongToHex(MQDLink.GetQuestionSN());
                        buffer = Encoding.Default.GetBytes(strData);
                        ofQDLinkM.Write(buffer, 0, strData.Length);

                        //if (MQuestion.SelectSNDS(MQDLink.GetQuestionSN()) != EnumSQLError.DB_NOERROR)
                        if (MQuestion.SelectSNDS(MQDLink.GetQuestionSN()) == EnumSQLError.DB_NOTFOUND)
                        {
                            _main.OutMsg(pgType, "Question " + MQDLink.GetQuestionSN().ToString() +
                                         " missing in the Question Table.");
                            ofQDLinkM.Close();
                            return;
                        }
                        //ofQDLinkM.Write(CVTHEX.LongToHex(MQuestion.GetProperties()));
                        strData = CVTHEX.LongToHex(MQuestion.GetProperties());
                        buffer = Encoding.Default.GetBytes(strData);
                        ofQDLinkM.Write(buffer, 0, strData.Length);

                        // Compute the TagDate for this question (only for the last ModuleVersionSN).
                        long TagDate = 0;

                        if (ModuleVersionSN == LastModuleVersionSN)
                        {

                            MRGKeyWord.SelectForQuestionDS(MQDLink.GetQuestionSN());
                            while (MRGKeyWord.FetchNextDS() == EnumSQLError.DB_NOERROR)
                            {
                                TagDate = Math.Max(TagDate, MRGKeyWord.GetTagDate());
                            }
                            strData = CVTHEX.LongToHex(TagDate);
                            buffer = Encoding.Default.GetBytes(strData);
                            ofQDLinkM.Write(buffer, 0, strData.Length);
                        }
                    }
                    if (CheckForCancel) break;

                    // Second the pure applicability questions.
                    // We access them by the ApplicabilityVariable table.
                    //assert(iCount > 0);

                    MApplicVar.SelectPureForModuleDS(ModuleSN, ModuleVersionSN);
                    while (MApplicVar.FetchNextDS() == EnumSQLError.DB_NOERROR && !CheckForCancel)
                    {
                        // Display a dot every 100 questions.
                        if (iCount++ % 300 == 0)
                        {
                            _main.OutMsg(pgType, ".");
                            jCount2++;

                            if (jCount2 > 170)
                            {
                                jCount2 = 0;
                                _main.OutMsg(pgType, Environment.NewLine);

                            }

                        }

                        // DomainID is always -1, and properties are 0.
                        strData = @"\xFF\xFF\xFF\xFF" + CVTHEX.LongToHex(MApplicVar.GetASN()) + @"\x00\x00\x00\x00";
                        buffer = Encoding.Default.GetBytes(strData);
                        ofQDLinkM.Write(buffer, 0, strData.Length);

                        // Compute the TagDate for this question (only for the last ModuleVersionSN).
                        long TagDate = 0;

                        if (ModuleVersionSN == LastModuleVersionSN)
                        {

                            MRGKeyWord.SelectForQuestionDS(MApplicVar.GetASN());
                            while (MRGKeyWord.FetchNextDS() == EnumSQLError.DB_NOERROR)
                            {
                                TagDate = Math.Max(TagDate, MRGKeyWord.GetTagDate());
                            }
                            //ofQDLinkM.Write(CVTHEX.LongToHex(TagDate));
                            strData = CVTHEX.LongToHex(TagDate);
                            buffer = Encoding.Default.GetBytes(strData);
                            ofQDLinkM.Write(buffer, 0, strData.Length);
                        }
                    }
                    if (CheckForCancel) break;

                    if (iCount > 0)
                    {
                        strData = "'\r\n";
                        buffer = Encoding.Default.GetBytes(strData);
                        ofQDLinkM.Write(buffer, 0, strData.Length);
                        _main.OutMsg(pgType, " " + iCount.ToString() + " questions.\r\n");
                    }
                    // Check the size of the blob.
                    CheckSizeBlob(iCount, SizeChunkQDLM);

                    _main.OutMsg(pgType, "   " + MModule.GetModuleName().Trim() + " (" + ModuleVersionSN.ToString() + ")");

                    // Select all the QDLink for this module (ordered by QuestionSN).
                    iCount = 0;
                    jCount2 = 0;
                    short DCount = 0;    // reset the counter.
                    MDomain.SelectForModuleDS(ModuleSN, ModuleVersionSN);
                    while (MDomain.FetchNextDS() == EnumSQLError.DB_NOERROR && !CheckForCancel)
                    {

                        DomainSN = MDomain.GetDomainSN();

                        // Display a dot every 100 domains.
                        if (DCount++ % 300 == 0)
                        {
                            _main.OutMsg(pgType, ".");
                            jCount2++;

                            if (jCount2 > 170)
                            {
                                jCount2 = 0;
                                _main.OutMsg(pgType, Environment.NewLine);

                            }
                        }

                        // Skip the subquestion domain (will be merged with its parent domain).
                        if (MDomain.GetSubQuestion()) continue;

                        // Select all the questions related with the current domain.
                        iCount = 0;

                        MQDLink.SelectForDomainDS(DomainSN, ModuleVersionSN);
                        while (MQDLink.FetchNextDS() == EnumSQLError.DB_NOERROR && !CheckForCancel)
                        {

                            if (iCount == 0)
                            {
                                //ofQDLinkD.Write(CMBlobSet.BlobClass.BlobQDLink + "," + DomainSN + "," + ModuleVersionSN + ",0,'");
                                strData = ((int)CMBlobSet.BlobClass.BlobQDLink).ToString() + "," + DomainSN + "," + ModuleVersionSN + ",0,'";
                                buffer = Encoding.Default.GetBytes(strData);
                                ofQDLinkD.Write(buffer, 0, strData.Length);
                            }
                            iCount++;

                            // Output the current QDLink.
                            strData = CVTHEX.LongToHex(MQDLink.GetDomainSN())
                                      + CVTHEX.LongToHex(MQDLink.GetQuestionSN());
                            buffer = Encoding.Default.GetBytes(strData);
                            ofQDLinkD.Write(buffer, 0, strData.Length);

                            // Look if SubQuestion.
                            if (MQDLink.GetQSSN() != -1)
                            {
                                // There is subquestion related.

                                MQSLink.SelectSNDS(MQDLink.GetQSSN(), ModuleSN, ModuleVersionSN);
                                while (MQSLink.FetchNextDS() == EnumSQLError.DB_NOERROR && !CheckForCancel)
                                {
                                    // Get the Questions related with this SubDomain.
                                    long SubDomainSN = MQSLink.GetSubQuestionDomainSN();

                                    MQDLinkSub.SelectForDomainDS(SubDomainSN, ModuleVersionSN);
                                    while (MQDLinkSub.FetchNextDS() == EnumSQLError.DB_NOERROR)
                                    {
                                        //ofQDLinkD.Write(CVTHEX.LongToHex(SubDomainSN) + CVTHEX.LongToHex(MQDLinkSub.GetQuestionSN()));
                                        strData = CVTHEX.LongToHex(SubDomainSN) + CVTHEX.LongToHex(MQDLinkSub.GetQuestionSN());
                                        buffer = Encoding.Default.GetBytes(strData);
                                        ofQDLinkD.Write(buffer, 0, strData.Length);
                                        iCount++;
                                    }
                                }
                            }
                        }
                        if (iCount > 0)
                        {
                            //ofQDLinkD.WriteLine("'");
                            strData = "'\r\n";
                            buffer = Encoding.Default.GetBytes(strData);
                            ofQDLinkD.Write(buffer, 0, strData.Length);
                        }
                        // Check the size of the blob.
                        CheckSizeBlob(iCount, SizeChunkQDLD);
                    }
                    if (!CheckForCancel)
                    {
                        _main.OutMsg(pgType, " " + DCount.ToString() + " domains.\r\n");
                    }
                }
            }
            ofQDLinkM.Close();
            ofQDLinkD.Close();

            ////ofTest.Close();
            //if (!CheckForCancel)
            //{

            //    if (UTIL.FileSize(FileNameQDLM) > 0 || UTIL.FileSize(FileNameQDLD) > 0)
            //    {
            //        _main.OutMsg(pgType, "Loading data into the database.\r\n");
            //    }
            //    if (UTIL.FileSize(FileNameQDLM) > 0)
            //    {

            //        // There is something to load.
            //        //assert (FileNameQDLM.length () < 255);
            //        //strcpy (h_FileName, ("LOAD TABLE Blob FROM '" + FileNameQDLM + "'"));
            //        sqlbase.LoadTextToTable(FileNameQDLM, "Blob");

            //        SetHasChanged(true);
            //    }

            //    if (UTIL.FileSize(FileNameQDLD) > 0)
            //    {
            //        // There is something to load.
            //        sqlbase.LoadTextToTable(FileNameQDLD, "Blob");

            //        SetHasChanged(true);
            //    }
            if (!CheckForCancel)
            {
                _main.OutMsg(pgType, "Blobs for Question/Domain Linkages completed.\r\n\r\n");
            }
            //}
        }

        protected void LoadData()
        {
            string FileName = Path.Combine(_main.toolSheet.TempDir, "BlobDom.Asc");
            if (UTIL.FileSize(FileName) > 0)
            {
                // There is something to load.
                _main.OutMsg(pgType, "Loading domian data into the database.\r\n");
                sqlbase.LoadTextToTable(FileName, "Blob");
                SetHasChanged(true);
            }

            if (!CheckForCancel)
            {
                FileName = Path.Combine(_main.toolSheet.TempDir, "BlobRule.Asc");

                if (UTIL.FileSize(FileName) > 0)
                {
                    _main.OutMsg(pgType, "Loading rule data into the database.\r\n");
                    sqlbase.LoadTextToTable(FileName, "Blob");
                    SetHasChanged(true);
                }
            }

            if (!CheckForCancel)
            {
                FileName = Path.Combine(_main.toolSheet.TempDir, "BlobVar.Asc");
                if (UTIL.FileSize(FileName) > 0)
                {
                    _main.OutMsg(pgType, "Loading applicability variables data into the database.\r\n");
                    sqlbase.LoadTextToTable(FileName, "Blob");
                    SetHasChanged(true);
                }
            }

            if (!CheckForCancel)
            {
                _main.OutMsg(pgType, "Loading reference data into the database.\r\n");
                FileName = Path.Combine(_main.toolSheet.TempDir, "BlobRefM.Asc");
                if (UTIL.FileSize(FileName) > 0)
                {
                    // There is something to load.
                    sqlbase.LoadTextToTable(FileName, "Blob");
                    SetHasChanged(true);
                }

                FileName = Path.Combine(_main.toolSheet.TempDir, "BlobRefD.Asc");
                if (UTIL.FileSize(FileName) > 0)
                {
                    // There is something to load.
                    sqlbase.LoadTextToTable(FileName, "Blob");
                    SetHasChanged(true);
                }

            }

            if (!CheckForCancel)
            {
                _main.OutMsg(pgType, "Loading question/domain linkages data into the database.\r\n");

                FileName = Path.Combine(_main.toolSheet.TempDir, "BlobQDLM.Asc");
                if (UTIL.FileSize(FileName) > 0)
                {
                    sqlbase.LoadTextToTable(FileName, "Blob");
                    SetHasChanged(true);
                }

                FileName = Path.Combine(_main.toolSheet.TempDir, "BlobQdlD.Asc");
                if (UTIL.FileSize(FileName) > 0)
                {
                    // There is something to load.
                    sqlbase.LoadTextToTable(FileName, "Blob");
                    SetHasChanged(true);
                }
            }

            FileName = Path.Combine(_main.toolSheet.TempDir, "BlStQDLk.Asc");

            if (!CheckForCancel)
            {
                _main.OutMsg(pgType, "Loading state data into the database.\r\n");

                if (UTIL.FileSize(FileName) > 0)
                {
                    sqlbase.LoadTextToTable(FileName, "BlobState");
                    SetHasChanged(true);
                }

                FileName = Path.Combine(_main.toolSheet.TempDir, "BlStSect.Asc");
                if (UTIL.FileSize(FileName) > 0)
                {
                    sqlbase.LoadTextToTable(FileName, "BlobState");
                    SetHasChanged(true);
                }
            }
        }
        protected void OutputListRef(FileStream ORefFile, long DomainSN, ReferenceTableType TListRef, int Class)
        {
            short iCount = 0;
            short Sequence = 0;
            const short LenRGKeyWord = 66;
            const short SizeChunk = LenRGKeyWord + 8;    // length of a chunk in the blob.
            string KeyWord;

            //TListRef.Sort(CompareTRefItem);

            byte[] buffer = null;
            string strData = string.Empty;

            for (int i = 0; i < TListRef.Count; i++)
            {
                if (iCount == 0)
                {
                    strData = Class + "," + DomainSN + ",-1," + Sequence + ",'";
                    buffer = Encoding.Default.GetBytes(strData);
                    ORefFile.Write(buffer, 0, strData.Length);
                }
                iCount++;

                //ORefFile.Write(CVTHEX.LongToHex(TListRef[i].GetReferenceSN()));
                strData = CVTHEX.LongToHex(TListRef[i].GetReferenceSN());
                buffer = Encoding.Default.GetBytes(strData);
                ORefFile.Write(buffer, 0, strData.Length);

                KeyWord = TListRef[i].ReferenceName;

                //if (KeyWord.ToLower().IndexOf("discharge of storm water")>-1)
                //{
                //    string s = "";
                //}

                // Double the quote, because the delimiter is a Quote.
                int len = KeyWord.Length;
                KeyWord = KeyWord.Replace("\'", "''");
                if (len > LenRGKeyWord)
                {
                    KeyWord = KeyWord.Substring(0, LenRGKeyWord);
                }
                buffer = Encoding.Default.GetBytes(KeyWord);
                ORefFile.Write(buffer, 0, KeyWord.Length);

                //string s = "";
                //if (KeyWord.IndexOf("to Operators of Gas Transmission Pip") > -1)
                //{
                //    s = CVTHEX.LongToHex(-1);
                //}

                if (len < LenRGKeyWord)
                {
                    char[] chBlk = new char[LenRGKeyWord - len];
                    for (int j = 0; j < LenRGKeyWord - len; j++)
                    {
                        chBlk[j] = ' ';
                    }

                    strData = new string(chBlk);
                    buffer = Encoding.Default.GetBytes(strData);
                    ORefFile.Write(buffer, 0, strData.Length);
                }

                strData = CVTHEX.LongToHex(TListRef[i].TagDate);
                buffer = Encoding.Default.GetBytes(strData);
                ORefFile.Write(buffer, 0, strData.Length);

                // If the length of the current Blob is greater than ..., close it.
                if ((iCount + 1) * SizeChunk > 65000)
                {    // (iCount + 1) because we want to check if we
                    //ORefFile.WriteLine("'");               // have enough space for the next chunk.
                    strData = "'" + System.Environment.NewLine;
                    buffer = Encoding.Default.GetBytes(strData);
                    ORefFile.Write(buffer, 0, strData.Length);

                    iCount = 0;
                    Sequence++;
                }
            }
            // Don't forget to close the last blob.
            if (iCount > 0)
            {
                //ORefFile.WriteLine("'");
                strData = "'" + System.Environment.NewLine;
                buffer = Encoding.Default.GetBytes(strData);
                ORefFile.Write(buffer, 0, strData.Length);
            }
            // Empty the array.
            TListRef.Clear();
        }
        protected void GetListRefDomain(long DomainSN, long ModuleVersionSN, ReferenceTableType TListRef, 
                ref int iCount, CMRGKeyWordSetDomain MRGKeyWord, CMDomainSet MDomainChild, TRefItem pSearch, bool Recurse)
        {
            string KeyWord = string.Empty;

            MRGKeyWord.SelectForDomainDS(DomainSN);
            while (MRGKeyWord.FetchNextDS() == EnumSQLError.DB_NOERROR)
            {
                KeyWord = MRGKeyWord.GetKeyWord();
                pSearch.PutReferenceName(KeyWord);

                //if (KeyWord == "Decree_91-451_VisualScreen Art. 3" || KeyWord == "Decree_91-451_VisualScreen art. 3")
                //{
                //    string s = "";
                //}

                _tRefItem = pSearch;
                _tRefItem = TListRef.Find(matchTRefItem);
                if (TRefItem.Equals(_tRefItem, null))
                {
                    TListRef.Add(new TRefItem(KeyWord, MRGKeyWord.GetReferenceSN(), MRGKeyWord.GetTagDate()));
                    iCount++;
                }

            }
            if (CheckForCancel) return;

            // Merge also all the references included in the subdomains and children (depending on Recurse).
            TLongArray ListChild = new TLongArray();// (10, 0, 10);

            MDomainChild.SelectChildDS(DomainSN, ModuleVersionSN);
            while (MDomainChild.FetchNextDS() == EnumSQLError.DB_NOERROR)
            {
                if (MDomainChild.GetSubQuestion() || Recurse)
                    ListChild.Add(MDomainChild.GetDomainSN());
            }

            for (int i = 0; i < ListChild.Count; i++)
            {
                GetListRefDomain(ListChild[i], ModuleVersionSN, TListRef, ref iCount, MRGKeyWord, MDomainChild, pSearch, Recurse);
                if (CheckForCancel) break;
            }
        }
        protected void BlobState()
        {
            //int generation = 0;
            _main.OutMsg(pgType, "Building Blobs for States - Sections(" + DateTime.Now.ToLongTimeString() + ").\r\n");

            // Declaration of database objects.
            CMStateSet MState = new CMStateSet("State");
            CMStateModuleSet MStateModule = new CMStateModuleSet("StateModule");

            string Heading;
            const short LenHeading = 120;
            const short SizeChunkSect = LenHeading + 12;      // Size of one piece of the blob.

            // Open the output file
            string FileNameSect = Path.Combine(_main.toolSheet.TempDir, "BlStSect.Asc");
            UTIL.RemoveFile(FileNameSect);

            StreamWriter ofStateSect = null;
            try
            {
                ofStateSect = new StreamWriter(FileNameSect, false, Encoding.Default);
            }
            catch(Exception e)
            {
                throw (new Exception("Can't create " + FileNameSect + Environment.NewLine + e.Message));
            }

            // For each State, read its sections, and build the blob.
            int StateSN;
            int StateVersionSN;
            int ModuleSN;
            int ModuleVersionSN;

            CMStateSectionSetForState MStateSectionForState =  new CMStateSectionSetForState("StateSection");
            CMBlobStateSet MBlob = new CMBlobStateSet("BlobState");

            MBlob.SelectAllBase(0);
            while (MState.FetchNextDS() == EnumSQLError.DB_NOERROR && !CheckForCancel)
            {
                StateSN = MState.GetStateSN();

                // First, see if we need to rebuild or not.
                if (!m_bFullRebuild)
                {
                    // In Partial Rebuild, See if there is a blob record for this StateSN.
                    //MBlob.SelectForStateAndModule((int)CMBlobStateSet.BlobClass.BlobSection, StateSN, 0, 0, 0);
                    MBlob.SelectForStateAndModuleDS((int)CMBlobStateSet.BlobClass.BlobSection, StateSN.ToString(), "0", "0", "0");
                    if (MBlob.FetchNextDS() == EnumSQLError.DB_NOERROR) continue;    // Blob already there.
                }

                MStateSectionForState.SelectAllBase(StateSN.ToString());

                _main.OutMsg(pgType, "   " + MState.GetStateName().Trim());

                // Select all the Sections for this State.
                short iCount = 0;

                while (MStateSectionForState.FetchNextDS() == EnumSQLError.DB_NOERROR && CheckForCancel == false)
                {
                    if (iCount == 0)
                    {
                        ofStateSect.Write((int)CMBlobStateSet.BlobClass.BlobSection + "," + StateSN + ",0,0,0,0,'");
                    }
                    iCount++;

                    // Output the current SectionSN.
                    ofStateSect.Write(CVTHEX.LongToHex(MStateSectionForState.GetSDomainSN()) +
                            CVTHEX.LongToHex(MStateSectionForState.GetSectionSN()));
                    Heading = MStateSectionForState.GetHeading();
                    // Double the quotes.
                    int i = 0;
                    char c;
                    while (i < Math.Min(LenHeading, (short)Heading.Length) && !CheckForCancel)
                    {
                        c = Heading[i];
                        if (c == '\'')
                        {
                            ofStateSect.Write("''");
                        }
                        else
                        {
                            ofStateSect.Write(c);
                        }
                        i++;
                    }

                    // string pad with spaces.
                    while (i < LenHeading) { ofStateSect.Write(" "); i++; }

                    ofStateSect.Write(CVTHEX.LongToHex(MStateSectionForState.GetTagDate()));
                }
                if (!CheckForCancel)
                {
                    if (iCount > 0)
                    {
                        ofStateSect.WriteLine("'");
                        _main.OutMsg(pgType, " - " + iCount.ToString() + " sections.\r\n");
                    }
                    // Check the size of the blob.
                    CheckSizeBlob(iCount, SizeChunkSect);
                }

            }
            ofStateSect.Close();

            if (CheckForCancel) return;


            //**************************************************************** Blobs for QDStateLink.
            _main.OutMsg(pgType, "\r\nBuild Blobs for States - Question/Domain linkages.\r\n");

            // Open the output file
            string FileNameQDLk = Path.Combine(_main.toolSheet.TempDir, "BlStQDLk.Asc");
            UTIL.RemoveFile(FileNameQDLk);

            StreamWriter ofStateQDLk = null;

            try
            {
                ofStateQDLk = new StreamWriter(FileNameQDLk, false, Encoding.Default);
            }
            catch(Exception e)
            {
                throw (new Exception("Can't create " + FileNameQDLk + Environment.NewLine + e.Message));
            }

            long PrecSDomainSN = -1;
            long SDomainSN;
            long TagDate = 0;
            const short SizeChunkQDLk = 16;

            CMStateVersionSet MStateVersion = new CMStateVersionSet("StateVersion");

            CMQDStateLinkSet MQDStateLink = new CMQDStateLinkSet("QDStateLink");
            bool MQDStateLink_needReload = true;

            CMStateSectionSetForDomainAndState MStateSectionForDomainAndState =
                    new CMStateSectionSetForDomainAndState("StateSection");
            bool MStateSectionForDomainAndState_needReload = true;

            CMQCountStateSet MQCountState = new CMQCountStateSet("QCountState");

            List<string> lstSQL = new List<string>();
            while (MStateVersion.FetchNextDS() == EnumSQLError.DB_NOERROR && !CheckForCancel)
            {

                StateVersionSN = MStateVersion.GetStateVersionSN();
                //StateVersionSN = 56;
                MBlob.SelectAllBase(StateVersionSN);
                MQDStateLink_needReload = true;
                MStateSectionForDomainAndState_needReload = true;

                MQCountState.SelectAllBase(StateVersionSN);

                // Get the states available for this current StateVersionSN.
                while (MQCountState.FetchNextDS() == EnumSQLError.DB_NOERROR && !CheckForCancel)
                {
                    StateSN = MQCountState.GetStateSN();

                    if (MState.SelectSNDS(StateSN.ToString()) == EnumSQLError.DB_NOTFOUND)
                    {
                        throw (new Exception("StateSN " + StateSN.ToString() + " not found."));
                    }

                    short MCount = 0;

                    MStateModule.SelectForStateVersionDS(StateVersionSN); //.SelectForStateVersionDS(StateVersionSN.ToString());
                    while (MStateModule.FetchNextDS() == EnumSQLError.DB_NOERROR && CheckForCancel == false)
                    {

                        ModuleSN = MStateModule.GetModuleSN();
                        ModuleVersionSN = MStateModule.GetModuleVersionSN();

                        // First, see if we need to rebuild or not.
                        if (!m_bFullRebuild)
                        {
                            MBlob.SelectForStateAndModuleDS((int)CMBlobStateSet.BlobClass.BlobQDStateLink, StateSN.ToString(),
                                    StateVersionSN.ToString(), ModuleSN.ToString(), ModuleVersionSN.ToString());

                            if (MBlob.FetchNextDS() == EnumSQLError.DB_NOERROR) continue;   // Blob already there.

                        }

                        if (MCount == 0)
                        {
                            _main.OutMsg(pgType, "   " + MState.GetStateName().Trim() + " (" + StateVersionSN.ToString() +
                                              ")");
                        }
                        MCount++;

                        short iCount = 0;

                        if (MQDStateLink_needReload)
                        {
                            MQDStateLink.SelectAllBase(StateVersionSN);
                            MQDStateLink_needReload = false;
                        }

                        MQDStateLink.SelectForModuleAndStateDS(ModuleSN.ToString(), ModuleVersionSN.ToString(), 
                                StateVersionSN.ToString(), StateSN.ToString());
                        while (MQDStateLink.FetchNextDS() == EnumSQLError.DB_NOERROR && CheckForCancel == false)
                        {

                            if (iCount == 0)
                            {
                                _main.OutMsg(pgType, ".");
                                ofStateQDLk.Write((int)CMBlobStateSet.BlobClass.BlobQDStateLink + "," + StateSN + ","
                                        + StateVersionSN + "," + ModuleSN + "," + ModuleVersionSN + ",0,'");
                            }
                            iCount++;

                            SDomainSN = MQDStateLink.GetSDomainSN();
                            ofStateQDLk.Write(CVTHEX.LongToHex(SDomainSN)
                                        + CVTHEX.LongToHex(MQDStateLink.GetQuestionSN())
                                        + CVTHEX.LongToHex(MQDStateLink.GetProperties()));

                            // Compute the TagDate for this question.
                            // The TagDate of this question is the TagDate of the State Section related to its domain.
                            // If the current state Domain has not changed, the TagDate is already set (speed issue).
                            if (SDomainSN != PrecSDomainSN)
                            {
                                if (MStateSectionForDomainAndState_needReload)
                                {
                                    MStateSectionForDomainAndState.SelectAllBase(StateVersionSN);
                                    MStateSectionForDomainAndState_needReload = false;
                                }

                                if (MStateSectionForDomainAndState.SelectForDomainAndStateDS(StateSN.ToString(), 
                                            StateVersionSN.ToString(), SDomainSN.ToString()) == EnumSQLError.DB_NOTFOUND)
                                {
                                    // That must be a retired section.
                                    TagDate = 0;
                                }
                                else
                                {
                                    TagDate = MStateSectionForDomainAndState.GetTagDate();
                                    //EXEC SQL BEGIN DECLARE SECTION;

                                    long h_SectionSN;

                                    //EXEC SQL END DECLARE SECTION;
                                    //EXEC SQL CREATE VARIABLE h_Blob LONG BINARY;
                                    /*EXEC SQL SET h_Blob = :h_Buf;*/

                                    h_SectionSN = MStateSectionForDomainAndState.GetSectionSN();
                                    ////EXEC SQL UPDATE RGSection SET TagDate = h_Blob WHERE SectionSN = :h_SectionSN;

                                    lstSQL.Add("UPDATE RGSection    SET TagDate = '" + CVTHEX.LongToHex(TagDate) + CVTHEX.LongToHex(0) +
                                          CVTHEX.LongToHex(UInt16.MaxValue) + "' WHERE SectionSN = " + h_SectionSN.ToString());
                                }
                            }
                            ofStateQDLk.Write(CVTHEX.LongToHex(TagDate));
                            PrecSDomainSN = SDomainSN;
                        }
                        if (!CheckForCancel)
                        {
                            if (iCount > 0)
                            {
                                ofStateQDLk.WriteLine("'");
                            }
                            // Check the size of the blob.
                            CheckSizeBlob(iCount, SizeChunkQDLk);
                        }
                    }
                    if (!CheckForCancel && MCount > 0)
                    {
                        _main.OutMsg(pgType, " " + MCount.ToString() + " modules.\r\n");
                    }
                }

            }

            if (lstSQL.Count > 0)
            {
                sqlbase.RunSQL(lstSQL.ToArray(), true);
            }

            ofStateQDLk.Close();

            MStateVersion = null;
            MQDStateLink = null;
            MStateSectionForDomainAndState = null;
            MState = null;
            MStateModule = null;
            MQCountState = null;
            MQDStateLink = null;
            MBlob = null;

            GC.Collect();
            GC.WaitForPendingFinalizers();

            //if (!CheckForCancel)
            //{
            //    if (UTIL.FileSize(FileNameSect) > 0 || UTIL.FileSize(FileNameQDLk) > 0)
            //    {
            //        _main.OutMsg(pgType, "Loading data into the database.\r\n");
            //    }
            //    if (UTIL.FileSize(FileNameSect) > 0)
            //    {
            //        //EXEC SQL EXECUTE IMMEDIATE :h_FileName;
            //        sqlbase.LoadTextToTable(FileNameSect, "BlobState");

            //        SetHasChanged(true);
            //    }

            //    if (UTIL.FileSize(FileNameQDLk) > 0)
            //    {
            //        // There is something to load.
            //        //assert (FileNameQDLk.length () < 255);
            //        //strcpy (h_FileName, ("LOAD TABLE BlobState FROM '" + FileNameQDLk + "'"));
            //        sqlbase.LoadTextToTable(FileNameQDLk, "BlobState");

            //        //string ret = sybase.RunSQL(h_FileName);
            //        //_main.OutMsg(pgType, ret + "\r\n");

            //        SetHasChanged(true);
            //    }

            _main.OutMsg(pgType, "Blobs for States completed.\r\n\r\n");
            //}
        }

        protected void CheckSizeBlob(short iCount, short SizeChunk)
        {
            if (iCount * SizeChunk > 65000)
            {
                //throw (new Exception("Blob too big - See Software department"));
            }
        }

        private void ErrorThrow(string message)
        {
            if (message != string.Empty)
            {
                _main.OutMsg(pgType, message + ".\r\n");
                _main.processFailed = true;
            }
        }

        protected bool CheckForCancel
        {
            get
            {
                return _main.cancelPressed;
            }
        }
        protected void SetHasChanged(bool state)
        {
        }

        private static TRefItem _tRefItem = null;
        private static bool matchTRefItem(TRefItem tRefItem)
        {
            return (_tRefItem == tRefItem);
        }

        private static int CompareTRefItem(TRefItem trItem1, TRefItem trItem2)
        {
            if (trItem1.Equals(null))
            {
                if (trItem2.Equals(null))
                {
                    return 0;
                }
                else
                {
                    return -1;
                }
            }
            else
            {
                if (trItem2.Equals(null))
                {
                    return 1;
                }
                else
                {
                    return StringLogicalComparer.CompareNew(trItem1.ReferenceName, trItem2.ReferenceName);
                }
            }
        }
    }

}
