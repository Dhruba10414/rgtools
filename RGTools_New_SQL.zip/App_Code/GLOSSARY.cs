using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.Globalization;
using NaturalNumericSort;

namespace RGTools_New
{
    class TStringList : List<string>
    {
        public List<long> LineNumbers = new List<long>();

        public TStringList()
        { }
    }

    class TDefinition : TTextBlock
    {
        private string m_SortKey;
        private TStringList m_KeyList = new TStringList();

        public TDefinition(string pSortKey, long lineNo)
            : base(string.Empty)
        {
            m_SortKey = pSortKey;

            AddKey(pSortKey, lineNo);
            m_SortKey=m_SortKey.ToUpper();    //.to_upper();
        }

        public string GetSortKey()
        { return m_SortKey; }

        public string SortKey
        {
            get
            { return m_SortKey; }
        }

        public void AddKey(string pKey, long lineNo)
        {
            m_KeyList.Add(pKey);
            m_KeyList.LineNumbers.Add(lineNo);
        }

        public TStringList GetKeyList() { return m_KeyList; }

        public static bool operator ==(TDefinition def1, TDefinition def2)
        {
            if (IsNull(def1) && IsNull(def2))
            {
                return true;
            }
            else if (IsNull(def1) || IsNull(def2))
            {
                return false;
            }
            else
            {
                return (def1.m_SortKey == def2.m_SortKey) ? true : false;
            }
        }
        public static bool IsNull(TDefinition def)
        {
            return TDefinition.Equals(def, null);
        }
        public static bool operator !=(TDefinition def1, TDefinition def2)
        {
            if (IsNull(def1) && IsNull(def2))
            {
                return false;
            }
            else if (IsNull(def1) || IsNull(def2))
            {
                return true;
            }
            else
            {
                return (def1.m_SortKey != def2.m_SortKey) ? true : false;
            }
        }
        public override bool Equals(object def)
        {
            if (IsNull(def as TDefinition))
            {
                return false;
            }
            else
            {
                return this.m_SortKey == (def as TDefinition).m_SortKey ? true : false;
            }
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

    }

    class TGlossary : List<TDefinition>
    {
        private static TDefinition _def = null;

        public TGlossary()
            : base()
        {
        }

        public new void Add(TDefinition pDefinition)
        {
            _def = pDefinition;

            UTIL.Assert(pDefinition != null, "Assertion Failed: pDefinition != null!");

            TDefinition pMatch = base.Find(match);

            if (pMatch != null)
            {
                throw (new Exception(pDefinition.SortKey + " is defined more than once"));
            }

            base.Add(pDefinition);
            //SortDefinition();

            //if (pMatch && (pMatch->GetSortKey() == pDefinition->GetSortKey()))
            //    throw xmsg (pDefinition->GetSortKey() + " is defined more than once");

            //return TIBinarySearchTreeImp<TDefinition>::Add (pDefinition);  
            //throw xmsg;

            //return 0;
        }

        private static bool match(TDefinition def)
        {
            if (def == null)
            {
                return false;
            }

            if (def.SortKey == _def.SortKey)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private static int CompareTDefinition(TDefinition definition1, TDefinition definition2)
        {
            if (definition1 == null)
            {
                if (definition2 == null)
                {
                    return 0;
                }
                else
                {
                    return -1;
                }
            }
            else
            {
                if (definition2 == null)
                {
                    return 1;
                }
                else
                {
                    //return UTIL.CmpareString(definition1.SortKey, definition2.SortKey);
                    return string.Compare(definition1.SortKey, definition2.SortKey, StringComparison.Ordinal);
                    //return StringLogicalComparer.Compare(definition1.SortKey, definition2.SortKey);
                }
            }
        }
        public void SortDefinition()
        {
            base.Sort(CompareTDefinition);
        }

    }
}

