using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Odbc;
using System.Data;
using System.Runtime.InteropServices;
using System.Collections;
using System.Diagnostics;

namespace RGTools_New
{
    class Parameters
    {
        internal string _SQL = "";
        internal DataSet _ds = null;

        public Parameters()
        { }

        public Parameters(string SQL, DataSet DS)
        {
            _SQL = SQL;
            _ds = DS;
        }

    }
    //public class CreateToolhelp32SnapshotFlags
    //{

    //    public const uint TH32CS_SNAPHEAPLIST = 0x00000001;
    //    public const uint TH32CS_SNAPPROCESS = 0x00000002;
    //    public const uint TH32CS_SNAPTHREAD = 0x00000004;
    //    public const uint TH32CS_SNAPMODULE = 0x00000008;
    //    public const uint TH32CS_SNAPMODULE32 = 0x00000010;
    //    public const uint TH32CS_SNAPALL = (TH32CS_SNAPHEAPLIST | TH32CS_SNAPPROCESS | TH32CS_SNAPTHREAD | TH32CS_SNAPMODULE);
    //    public const uint TH32CS_INHERIT = 0x80000000;
    //}

 



    class DataSybase
    {
        //const uint STANDARD_RIGHTS_REQUIRED = 0x000F0000;
        //const uint SYNCHRONIZE = 0x00100000;
        //const uint PROCESS_ALL_ACCESS = (STANDARD_RIGHTS_REQUIRED | SYNCHRONIZE | 0xFFFF);
        

        public delegate void Display(string message);

        public event Display callBack;

        protected DataSet dsBase = null;

        private Stopwatch stopWatch = new Stopwatch();
        internal string elapsedTime = "";

        OdbcConnection DbConnection = null;
        string _dsn = string.Empty;
        string _uid = string.Empty;
        string _pwd = string.Empty;

        int num = -1;
        public DataSybase(string dsnName, string user, string password)
        {
            _dsn = "DSN=" + dsnName;
            _uid = "UID=" + user;
            _pwd = "PWD=" + password;

            if (DbConnection == null)
            {
                DbConnection = new OdbcConnection(_dsn + ";" + _uid + ";" + _pwd);
            }
        }
        
        ~DataSybase()
        {
            if (dsBase != null)
            {
                int generation = GC.GetGeneration(dsBase);

                dsBase = null;
                GC.Collect(generation);
                GC.WaitForPendingFinalizers();
            }
        }

        public DataSet SelectOdbcSrvRows(string query)
        {
            DataSet ds = null;

            try
            {
                OdbcDataAdapter adapter = new OdbcDataAdapter();
                adapter.SelectCommand = new OdbcCommand(query, DbConnection);
                adapter.Fill(ds);
            }
            catch
            {
            }

            return ds;
        }

        public string RunSQL(string SQL)
        {
            return RunSQL(SQL, false);
        }

        public string RunSQL(string SQL, bool KeepOpen)
        {
            OdbcCommand myCommand = new OdbcCommand(SQL, DbConnection);

            try
            {
                if (DbConnection.State == ConnectionState.Closed)
                {
                    //DbConnection.Open();
                    Open();
                }

                num = myCommand.ExecuteNonQuery();

                return string.Empty;
            }
            catch (Exception e)
            {

                return e.Message;
            }
            finally
            {
                if (!KeepOpen)
                {
                    DbConnection.Close();
                }
            }

        }

        public bool RunError = false;
        public string RunSQL(string[] SQL, string[] message)
        {
            return RunSQL(SQL, message, true);
        }
        public string RunSQL(string[] SQL, string[] message, bool ErroBreak)
        {
            StringBuilder sbErrMsg = new StringBuilder();

            RunError = false;

            OdbcCommand myCommand = new OdbcCommand();
            myCommand.Connection = DbConnection;

            int i = 0;
            try
            {
                //myCommand.Connection.Open();
                if (DbConnection.State == ConnectionState.Closed)
                {
                    //DbConnection.Open();
                    Open();
                }
                for (i = 0; i < SQL.Length; i++)
                {
                    if (SQL[i]!=null && SQL[i] != string.Empty && SQL[i].Trim() != "")
                    {
                        if (callBack != null && message[i] != string.Empty)
                        {
                            callBack(message[i]);
                        }

                        myCommand.CommandText = SQL[i];
                        try
                        {

                            int ret = myCommand.ExecuteNonQuery();
                            if (callBack != null && message[i] == string.Empty && ret > -1
                                    && message[i].ToUpper().Trim() != "COMMIT WORK") 
                            {
                                //callBack(ret.ToString() + " record(s) changed.\r\n");
                            }
                        }
                        catch (Exception ee)
                        {
                            if (SQL[i].ToUpper().IndexOf(" INDEX ") > 0
                                    || SQL[i].ToUpper().IndexOf("DROP TABLE ") > 0
                                    || SQL[i].ToUpper().IndexOf(" KEY ") > 0)
                            {
                                continue;
                            }

                            RunError = true;
                            if (ErroBreak)
                            {
                                callBack(ee.Message + ".\r\n");

                                throw ee;
                            }
                            else
                            {
                                sbErrMsg.Append(ee.Message + ".\r\n");
                            }
                        }
                    }
                }

                if (RunError)
                {
                    return sbErrMsg.ToString();

                }

                return string.Empty;
            }
            catch (Exception e)
            {
                RunError = true;
                return e.Message;// +". Error in query " + SQL[i];
            }
            finally
            {
                DbConnection.Close();

                UTIL.KillProcess("dbeng50.exe");
            }
        }

        public string RunSQL(string[] SQL)
        {
            string[] message = new string[SQL.Length];

            for (int i = 0; i < message.Length; i++)
            {
                message[i] = string.Empty;
            }

            return RunSQL(SQL, message, false);
        }
        public void RunSQL(object obj)
        {
            try
            {
                string[] SQL = obj as string[];

                RunSQL(SQL);
            }
            catch
            {
            }
        }

        public void GetDataSet(object obj)
        {
            try
            {
                Parameters prm = obj as Parameters;
                string SQL = prm._SQL;
                DataSet ds = prm._ds;

                GetDataSet(SQL, ref ds);
            }
            catch
            { }
        }

        public DataSet GetDataSet(string SQL)
        {
            if (DbConnection == null)
            {
                DbConnection = new OdbcConnection(_dsn + ";" + _uid + ";" + _pwd);
            }

            OdbcCommand myCommand = new OdbcCommand(SQL, DbConnection);
            OdbcDataAdapter adapter = new OdbcDataAdapter();
            adapter.SelectCommand = myCommand;
            DataSet ds = new DataSet();

            try
            {
                //stopWatch.Reset();
                //stopWatch.Start();

                if (ds.Tables.Count > 0)
                {
                    ds.Tables.Clear();
                }
                adapter.Fill(ds);

                //stopWatch.Stop();
                //TimeSpan ts = stopWatch.Elapsed;
                //elapsedTime = String.Format("{0:00}:{1:00}", ts.Minutes, ts.Seconds);
                //Debug.Print(elapsedTime);
            }
            catch (Exception e1)
            {
                try
                {
                    adapter.Fill(ds);
                }
                catch //(Exception e2)
                {
                    try
                    {
                        adapter.Fill(ds);
                    }
                    catch //(Exception e3)
                    {
                        DbConnection = new OdbcConnection(_dsn + ";" + _uid + ";" + _pwd);
                        myCommand = new OdbcCommand(SQL, DbConnection);
                        adapter = new OdbcDataAdapter();
                        adapter.SelectCommand = myCommand;

                        ds = new DataSet();
                        try
                        {
                            adapter.Fill(ds);
                        }
                        catch //(Exception e4)
                        {
                            //string s = CVTHEX.LongToHex(0);
                        }
                    }
                }
            }

            //DbConnection.Close();
            return ds;
        }
        public void GetDataSet(string SQL, ref DataSet ds)
        {
            DbConnection = new OdbcConnection(_dsn + ";" + _uid + ";" + _pwd);
            OdbcCommand myCommand = new OdbcCommand(SQL, DbConnection);
            OdbcDataAdapter adapter = new OdbcDataAdapter();
            adapter.SelectCommand = myCommand;

            try
            {
                //stopWatch.Reset();
                //stopWatch.Start();

                if (ds.Tables.Count > 0)
                {
                    ds.Tables.Clear();
                }
                adapter.Fill(ds);

                //stopWatch.Stop();
                //TimeSpan ts = stopWatch.Elapsed;
                //elapsedTime = String.Format("{0:00}:{1:00}", ts.Minutes, ts.Seconds);
                //Debug.Print(elapsedTime);
            }
            catch (Exception e1)
            {
                try
                {
                    adapter.Fill(ds);
                }
                catch //(Exception e2)
                {
                    try
                    {
                        adapter.Fill(ds);
                    }
                    catch //(Exception e3)
                    {
                        DbConnection = new OdbcConnection(_dsn + ";" + _uid + ";" + _pwd);
                        myCommand = new OdbcCommand(SQL, DbConnection);
                        adapter = new OdbcDataAdapter();
                        adapter.SelectCommand = myCommand;

                        ds = new DataSet();
                        try
                        {
                            adapter.Fill(ds);
                        }
                        catch //(Exception e4)
                        {

                            //string s = CVTHEX.LongToHex(0);
                        }
                    }
                }
            }
        }
        //public DataSet GetDataSet(string[] ColNames, string Filter, string Sort)
        //{
        //    DataSet ds = new DataSet();

        //    if (dsBase == null)
        //    {
        //        return ds;
        //    }
        //    try
        //    {
        //        //stopWatch.Reset();
        //        //stopWatch.Start();

        //        //DataView dv = dsBase.Tables[0].DefaultView;

        //        //dv.RowFilter = Filter;
        //        //dv.Sort = Sort;
        //        //ds.Tables.Add(dv.ToTable());

        //        DataRow[] foundRows;
        //        foundRows = dsBase.Tables[0].Select(Filter, Sort);
        //        DataTable db = dsBase.Tables[0].Clone();
        //        db.Clear();
        //        // Print column 0 of each returned row.
        //        for (int i = 0; i < foundRows.Length; i++)
        //        {
        //            DataRow newRow = db.NewRow();
        //            for (int j = 0; j < dsBase.Tables[0].Columns.Count; j++)
        //            {
        //                newRow[j] = foundRows[i][j];
        //            }

        //            db.Rows.Add(newRow);
        //        }

        //        ds.Tables.Add(db);

        //        //stopWatch.Stop();
        //        //TimeSpan ts = stopWatch.Elapsed;
        //        //elapsedTime = String.Format("{0:00}:{1:00}", ts.Seconds, ts.Milliseconds);

        //    }
        //    catch (Exception e)
        //    {
        //        string s = e.Message;
        //    }

        //    return ds;
        //}
        public void GetDataSet(string Filter, string Sort, ref DataSet ds)
        {
            //DataSet ds = new DataSet();

            if (dsBase == null)
            {
                return ;
            }
            try
            {
                //stopWatch.Reset();
                //stopWatch.Start();

                //DataView dv = dsBase.Tables[0].DefaultView;

                //dv.RowFilter = Filter;
                //dv.Sort = Sort;
                //ds.Tables.Add(dv.ToTable());

                DataRow[] foundRows;
                foundRows = dsBase.Tables[0].Select(Filter, Sort);
                DataTable db = dsBase.Tables[0].Clone();
                db.Clear();
                // Print column 0 of each returned row.
                for (int i = 0; i < foundRows.Length; i++)
                {
                    DataRow newRow = db.NewRow();
                    for (int j = 0; j < dsBase.Tables[0].Columns.Count; j++)
                    {
                        newRow[j] = foundRows[i][j];
                    }

                    db.Rows.Add(newRow);
                }

                ds.Tables.Clear();
                ds.Tables.Add(db);

                //stopWatch.Stop();
                //TimeSpan ts = stopWatch.Elapsed;
                //elapsedTime = String.Format("{0:00}:{1:00}", ts.Seconds, ts.Milliseconds);

            }
            catch (Exception e)
            {
                string s = e.Message;
            }

            return;
        }
        //public DataSet GetDataSet(string[] SQLs)
        //{
        //    DbConnection = new OdbcConnection(_dsn + ";" + _uid + ";" + _pwd);
        //    DbConnection.Open();

        //    OdbcCommand myCommand = new OdbcCommand();
        //    myCommand.Connection=DbConnection;

        //    OdbcDataAdapter adapter = new OdbcDataAdapter();
        //    DataSet ds = new DataSet();

        //    foreach (string _sql in SQLs)
        //    {
        //        if(_sql==null || _sql.Trim()=="")
        //        {
        //            continue;
        //        }

        //        myCommand.CommandText = _sql;
        //        adapter.SelectCommand = myCommand;

        //        DataTable db = new DataTable();
        //        try
        //        {
        //            adapter.Fill(db);

        //        }
        //        catch (Exception e1)
        //        {
        //        }
        //        finally
        //        {
        //            ds.Tables.Add(db);
        //        }
        //    }

        //    DbConnection.Close();
        //    return ds;
        //}

        public DataSet GetDataSet(string Filter, string Sort)
        {
            DataSet ds = new DataSet();

            if (dsBase == null)
            {
                return ds;
            }
            try
            {
                //stopWatch.Reset();
                //stopWatch.Start();

                //DataView dv = dsBase.Tables[0].DefaultView;

                //dv.RowFilter = Filter;
                //dv.Sort = Sort;
                //ds.Tables.Add(dv.ToTable());

                DataRow[] foundRows;
                foundRows = dsBase.Tables[0].Select(Filter, Sort);
                DataTable db = dsBase.Tables[0].Clone();
                db.Clear();
                // Print column 0 of each returned row.
                for (int i = 0; i < foundRows.Length; i++)
                {
                    DataRow newRow = db.NewRow();
                    for (int j = 0; j < dsBase.Tables[0].Columns.Count; j++)
                    {
                        newRow[j] = foundRows[i][j];
                    }

                    db.Rows.Add(newRow);
                }

                ds.Tables.Add(db);

                //stopWatch.Stop();
                //TimeSpan ts = stopWatch.Elapsed;
                //elapsedTime = String.Format("{0:00}:{1:00}", ts.Seconds, ts.Milliseconds);

            }
            catch (Exception e)
            {
                string s = e.Message;
            }

            return ds;
        }
        public DataSet GetBaseDataSet(string SQL)
        {
            if (DbConnection == null)
            {
                DbConnection = new OdbcConnection(_dsn + ";" + _uid + ";" + _pwd);
            }
            OdbcCommand myCommand = new OdbcCommand(SQL, DbConnection);
            OdbcDataAdapter adapter = new OdbcDataAdapter();
            adapter.SelectCommand = myCommand;

            if (dsBase == null)
            {
                dsBase = new DataSet();
            }

            try
            {
                //stopWatch.Reset();
                //stopWatch.Start();

                //DbConnection.Open();
                if (dsBase.Tables.Count > 0)
                {
                    dsBase.Tables.Clear();
                }
                adapter.Fill(dsBase);

                //stopWatch.Stop();
                //TimeSpan ts = stopWatch.Elapsed;
                //elapsedTime = String.Format("{0:00}:{1:00}", ts.Minutes, ts.Seconds);
                //Debug.Print(elapsedTime);
            }
            catch (Exception e1)
            {
                try
                {
                    adapter.Fill(dsBase);
                }
                catch //(Exception e2)
                {
                    try
                    {
                        adapter.Fill(dsBase);
                    }
                    catch //(Exception e3)
                    {
                        DbConnection = new OdbcConnection(_dsn + ";" + _uid + ";" + _pwd);
                        myCommand = new OdbcCommand(SQL, DbConnection);
                        adapter = new OdbcDataAdapter();
                        adapter.SelectCommand = myCommand;

                        dsBase = new DataSet();
                        try
                        {
                            adapter.Fill(dsBase);
                        }
                        catch //(Exception e4)
                        {

                            //string s = CVTHEX.LongToHex(0);
                        }
                    }
                }
            }
            finally
            {
                //DbConnection.Close();
            }
            //DbConnection.Close();
            return dsBase;
        }

        private void RemoveDuplicates(DataTable tbl, string[] keyColumns)
        {
            int rowNdx = 0;

            while (rowNdx < tbl.Rows.Count - 1)
            {
                DataRow[] dups = FindDups(tbl, rowNdx, keyColumns);

                if (dups.Length > 0)
                {
                    foreach (DataRow dup in dups)
                    {
                        tbl.Rows.Remove(dup);
                    }
                }
                else
                {
                    rowNdx++;
                }
            }
        }

        private DataRow[] FindDups(DataTable tbl, int sourceNdx, string[] keyColumns)
        {
            ArrayList retVal = new ArrayList();
            DataRow sourceRow = tbl.Rows[sourceNdx];

            for (int i = sourceNdx + 1; i < tbl.Rows.Count; i++)
            {
                DataRow targetRow = tbl.Rows[i];
                if (IsDup(sourceRow, targetRow, keyColumns))
                {
                    retVal.Add(targetRow);
                }
            }

            return (DataRow[])retVal.ToArray(typeof(DataRow));
        }

        private bool IsDup(DataRow sourceRow, DataRow targetRow, string[] keyColumns)
        {
            bool retVal = true;

            foreach (string column in keyColumns)
            {
                retVal = retVal && sourceRow[column.Trim()].Equals(targetRow[column.Trim()]);

                if (!retVal) break;
            }

            return retVal;
        }

        private void PrintRows(DataTable tbl)
        {

            for (int i = 0; i < tbl.Rows.Count; i++)
            {

                Console.WriteLine("row: {0}, ColumnA: {1}, ColumnB: {2}", i, tbl.Rows[i]["ColumnA"], tbl.Rows[i]["ColumnB"]);

            }



        }

        public OdbcDataReader GetReader(string SQL)
        {
            OdbcCommand myCommand = new OdbcCommand(SQL, DbConnection);
            if (DbConnection.State == ConnectionState.Closed)
            {
                try
                {
                    //DbConnection.Open();
                    Open();
                    OdbcDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection);
                    return reader;
                }
                catch (Exception e)
                {
                    return null;
                }
            }
            else
            {
                try
                {
                    OdbcDataReader reader = myCommand.ExecuteReader(CommandBehavior.Default);
                    return reader;
                }
                catch //(Exception e)
                {
                    return null;
                }
            }
        }

        public void Open()
        {
            try
            {
                DbConnection.Open();
            }
            catch
            {
                try
                {
                    DbConnection.Open();
                }
                catch(Exception e)
                {
                    throw e;
                }
            }
        }
        public void Close()
        {
            try
            {
                DbConnection.Close();
                UTIL.KillProcess("dbeng50.exe");
            }
            catch
            {
            }
        }

    }

}
