using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Threading;
using System.Diagnostics;

namespace RGTools_New
{
    //******************************************************************
    enum ios { write, read }

    class SNStream
    {
        // Data Members.
        private string SNFileName;
        private FileStream pSNFile;
        private long SerialNumber;

        // ructors / Destructors.
        // See comment "friend class".
        protected SNStream(string PrefixCode, string SNDir)
        {
            pSNFile = null;

            // First, ruct the file.
            //DateTime Today;

            long Year = DateTime.Now.Year % 100;
            long Month = DateTime.Now.Month;
            long Composite = (Year + 20) * 100 + Month;

            StringBuilder Title = new StringBuilder();

            Title.Append(Composite.ToString() + PrefixCode + ".SER");// + Environment.NewLine);
            SNFileName = Title.ToString();

            UTIL.Assert(SNFileName.Length <= 12, "Assertion Failed: SNFileName.Length <= 12!");
            //If...
            SNFileName = SNDir + "\\" + SNFileName;

            //pSNFile = new FileStream(SNFileName,FileMode.OpenOrCreate,FileAccess.ReadWrite);

            if (!File.Exists(SNFileName))
            {

                // The file doesn't exist.
                SerialNumber = Composite * 100000L;
                TransferSN(ios.write);

            }
            else
            {
                TransferSN(ios.read);
            }

            if (SerialNumber < Composite * 100000L)
            {
                //CXMSG XMSG ("The Serial Number " + NumToString (SerialNumber) + " in " + SNFileName + " is not valid.");
                //XMSG.Throw();
            }
        }

        protected void TransferSN(ios Mode)
        {
            long RetryCount = 0;
            bool FileOpened = false;

            while (!FileOpened)
            {
                //pSNFile.open (SNFileName.c_str (), FileMode.OpenOrCreate);
                try
                {
                    pSNFile = new FileStream(SNFileName, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                }
                catch//(Exception e)
                {
                    if (RetryCount > 5)
                    {
                        //CXMSG XMSG ("Problem to open " + SNFileName);
                        //XMSG.Throw();
                    }

                    RetryCount++;

                    Thread.Sleep(1000);
                    //sleep(1);
                }
                FileOpened = true;

            }

            if (Mode == ios.write)
            {
                //StreamWriter sw = new StreamWriter(pSNFile);
                StreamWriter sw = new StreamWriter(pSNFile, Encoding.Default);
                sw.WriteLine(SerialNumber.ToString());
                sw.Close();
            }
            else
            {
                UTIL.Assert(Mode == ios.read, "Assertion Failed: Mode == ios.read!");

                StreamReader sr = new StreamReader(pSNFile, Encoding.Default);
                string Temp = sr.ReadLine();
                try
                {

                    SerialNumber = long.Parse(Temp);
                }
                catch (Exception e)
                {
                    throw (e);
                }
                sr.Close();
            }

            //pSNFile->close ();
        }
        protected long IncrementSN()
        {
            UTIL.Assert(RemainingSN() > 0, "Assertion Failed: RemainingSN() > 0!");

            // Increment the serial number.
            SerialNumber++;

            // Save the Serial Number.
            TransferSN(ios.write);

            return SerialNumber;
        }

        public long GetSN()
        {
            return SerialNumber;
        }
        public long SN
        {
            get
            {
                return SerialNumber;
            }
        }

        public long RemainingSN()
        {
            return 100000L - (SerialNumber % 100000L) - 1;
        }

        public long AllocateSN() { return IncrementSN(); }

    }


    //******************************************************************
    class TDomainSN : SNStream
    {
        public TDomainSN(string SNDir)
            : base("DOM", SNDir)
        {
        }
    }

    //******************************************************************
    class TQuestionSN : SNStream
    {
        public TQuestionSN(string SNDir)
            : base("QST", SNDir)
        {
        }
    }

    //******************************************************************
    class TStateDomainSN : SNStream
    {
        public TStateDomainSN(string SNDir)
            : base("SDO", SNDir)
        {
        }
    }

    //******************************************************************
    class TStateQuestionSN : SNStream
    {
        public TStateQuestionSN(string SNDir)
            : base("SQU", SNDir)
        {
        }
    }

    //******************************************************************
    class TStateSectionSN : SNStream
    {
        public TStateSectionSN(string SNDir)
            : base("SSE", SNDir)
        {
        }
    }
}
