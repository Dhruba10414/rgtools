using System;
using System.Collections.Generic;
using System.Text;
using System.Data.OleDb;
using System.Data;
using System.Configuration;


namespace RGTools_New
{
    class DataAccess
    {
        private string _connectString = string.Empty;

        public DataAccess()
        {
            _connectString = ConfigurationManager.AppSettings["selFilesConnectionString"];
        }

        public bool SaveFileStatus(string path, List<FileSelStatus> status)
        {
            if (path != string.Empty)
            {
                try
                {
                    OleDbConnection conn = new OleDbConnection(_connectString);
                    conn.Open();
                    OleDbCommand cmd = new OleDbCommand();

                    cmd.CommandText = "SELECT * FROM Path WHERE Path='" + path + "'";
                    cmd.Connection = conn;

                    OleDbDataAdapter adapter = new OleDbDataAdapter();
                    adapter.SelectCommand = cmd;

                    DataSet ds = new DataSet();
                    adapter.Fill(ds);

                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        long pathID = long.Parse(ds.Tables[0].Rows[0]["PathID"].ToString());

                        cmd.CommandText = "SELECT * FROM Files WHERE PathID=" + pathID;
                        adapter.SelectCommand = cmd;
                        adapter.Fill(ds);

                        foreach (FileSelStatus sta in status)
                        {
                            bool found = false;

                            foreach (DataRow row in ds.Tables[0].Rows)
                            {
                                if (row["FileName"].ToString() == sta.FileName)
                                {
                                    long fileID = long.Parse(row["FIleID"].ToString());
                                    //"UPDATE Files SET FileName = "a", Selected = "b" WHERE FileID=123"
                                    if(sta.Selected)
                                    {
                                        cmd.CommandText = "UPDATE Files SET Selected=1 WHERE FileID=" + fileID;
                                    }
                                    else
                                    {
                                        cmd.CommandText = "UPDATE Files SET Selected=0 WHERE FileID=" + fileID;
                                    }
                                    cmd.ExecuteNonQuery();
                                    found = true;
                                    break;
                                }
                            }
                            
                            if (!found)
                            {
                                cmd.CommandText = "INSERT INTO Files (FileName, Selected, PathID) VALUES ('"
                                            + sta.FileName + "'," + sta.Selected + ",'" + pathID + "')";
                               
                                cmd.ExecuteNonQuery();      
                            }
                        }
                    }
                    else
                    {
                        cmd.CommandText = "INSERT INTO Path (Path) VALUES ('" + path + "')";
                        cmd.ExecuteNonQuery();

                        cmd.CommandText = "SELECT * FROM Path WHERE Path='" + path + "'";
                        cmd.Connection = conn;

                        adapter.SelectCommand = cmd;
                        adapter.Fill(ds);

                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            long pathID = long.Parse(ds.Tables[0].Rows[0]["PathID"].ToString());

                            foreach (FileSelStatus sta in status)
                            {
                                cmd.CommandText = "INSERT INTO Files (FileName, Selected, PathID) VALUES ('"
                                            + sta.FileName + "','" + sta.Selected + "','" + pathID + "')";
                                cmd.ExecuteNonQuery();
                            }
                        }
                        else
                        {
                            return false;
                        }
                    }
                }
                catch// (Exception e)
                {
                    return false;
                }
                return true;
            }
            else
            {
                return false;
            }

        }
        public bool GetFileStatus(string path, List<FileSelStatus> status)
        {
            if (path != string.Empty)
            {
                try
                {
                    OleDbConnection conn = new OleDbConnection(_connectString);
                    conn.Open();
                    OleDbCommand cmd = new OleDbCommand();

                    cmd.CommandText = "SELECT * FROM Path WHERE Path='" + path + "'";
                    cmd.Connection = conn;

                    OleDbDataAdapter adapter = new OleDbDataAdapter();
                    adapter.SelectCommand = cmd;

                    DataSet ds = new DataSet();
                    adapter.Fill(ds);

                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        long pathID = long.Parse(ds.Tables[0].Rows[0]["PathID"].ToString());

                        cmd.CommandText = "SELECT * FROM Files WHERE PathID=" + pathID;
                        adapter.SelectCommand = cmd;
                        adapter.Fill(ds);

                        foreach (FileSelStatus sta in status)
                        {
                            foreach (DataRow row in ds.Tables[0].Rows)
                            {
                                if (row["FileName"].ToString() == sta.FileName)
                                {
                                    sta.Selected = bool.Parse(row["Selected"].ToString());
                                    break;
                                }
                            }
                        }
                    }
                    else
                    {
                        return true;
                    }
                }
                catch// (Exception e)
                {
                    return false;
                }
                return true;
            }
            else
            {
                return false;
            }

        }

        public bool SaveDirStatus(string path, List<FolderSelStatus> status)
        {
            if (path != string.Empty)
            {
                try
                {
                    OleDbConnection conn = new OleDbConnection(_connectString);
                    conn.Open();
                    OleDbCommand cmd = new OleDbCommand();

                    cmd.CommandText = "SELECT * FROM Path WHERE Path='" + path + "'";
                    cmd.Connection = conn;

                    OleDbDataAdapter adapter = new OleDbDataAdapter();
                    adapter.SelectCommand = cmd;

                    DataSet ds = new DataSet();
                    adapter.Fill(ds);

                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        long pathID = long.Parse(ds.Tables[0].Rows[0]["PathID"].ToString());

                        cmd.CommandText = "SELECT * FROM Directory WHERE PathID=" + pathID;
                        adapter.SelectCommand = cmd;
                        adapter.Fill(ds);

                        foreach (FolderSelStatus sta in status)
                        {
                            bool found = false;

                            foreach (DataRow row in ds.Tables[0].Rows)
                            {
                                if (row["DirName"].ToString() == sta.FolderName)
                                {
                                    long DirID = long.Parse(row["DirID"].ToString());
                                    //"UPDATE Files SET FileName = "a", Selected = "b" WHERE FileID=123"
                                    if (sta.Selected)
                                    {
                                        cmd.CommandText = "UPDATE Directory SET Selected=1 WHERE DirID=" + DirID;
                                    }
                                    else
                                    {
                                        cmd.CommandText = "UPDATE Directory SET Selected=0 WHERE DirID=" + DirID;
                                    }
                                    cmd.ExecuteNonQuery();
                                    found = true;
                                    break;
                                }
                            }

                            if (!found)
                            {
                                cmd.CommandText = "INSERT INTO Directory (DirName, Selected, PathID) VALUES ('"
                                            + sta.FolderName + "'," + sta.Selected + ",'" + pathID + "')";

                                cmd.ExecuteNonQuery();
                            }
                        }
                    }
                    else
                    {
                        cmd.CommandText = "INSERT INTO Path (Path) VALUES ('" + path + "')";
                        cmd.ExecuteNonQuery();

                        cmd.CommandText = "SELECT * FROM Path WHERE Path='" + path + "'";
                        cmd.Connection = conn;

                        adapter.SelectCommand = cmd;
                        adapter.Fill(ds);

                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            long pathID = long.Parse(ds.Tables[0].Rows[0]["PathID"].ToString());

                            foreach (FolderSelStatus sta in status)
                            {
                                cmd.CommandText = "INSERT INTO Directory (DirName, Selected, PathID) VALUES ('"
                                            + sta.FolderName + "'," + sta.Selected + ",'" + pathID + "')";
                                cmd.ExecuteNonQuery();
                            }
                        }
                        else
                        {
                            return false;
                        }
                    }
                }
                catch// (Exception e)
                {
                    return false;
                }
                return true;
            }
            else
            {
                return false;
            }

        }
        public bool SetDirStatus(string path, List<FolderSelStatus> status)
        {
            if (path != string.Empty)
            {
                try
                {
                    OleDbConnection conn = new OleDbConnection(_connectString);
                    conn.Open();
                    OleDbCommand cmd = new OleDbCommand();

                    cmd.CommandText = "SELECT * FROM Path WHERE Path='" + path + "'";
                    cmd.Connection = conn;

                    OleDbDataAdapter adapter = new OleDbDataAdapter();
                    adapter.SelectCommand = cmd;

                    DataSet ds = new DataSet();
                    adapter.Fill(ds);

                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        long pathID = long.Parse(ds.Tables[0].Rows[0]["PathID"].ToString());

                        cmd.CommandText = "SELECT * FROM Directory WHERE PathID=" + pathID;
                        adapter.SelectCommand = cmd;
                        adapter.Fill(ds);

                        foreach (FolderSelStatus sta in status)
                        {
                            foreach (DataRow row in ds.Tables[0].Rows)
                            {
                                if (row["DirName"].ToString() == sta.FolderName)
                                {
                                    sta.Selected = bool.Parse(row["Selected"].ToString());
                                    break;
                                }
                            }
                        }
                    }
                    else
                    {
                        return true;
                    }
                }
                catch// (Exception e)
                {
                    return false;
                }
                return true;
            }
            else
            {
                return false;
            }

        }

        public bool GetDirStatus(string path, List<FolderSelStatus> status)
        {
            if (path != string.Empty)
            {
                try
                {
                    OleDbConnection conn = new OleDbConnection(_connectString);
                    conn.Open();
                    OleDbCommand cmd = new OleDbCommand();

                    cmd.CommandText = "SELECT * FROM Path WHERE Path='" + path + "'";
                    cmd.Connection = conn;

                    OleDbDataAdapter adapter = new OleDbDataAdapter();
                    adapter.SelectCommand = cmd;

                    DataSet ds = new DataSet();
                    adapter.Fill(ds);

                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        long pathID = long.Parse(ds.Tables[0].Rows[0]["PathID"].ToString());

                        cmd.CommandText = "SELECT * FROM Directory WHERE PathID=" + pathID;
                        adapter.SelectCommand = cmd;
                        adapter.Fill(ds);

                        foreach (DataRow row in ds.Tables[0].Rows)
                        {
                            try
                            {
                                string dir = row["DirName"].ToString().Trim();
                                bool sel = bool.Parse(row["Selected"].ToString());
                                if (dir != string.Empty)
                                {
                                    FolderSelStatus _sta = new FolderSelStatus(sel, dir);
                                    status.Add(_sta);
                                }
                            }
                            catch
                            {
                            }
                        }
                    }
                    else
                    {
                        return true;
                    }
                }
                catch //(Exception e)
                {
                    return false;
                }
                return true;
            }
            else
            {
                return false;
            }

        }

        public bool SaveLog(string Source, string Message)
        {
            if (Source != string.Empty && Message != string.Empty)
            {
                Message = Message.Replace("'", "''");
                OleDbConnection conn =null;
                try
                {
                    conn = new OleDbConnection(_connectString);
                    conn.Open();
                    OleDbCommand cmd = new OleDbCommand();

                    cmd.Connection = conn;

                    cmd.CommandText = "INSERT INTO Log (Source,Message) VALUES ('" + Source +
                            "','"+Message+ "')";
                    cmd.ExecuteNonQuery();

                }
                catch  //(Exception e)
                {
                    return false;
                }
                finally
                {
                    conn.Close();
                }
                return true;
            }
            else
            {
                return false;
            }

        }

        public DataSet GetLogData(DateTime date, PageType pType)
        {
            try
            {
                OleDbConnection conn = new OleDbConnection(_connectString);
                conn.Open();
                OleDbCommand cmd = new OleDbCommand();

                //SELECT * FROM Log WHERE Date=#2/26/2009#
                //AND Source="blobcreation"

                cmd.CommandText = "SELECT * FROM Log WHERE Delete=False AND Date =#" + 
                        date.ToString("MM/dd/yyyy") + "#";
                if (pType != PageType.All)
                {
                    cmd.CommandText += " AND Source='" + pType.ToString() + "'";
                }

                cmd.Connection = conn;

                OleDbDataAdapter adapter = new OleDbDataAdapter();
                adapter.SelectCommand = cmd;

                DataSet ds = new DataSet();
                adapter.Fill(ds);

                return ds;
            }
            catch//(Exception e)
            {
            }

            return null;
        }

        public bool DelLog(DateTime date, PageType pType)
        {
                OleDbConnection conn = null;
                try
                {
                    conn = new OleDbConnection(_connectString);
                    conn.Open();
                    OleDbCommand cmd = new OleDbCommand();

                    cmd.Connection = conn;

                    //UPDATE Log SET Delete = True
                    //WHERE Date=#2/27/2009# AND Source="buildrem";
                    cmd.CommandText = "UPDATE Log SET [Delete] = True WHERE Date =#" + date.ToString("MM/dd/yyyy") + "#";
                    if (pType != PageType.All)
                    {
                        cmd.CommandText += " AND Source='" + pType.ToString() + "'";
                    }

                    cmd.ExecuteNonQuery();

                }
                catch  //(Exception e)
                {
                    return false;
                }
                finally
                {
                    conn.Close();
                }
                return true;
        }
    }
}
