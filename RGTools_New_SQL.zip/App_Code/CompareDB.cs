using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace RGTools_New
{
    class CompareDB
    {
        string[] tbNames = new string[] 
                    {
                    //"ApplicabilityVariable", 
                    //"aw_Hyperlink",
                    //"aw_InfoOnly",
                    //"Blob",
                    //"BlobState",
                    "DomainStructure",
                    "Module",
                    "ModuleVersion",
                    "QCountState",
                    "QDLink",
                    "QDStateLink",
                    "QRLink",
                    "QSLink",
                    "Question",
                    "QuestionBody",
                    "RGKeyword",
                    "RGSection",
                    "RGTOC",
                    "ScreenGoal",
                    "SDVLink",
                    "State",
                    "StateDomainStructure",
                    "StateModule",
                    "StateSection",
                    "StateVersion",
                    "TemplateRule",
                    "Version"};

        private frmMain _main = null;
        const string _sql = "select * from ";
        PageType pgType = PageType.CompareDB;
        DataSybase sybase1 = null;
        DataSybase sybase2 = null;
        public CompareDB(frmMain Main)
        {
            _main = Main;

            sybase1 = new DataSybase("11_2009_UpdateStd1", _main.SybaseUser, _main.SybasePW);
            sybase2 = new DataSybase("std1_blobulrlwith020309tool", _main.SybaseUser, _main.SybasePW);
        }

        internal void DoProcess()
        {
            DataSet ds1 = null;
            DataSet ds2 = null;

            foreach (string str in tbNames)
            {
                _main.OutMsg(PageType.CompareDB, "Comparing table " + str + " now..." + Environment.NewLine);

                string SQL = _sql + str;

                ds1 = sybase1.GetDataSet(SQL);
                ds2 = sybase2.GetDataSet(SQL);

                if (UTIL.CheckDataSet(ds1) && UTIL.CheckDataSet(ds2))
                {
                    if (ds1.Tables[0].Rows.Count != ds2.Tables[0].Rows.Count)
                    {
                        _main.OutMsg(PageType.CompareDB, "2 table " + str + " have differnt sizes!" + Environment.NewLine);
                    }
                    else
                    {
                        for (int i = 0; i < ds1.Tables[0].Rows.Count; i++)
                        {
                            for (int j = 0; j < ds1.Tables[0].Columns.Count; j++) 
                            {
                                String str1 = ds1.Tables[0].Rows[i][j].ToString();
                                String str2 = ds2.Tables[0].Rows[i][j].ToString();

                                if (String.Compare(str1, str2, StringComparison.CurrentCulture) != 0) 
                                {
                                    _main.OutMsg(PageType.CompareDB, "Different values at row " + i.ToString() +
                                            " of field " + ds1.Tables[0].Columns[j].ColumnName + "!" + Environment.NewLine);
                                }
                            }
                        }
                    }
                }
                else
                {
                    _main.OutMsg(PageType.CompareDB, "One or all table " + str + " is(are) empty!" + Environment.NewLine);
                }
            }
        }
    }
}
