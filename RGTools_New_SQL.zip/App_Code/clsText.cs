using System;
using System.Collections.Generic;
using System.Text;

namespace RGTools_New
{
    //class Domain : List<Question>
    //{
    //    string _name = string.Empty;
    //    string _title = string.Empty;
    //    Domain _parent = null;

    //    public Domain(Domain parent, string name, string title)
    //    {
    //        _name = name;
    //        _parent = parent;
    //        _title = title;
    //    }
    //    public Domain(string name)
    //    {
    //        _name = name;
    //    }

    //    public string Name
    //    {
    //        get { return _name; }
    //    }
    //    public string Title
    //    {
    //        get { return _title; }
    //        set
    //        {
    //            _title = value;
    //        }
    //    }
    //    public Domain Parent
    //    {
    //        get { return _parent; }
    //        set
    //        {
    //            _parent = value;
    //        }
    //    }

    //    public void AddQuestion(Question question)
    //    {
    //        Question _question = this.FindFirst(question);

    //        if (_question == null)
    //        {
    //            base.Add(question);
    //        }
    //    }

    //    private static Question _question = null;
    //    private static bool match(Question question)
    //    {
    //        if (_question.KLine == question.KLine)
    //        {
    //            return true;
    //        }
    //        else
    //        {
    //            return false;
    //        }
    //    }

    //    public Question FindFirst(Question question)
    //    {
    //        _question = question;

    //        return base.Find(match);
    //    }
    //}

    //class DomainList : List<Domain>
    //{
    //    public DomainList()
    //    {
    //    }

    //    public void AddDomain(Domain domain)
    //    {
    //        Domain _domain = this.FindFirst(domain);

    //        if (_domain == null)
    //        {
    //            base.Add(domain);
    //        }
    //    }

    //    private static Domain _domain = null;
    //    private static bool match(Domain domain)
    //    {
    //        if (domain.Name == _domain.Name)
    //        {
    //            return true;
    //        }
    //        else
    //        {
    //            return false;
    //        }
    //    }

    //    public Domain FindFirst(Domain domain)
    //    {
    //        _domain = domain;

    //        return base.Find(match);
    //    }
    //}
    
    //class Question
    //{
    //    private string _kLine = string.Empty;
    //    private string _header = string.Empty;
    //    private string _subHeader = string.Empty;
    //    private bool _flag = true;
    //    public List<string> RLine = new List<string>();
    //    public List<string> LLine = new List<string>();
    //    public List<string> IfLine = new List<string>();    //@line

    //    public List<string> TLine = new List<string>();

    //    public bool RedFlag
    //    {
    //        get
    //        {
    //            return _flag;
    //        }
    //        set
    //        {
    //            _flag = value;
    //        }
    //    }
    //    public Question(string kLine)
    //    {
    //        _kLine = kLine;
    //    }

    //    public string KLine
    //    {
    //        get { return _kLine; }
    //        set
    //        {
    //            _kLine = value;
    //        }
    //    }
    //    public string Header
    //    {
    //        get { return _header; }
    //        set
    //        {
    //            _header = value;
    //        }
    //    }
    //    public string SubHeader
    //    {
    //        get { return _subHeader; }
    //        set
    //        {
    //            _subHeader = value;
    //        }
    //    }

    //    public void AddRLine(string rLine)
    //    {
    //        string _rLine =this.FindFirstRLine(rLine);

    //        if (_rLine == null)
    //        {
    //            this.RLine.Add(rLine);
    //        }
    //    }
    //    public void AddLLine(string lLine)
    //    {
    //        string _lLine = this.FindFirstRLine(lLine);

    //        if (_lLine == null)
    //        {
    //            this.LLine.Add(lLine);
    //        }
    //    }
    //    public void AddIfLine(string ifLine)
    //    {
    //        string _ifLine = this.FindFirstRLine(ifLine);

    //        if (_ifLine == null)
    //        {
    //            this.IfLine.Add(ifLine);
    //        }
    //    }
    //    private static string _rLine = string.Empty;
    //    private static bool matchRLine(string rLine)
    //    {
    //        if (rLine == _rLine)
    //        {
    //            return true;
    //        }
    //        else
    //        {
    //            return false;
    //        }
    //    }
    //    public string FindFirstRLine(string rLine)
    //    {
    //        _rLine = rLine;

    //        return RLine.Find(matchRLine);
    //    }

    //    private static string _lLine = string.Empty;
    //    private static bool matchLLIne(string lLine)
    //    {
    //        if (lLine == _lLine)
    //        {
    //            return true;
    //        }
    //        else
    //        {
    //            return false;
    //        }
    //    }
    //    public string FindFirstLLine(string lLine)
    //    {
    //        _lLine = lLine;

    //        return LLine.Find(matchLLIne);
    //    }

    //    private static string _ifLine = string.Empty;
    //    private static bool matchIfLine(string ifLine)
    //    {
    //        if (ifLine == _ifLine)
    //        {
    //            return true;
    //        }
    //        else
    //        {
    //            return false;
    //        }
    //    }
    //    public string FindFirstIfLine(string ifLine)
    //    {
    //        _ifLine = ifLine;

    //        return IfLine.Find(matchLLIne);
    //    }

    //}

    public class ModuleListItem
    {
        private string m_ModuleName = string.Empty;
        private long m_ModuleSN = 0;

        public ModuleListItem(string ModuleName, long ModuleSN)
        {
            m_ModuleName = ModuleName;
            m_ModuleSN = ModuleSN;
        }

        public string ModuleName
        {
            get { return this.m_ModuleName; }
            set { this.m_ModuleName = value; }
        }
        public long ModuleSN
        {
            get { return this.m_ModuleSN; }
            set { this.m_ModuleSN = value; }
        }
        public override string ToString()
        {
            return m_ModuleName;
        }
    }
}
