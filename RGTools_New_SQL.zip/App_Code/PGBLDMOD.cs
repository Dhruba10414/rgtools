//----------------------------------------------------------------------------
//  Project RGTools
//  Dakota Software Corporation
//  Copyright � 1997. All Rights Reserved.
//  FILE:    pgbldmod.h
//  AUTHOR:  Marc CHANTEGREIL
//
//  OVERVIEW
//  ~~~~~~~~
//  Class definition for TPageBuildModule (TPageRGTools).
//
//----------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Configuration;
using System.Windows.Forms;
using System.Windows;
using System.Data;
using System.Data.SqlClient;

namespace RGTools_New
{
    //******************************************************************
    //**//// TPageBuildModule //////////////////////////////////////////
    //******************************************************************
    class TPageBuildModule //: TPageRGTools
    {
        private frmMain _main = null;
        //private string ModuleName = string.Empty;
        private string ModuleDir = string.Empty;
        private PageType pgType = PageType.BuildMODULE;

        // Constructors, Destructors.
        public TPageBuildModule(frmMain Main)
        {
            _main = Main;
            _lstModuleSel = Main.lstModuleSel;
            ModuleDir = _main.txtModuleDir.Text.Trim();
            pgType = PageType.BuildMODULE;

            sqlbase = new DataSql(_main.txtModuleServer.Text, _main.txtModuleDB.Text, _main.ModuleUser, _main.ModulePW);
        }

        public TPageBuildModule(frmMain Main, ListBox lstModuleSel)
        {
            _main = Main;
            _lstModuleSel = lstModuleSel;
            //ModuleName = _main.txtAutoDB.Text.Trim();
            //ModuleDir = _main.txtAutoDir.Text.Trim();
            pgType = PageType.AutoProcess;
            sqlbase = new DataSql(_main.txtModuleServer.Text, _main.txtModuleDB.Text, _main.ModuleUser, _main.ModulePW);
        }

        const string __SQLV_pgbldmod_5 = "UPDATE ModuleVersion SET ModuleVersionSN = 0, DAResearchDate = 0, BNAResearchDate = 0";
        const string __SQLV_pgbldmod_6 = "UPDATE DomainStructure SET ModuleVersionSN = 0";
        const string __SQLV_pgbldmod_7 = "UPDATE QuestionBody SET Properties = 0";
        //const string __SQLV_pgbldmod_8 = "UPDATE QuestionBody SET Properties = 1 WHERE Properties = 0 AND (locate(stdtext, 'Not specifically a regulatory requirement') > 0 OR locate(notetext,'Not specifically a regulatory requirement') > 0 OR locate(stdtext, 'Not specifically an ISO 14001 Requirement') > 0 OR locate(notetext,'Not specifically an ISO 14001 Requirement') > 0)";
        const string __SQLV_pgbldmod_8 = "UPDATE QuestionBody SET Properties = 1 WHERE Properties = 0 AND (CHARINDEX('Not specifically a regulatory requirement',stdtext) > 0 OR CHARINDEX('Not specifically a regulatory requirement',notetext) > 0 OR CHARINDEX('Not specifically an ISO 14001 Requirement',stdtext) > 0 OR CHARINDEX('Not specifically an ISO 14001 Requirement',notetext) > 0)";
        //const string __SQLV_pgbldmod_9 = "UPDATE questionbody SET Properties = 2 WHERE Properties = 0 AND (locate(stdtext, 'Proposed') = 1 OR locate(stdtext, 'Draft Proposed') = 1)";
        const string __SQLV_pgbldmod_9 = "UPDATE questionbody SET Properties = 2 WHERE Properties = 0 AND (CHARINDEX('Proposed',stdtext) = 1 OR CHARINDEX('Draft Proposed',stdtext) = 1)";
        const string __SQLV_pgbldmod_10 = "UPDATE Question SET QuestionBodySN = QuestionSN";
        //const string __SQLV_pgbldmod_11 = "UPDATE Question KEY JOIN QuestionBody SET RFValue = 2 WHERE DataType = 'M'";
        const string __SQLV_pgbldmod_11 = "UPDATE Question SET RFValue = 2 from question inner JOIN QuestionBody on question.QuestionSN=QuestionBody.QuestionBodySN WHERE QuestionBody.DataType = 'M'";
        const string __SQLV_pgbldmod_12 = "UPDATE QDLink SET ModuleVersionSN = 0";
        const string __SQLV_pgbldmod_13 = "UPDATE QSLink SET ModuleVersionSN = 0";
        const string __SQLV_pgbldmod_14 = "UPDATE ApplicabilityVariable SET ModuleVersionSN = 0";
        const string __SQLV_pgbldmod_15 = "UPDATE ScreenGoal SET ModuleVersionSN = 0";
        const string __SQLV_pgbldmod_16 = "UPDATE TemplateRule SET ModuleVersionSN = 0";
        const string __SQLV_pgbldmod_17 = "UPDATE RGSection SET Sequence = SectionSN";
        const string __SQLV_pgbldmod_18 = "UPDATE aw_Hyperlink SET ModuleVersionSN = 0";
        const string __SQLV_pgbldmod_19 = "UPDATE aw_InfoOnly SET ModuleVersionSN = 0";

        const string __find_duplicate_domainSN = "SELECT distinct domainsn, m.ModuleName FROM DomainStructure d1 " +
            " inner join Module m on d1.ModuleSN=m.ModuleSN " +
            " where 1 < (select count(*) from DomainStructure d2 " +
            " where d1.domainsn  = d2.domainsn and d1.moduleversionsn=d2.moduleversionsn )";

        private ListBox _lstModuleSel;
                    DataSql sqlbase = null;

        public  void DoProcess()
        {
            //UTIL.RemoveFilesInDir(_main.toolSheet.TempDir);

            if(_lstModuleSel.Items.Count<1)
            {
                ErrorThrow("No selected Module(s)!");
                return;
            }

            //sqlbase = new DataSql(_main.txtModuleServer.Text, _main.txtModuleDB.Text, _main.ModuleUser, _main.ModulePW);

            try
            {
                //string inputline = "abc,'d,ef',ghi','jk,lm,nop',qst";
                //string[] arr = sqlbase.GetInputColumns(inputline);

                if (_main.ValidSqlServerConfiguration)
                {
                    sqlbase.Open();

                    sqlbase.RunSQL(Query.DeleteConstrains, true);
                    sqlbase.RunSQL(Query.DeleteSQLTables, true);
                    sqlbase.RunSQL(Query.CreateSQLTables, true);
                    sqlbase.RunSQL(Query.CreateConstrains, true);

                    // Build the nodule database.
                    BuildModule();

                    sqlbase.Close();
                }
                else
                {
                    _main.OutMsg(PageType.BuildMODULE, "Incorrect SQL server configuration!" + Environment.NewLine);
                }
            }
            catch(Exception e)
            {
                ErrorThrow(e.Message);
            }
        }

        //private bool CheckDir()
        //{
        //    if (ModuleName == string.Empty)
        //    {
        //        return false;
        //    }

        //    string ParentDir = Path.GetDirectoryName(ModuleName);// GetParentPath (ModuleName));

        //    if (ParentDir != string.Empty)
        //    {
        //        if (!Directory.Exists(ParentDir))
        //        {
        //            return false;
        //        }
        //    }
        //    else
        //    {
        //        ModuleName = Path.Combine(ModuleDir, ModuleName);
        //    }

        //    return true;
        //}

        string errMessage = "";
        internal void BuildModule()
        {
            errMessage = "";

            // Create the consolidate REM files.
            _main.OutMsg(pgType, "Consolidating the REM files:\r\n");

            // The three next BuildConsolidate use a prebuild file.
            string FileName = string.Empty;
            string TmpRGT = _main.toolSheet.TempDir;// m_pSheetParent.GetTempDir() + "\\";

            StreamWriter sw = null;
            //******************************************* App. Var.

            FileName = Path.Combine(TmpRGT, "AppVar.REM");
            try
            {
                sw = new StreamWriter(FileName, false, Encoding.Default);
                sw.WriteLine("0,'D',0,'A',0");
            }
            catch(Exception e)
            {
                ErrorThrow(e.Message);
                return;
            }
            finally
            {
                sw.Close();
            }

            //******************************************* Module.
            FileName = Path.Combine(TmpRGT, "Module.REM");
            try
            {
                sw = new StreamWriter(FileName, false, Encoding.Default);
                sw.WriteLine("0,'System',0,0,0");
            }
            catch (Exception e)
            {
                ErrorThrow(e.Message);
                return;
            }
            finally
            {
                sw.Close();
            }

            //BuildConsolidateREM("Module.REM");

            //******************************************* Module Version.
            FileName = Path.Combine(TmpRGT, "ModuleV.REM");
            try
            {
                sw = new StreamWriter(FileName, false, Encoding.Default);
                sw.WriteLine("0,'Release 1'");
            }
            catch (Exception e)
            {
                ErrorThrow(e.Message);
                return;
            }
            finally
            {
                sw.Close();
            }
            //BuildConsolidateREM("ModuleV.REM");
            try
            {
                if (CheckForCancel) return;

                BuildConsolidateREM("Question.REM");              

                if (CheckForCancel) return;

                BuildConsolidateREM("QDLink.REM");

                if (CheckForCancel) return;

                BuildConsolidateREM("QSLink.REM");

                if (CheckForCancel) return;

                BuildConsolidateREM("Rules.REM");

                if (CheckForCancel) return;

                BuildConsolidateREM("QstBody.REM");

                if (CheckForCancel) return;

                BuildConsolidateREM("Goal.REM");

                if (CheckForCancel) return;

                BuildConsolidateREM("RGSect.REM");

                if (CheckForCancel) return;

                BuildConsolidateREM("RGTOC.REM");

                if (CheckForCancel) return;

                BuildConsolidateREM("RGKeyWd.REM");

                if (CheckForCancel) return;

                BuildConsolidateREM("Domains.REM");

                if (CheckForCancel) return;

                BuildConsolidateREM("QRLink.REM");

                if (CheckForCancel) return;

                BuildConsolidateREM("HLINK.REM");

                if (CheckForCancel) return;

                BuildConsolidateREM("AppVar.REM");

                if (CheckForCancel) return;

                BuildConsolidateREM("Module.REM");

                if (CheckForCancel) return;

                BuildConsolidateREM("ModuleV.REM");

                if (CheckForCancel) return;

                BuildConsolidateREM("INFOONLY.REM");

                if (CheckForCancel) return;

                BuildConsolidateREM("RETIREDQUET.REM");

                _main.OutMsg(pgType, "\r\n");

                _main.OutMsg(PageType.BuildMODULE, "Importing Module Table Data.\r\n");
                LoadTextToTable(Path.Combine(TmpRGT, "Module.REM"), "Module");

                _main.OutMsg(PageType.BuildMODULE, "Importing ModuleVersion Table Data.\r\n");
                LoadTextToTable(Path.Combine(TmpRGT, "ModuleV.REM"), "ModuleVersion");
             
                sqlbase.RunSQL(__SQLV_pgbldmod_5, true);

                _main.OutMsg(PageType.BuildMODULE, "Importing DomainStructure Table Data.\r\n");
                LoadTextToTable(Path.Combine(TmpRGT, "Domains.REM"), "DomainStructure");

                sqlbase.RunSQL(__SQLV_pgbldmod_6, true);

                _main.OutMsg(PageType.BuildMODULE, "Importing QuestionBody Table Data.\r\n");
                LoadTextToTable(Path.Combine(TmpRGT, "QstBody.REM"), "QuestionBody");

                sqlbase.RunSQL(__SQLV_pgbldmod_7, true);

                sqlbase.RunSQL(__SQLV_pgbldmod_8, true);

                sqlbase.RunSQL(__SQLV_pgbldmod_9, true);

                _main.OutMsg(PageType.BuildMODULE, "Importing Question Table Data.\r\n");
                LoadTextToTable(Path.Combine(TmpRGT, "Question.REM"), "Question");

                sqlbase.RunSQL(__SQLV_pgbldmod_10, true);

                sqlbase.RunSQL(__SQLV_pgbldmod_11, true);

                _main.OutMsg(PageType.BuildMODULE, "Importing QDLink Table Data.\r\n");
                LoadTextToTable(Path.Combine(TmpRGT, "QDLink.REM"), "QDLink");

                sqlbase.RunSQL(__SQLV_pgbldmod_12, true);

                _main.OutMsg(PageType.BuildMODULE, "Importing QSLink Table Data.\r\n");
                LoadTextToTable(Path.Combine(TmpRGT, "QSLink.REM"), "QSLink");

                sqlbase.RunSQL(__SQLV_pgbldmod_13, true);

                _main.OutMsg(PageType.BuildMODULE, "Importing ApplicabilityVariable Table Data.\r\n");
                LoadTextToTable(Path.Combine(TmpRGT, "AppVar.REM"), "ApplicabilityVariable");

                sqlbase.RunSQL(__SQLV_pgbldmod_14, true);

                _main.OutMsg(PageType.BuildMODULE, "Importing ScreenGoal Table Data.\r\n");
                LoadTextToTable(Path.Combine(TmpRGT, "Goal.REM"), "ScreenGoal");

                sqlbase.RunSQL(__SQLV_pgbldmod_15, true);

                _main.OutMsg(PageType.BuildMODULE, "Importing TemplateRule Table Data.\r\n");
                LoadTextToTable(Path.Combine(TmpRGT, "Rules.REM"), "TemplateRule");

                sqlbase.RunSQL(__SQLV_pgbldmod_16, true);

                _main.OutMsg(PageType.BuildMODULE, "Importing RGSection Table Data.\r\n");
                LoadTextToTable(Path.Combine(TmpRGT, "RGSect.REM"), "RGSection");

                sqlbase.RunSQL(__SQLV_pgbldmod_17, true);

                _main.OutMsg(PageType.BuildMODULE, "Importing RGTOC Table Data.\r\n");
                LoadTextToTable(Path.Combine(TmpRGT, "RGTOC.REM"), "RGTOC");

                _main.OutMsg(PageType.BuildMODULE, "Importing RGKeyWord Table Data.\r\n");
                LoadTextToTable(Path.Combine(TmpRGT, "RGKeyWd.REM"), "RGKeyWord");

                _main.OutMsg(PageType.BuildMODULE, "Importing QRLink Table Data.\r\n");
                LoadTextToTable(Path.Combine(TmpRGT, "QRLink.REM"), "QRLink");

                _main.OutMsg(PageType.BuildMODULE, "Importing aw_Hyperlink Table Data.\r\n");
                LoadTextToTable(Path.Combine(TmpRGT, "HLink.REM"), "aw_Hyperlink");

                sqlbase.RunSQL(__SQLV_pgbldmod_18, true);

                _main.OutMsg(PageType.BuildMODULE, "Importing aw_InfoOnly Table Data.\r\n");
                LoadTextToTable(Path.Combine(TmpRGT, "InfoOnly.REM"), "aw_InfoOnly");

                sqlbase.RunSQL(__SQLV_pgbldmod_19, true);

                _main.OutMsg(PageType.BuildMODULE, "Importing RetiredQuest Table Data.\r\n");
                LoadTextToTable(Path.Combine(TmpRGT, "RETIREDQUET.REM"), "RetiredQuest");

                //check duplicate domain SN
                DataSet ds = sqlbase.GetDataSet(__find_duplicate_domainSN);

                if (ds == null)
                {
                    throw (new Exception("Error raised when running a query!"));
                }

                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    _main.DisplayData(ds, PageType.BuildMODULE);

                    throw (new Exception("There are duplicate domain SNs in single version!"));
                }
            }
            catch (Exception e)
            {
                if (!_main.isAutoProcess)
                {
                    ErrorThrow(e.Message);
                }
                else
                {
                    errMessage += e.Message + "\r\n";
                }
            }

            if (_main.isAutoProcess && errMessage != "")
            {
                ErrorThrow(errMessage);
            }
        }

        private bool LoadTextToTable(string FilePath, string TableName)
        {
            try
            {
                return sqlbase.LoadTextToTable(FilePath, TableName);
            }
            catch (Exception ee)
            {
                if (!_main.isAutoProcess)
                {
                    throw (ee);
                }
                else
                {
                    errMessage += ee.Message + "\r\n";
                }

                return false;
            }
        }

        private  void ErrorThrow(string message)
        {
            _main.OutMsg(pgType, message + ".\r\n");
            _main.processFailed = true;
        }
        private  void sybase_callBack(string message)
        {
            _main.OutMsg(pgType, message);
        }

        protected  void BuildConsolidateREM(string REMFile)
        {
            string TmpRGT = _main.toolSheet.TempDir;    // m_pSheetParent.GetTempDir() + "\\";

            string ConcatREM = Path.Combine(TmpRGT, REMFile);// TmpRGT + REMFile;
            string DirModule = ModuleDir;  // GetDlgField(this, IDC_DIRMODULE) + "\\";
            if (!DirModule.EndsWith(@"\"))
            {
                DirModule += @"\";
            }

            StreamWriter sw = null;

            // Create an empty file, if it doesn't exist.
            if (!File.Exists(ConcatREM))
            {

                try
                {
                    sw = new StreamWriter(ConcatREM, false, Encoding.Default);
                }
                catch(Exception e)
                {
                    if (!_main.isAutoProcess)
                    {
                        throw (e);
                    }
                    else
                    {
                        errMessage += e.Message + "\r\n";
                    }

                    return;
                }
                finally
                {
                    sw.Close();
                    sw.Dispose();
                }
            }

            for (int i = 0; i < _lstModuleSel.Items.Count; i++)
            {

                // Get the list of modules to build.
                string ModuleStr = _lstModuleSel.Items[i].ToString().Trim();

                sw = File.AppendText(ConcatREM);
                sw.WriteLine("--" + ModuleStr.Substring(2));
                sw.Close();
                sw.Dispose();

                if (!UTIL.FileCopy(DirModule + ModuleStr + "\\" + REMFile, ConcatREM, TypeFlagCopy.AppendMode))
                {
                    if (!_main.isAutoProcess)
                    {
                        throw (new Exception("Error during the creation of the consolidated REM files for " + DirModule + ModuleStr + "\\" + REMFile));
                    }
                    else
                    {
                        errMessage += "Error during the creation of the consolidated REM files for " + DirModule + ModuleStr + "\\" + REMFile + "\r\n";
                    }
                }
            }

            _main.OutMsg(pgType, ".");
        }

        private bool CheckForCancel
        {
            get
            {
                return _main.cancelPressed;
            }
        }

    }
}
