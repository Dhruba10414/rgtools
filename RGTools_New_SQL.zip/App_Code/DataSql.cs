﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Data;
using System.Runtime.InteropServices;
using System.Collections;
using System.Diagnostics;
using System.IO;
using System.Globalization;

namespace RGTools_New
{
    class Parameters
    {
        internal string _SQL = "";
        internal DataSet _ds = null;

        public Parameters()
        { }

        public Parameters(string SQL, DataSet DS)
        {
            _SQL = SQL;
            _ds = DS;
        }

    }

    class DataSql
    {
        const string Applicability = "INSERT INTO dbo.ApplicabilityVariable(ApplicSN,AClass,ASN,Applicability,ModuleSN)VALUES ";
        const string aw_Hyperlink = "INSERT INTO dbo.aw_Hyperlink(QuestionSN,LinkText,LinkSN,LinkType,VarSN,ModuleSN,ChildP) VALUES ";
        const string aw_InfoOnly = "INSERT INTO dbo.aw_InfoOnly(QuestionSN,ReferenceSN,ModuleSN) VALUES ";
        const string Blob = "INSERT INTO dbo.Blob(Class,SN,ModuleVersionSN,Sequence,Blob) VALUES ";
        const string BlobState = "INSERT INTO dbo.BlobState(Class,StateSN,StateVersionSN,ModuleSN,ModuleVersionSN,Sequence,Blob) VALUES ";
        const string DomainStructure = "INSERT INTO dbo.DomainStructure(DomainSN,Heading,ModuleSN,NQuestions,SubQuestion,Marked,ParentSN,ChildOrder) VALUES ";
        const string Module = "INSERT INTO dbo.Module(ModuleSN,ModuleName,MasterModuleID,MasterGroupID,MasterClassID) VALUES ";
        const string ModuleVersion = "INSERT INTO dbo.ModuleVersion(ModuleSN,VersionName) VALUES ";
        const string QCountState = "INSERT INTO dbo.QCountState(StateSN,StateVersionSN,StateDomainSN,QCount,TagDate) VALUES ";
        const string QDLink = "INSERT INTO dbo.QDLink(QDOrder,DomainSN,QuestionSN,QSSN,ModuleSN) VALUES ";
        const string QDStateLink = "INSERT INTO dbo.QDStateLink(StateSN,StateVersionSN,StateDomainSN,QDOrder,QuestionSN) VALUES ";
        const string QRLink = "INSERT INTO dbo.QRLink(QuestionSN,ReferenceSN,Sequence) VALUES ";
        const string QSLink = "INSERT INTO dbo.QSLink(QSSN,SubQuestionDomainSN,QSOrder,ModuleSN) VALUES ";
        const string Question = "INSERT INTO dbo.Question(QuestionSN,RFValue) VALUES ";
        const string QuestionBody = "INSERT INTO dbo.QuestionBody(QuestionBodySN,StdText,NoteText,ListAnswer,DataType) VALUES ";
        const string RGKeyword = "INSERT INTO dbo.RGKeyword(ReferenceSN,KeyWord,PStart,SectionSN,ModuleSN,TagDate) VALUES ";
        const string RGSection = "INSERT INTO dbo.RGSection(ModuleSN,SectionSN,Sequence,Heading,TextBlock,TagDate) VALUES ";
        const string RGTOC = "INSERT INTO dbo.RGTOC(ModuleSN,SectionSN,PStart,Sequence,Depth,HeadingNo,HeadingText,TagDate) VALUES ";
        const string ScreenGoal = "INSERT INTO dbo.ScreenGoal(ApplicSN,GoalOrder,ModuleSN) VALUES ";
        const string SDVLink = "INSERT INTO dbo.SDVLink(StateVersionSN,StateDomainSN) VALUES ";
        const string State = "INSERT INTO dbo.State(StateSN,StateName,PostalCode,MasterModuleID,MasterGroupID,MasterClassID) VALUES ";
        const string StateDomainStructure = "INSERT INTO dbo.StateDomainStructure(StateVersionSN,StateDomainSN,ModuleSN,ModuleVersionSN,Heading,ChildOrder,ParentSN) VALUES ";
        const string StateModule = "INSERT INTO dbo.StateModule(ModuleSN,ModuleVersionSN,StateVersionSN) VALUES ";
        const string StateSection = "INSERT INTO dbo.StateSection(StateDomainSN,StateVersionSN,StateSN,SectionSN,TagDate) VALUES ";
        const string StateVersion = "INSERT INTO dbo.StateVersion(StateVersionSN ,VersionName) VALUES ";
        const string TemplateRule = "INSERT INTO dbo.TemplateRule(RuleSN,SetSN,Op,CompASN,CompBSN,ModuleSN) VALUES ";
        const string Version = "INSERT INTO dbo.Version(VersionID) VALUES ";
        const string RetiredQuest = "INSERT INTO dbo.RetiredQuest(NewQuestionSN,OldQuestionSN,KLIne,ModuleVersionSN,IsDeleted) VALUES ";

        const string Applicability_full = "INSERT INTO dbo.ApplicabilityVariable(ApplicSN,ModuleSN,ModuleVersionSN,AClass,ASN,Applicability)VALUES ";
        const string aw_Hyperlink_full = "INSERT INTO dbo.aw_Hyperlink(QuestionSN,LinkText,LinkSN,LinkType,VarSN,ModuleSN,ChildP,ModuleVersionSN) VALUES ";
        const string aw_InfoOnly_full = "INSERT INTO dbo.aw_InfoOnly(QuestionSN,ReferenceSN,ModuleSN,ModuleVersionSN) VALUES ";
        const string Blob_full = "INSERT INTO dbo.Blob(Class,SN,ModuleVersionSN,Sequence,Blob) VALUES ";
        const string BlobState_full = "INSERT INTO dbo.BlobState(Class,StateSN,StateVersionSN,ModuleSN,ModuleVersionSN,Sequence,Blob) VALUES ";
        const string DomainStructure_full = "INSERT INTO dbo.DomainStructure(DomainSN,ModuleSN,ModuleVersionSN,NQuestions,SubQuestion,Marked,ParentSN,ChildOrder,Heading) VALUES ";
        const string Module_full = "INSERT INTO dbo.Module(ModuleSN,MasterModuleID,MasterGroupID,MasterClassID,ModuleName) VALUES ";
        const string ModuleVersion_full = "INSERT INTO dbo.ModuleVersion(ModuleVersionSN,ModuleSN,VersionName,DTRevision,BNAVersionName,DAResearchDate,BNAResearchDate) VALUES ";
        const string QCountState_full = "INSERT INTO dbo.QCountState(StateSN,StateVersionSN,StateDomainSN,QCount,TagDate) VALUES ";
        const string QDLink_full = "INSERT INTO dbo.QDLink(ModuleSN,ModuleVersionSN,DomainSN,QDOrder,QuestionSN,QSSN) VALUES ";
        const string QDStateLink_full = "INSERT INTO dbo.QDStateLink(StateSN,StateVersionSN,StateDomainSN,QDOrder,QuestionSN) VALUES ";
        const string QRLink_full = "INSERT INTO dbo.QRLink(QuestionSN,Sequence,ReferenceSN) VALUES ";
        const string QSLink_full = "INSERT INTO dbo.QSLink(ModuleSN,ModuleVersionSN,QSSN,QSOrder,SubQuestionDomainSN) VALUES ";
        const string Question_full = "INSERT INTO dbo.Question(QuestionSN,RFValue,RGKeyWordList,QuestionBodySN) VALUES ";
        const string QuestionBody_full = "INSERT INTO dbo.QuestionBody(QuestionBodySN,StdText,NoteText,ListAnswer,DataType,Properties) VALUES ";
        const string QuestionBody_full_1 = "INSERT INTO dbo.QuestionBody(QuestionBodySN,StdText,ListAnswer,NoteText,DataType,Properties) VALUES ";
        const string RGKeyword_full = "INSERT INTO dbo.RGKeyword(ReferenceSN,KeyWord,SectionSN,PStart,ModuleSN,TagDate) VALUES ";
        const string RGSection_full = "INSERT INTO dbo.RGSection(SectionSN,ModuleSN,Heading,TextBlock,TagDate,Sequence) VALUES ";
        const string RGTOC_full = "INSERT INTO dbo.RGTOC(ModuleSN,Sequence,SectionSN,Depth,HeadingNo,HeadingText,TagDate,PStart) VALUES ";
        const string ScreenGoal_full = "INSERT INTO dbo.ScreenGoal(ModuleSN,ModuleVersionSN,GoalOrder,ApplicSN) VALUES ";
        const string SDVLink_full = "INSERT INTO dbo.SDVLink(StateVersionSN,StateDomainSN) VALUES ";
        const string State_full = "INSERT INTO dbo.State(StateSN,StateName,PostalCode,MasterModuleID,MasterGroupID,MasterClassID) VALUES ";
        const string StateDomainStructure_full = "INSERT INTO dbo.StateDomainStructure(StateVersionSN,StateDomainSN,ModuleSN,ModuleVersionSN,ChildOrder,ParentSN,Heading) VALUES ";
        const string StateModule_full = "INSERT INTO dbo.StateModule(ModuleSN,ModuleVersionSN,StateVersionSN) VALUES ";
        const string StateSection_full = "INSERT INTO dbo.StateSection(StateDomainSN,StateSN,SectionSN,StateVersionSN,TagDate) VALUES ";
        const string StateVersion_full = "INSERT INTO dbo.StateVersion(StateVersionSN ,VersionName, DTRevision) VALUES ";
        const string TemplateRule_full = "INSERT INTO dbo.TemplateRule(RuleSN,ModuleSN,ModuleVersionSN,SetSN,Op,CompASN,CompBSN) VALUES ";
        const string Version_full = "INSERT INTO dbo.Version(VersionID) VALUES ";

        const string Applicability_export = "SELECT [ApplicSN],[ModuleSN],[ModuleVersionSN],[AClass],[ASN],[Applicability] FROM [dbo].[ApplicabilityVariable] order by [ApplicSN],[ModuleSN],[ModuleVersionSN]";
        const string aw_Hyperlink_export = "SELECT [QuestionSN],[LinkText],[LinkSN],[LinkType],[VarSN],[ModuleSN] ,[ChildP],[ModuleVersionSN] FROM [dbo].[aw_Hyperlink]";
        const string aw_InfoOnly_export = "SELECT [QuestionSN],[ReferenceSN],[ModuleSN],[ModuleVersionSN] FROM [dbo].[aw_InfoOnly]";
        const string Blob_export = "SELECT [Class],[SN],[ModuleVersionSN],[Sequence],[Blob] FROM [dbo].[Blob] order by [Class],[SN],[ModuleVersionSN],[Sequence]";
        const string BlobState_export = "SELECT [Class],[StateSN],[StateVersionSN],[ModuleSN],[ModuleVersionSN],[Sequence] ,[Blob] FROM [dbo].[BlobState] order by [Class],[StateSN],[StateVersionSN],[ModuleSN],[ModuleVersionSN],[Sequence]";
        const string DomainStructure_export = "SELECT [DomainSN],[ModuleSN],[ModuleVersionSN],[NQuestions],[SubQuestion],[Marked],[ParentSN],[ChildOrder],[Heading] FROM [dbo].[DomainStructure] order by [DomainSN],[ModuleSN],[ModuleVersionSN]";
        const string Module_export = "SELECT [ModuleSN],[MasterModuleID],[MasterGroupID],[MasterClassID],[ModuleName] FROM [dbo].[Module] order by [ModuleSN]";
        const string ModuleVersion_export = "SELECT [ModuleVersionSN],[ModuleSN],[VersionName],[DTRevision],[BNAVersionName],[DAResearchDate],[BNAResearchDate] FROM [dbo].[ModuleVersion] order by [ModuleVersionSN],[ModuleSN]";
        const string QCountState_export = "SELECT [StateSN],[StateVersionSN],[StateDomainSN],[QCount],[TagDate] FROM [dbo].[QCountState] order by [StateSN],[StateVersionSN],[StateDomainSN]";
        const string QDLink_export = "SELECT [ModuleSN],[ModuleVersionSN],[DomainSN],[QDOrder],[QuestionSN],[QSSN] FROM [dbo].[QDLink] order by [ModuleSN],[ModuleVersionSN],[DomainSN],[QDOrder]";
        const string QDStateLink_export = "SELECT [StateSN],[StateVersionSN],[StateDomainSN],[QDOrder],[QuestionSN] FROM [dbo].[QDStateLink] order by [StateSN],[StateVersionSN],[StateDomainSN],[QDOrder]";
        const string QRLink_export = "SELECT [QuestionSN],[Sequence],[ReferenceSN] FROM [dbo].[QRLink] order by [QuestionSN],[Sequence]";
        const string QSLink_export = "SELECT [ModuleSN],[ModuleVersionSN],[QSSN],[QSOrder],[SubQuestionDomainSN] FROM [dbo].[QSLink] order by [ModuleSN],[ModuleVersionSN],[QSSN],[QSOrder]";
        const string Question_export = "SELECT [QuestionSN],[RFValue],[RGKeyWordList],[QuestionBodySN] FROM [dbo].[Question] order by [QuestionSN]";
        const string QuestionBody_export = "SELECT [QuestionBodySN],[StdText],[NoteText],[ListAnswer],[DataType],[Properties] FROM [dbo].[QuestionBody] order by [QuestionBodySN]";
        const string RGKeyword_export = "SELECT [ReferenceSN],[KeyWord],[SectionSN],[PStart],[ModuleSN],[TagDate] FROM [dbo].[RGKeyword] order by [ReferenceSN]";
        const string RGSection_export = "SELECT [SectionSN],[ModuleSN],[Heading],[TextBlock],[TagDate],[Sequence] FROM [dbo].[RGSection] order by [SectionSN]";
        const string RGTOC_export = "SELECT [ModuleSN],[Sequence],[SectionSN],[Depth],[HeadingNo],[HeadingText],[TagDate],[PStart] FROM [dbo].[RGTOC] order by [ModuleSN],[Sequence]";
        const string ScreenGoal_export = "SELECT [ModuleSN],[ModuleVersionSN],[GoalOrder],[ApplicSN] FROM [dbo].[ScreenGoal] order by [ModuleSN],[ModuleVersionSN],[GoalOrder]";
        const string SDVLink_export = "SELECT [StateVersionSN],[StateDomainSN] FROM [dbo].[SDVLink] order by [StateVersionSN],[StateDomainSN]";
        const string State_export = "SELECT [StateSN],[StateName],[PostalCode],[MasterModuleID],[MasterGroupID],[MasterClassID] FROM [dbo].[State] order by [StateSN]";
        const string StateDomainStructure_export = "SELECT [StateVersionSN],[StateDomainSN],[ModuleSN],[ModuleVersionSN],[ChildOrder],[ParentSN],[Heading] FROM [dbo].[StateDomainStructure] order by [StateVersionSN],[StateDomainSN],[ModuleSN],[ModuleVersionSN]";
        const string StateModule_export = "SELECT [ModuleSN],[ModuleVersionSN],[StateVersionSN] FROM [dbo].[StateModule] order by [ModuleSN],[ModuleVersionSN],[StateVersionSN]";
        const string StateSection_export = "SELECT [StateDomainSN],[StateSN],[SectionSN],[StateVersionSN],[TagDate] FROM [dbo].[StateSection] order by [StateDomainSN],[StateSN],[StateVersionSN]";
        const string StateVersion_export = "SELECT [StateVersionSN],[VersionName],[DTRevision] FROM [dbo].[StateVersion] order by [StateVersionSN]";
        const string TemplateRule_export = "SELECT [RuleSN],[ModuleSN],[ModuleVersionSN],[SetSN],[Op],[CompASN],[CompBSN] FROM [dbo].[TemplateRule] order by [RuleSN],[ModuleSN],[ModuleVersionSN]";
        const string Version_export = "SELECT [VersionID] FROM [dbo].[Version]";

        Hashtable _tableQueires = new Hashtable();
        Hashtable _tableQueires_full = new Hashtable();
        Hashtable _tableQueires_export = new Hashtable();

        int defaultTimeout = 3600;
        //string[] _physical_path = null;

        private void LoadTableQueries_full()
        {
            _tableQueires_full.Clear();
            _tableQueires_full.Add("applicabilityvariable", Applicability_full);
            _tableQueires_full.Add("aw_hyperlink", aw_Hyperlink_full);
            _tableQueires_full.Add("aw_infoonly", aw_InfoOnly_full);
            _tableQueires_full.Add("blob", Blob_full);
            _tableQueires_full.Add("blobstate", BlobState_full);
            _tableQueires_full.Add("domainstructure", DomainStructure_full);
            _tableQueires_full.Add("module", Module_full);
            _tableQueires_full.Add("moduleversion", ModuleVersion_full);
            _tableQueires_full.Add("qcountstate", QCountState_full);
            _tableQueires_full.Add("qdlink", QDLink_full);
            _tableQueires_full.Add("qdstatelink", QDStateLink_full);
            _tableQueires_full.Add("qrlink", QRLink_full);
            _tableQueires_full.Add("qslink", QSLink_full);
            _tableQueires_full.Add("question", Question_full);
            _tableQueires_full.Add("questionbody", QuestionBody_full);
            _tableQueires_full.Add("rgkeyword", RGKeyword_full);
            _tableQueires_full.Add("rgsection", RGSection_full);
            _tableQueires_full.Add("rgtoc", RGTOC_full);
            _tableQueires_full.Add("screengoal", ScreenGoal_full);
            _tableQueires_full.Add("sdvlink", SDVLink_full);
            _tableQueires_full.Add("state", State_full);
            _tableQueires_full.Add("statedomainstructure", StateDomainStructure_full);
            _tableQueires_full.Add("statemodule", StateModule_full);
            _tableQueires_full.Add("statesection", StateSection_full);
            _tableQueires_full.Add("stateversion", StateVersion_full);
            _tableQueires_full.Add("templaterule", TemplateRule_full);
            _tableQueires_full.Add("version", Version_full);
        }
        private void LoadTableQueries()
        {
            _tableQueires_full.Clear();

            _tableQueires.Add("applicabilityvariable", Applicability);
            _tableQueires.Add("aw_hyperlink", aw_Hyperlink);
            _tableQueires.Add("aw_infoonly", aw_InfoOnly);
            _tableQueires.Add("blob", Blob);
            _tableQueires.Add("blobstate", BlobState);
            _tableQueires.Add("domainstructure", DomainStructure);
            _tableQueires.Add("module", Module);
            _tableQueires.Add("moduleversion", ModuleVersion);
            _tableQueires.Add("qcountState", QCountState);
            _tableQueires.Add("qdlink", QDLink);
            _tableQueires.Add("qdstatelink", QDStateLink);
            _tableQueires.Add("qrlink", QRLink);
            _tableQueires.Add("qslink", QSLink);
            _tableQueires.Add("question", Question);
            _tableQueires.Add("questionbody", QuestionBody);
            _tableQueires.Add("rgkeyword", RGKeyword);
            _tableQueires.Add("rgsection", RGSection);
            _tableQueires.Add("rgtoc", RGTOC);
            _tableQueires.Add("screengoal", ScreenGoal);
            _tableQueires.Add("sdvlink", SDVLink);
            _tableQueires.Add("state", State);
            _tableQueires.Add("statedomainstructure", StateDomainStructure);
            _tableQueires.Add("statemodule", StateModule);
            _tableQueires.Add("statesection", StateSection);
            _tableQueires.Add("stateversion", StateVersion);
            _tableQueires.Add("templaterule", TemplateRule);
            _tableQueires.Add("version", Version);
            _tableQueires.Add("retiredquest", RetiredQuest);
        }
        private void LoadTableQueries_export()
        {
            _tableQueires_export.Clear();
            _tableQueires_export.Add("applicabilityvariable", Applicability_export);
            _tableQueires_export.Add("aw_hyperlink", aw_Hyperlink_export);
            _tableQueires_export.Add("aw_infoonly", aw_InfoOnly_export);
            _tableQueires_export.Add("blob", Blob_export);
            _tableQueires_export.Add("blobstate", BlobState_export);
            _tableQueires_export.Add("domainstructure", DomainStructure_export);
            _tableQueires_export.Add("module", Module_export);
            _tableQueires_export.Add("moduleversion", ModuleVersion_export);
            _tableQueires_export.Add("qcountstate", QCountState_export);
            _tableQueires_export.Add("qdlink", QDLink_export);
            _tableQueires_export.Add("qdstatelink", QDStateLink_export);
            _tableQueires_export.Add("qrlink", QRLink_export);
            _tableQueires_export.Add("qslink", QSLink_export);
            _tableQueires_export.Add("question", Question_export);
            _tableQueires_export.Add("questionbody", QuestionBody_export);
            _tableQueires_export.Add("rgkeyword", RGKeyword_export);
            _tableQueires_export.Add("rgsection", RGSection_export);
            _tableQueires_export.Add("rgtoc", RGTOC_export);
            _tableQueires_export.Add("screengoal", ScreenGoal_export);
            _tableQueires_export.Add("sdvlink", SDVLink_export);
            _tableQueires_export.Add("state", State_export);
            _tableQueires_export.Add("statedomainstructure", StateDomainStructure_export);
            _tableQueires_export.Add("statemodule", StateModule_export);
            _tableQueires_export.Add("statesection", StateSection_export);
            _tableQueires_export.Add("stateversion", StateVersion_export);
            _tableQueires_export.Add("templaterule", TemplateRule_export);
            _tableQueires_export.Add("version", Version_export);
        }

        public delegate void Display(string message);
        public delegate Boolean IsCancel();

        public event Display callBack;
        public event IsCancel checkCancel;

        protected DataSet dsBase = null;

        private Stopwatch stopWatch = new Stopwatch();
        internal string elapsedTime = "";

        //for all objects share one connection
        static SqlConnection DbConnection = null;
        private string _connectionString;

        string _Server = null;
        string _DB = null;
        string _user = null;
        string _pass = null;

        int num = -1;
        public DataSql()
        {
            _Server = null;
            _DB = null;
            _user = null;
            _pass = null;
        }

        public string ConnectionString
        {
            get
            {
                return _connectionString;
            }
        }
        //private int _timeout = 300;
        public DataSql(string connectionString)
        {
            _connectionString = connectionString;

            if (DbConnection != null && DbConnection.State == ConnectionState.Open)
            {
                DbConnection.Close();
            }

            //DbConnection = new SqlConnection(_connectionString);
        }
        public DataSql(string Server, string DB)
        {
            _Server = Server;
            _DB = DB;

            _connectionString = UTIL.GetSqlServerConnectionString(Server, DB);
            if (DbConnection != null && DbConnection.State == ConnectionState.Open)
            {
                DbConnection.Close();
            }
            //DbConnection = new SqlConnection(_connectionString);
            //LoadTableQueries();
        }
        public DataSql(string Server, string DB, string user, string pass)
        {
            _user = user;
            _pass = pass;
            _Server = Server;
            _DB = DB;

            if (user != null && user != "" && pass != null && pass != "")
            {
                _connectionString = UTIL.GetSqlServerConnectionString(Server, DB, user, pass);
            }
            else
            {
                _connectionString = UTIL.GetSqlServerConnectionString(Server, DB);
            }

            //DbConnection = new SqlConnection(_connectionString);
        }

        ~DataSql()
        {
            if (dsBase != null)
            {
                int generation = GC.GetGeneration(dsBase);

                dsBase = null;
                GC.Collect(generation);
                GC.WaitForPendingFinalizers();
            }
        }


        public DataSet SelectOdbcSrvRows(string query)
        {
            DataSet ds = null;

            try
            {
                SqlDataAdapter adapter = new SqlDataAdapter();
                adapter.SelectCommand = new SqlCommand(query, DbConnection);
                adapter.SelectCommand.CommandTimeout = defaultTimeout;
                adapter.Fill(ds);
            }
            catch
            {
            }

            return ds;
        }

        public void SetServer(string Server, string DB, string user, string pass)
        {
            _user = user;
            _pass = pass;
            _Server = Server;
            _DB = DB;

            if (user != null && user != "" && pass != null && pass != "")
            {
                _connectionString = UTIL.GetSqlServerConnectionString(Server, DB, user, pass);
            }
            else
            {
                _connectionString = UTIL.GetSqlServerConnectionString(Server, DB);
            }
        }

        private void LogEvent(string eMessage, EventLogEntryType eType)
        {
            string sSource = "RGTools";
            string sLog = "Application";
            //try/catch because the logged in user may not have rights to write to the log
            try
            {
                if (!EventLog.SourceExists(sSource))
                {
                    EventLog.CreateEventSource(sSource, sLog);
                }
                EventLog.WriteEntry(sSource, eMessage, eType);
            }
            catch (Exception) { }
        }

        public string RunSQL(string SQL)
        {
            return RunSQL(SQL, true, 3600);  //Increase timeout to 60 minutes
        }
        public string RunSQL(string SQL, int timeout)
        {
            return RunSQL(SQL, true, timeout);
        }
        public string RunSQL(string SQL, bool KeepOpen)
        {
            return RunSQL(SQL, KeepOpen, 3600);
        }
        public string RunSQL(string SQL, bool KeepOpen, int timeout)
        {
            SqlCommand myCommand = new SqlCommand(SQL, DbConnection);
            myCommand.Transaction = _trans;
            myCommand.CommandTimeout = timeout;
            try
            {
                if (DbConnection.State == ConnectionState.Closed)
                {
                    DbConnection.Open();
                }

                num = myCommand.ExecuteNonQuery();

                return string.Empty;
            }
            catch (Exception e)
            {
                this.LogEvent(e.Message + Environment.NewLine + "Failed SQL Code: " + SQL, EventLogEntryType.Error);
                return e.Message;
            }
            finally
            {
                if (!KeepOpen)
                {
                    DbConnection.Close();
                }
            }

        }

        public bool RunError = false;
        public string RunSQL(string[] SQL, string[] message)
        {
            return RunSQL(SQL, message, true, true);
        }
        public string RunSQL(string[] SQL, string[] message, bool ErroBreak, bool KeepOpen)
        {
            StringBuilder sbErrMsg = new StringBuilder();

            RunError = false;

            SqlCommand myCommand = new SqlCommand();
            myCommand.Connection = DbConnection;
            myCommand.Transaction = _trans;
            myCommand.CommandTimeout = defaultTimeout;

            int i = 0;
            try
            {
                if (myCommand.Connection.State == ConnectionState.Closed)
                {
                    myCommand.Connection = DbConnection;

                    if (DbConnection.State == ConnectionState.Closed)
                    {
                        Open();
                    }
                }

                for (i = 0; i < SQL.Length; i++)
                {
                    if (checkCancel != null)
                    {
                        if (checkCancel())
                        {
                            break;
                        }
                    }

                    if (SQL[i] != null && SQL[i] != string.Empty && SQL[i].Trim() != "")
                    {
                        if (callBack != null && message[i] != string.Empty)
                        {
                            callBack(message[i]);
                        }

                        myCommand.CommandText = SQL[i];
                        myCommand.CommandTimeout = 3600;
                        try
                        {
                            int ret = myCommand.ExecuteNonQuery();
                        }
                        catch (Exception ee)
                        {
                            if (SQL[i].ToUpper().IndexOf(" INDEX ") > 0
                                    || SQL[i].ToUpper().IndexOf("DROP TABLE ") > 0
                                    || SQL[i].ToUpper().IndexOf(" KEY ") > 0)
                            {
                                continue;
                            }

                            RunError = true;
                            if (callBack != null)
                            {
                                callBack(ee.Message + ".\r\n");
                            }

                            if (ErroBreak)
                            {


                                throw ee;
                            }
                            else
                            {
                                sbErrMsg.Append(ee.Message + ".\r\n");
                            }
                        }
                    }
                }

                if (RunError)
                {
                    return sbErrMsg.ToString();

                }

                return string.Empty;
            }
            catch (Exception e)
            {
                RunError = true;
                return e.Message;// +". Error in query " + SQL[i];
            }
            finally
            {
                if (!KeepOpen)
                {
                    DbConnection.Close();
                }
            }
        }

        public string RunSQL(string[] SQL, bool ErroBreak, bool KeepOpen)
        {
            StringBuilder sbErrMsg = new StringBuilder();

            RunError = false;

            SqlCommand myCommand = new SqlCommand();
            myCommand.Connection = DbConnection;
            myCommand.Transaction = _trans;
            myCommand.CommandTimeout = defaultTimeout;

            int i = 0;
            try
            {
                if (myCommand.Connection.State == ConnectionState.Closed)
                {
                    myCommand.Connection = DbConnection;

                    if (DbConnection.State == ConnectionState.Closed)
                    {
                        Open();
                    }
                }

                for (i = 0; i < SQL.Length; i++)
                {
                    if (checkCancel != null)
                    {
                        if (checkCancel())
                        {
                            break;
                        }
                    }

                    if (SQL[i] != null && SQL[i] != string.Empty && SQL[i].Trim() != "")
                    {

                        myCommand.CommandText = SQL[i];
                        myCommand.CommandTimeout = 0;
                        try
                        {
                            int ret = myCommand.ExecuteNonQuery();

                        }
                        catch (Exception ee)
                        {
                            if (SQL[i].ToUpper().IndexOf(" INDEX ") > 0
                                    || SQL[i].ToUpper().IndexOf("DROP TABLE ") > 0)
                            {
                                continue;
                            }

                            RunError = true;

                            if (callBack != null)
                            {
                                callBack(ee.Message + ".\r\n");
                            }

                            if (ErroBreak)
                            {
                                throw new Exception(ee.Message + Environment.NewLine + "Failed SQL Code: " + SQL[i]);
                            }
                            else
                            {
                                sbErrMsg.Append(ee.Message + ".\r\n");
                            }
                        }
                    }
                }

                if (RunError)
                {
                    return sbErrMsg.ToString();

                }

                return string.Empty;
            }
            catch (Exception e)
            {
                this.LogEvent(e.Message, EventLogEntryType.Error);
                RunError = true;
                return e.Message;// +". Error in query " + SQL[i];
            }
            finally
            {
                if (!KeepOpen)
                {
                    DbConnection.Close();
                }
            }
        }

        public string RunSQL(string[] SQL)
        {
            return RunSQL(SQL, true, true);
        }
        public string RunSQL(string[] SQL, bool KeepOpen)
        {
            return RunSQL(SQL, true, KeepOpen);
        }
        public void RunSQL(object obj)
        {
            try
            {
                string[] SQL = obj as string[];

                RunSQL(SQL);
            }
            catch
            {
            }
        }

        public void GetDataSet(object obj)
        {
            try
            {
                Parameters prm = obj as Parameters;
                string SQL = prm._SQL;
                DataSet ds = prm._ds;

                GetDataSet(SQL, ref ds);
            }
            catch
            { }
        }

        public DataSet GetDataSet(string SQL)
        {
            if (DbConnection == null)
            {
                DbConnection = new SqlConnection(_connectionString);
            }

            SqlCommand myCommand = new SqlCommand(SQL, DbConnection);
            myCommand.Transaction = _trans;
            myCommand.CommandTimeout = defaultTimeout;

            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = myCommand;
            DataSet ds = new DataSet();

            try
            {
                //stopWatch.Reset();
                //stopWatch.Start();

                if (ds.Tables.Count > 0)
                {
                    ds.Tables.Clear();
                }
                adapter.Fill(ds);

                //stopWatch.Stop();
                //TimeSpan ts = stopWatch.Elapsed;
                //elapsedTime = String.Format("{0:00}:{1:00}", ts.Minutes, ts.Seconds);
                //Debug.Print(elapsedTime);
            }
            catch// (Exception e1)
            {
                return null;
            }

            //DbConnection.Close();
            return ds;
        }
        public void GetDataSet(string SQL, ref DataSet ds)
        {
            if (DbConnection == null)
            {
                DbConnection = new SqlConnection(_connectionString);
            }

            SqlCommand myCommand = new SqlCommand(SQL, DbConnection);
            myCommand.Transaction = _trans;
            myCommand.CommandTimeout = defaultTimeout;

            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = myCommand;

            try
            {
                //stopWatch.Reset();
                //stopWatch.Start();

                if (ds.Tables.Count > 0)
                {
                    ds.Tables.Clear();
                }
                adapter.Fill(ds);

                //stopWatch.Stop();
                //TimeSpan ts = stopWatch.Elapsed;
                //elapsedTime = String.Format("{0:00}:{1:00}", ts.Minutes, ts.Seconds);
                //Debug.Print(elapsedTime);
            }
            catch //(Exception e1)
            {
                ds = null;
            }
        }

        public void GetDataSet(string Filter, string Sort, ref DataSet ds)
        {
            if (dsBase == null)
            {
                return;
            }
            try
            {
                //stopWatch.Reset();
                //stopWatch.Start();

                DataRow[] foundRows;
                foundRows = dsBase.Tables[0].Select(Filter, Sort);
                DataTable db = dsBase.Tables[0].Clone();
                db.Clear();
                // Print column 0 of each returned row.
                for (int i = 0; i < foundRows.Length; i++)
                {
                    DataRow newRow = db.NewRow();
                    for (int j = 0; j < dsBase.Tables[0].Columns.Count; j++)
                    {
                        newRow[j] = foundRows[i][j];
                    }

                    db.Rows.Add(newRow);
                }

                ds.Tables.Clear();
                ds.Tables.Add(db);

                //stopWatch.Stop();
                //TimeSpan ts = stopWatch.Elapsed;
                //elapsedTime = String.Format("{0:00}:{1:00}", ts.Seconds, ts.Milliseconds);

            }
            catch (Exception e)
            {
                string s = e.Message;
            }

            return;
        }

        public DataSet GetDataSet(string Filter, string Sort)
        {
            DataSet ds = new DataSet();

            if (dsBase == null)
            {
                return ds;
            }
            try
            {
                //stopWatch.Reset();
                //stopWatch.Start();

                DataRow[] foundRows;
                foundRows = dsBase.Tables[0].Select(Filter, Sort);
                DataTable db = dsBase.Tables[0].Clone();
                db.Clear();
                // Print column 0 of each returned row.
                for (int i = 0; i < foundRows.Length; i++)
                {
                    DataRow newRow = db.NewRow();
                    for (int j = 0; j < dsBase.Tables[0].Columns.Count; j++)
                    {
                        newRow[j] = foundRows[i][j];
                    }

                    db.Rows.Add(newRow);
                }

                ds.Tables.Add(db);

                //stopWatch.Stop();
                //TimeSpan ts = stopWatch.Elapsed;
                //elapsedTime = String.Format("{0:00}:{1:00}", ts.Seconds, ts.Milliseconds);

            }
            catch (Exception e)
            {
                string s = e.Message;
            }

            return ds;
        }
        public DataSet GetBaseDataSet(string SQL)
        {
            if (DbConnection == null)
            {
                DbConnection = new SqlConnection(_connectionString);
            }

            SqlCommand myCommand = new SqlCommand(SQL, DbConnection);
            myCommand.Transaction = _trans;

            myCommand.CommandTimeout = defaultTimeout;
 
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = myCommand;

            if (dsBase == null)
            {
                dsBase = new DataSet();
            }

            try
            {
                //stopWatch.Reset();
                //stopWatch.Start();

                //DbConnection.Open();
                if (dsBase.Tables.Count > 0)
                {
                    dsBase.Tables.Clear();
                }
                adapter.Fill(dsBase);

                //stopWatch.Stop();
                //TimeSpan ts = stopWatch.Elapsed;
                //elapsedTime = String.Format("{0:00}:{1:00}", ts.Minutes, ts.Seconds);
                //Debug.Print(elapsedTime);
            }
            catch// (Exception e1)
            {
                return null;
            }
            finally
            {
                //DbConnection.Close();
            }
            //DbConnection.Close();
            return dsBase;
        }

        private void RemoveDuplicates(DataTable tbl, string[] keyColumns)
        {
            int rowNdx = 0;

            while (rowNdx < tbl.Rows.Count - 1)
            {
                DataRow[] dups = FindDups(tbl, rowNdx, keyColumns);

                if (dups.Length > 0)
                {
                    foreach (DataRow dup in dups)
                    {
                        tbl.Rows.Remove(dup);
                    }
                }
                else
                {
                    rowNdx++;
                }
            }
        }

        private DataRow[] FindDups(DataTable tbl, int sourceNdx, string[] keyColumns)
        {
            ArrayList retVal = new ArrayList();
            DataRow sourceRow = tbl.Rows[sourceNdx];

            for (int i = sourceNdx + 1; i < tbl.Rows.Count; i++)
            {
                DataRow targetRow = tbl.Rows[i];
                if (IsDup(sourceRow, targetRow, keyColumns))
                {
                    retVal.Add(targetRow);
                }
            }

            return (DataRow[])retVal.ToArray(typeof(DataRow));
        }

        private bool IsDup(DataRow sourceRow, DataRow targetRow, string[] keyColumns)
        {
            bool retVal = true;

            foreach (string column in keyColumns)
            {
                retVal = retVal && sourceRow[column.Trim()].Equals(targetRow[column.Trim()]);

                if (!retVal) break;
            }

            return retVal;
        }

        private void PrintRows(DataTable tbl)
        {

            for (int i = 0; i < tbl.Rows.Count; i++)
            {

                Console.WriteLine("row: {0}, ColumnA: {1}, ColumnB: {2}", i, tbl.Rows[i]["ColumnA"], tbl.Rows[i]["ColumnB"]);

            }



        }

        public SqlDataReader GetReader(string SQL)
        {
            SqlCommand myCommand = new SqlCommand(SQL, DbConnection);
            myCommand.Transaction = _trans;
            myCommand.CommandTimeout = defaultTimeout;

            if (DbConnection.State == ConnectionState.Closed)
            {
                try
                {
                    DbConnection.Open();
                    SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.CloseConnection);
                    return reader;
                }
                catch// (Exception e)
                {
                    return null;
                }
            }
            else
            {
                try
                {
                    SqlDataReader reader = myCommand.ExecuteReader(CommandBehavior.Default);
                    return reader;
                }
                catch //(Exception e)
                {
                    return null;
                }
            }
        }

        public void Open()
        {
            try
            {
                if (_user != null && _user != "" && _pass != null && _pass != "")
                {
                    _connectionString = UTIL.GetSqlServerConnectionString(_Server, _DB, _user, _pass);
                }
                else
                {
                    _connectionString = UTIL.GetSqlServerConnectionString(_Server, _DB);
                }

                DbConnection = new SqlConnection(_connectionString);
                _trans = null;
                DbConnection.Open();
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public void Close()
        {
            try
            {
                DbConnection.Close();
                DbConnection = null;
                _trans = null;
            }
            catch
            {
            }
        }

        public bool IsConnectionOpen
        {
            get
            {
                return (DbConnection.State == ConnectionState.Open ? true : false);
            }
        }

        public bool CreateEmptyTables()
        {
            return true;
        }

        //load REM files to tables
        public bool LoadTextToTable(string FilePath, string TableName)
        {
            string ModuleName = "";

            if (_tableQueires == null || _tableQueires.Count == 0)
            {
                LoadTableQueries();
            }

            string result = null;
            TableName = TableName.ToLower().Trim();
            string sql = _tableQueires[TableName] as string;

            if (sql != null && sql.Trim() != "")
            {
                int paranum = sql.Split(new char[] { ',' }).Length;

                StreamReader QIFile = new StreamReader(FilePath, Encoding.Default);
                List<string> lstSQL = new List<string>();
                
                string InputLine = null;
                while ((InputLine = QIFile.ReadLine()) != null)
                {
                    if (InputLine.StartsWith("--"))
                    {
                        ModuleName = InputLine;
                        continue;
                    }
                    if (TableName == "questionbody")
                    {
                        InputLine = InputLine.Replace("\\n", "\n");
                    }

                    string[] cols = InputLine.Split(new char[] { ',' });
                    if (cols.Length > paranum)
                    {
                        cols = GetInputColumns(InputLine);
                    }

                    string val = "(";

                    for (int i = 0; i < cols.Length; i++)// (string col in cols)
                    {
                        string col = cols[i];

                        val += col + ",";
                    }

                    lstSQL.Add(sql + val.Remove(val.Length - 1) + ")" + ModuleName);

                    if (lstSQL.Count > 30000)
                    {
                        result = RunSQL(lstSQL.ToArray(), true);

                        if (result != "")
                        {
                            QIFile.Close();
                            throw new Exception(result);
                        }

                        lstSQL.Clear();
                        lstSQL = null;
                        GC.Collect();
                        GC.WaitForPendingFinalizers();

                        lstSQL = new List<string>();
                    }

                }

                QIFile.Close();

                result = RunSQL(lstSQL.ToArray(), true);

                if (result != "")
                {
                    throw new Exception(result);
                }

                lstSQL.Clear();
                lstSQL = null;
                GC.Collect();
                GC.WaitForPendingFinalizers();

                return true;
            }
            else
            {
                return false;
            }

        }

        //Converting Tagdates in rgsection to binary formats
        private bool ConvTagdateToBin()
        {
            try
            {
                string SectionSN = null;
                string TagDate = null;
                string sql = "select sectionsn,tagdate from dbo.rgsection";
                DataSet ds = GetDataSet(sql);

                if (ds != null && ds.Tables.Count > 0)
                {
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        if (checkCancel != null)
                        {
                            if (checkCancel())
                            {
                                break;
                            }
                        }

                        SectionSN = row[0].ToString();

                        //if (SectionSN == "11908")
                        //{
                        //    string s = "";
                        //}

                        TagDate = ConvertHexToBin(row[1].ToString());
                        TagDate = TagDate.Replace("'", "''");

                        //TagDate = TagDate.Replace("\\\r", "\\\\\r");

                        //TagDate = "\0\0\0!ñ1\\\\\r\0\07\0\0\0»|1“\r\0\0\0\0\0!ñ1";
                        sql = "UPDATE RGSection SET TagDate = '" + TagDate + "' WHERE SectionSN = " + SectionSN;

                        RunSQL(sql, true);

                        sql = "select tagdate from dbo.rgsection  WHERE SectionSN = " + SectionSN;

                        DataSet ds1 = GetDataSet(sql);
                    }

                }
                return true;
            }
            catch// (Exception e)
            {
                return false;
            }
            finally
            {
            }
        }

        //Converting Tagdates in rgsection to hexadecimal formats
        //private bool ConvTagdateToHex()
        //{
        //    try
        //    {
        //        string SectionSN = null;
        //        string TagDate = null;
        //        string sql = "select sectionsn,tagdate from dbo.rgsection";
        //        DataSet ds = GetDataSet(sql);

        //        if (ds != null && ds.Tables.Count > 0)
        //        {
        //            foreach (DataRow row in ds.Tables[0].Rows)
        //            {
        //                if (checkCancel != null)
        //                {
        //                    if (checkCancel())
        //                    {
        //                        break;
        //                    }
        //                }

        //                SectionSN = row[0].ToString();

        //                //if (SectionSN == "11908")
        //                //{
        //                //    string s = "";
        //                //}

        //                TagDate = ConvertBinToHex(row[1].ToString());
        //                //TagDate = TagDate.Replace("'", "''");

        //                //TagDate = TagDate.Replace("\\\r", "\\\\\r");

        //                //TagDate = "\0\0\0!ñ1\\\\\r\0\07\0\0\0»|1“\r\0\0\0\0\0!ñ1";
        //                sql = "UPDATE RGSection SET TagDate = '" + TagDate + "' WHERE SectionSN = " + SectionSN;

        //                RunSQL(sql, true);

        //                //sql = "select tagdate from dbo.rgsection  WHERE SectionSN = " + SectionSN;

        //                //DataSet ds1 = GetDataSet(sql);
        //            }

        //        }
        //        return true;
        //    }
        //    catch// (Exception e)
        //    {
        //        return false;
        //    }
        //    finally
        //    {
        //    }
        //}

        public bool LoadTextToTable_full(string FilePath, string TableName)
        {
            return LoadTextToTable_full(FilePath, TableName, false);
        }
        public bool LoadTextToTable_full(string FilePath, string TableName, bool MergingStates)
        {
            if (_tableQueires_full == null || _tableQueires_full.Count == 0)
            {
                LoadTableQueries_full();
            }

            TableName = TableName.ToLower().Trim();
            if (TableName == "questionbody")
            {
                if (MergingStates)
                {
                    _tableQueires_full["questionbody"] = QuestionBody_full_1;
                }
                else
                {
                    _tableQueires_full["questionbody"] = QuestionBody_full;
                }
            }

            string sql = _tableQueires_full[TableName] as string;
            string result = null;

            if (sql != null && sql.Trim() != "")
            {
                int paranum = sql.Split(new char[] { ',' }).Length;

                StreamReader QIFile = new StreamReader(FilePath, Encoding.Default);
                List<string> lstSQL = new List<string>();

                string InputLine = null;
                while ((InputLine = QIFile.ReadLine()) != null)
                {
                    //if (TableName == "rgsection" || TableName == "questionbody")
                    if (TableName == "questionbody")
                    {
                        InputLine = ConvertHexToBin(InputLine).Replace("\\n", "\n"); ;
                        //InputLine = InputLine.Replace("\\n", "\n");
                    }

                    string[] cols = InputLine.Split(new char[] { ',' });

                    if (cols.Length > paranum)
                    {
                        cols = GetInputColumns(InputLine);

                        //if (cols.Length != paranum)
                        //{
                        //    string s = "";
                        //}
                    }

                    if (TableName == "question")
                    {
                        if (cols[2].Trim() == "")
                        {
                            cols[2] = "''";
                        }
                    }

                    if (TableName == "rgsection")
                    {
                        cols[3] = ConvertHexToBin(cols[3]).Replace("\\n", "\n");
                        cols[4] = "'" + ConvertBinToHex(cols[4].Substring(1, cols[4].Length - 2)) + "'";
                    }

                    if (TableName == "blob")
                    {
                        if (cols[4].Trim() == "")
                        {
                            cols[4] = "''";
                        }
                    }

                    if (TableName == "questionbody")
                    {
                        if (cols[1].Trim() == "")
                        {
                            cols[1] = "''";
                        }

                        if (cols[2].Trim() == "")
                        {
                            cols[2] = "''";
                        }

                        if (cols[3].Trim() == "")
                        {
                            cols[3] = "''";
                        }
                    }

                    if (TableName == "stateversion")
                    {
                        DateTime dt = DateTime.Now;

                        try
                        {
                            dt = DateTime.Parse(cols[cols.Length - 1]);
                        }
                        catch
                        {
                        }

                        cols[cols.Length - 1] = "'" + dt.ToString("MM/dd/yyyy h:mm:ss.fff tt") + "'";
                    }

                    if (TableName == "moduleversion")
                    {
                        DateTime dt = DateTime.Now;

                        try
                        {
                            dt = DateTime.Parse(cols[3].ToString());
                        }
                        catch
                        {
                        }
                        cols[3] = "'" + dt.ToString("MM/dd/yyyy h:mm:ss.fff tt") + "'";

                        if (cols[4].Trim() == "")
                        {
                            cols[4] = "''";
                        }
                    }

                    string val = "(";

                    for (int i = 0; i < cols.Length; i++)// (string col in cols)
                    {
                        string col = cols[i];

                        val += col + ",";
                    }

                    lstSQL.Add(sql + val.Remove(val.Length - 1) + ")");

                    if (lstSQL.Count > 500)
                    {
                        result = RunSQL(lstSQL.ToArray(), true, true);
                        if (result != "")
                        {
                            QIFile.Close();
                            throw new Exception(result);
                        }
                        else
                        {
                            lstSQL.Clear();
                        }

                        //int generation = GC.GetGeneration(lstSQL);
                        //GC.Collect(generation);

                        GC.Collect();
                        GC.WaitForPendingFinalizers();

                    }
                }

                QIFile.Close();

                result = RunSQL(lstSQL.ToArray(), true, true);

                if (result != "")
                {
                    throw new Exception(result);
                }

                return true;
            }
            else
            {
                return false;
            }
        }
        public bool UnloadTableToText(string FilePath, string TableName)
        {
            if (_tableQueires_export == null || _tableQueires_export.Count == 0)
            {
                LoadTableQueries_export();
            }

            TableName = TableName.ToLower().Trim();
            string sql = _tableQueires_export[TableName] as string;

            if (sql != null && sql.Trim() != "")
            {

                StreamWriter ModuleFile = null;
                SqlDataReader reader = null;
                try
                {
                    if (File.Exists(FilePath))
                    {
                        File.Delete(FilePath);
                    }

                    ModuleFile = new StreamWriter(FilePath, false, Encoding.Default);
                    //sql = "select * from " + TableName;
                    string output = null;
                    //string strTmp = null;

                    reader = GetReader(sql);
                    //string TagDate = null;
                    while (reader.Read())
                    {
                        if (checkCancel != null)
                        {
                            if (checkCancel())
                            {
                                break;
                            }
                        }

                        output = "";

                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            string type = reader[i].GetType().Name;
                            if (reader[i].GetType().FullName == "System.String")
                            {
                                output += "'" + reader.GetString(i).Replace("'", "''") + "',";
                            }
                            else if ((reader[i].GetType().FullName == "System.DateTime"))
                            {
                                output += reader.GetDateTime(i).ToString("yyyy/MMM/dd HH:mm:ss.ffffff").ToLower() + ",";
                            }
                            else
                            {
                                output += reader[i].ToString() + ",";
                            }
                        }

                        if (output != "")
                        {
                            output = output.Remove(output.Length - 1, 1);

                            if (TableName == "rgsection" || TableName == "questionbody")
                            {
                                output = output.Replace("\\", "\\\\");
                                output = output.Replace("\\\\x", "\\x");
                                if (output.IndexOf('\n') > -1)
                                {
                                    output = output.Replace("\n", "\\x0a");
                                }
                            }


                            ModuleFile.WriteLine(output);
                        }
                    }
                }
                catch// (Exception e)
                {
                    return false;
                }
                finally
                {
                    reader.Close();
                    ModuleFile.Close();
                }
            }
            return true;
        }

        private string ConvertBinToHex(string InputLine)
        {
            StringBuilder sb = new StringBuilder();
            byte bTmp1 = 0;
            byte bTmp2 = 0;

            InputLine = InputLine.Replace("''", "'");
            try
            {
                for (int i = 0; i < InputLine.Length; i++)
                {
                    if (InputLine[i] == '\\')
                    {
                        if (i < InputLine.Length - 1)
                        {
                            if (InputLine[i + 1] == '\\')   //"\\" need to be kept
                            {
                                bTmp1 = ASCIIEncoding.Default.GetBytes(new char[] { InputLine[i] })[0];
                                sb.Append(CVTHEX.ByteToHexWithX(bTmp1));

                                i++;
                                continue;
                            }
                        }

                        if (i < InputLine.Length - 3)
                        {
                            if (InputLine[i + 1] == 'x' || InputLine[i + 1] == 'X')
                            {
                                try
                                {
                                    bTmp1 = byte.Parse(InputLine[i + 2].ToString(), NumberStyles.HexNumber);
                                    bTmp2 = byte.Parse(InputLine[i + 3].ToString(), NumberStyles.HexNumber);
                                    sb.Append("\\x" + CVTHEX.ByteToHex(bTmp1).Substring(1) + CVTHEX.ByteToHex(bTmp2).Substring(1));
                                    i += 3;
                                }
                                catch //(Exception e)
                                {
                                    //no hexadeimal data
                                    bTmp1 = ASCIIEncoding.Default.GetBytes(new char[] { InputLine[i] })[0];
                                    sb.Append(CVTHEX.ByteToHexWithX(bTmp1));
                                }
                            }
                            else
                            {
                                bTmp1 = ASCIIEncoding.Default.GetBytes(new char[] { InputLine[i] })[0];
                                sb.Append(CVTHEX.ByteToHexWithX(bTmp1));
                            }
                        }
                        else if (i < InputLine.Length - 2)
                        {
                            bTmp1 = byte.Parse(InputLine[i + 2].ToString(), NumberStyles.HexNumber);
                            sb.Append("\\x" + CVTHEX.ByteToHex(bTmp1));
                            i += 2;
                        }
                        else
                        {
                            bTmp1 = ASCIIEncoding.Default.GetBytes(new char[] { InputLine[i] })[0];
                            sb.Append(CVTHEX.ByteToHexWithX(bTmp1).Substring(1));
                        }
                    }
                    else
                    {
                        bTmp1 = ASCIIEncoding.Default.GetBytes(new char[] { InputLine[i] })[0];
                        sb.Append(CVTHEX.ByteToHexWithX(bTmp1));
                    }
                }
            }
            catch// (Exception e)
            {
            }
            return sb.ToString();

            //long iDate = 0;

            //int j = 0;
            //byte[] bInput = Encoding.Default.GetBytes(InputLine);
            //try
            //{
            //    for (int i = 0; i < bInput.Length; i = i + 4)
            //    {
            //        j = i;
            //        iDate = bInput[i + 3] * 16777216 + bInput[i + 2] * 65536 + bInput[i + 1] * 256 + bInput[i];

            //        sb.Append(CVTHEX.LongToHex(iDate));

            //        if (i > 610)
            //        {
            //            string s = "";
            //        }
            //    }
            //}
            //catch(Exception e)
            //{
            //}
            //return sb.ToString(); ;
        }
        private string ConvertHexToBin(string InputLine)
        {
            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < InputLine.Length; i++)
            {
                if (InputLine[i] == '\\')
                {
                    if (i < InputLine.Length - 1)
                    {
                        if (InputLine[i + 1] == '\\')   //"\\" need to be kept
                        {
                            sb.Append(InputLine[i].ToString());

                            i++;
                            continue;
                        }
                    }

                    if (i < InputLine.Length - 3)
                    {
                        if (InputLine[i + 1] == 'x' || InputLine[i + 1] == 'X')
                        {
                            try
                            {
                                int iTmp1 = int.Parse(InputLine[i + 2].ToString(), NumberStyles.HexNumber);
                                int iTmp2 = int.Parse(InputLine[i + 3].ToString(), NumberStyles.HexNumber);
                                string str = ASCIIEncoding.Default.GetString(new byte[] { (byte)(iTmp1 * 16 + iTmp2) });

                                sb.Append(str);
                                i += 3;
                            }
                            catch //(Exception e)
                            {
                                //no hexadeimal data
                                sb.Append(InputLine.Substring(i, 4));
                                i += 3;

                                continue;
                            }
                        }
                        else
                        {
                            sb.Append(InputLine[i].ToString());
                        }
                    }
                    else
                    {
                        sb.Append(InputLine[i].ToString());
                    }
                }
                else
                {
                    sb.Append(InputLine[i].ToString());
                }
            }

            return sb.ToString();
        }

        internal string[] GetInputColumns(string InputLine)
        {

            string[] arr1 = InputLine.Split(new char[] { '\'' }, StringSplitOptions.None);

            for (int i = 1; i < arr1.Length; i = i + 2)
            {
                arr1[i] = arr1[i].Replace(",", "EB90");
            }

            string newLine = "";

            foreach (string str in arr1)
            {
                newLine += str + "'";
            }

            newLine = newLine.Remove(newLine.Length - 1);


            string[] arr2 = newLine.Split(new char[] { ',' });
            for (int i = 0; i < arr2.Length; i++)
            {
                arr2[i] = arr2[i].Replace("EB90", ",");
            }

            return arr2;
        }

        public bool CreateNewDB(string DBName)
        {
            string[] arrSQL ={
                    "use master",
                    "IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'" + DBName + "') ALTER DATABASE " + DBName + " SET SINGLE_USER WITH ROLLBACK IMMEDIATE",
                    "IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'" + DBName + "') DROP DATABASE " + DBName,
                    "CREATE DATABASE "+DBName};

            if (RunSQL(arrSQL, true) == string.Empty)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        static SqlTransaction _trans = null;
        public SqlTransaction BeginTransaction()
        {
            _trans = DbConnection.BeginTransaction();
            return _trans;
        }

        internal SqlConnection Connection
        {
            get
            {
                return DbConnection;
            }
        }

        //internal string[] DBPhysicalPath
        //{
        //    get
        //    {
        //        if (_physical_path != null)
        //        {
        //            return _physical_path;
        //        }
        //        else
        //        {
        //            string _SQL = "SELECT name, physical_name AS current_file_location FROM sys.database_files ";
        //            string[] _result = new string[4] ;//{ "", "" };

        //            SqlDataReader _reader = GetReader(_SQL);

        //            if (_reader == null)
        //            {
        //                return null;
        //            }

        //            if (_reader.Read())
        //            {
        //                _result[0] = _reader.GetString(0);
        //                _result[1] = _reader.GetString(1);
        //            }

        //            if (_reader.Read())
        //            {
        //                _result[2] = _reader.GetString(0);
        //                _result[3] = _reader.GetString(1);
        //            }

        //            _reader.Close();

        //            if (_result[0] == null || _result[2] == null)
        //            {
        //                return null;
        //            }
        //            return _result;
        //        }
        //    }

        //}
        internal string[] GetDBPhysicalPath(string bak_path)
        {
            //_physical_path = null;

            //if (_physical_path != null)
            //{
            //    return _physical_path;
            //}
            //else
            //{
            string _SQL = "SELECT name, physical_name AS current_file_location FROM sys.database_files ";
            string[] _result = new string[4];//{ "", "" };

            SqlDataReader _reader = GetReader(_SQL);

            if (_reader == null)
            {
                return null;
            }

            if (_reader.Read())
            {
                _result[0] = _reader.GetString(0);
                _result[1] = _reader.GetString(1);
            }

            if (_reader.Read())
            {
                _result[2] = _reader.GetString(0);
                _result[3] = _reader.GetString(1);
            }

            _reader.Close();

            if (File.Exists(bak_path))
            {
                _SQL = @"restore FILELISTONLY from disk='" + bak_path + "'";

                _reader = GetReader(_SQL);

                if (_reader.Read())
                {
                    _result[0] = _reader.GetString(0);
                }
                if (_reader.Read())
                {
                    _result[2] = _reader.GetString(0);
                }
                _reader.Close();
            }
            if (_result[0] == null || _result[2] == null)
            {
                return null;
            }
            return _result;
            //}
        }

    }
}
