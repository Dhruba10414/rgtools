using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Collections;

namespace RGTools_New
{
    class TGOAL
    {
        public static void GenerateGoals(frmMain _main, StreamWriter BogueFile, string WorkingDirectory, TSymbolTable SymbolTable)
        {
            //char iline[200];  // Input line buffer.
            long Order = 0;
            string ts;
            // Open the domain file and exit on error.
            //ts = WorkingDirectory + "\\SCREEN.TXT";
            ts = Path.Combine(WorkingDirectory, "SCREEN.TXT");
            StreamReader DIFile = null;

            try
            {
                DIFile = new StreamReader(ts, Encoding.Default);
            }
            catch
            {
                throw (new Exception("Error! Could not open SCREEN.TXT."));
            }

            //ts = WorkingDirectory + "\\GOAL.REM";
            ts = Path.Combine(WorkingDirectory, "GOAL.REM");
            StreamWriter GoalFile = null;

            try
            {
                //GoalFile = new StreamWriter(ts);
                GoalFile = new StreamWriter(ts, false, Encoding.Default);
            }
            catch
            {
                throw (new Exception("Could not create GOAL.REM file."));
            }

            Hashtable hsApplicSN = new Hashtable();
            int lineNum = 0;
            long moduleSN = 0;
            string InputLine = string.Empty;

            while ((InputLine = DIFile.ReadLine()) != null)
            {
                lineNum++;
                //string InputLine = iline;
                InputLine = InputLine.Trim(new char[]{' '});

                // If the line is blank, or it's a comment (Denoted by starting with an asterisk)
                // skip to next line.
                if ((InputLine.Length == 0) || (InputLine[0] == '*')) continue;

                // Look up domain name in the symbol table. If it's not there, puke.
                TSymbol pS = SymbolTable.FindFirst(new TSymbol(InputLine));
                if (pS == null)
                {
                    //throw (new Exception("Can't find Goal " + InputLine + "."));
                    ErrorThrow(_main, BogueFile, "Can't find Goal " + InputLine + " in SCREEN.TXT at line :" + lineNum);
                }
                else
                {
                    if (Order == 0)
                    {
                        Order = pS.ModuleSN;
                        moduleSN = pS.ModuleSN;
                    }
                    else
                    {
                        if (Order > 0)
                        {
                            Order++;
                        }
                        else
                        {
                            Order--;
                        }
                    }

                    try
                    {
                        hsApplicSN.Add(pS.InternalSN, Order);
                    }
                    catch
                    {
                        ErrorThrow(_main, BogueFile, "Duplicated lines in SCREEN.TXT at line :" + lineNum);
                    }
                    //
                }
            }

            foreach (DictionaryEntry entry in hsApplicSN)
            {
                GoalFile.WriteLine(entry.Key.ToString() + "," + entry.Value.ToString() + "," + moduleSN.ToString());// GetModuleSN() << endl;
            }

            // Close the input file.
            DIFile.Close();
            GoalFile.Close();
        }
        private static void ErrorThrow(frmMain _main, StreamWriter BogueFile, string message)
        {
            if (message != string.Empty)
            {
                _main.OutMsg(PageType.BuildREM, message + ".\r\n");
                BogueFile.WriteLine(message + "\r\n");
                _main.processFailed = true;
            }
        }
    }
}

