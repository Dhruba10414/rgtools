using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Diagnostics;

namespace RGTools_New
{
    enum TerminatorType { Comma, Space, LineBreak };

    class ISQLStream
    {
        StreamReader QIFile=null;

        public ISQLStream(string FileName)
        {
            //QIFile = new StreamReader(QInputName, Encoding.Default);

            //ifstream (FileName.c_str(), ios::in | ios::binary)
        }
        public bool ReadLong(long LValue, TerminatorType Terminator)
        {
            const int BUFFER_SIZE = 40;
            char[] icheck = new char[BUFFER_SIZE];
            char bit;
            int Offset = -1;
            bool Success = false;

            //// look for (+|-)0 (0|1|2|3|4|5|6|7|8|9)*
            //while (get(bit))
            //{
            //    if (((Terminator == TerminatorType.Comma) && (bit == ',')) ||
            //          ((Terminator == TerminatorType.Space) && (bit == ' ')) ||
            //          ((Terminator == TerminatorType.LineBreak) && (bit == '\n')))
            //    {
            //        Offset++;
            //        assert(Offset < BUFFER_SIZE);
            //        icheck[Offset] = 0;
            //        LValue = atol(icheck);
            //        Success = true;
            //        break;
            //    }
            //    else
            //    {
            //        Offset++;
            //        assert(Offset < BUFFER_SIZE);
            //        icheck[Offset] = bit;
            //    }
            //}

            return Success;
        }
        public bool ReadString(ref string SValue, TerminatorType Terminator)
        {
            const int BUFFER_SIZE = 30000;
            char[] icheck = new char[BUFFER_SIZE];
            //char bit;
            int Offset = -1;
            //bool QuoteOn = false;
            bool Success = false;

            //while (get(bit)) 
            //{
            //    if (!QuoteOn &&
            //        (((Terminator == Comma) && (bit == ',')) ||
            //         ((Terminator == Space) && (bit == ' ')) ||
            //             ((Terminator == LineBreak) && (bit == '\n')))) {
            //        Success = true;
            //            break;
            //    } else {
            //        if (bit == '\'') QuoteOn = !QuoteOn;
            //        Offset++;
            //        assert (Offset < BUFFER_SIZE);
            //        icheck[Offset] = bit;
            //    }
            //}

            Offset++;
            Debug.Assert(Offset < BUFFER_SIZE);
            //icheck[Offset] = 0;
            //SValue = icheck;

            //delete[] icheck;
            return Success;
        }
    }


    class OSQLStream : FileStream
    {

        public OSQLStream(string FileName)
            : base(FileName, FileMode.OpenOrCreate)//FileAccess.Write)
        {
            //ofstream (FileName.c_str(), ios::out | ios::binary)
            //string FileName
        }
    }

}
