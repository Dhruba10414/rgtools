using System;
using System.Collections.Generic;
using System.Text;
using System.IO;


namespace RGTools_New
{
    public class FileSelStatus
    {
        bool _sel = false;
        string _name = string.Empty;
        string _path = string.Empty;

        public FileSelStatus(bool isChecked, string FileName)
        {
            _sel = isChecked;
            _name = FileName;
        }

        public string DirPath
        {
            get
            {
                return _path;
            }
            set
            {
                _path = value;
            }
        }
        public FileSelStatus(string FullFileName)
        {
            _name = Path.GetFileName(FullFileName);
            _path = Path.GetDirectoryName(FullFileName);
        }

        public bool Selected
        {
            get
            {
                return _sel;
            }
            set
            {
                _sel = value;
            }
        }

        public string FileName
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }
    }
}
