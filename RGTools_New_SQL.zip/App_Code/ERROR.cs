using System;
using System.Collections.Generic;
using System.Text;

namespace RGTools_New
{
    public enum EnumSQLError
    {
        DB_NOERROR = 1,  // No error.
        DB_NOTFOUND,     // Query returns no record selected (may be normal situation).
        DB_MULTIPLEROW
    } // Multiple row result for a one-row-query (see SelectUniqueQuery()).

    //class ERROR
    //{
    //}
}
