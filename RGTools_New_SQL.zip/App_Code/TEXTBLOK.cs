using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace RGTools_New
{

    class TChange
    {
        private int m_Date;
        private int m_Offset;
        private int m_Length;

        public TChange(int pDate, int pOffset, int pLength)
        {
            m_Date = pDate;
            m_Offset = pOffset;
            m_Length = pLength;
        }

        public int GetDate() { return m_Date; }
        public int Date
        {
            get
            { return m_Date; }
        }
        public int GetOffset() { return m_Offset; }
        public int Offset
        {
            get
            { return m_Offset; }
        }
        public int GetLength() { return m_Length; }
        public int Length
        {
            get
            {
                return m_Length;
            }
        }
        public void AdjustOffset(int pAdjust) { m_Offset += pAdjust; }

        public static bool operator ==(TChange change1, TChange change2)
        {
            if (IsNull(change1) && IsNull(change2))
            {
                return true;
            }
            else if (IsNull(change1) || IsNull(change2))
            {
                return false;
            }
            else
            {
                return (change1.m_Date == change2.m_Date) ? true : false;
            }
        }
        public static bool operator !=(TChange change1, TChange change2)
        {
            if (IsNull(change1) && IsNull(change2))
            {
                return false;
            }
            else if (IsNull(change1) || IsNull(change2))
            {
                return true;
            }
            else
            {
                return (change1.m_Date != change2.m_Date) ? true : false;
            }
        }
        public static bool IsNull(TChange change)
        {
            return TChange.Equals(change, null);
        }
        public override bool Equals(object change)
        {
            if (IsNull(change as TChange))
            {
                return false;
            }
            else
            {
                return this.m_Date == (change as TChange).m_Date ? true : false;
            }
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

    }

    class TChangeList : List<TChange>
    {

        public TChangeList()
        { }

        public void AdjustOffset(int pAdjust)
        {
            for (int i = 0; i < base.Count; i++)
                base[i].AdjustOffset(pAdjust);
        }

        public void Append(TChangeList pAppendList, int Offset)
        {
            for (int i = 0; i < pAppendList.Count; i++)
            {
                TChange pChange = pAppendList[i];
                Add(new TChange(pChange.Date, pChange.Offset + Offset, pChange.Length));
            }
        }
        public void Append(TChangeList pAppendList)
        {
            Append(pAppendList, 0);
        }
        public int GetLatestDate()
        {
            int LatestDate = 0;
            for (int i = 0; i < base.Count; i++)
            {
                TChange pChange = base[i];
                if (pChange.Date > LatestDate)
                    LatestDate = pChange.GetDate();
            }
            return LatestDate;
        }
    }

    public enum BlockType { DEF, KEY, None };

    class BlockDetail
    {
        string mKey = string.Empty;
        public int Date = 0;
        public string Text = string.Empty;
        public string Caption = string.Empty;
        public string SubHeader = string.Empty;
        public RGTokenType Indent = RGTokenType.Undefined;
        public RGTokenType IndentStatus = RGTokenType.Undefined;
        public BlockType Type = BlockType.None;
        public bool tokBOnly = false;

        public BlockDetail(RGTokenType indent)
        {
            Indent = indent;
            IndentStatus = indent;
        }
        public BlockDetail(string BlockKey, BlockType type)
        {
            mKey = BlockKey;
            Type = type;
        }
        public BlockDetail(string BlockKey, BlockType type, RGTokenType indent)
        {
            mKey = BlockKey;
            Type = type;
            Indent = indent;
            IndentStatus = indent;
        }

        public string Key
        {
            get
            {
                return mKey;
            }
        }
    }

    class TTextBlock : List<BlockDetail>
    {
        string SEP_LISTANSWER = ASCIIEncoding.Default.GetString(new byte[] { 0x7F }); //Convert.ToChar(0x7F);
        string SEP_LISTREF = ASCIIEncoding.Default.GetString(new byte[] { 0x7F }); //Convert.ToChar(0X7F);
        string FORMAT_PREFIX = ASCIIEncoding.Default.GetString(new byte[] { 0X07 }); //Convert.ToChar(0X07);
        string BOLD_ON = ASCIIEncoding.Default.GetString(new byte[] { 0X11 }); //Convert.ToChar(0X11);
        string BOLD_OFF = ASCIIEncoding.Default.GetString(new byte[] { 0X91 }); //Convert.ToChar(0X91);
        string FIXED_ON = ASCIIEncoding.Default.GetString(new byte[] { 0X12 }); //Convert.ToChar(0X12);
        string FIXED_OFF = ASCIIEncoding.Default.GetString(new byte[] { 0X92 }); //Convert.ToChar(0X92);
        string PARAGRAPH_BREAK = ASCIIEncoding.Default.GetString(new byte[] { 0X0E }); //Convert.ToChar(0X0E);   // leaves a blank line.
        string LINE_BREAK = ASCIIEncoding.Default.GetString(new byte[] { 0X0F }); //Convert.ToChar(0X0F);   // a simple CRLF.
        string LEFTMARGIN = ASCIIEncoding.Default.GetString(new byte[] { 0X10 }); //Convert.ToChar(0X10); //0x10;

        private string m_Text = string.Empty;
        private TChangeList m_ChangeList = new TChangeList();
        private int m_ParagraphCount = 0;
        private int m_CurrentDate = 0;
        private int m_CurrentDateOffset = 0;

        private BlockDetail m_CurrentBlockDetail = null;

        public void AddBlockDetail(BlockDetail detail)
        {
            if (detail != null)
            {
                switch (detail.Indent)
                {
                    case RGTokenType.OutOfTokens:
                    case RGTokenType.tokINDENT:
                    case RGTokenType.tokA:
                        if (m_CurrentBlockDetail != null && m_CurrentBlockDetail.IndentStatus == RGTokenType.tokB)
                        {
                            if (m_CurrentBlockDetail.tokBOnly)
                            {
                                base.Add(new BlockDetail("", m_CurrentBlockDetail.Type, RGTokenType.tokOFF));
                            }
                            else
                            {
                                detail = new BlockDetail(RGTokenType.tokOFF);
                                detail.IndentStatus = RGTokenType.tokA;
                            }
                        }

                        if (m_CurrentBlockDetail != null)
                        {
                            if (m_CurrentBlockDetail.IndentStatus == RGTokenType.tokA)
                            {
                                break;
                            }

                            detail.Type = m_CurrentBlockDetail.Type;
                        }

                        detail.tokBOnly = false;
                        base.Add(detail);
                        m_CurrentBlockDetail = detail;
                        break;
                    case RGTokenType.tokOFF:
                        if (m_CurrentBlockDetail != null && (m_CurrentBlockDetail.IndentStatus == RGTokenType.tokB
                                || m_CurrentBlockDetail.IndentStatus == RGTokenType.tokA))
                        {
                            if (m_CurrentBlockDetail.IndentStatus == RGTokenType.tokB && !m_CurrentBlockDetail.tokBOnly)
                            {
                                base.Add(new BlockDetail("", m_CurrentBlockDetail.Type, RGTokenType.tokOFF));
                                //if (m_CurrentBlockDetail.Type == BlockType.KEY)
                                //{
                                //    base.Add(new BlockDetail("", m_CurrentBlockDetail.Type, RGTokenType.tokOFF));
                                //}
                                //else
                                //{
                                //    detail.IndentStatus = RGTokenType.tokA;
                                //}
                            }

                            detail.Type = m_CurrentBlockDetail.Type;

                            detail.tokBOnly = false;
                            base.Add(detail);
                            m_CurrentBlockDetail = detail;
                        }
                        break;
                    case RGTokenType.tokB:
                        detail.tokBOnly = false;
                        if (m_CurrentBlockDetail != null)
                        {
                            if (m_CurrentBlockDetail.IndentStatus == RGTokenType.tokB)
                            {
                                break;
                            }

                            detail.Type = m_CurrentBlockDetail.Type;

                            if (m_CurrentBlockDetail.IndentStatus != RGTokenType.tokA)
                            {
                                detail.tokBOnly = true;
                            }
                        }
                        base.Add(detail);
                        m_CurrentBlockDetail = detail;
                        break;
                    default:
                        base.Add(detail);
                        m_CurrentBlockDetail = detail;
                        break;
                }
            }
        }

        public BlockDetail CurrentBlockDetail
        {
            get
            {
                return m_CurrentBlockDetail;
            }
        }

        public TTextBlock(string pStartString)
        {
            m_Text = pStartString;
            m_ParagraphCount = 0;
            m_CurrentDate = 0;
            m_CurrentDateOffset = 0;
        }
        public TTextBlock()
        {
            m_Text = string.Empty;
            m_ParagraphCount = 0;
            m_CurrentDate = 0;
            m_CurrentDateOffset = 0;
        }

        public void MarkRevision(int pDate, int pOffset, int pLength)
        {
            m_ChangeList.Add(new TChange(pDate, pOffset, pLength));
        }
         
        long USHRT_MAX = 65535;
        public void Append(string pAppendString)
        {
            //byte[] unicodeBytes = Encoding.Default.GetBytes(pAppendString);
            //string s = ASCIIEncoding.Default.GetString(unicodeBytes);

            if (((long)m_Text.Length + (long)pAppendString.Length) > USHRT_MAX)
            {
                m_Text = "";
                throw (new Exception("*String is too long, insert a break at a logic point before this line"));
            }
            m_Text += pAppendString;

            //unicodeBytes = Encoding.Default.GetBytes(m_Text);
            //s = ASCIIEncoding.Default.GetString(unicodeBytes);

        }//throw (xmsg);
        public void Append(TTextBlock pAppendBlock)
        {
            if (((long)m_Text.Length + (long)pAppendBlock.m_Text.Length) > USHRT_MAX)
            {
                m_Text = "";
                throw (new Exception("*String to too long, insert a break at a logical point before this line"));
            }
            int BaseLength = GetLength();
            m_Text += pAppendBlock.m_Text;
            m_ParagraphCount += pAppendBlock.m_ParagraphCount;
            m_ChangeList.Append(pAppendBlock.m_ChangeList, BaseLength);
        }
        //throw (xmsg);
        public int GetLength() { return m_Text.Length; }
        public long Length
        {
            get
            { return m_Text.Length; }
        }
        public int GetLatestDate() { return m_ChangeList.GetLatestDate(); }
        public int LatestDate
        {
            get
            { return m_ChangeList.GetLatestDate(); }
        }
        public void SetBold(bool pState)
        {
            if (pState)
            {
                Append(FORMAT_PREFIX.ToString() + BOLD_ON.ToString());
            }

            else
            {
                Append(FORMAT_PREFIX.ToString() + BOLD_OFF.ToString());
            }

        }//throw (xmsg);

        public void SetFixed(bool pState)
        {
            if (pState)
                Append(FORMAT_PREFIX.ToString() + FIXED_ON.ToString());
            else
                Append(FORMAT_PREFIX.ToString() + FIXED_OFF.ToString());
        }//throw (xmsg);
        public void SetIndent(long pIndent)
        {
            //char Indent = (char)(pIndent);
            char Indent =Convert.ToChar( (byte)(pIndent));
            Append(FORMAT_PREFIX.ToString() + LEFTMARGIN.ToString() + Indent.ToString());
        }//throw (xmsg);
        public void NewLine()
        {

            //byte[] unicodeBytes = Encoding.Default.GetBytes(m_Text);
            //string s = ASCIIEncoding.Default.GetString(unicodeBytes);

            // If we are at the start of a block, don't add leading new lines.
            if (m_Text.Length == 0) return;

            // If there are two new lines preceding, don't add another.
            if (m_Text.Length >= 4)
            {
                int Offset = m_Text.Length - 4;
                //if ((m_Text[Offset] == FORMAT_PREFIX) && (m_Text[Offset + 1] == LINE_BREAK) &&
                //    (m_Text[Offset + 2] == FORMAT_PREFIX) && (m_Text[Offset + 3] == LINE_BREAK)) return;
                if ((m_Text.Substring(Offset, 1) == FORMAT_PREFIX) && (m_Text.Substring(Offset+1, 1) == LINE_BREAK) &&
                   (m_Text.Substring(Offset + 2, 1) == FORMAT_PREFIX) && (m_Text.Substring(Offset + 3, 1) == LINE_BREAK)) return;
            }

            // Check for a preceding line break followed by indent which has a similar effect.
            if (m_Text.Length >= 5)
            {
                int Offset = m_Text.Length - 5;
                if ((m_Text.Substring(Offset, 1) == FORMAT_PREFIX) && (m_Text.Substring(Offset + 1, 1) == LINE_BREAK) &&
                    (m_Text.Substring(Offset + 2, 1) == FORMAT_PREFIX) && (m_Text.Substring(Offset + 3, 1) == LEFTMARGIN)) return;
            }

            m_ParagraphCount++;
            Append(FORMAT_PREFIX.ToString() + LINE_BREAK.ToString());

            //unicodeBytes = Encoding.Default.GetBytes(m_Text);
            //s = ASCIIEncoding.Default.GetString(unicodeBytes);

        }//throw (xmsg);
        public void NewParagraph()
        {
            NewLine();
            NewLine();
        }

        public long GetParagraphCount() { return m_ParagraphCount; }
        public long ParagraphCount
        {
            get
            { return m_ParagraphCount; }
        }
        public TChangeList GetChangeList() { return m_ChangeList; }
        public TChangeList ChangeList
        {
            get
            { return m_ChangeList; }
        }
        public string GetText() { return m_Text; }
        public string Text
        {
            get
            { return m_Text; }
        }

        public int CurrentDate
        {
            get
            {
                return m_CurrentDate;
            }
            set
            {
                if (m_CurrentDate != 0)
                {
                    // Save current date & offset, then reset.
                    m_ChangeList.Add(new TChange(m_CurrentDate, m_CurrentDateOffset, m_Text.Length - m_CurrentDateOffset));
                }

                m_CurrentDate = value;
                m_CurrentDateOffset = m_Text.Length;
            }
        }
        public void SetDate(int pDate)
        {
            if (m_CurrentDate != 0)
            {
                // Save current date & offset, then reset.
                m_ChangeList.Add(new TChange(m_CurrentDate, m_CurrentDateOffset, m_Text.Length - m_CurrentDateOffset));
            }

            m_CurrentDate = pDate;
            m_CurrentDateOffset = m_Text.Length;
        }
        public bool CleanTermination()
        {
            // Returns true if we are at the start of the block or the last entry is a
            // line break.
            if (m_Text.Length == 0)
                return true;

            if (m_Text.Length > 1)
            {
                int Offset = m_Text.Length - 2;
                //if ((m_Text[Offset] == FORMAT_PREFIX) && (m_Text[Offset + 1] == LINE_BREAK))
                //    return true;

                //if ((m_Text.Length > 2) &&
                //    (m_Text[Offset - 1] == FORMAT_PREFIX) && (m_Text[Offset] == LEFTMARGIN))
                //    return true;
                if ((m_Text.Substring(Offset,1) == FORMAT_PREFIX) && (m_Text.Substring(Offset+1,1) == LINE_BREAK))
                    return true;

                if ((m_Text.Length > 2) &&
                    (m_Text.Substring(Offset - 1, 1) == FORMAT_PREFIX) && (m_Text.Substring(Offset, 1) == LEFTMARGIN))
                    return true;

                return false;
            }
            else
                return true;
        }
    }
}
