//----------------------------------------------------------------------------
//  Project RGTools
//  Dakota Software Corporation
//  Copyright � 1997. All Rights Reserved.
//  FILE:    counter.cpp
//  AUTHOR:  Marc CHANTEGREIL
//----------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Text;

namespace RGTools_New
{
    class TCounter
    {

        private long ParagraphCounter;

        public TCounter()
        { ResetCounter(); }

        public void ResetCounter() { ParagraphCounter = 2; } // with 0, the computation of the offset for the table is wrong.
        public long GetCounter() { return ParagraphCounter; }
        public string OutputSeparator(string Separator)
        {
            ParagraphCounter++;
            return Separator;
        }
        public void IncrementCounter(long Delta) { ParagraphCounter += Delta; }
        public void IncrementCounter()
        {
            long Delta = 1;
            ParagraphCounter += Delta;
        }

    }
}
