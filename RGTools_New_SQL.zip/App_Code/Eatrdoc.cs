using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using NaturalNumericSort;

namespace RGTools_New
{
    class TParseLine
    {
        public enum LineClass
        {
            lcText,
            lcSection,
            lcSubHeader,
            lcCaption,
            lcList,
            lcEndList,
            lcTable,
            lcEndTable,
            lcIndent,
            lcBreak,
            lcKey,
            lcDefinition,
            lcDate,
            EndOfFile
        }

        public enum GeneralClass { gcText, gcCommand }

        private string m_Text;
        private long m_LineNumber;
        private LineClass m_LineClass;

        public TParseLine(string pText, long pLineNumber, LineClass pLineClass)
        {
            m_Text = pText;

            m_LineNumber = pLineNumber;
            m_LineClass = pLineClass;
        }// 

        public string GetText()
        { return m_Text; }
        public long GetLineNumber() 
        { 
            return m_LineNumber; 
        }
        public string Text
        {
            get
            {
                return m_Text;
            }
        }
        public long LineNumber
        {
            get
            {
                return m_LineNumber;
            }
        }
        public LineClass GetLineClass() { return m_LineClass; }
        public LineClass LineType 
        {
            get
            {
                return m_LineClass;
            }
        }

        public static bool operator ==(TParseLine line1, TParseLine line2)
        {
            if (IsNull(line1) && IsNull(line2))
            {
                return true;
            }
            else if (IsNull(line1) || IsNull(line2))
            {
                return false;
            }
            else
            {
                return (line1.m_LineNumber == line2.m_LineNumber) ? true : false;
            }
        }
        public static bool operator !=(TParseLine line1, TParseLine line2)
        {
            if (IsNull(line1) && IsNull(line2))
            {
                return false;
            }
            else if (IsNull(line1) || IsNull(line2))
            {
                return true;
            }
            else
            {
                return (line1.m_LineNumber != line2.m_LineNumber) ? true : false;
            }
        }
        public static bool IsNull(TParseLine line)
        {
            return TParseLine.Equals(line, null);
        }
        public override bool Equals(object line)
        {
            if (IsNull(line as TParseLine))
            {
                return false;
            }
            else
            {
                return this.m_LineNumber == (line as TParseLine).m_LineNumber ? true : false;
            }
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }

    //string LineClassToString (TParseLine::LineClass pClass);

    class TParseDoc : List<TParseLine>
    {
        //int TokenCount = 15;
        struct strToken
        {
            private string _name;
            private RGTokenType _tok;

            public strToken(string name, RGTokenType tok)
            {
                _name = name;
                _tok = tok;
            }

            public string Name
            {
                get
                {
                    return _name;
                }
            }
            public RGTokenType Tok
            {
                get
                {
                    return _tok;
                }
            }
        }

        static strToken[] TokenArray =
                {   new strToken("A", RGTokenType.tokA), 
                    new strToken("B", RGTokenType.tokB), 
                    new strToken("BREAK", RGTokenType.tokBREAK),
                    new strToken("CAPTION", RGTokenType.tokCAPTION), 
                    new strToken("DATE", RGTokenType.tokDATE),
                    new strToken("DEFAULT", RGTokenType.tokDEFAULT), 
                    new strToken("DEF", RGTokenType.tokDEFINITION),
                    new strToken("END", RGTokenType.tokEND), 
                    new strToken("INDENT", RGTokenType.tokINDENT),
                    new strToken("KEY", RGTokenType.tokKEY), 
                    new strToken("LIST", RGTokenType.tokLIST),
                    new strToken("OFF", RGTokenType.tokOFF), 
                    new strToken("SECTION", RGTokenType.tokSECTION),
                    new strToken("SUBHEADER", RGTokenType.tokSUBHEADER), 
                    new strToken("TABLE", RGTokenType.tokTABLE)};

        //private int m_CurrentLinePos;
        private int m_CurrentLinePosPos;

        internal int CurrentLinePos
        {
            get
            {
                return m_CurrentLinePosPos;
            }
            set
            {
                m_CurrentLinePosPos = value;
            }
        }
        public TParseDoc()
        {
            //m_CurrentLinePos = -1;
            m_CurrentLinePosPos = -1;
        }

        public void DigestRefLib(string InputDirectory, StreamWriter Bogue)
        {
            // First try to open the input file.
            string RGInputName = InputDirectory + "\\REFLIB.TXT";
            StreamReader RGIFile = null;
            
            try
            {
                RGIFile = new StreamReader(RGInputName, Encoding.Default);
            }
            catch
            {
                throw (new Exception("Could not open " + RGInputName + "."));
            }

            long LineCount = 0;
            //char iline[500];
            bool HasProblems = false;
            bool ActiveSection = false;

            // Loop through the input, discarding comments and sorting commands from content.
            string InputLine = string.Empty;
            while ((InputLine = RGIFile.ReadLine()) != null)
            {
                LineCount++;
                if ((InputLine.Length > 0) && (InputLine.Substring(0, 1) == "*")) continue;

                if (InputLine.IndexOf(@"\t") != -1)
                {
                    InputLine.Replace('\t',' ');
                    Bogue.WriteLine("Note: Tabs were removed from line " + LineCount.ToString());// + endl;
                }

                // Now classify the two remaining choices.
                int Offset =UTIL.find_first_not_of(InputLine, new char[] { ' ' });
                if ((Offset == -1) || (InputLine.Substring(Offset, 1)) != "@")
                {
                    if (!ActiveSection)
                    {
                        string ts = InputLine.TrimStart(new char[] { ' ' });
                        if (ts.Length == 0)
                        {
                            continue;
                        }
                        else
                        {
                            Bogue.WriteLine("Text not associated with a definition or section at line " + LineCount.ToString());// + endl;
                            HasProblems = true;
                            continue;
                        }
                    }

                    int pos = InputLine.IndexOf("\0");
                    if (pos > -1)
                    {
                        InputLine = InputLine.Substring(0, pos);
                    }
                    Add(new TParseLine(InputLine, LineCount, TParseLine.LineClass.lcText));
                    //SortLine();
                }
                else
                {
                    ActiveSection = true;

                    // Trim off the command junk.
                    //InputLine = InputLine.Trim(new char[]{' '});
                    InputLine = InputLine.Trim(new char[]{' '});
                    byte[] _by = ASCIIEncoding.Default.GetBytes(InputLine);

                    InputLine=InputLine.Remove(0, 1);
                    //InputLine = InputLine.Trim(new char[]{' '});
                    InputLine = InputLine.Trim(new char[] { ' ' });
                    if (InputLine.Length == 0)
                    {
                        Bogue.WriteLine("Empty command at line " + LineCount.ToString());// + endl;
                        HasProblems = true;
                        continue;
                    }

                    while (InputLine.Substring(InputLine.Length - 1, 1) == "!")
                    {
                        // We have a continuation situation.
                        InputLine = InputLine.Remove(InputLine.Length - 1);
                        InputLine = InputLine.Trim(new char[]{' '});

                            //if (!RGIFile.getline(iline, 500))

                        string ts = string.Empty;
                        if ((ts = RGIFile.ReadLine()) == null)
                        {
                            Bogue.WriteLine("Continuation line failed at line " + LineCount.ToString());// + endl;
                            HasProblems = true;
                            break;
                        }

                        LineCount++;

                        //string ts = InputLine;
                        ts = ts.Trim(new char[]{' '});
                        InputLine = InputLine + " " + ts;
                    }

                    try
                    {
                        TParseLine.LineClass ThisLineClass=new TParseLine.LineClass();
                        Preparse(ref InputLine, ref ThisLineClass);
                        TParseLine pParseLine = new TParseLine(InputLine, LineCount, ThisLineClass);
                        Add(pParseLine);
                        //SortLine();
                    }
                    catch (Exception e)
                    {
                        Bogue.WriteLine(e.Message + " at line " + LineCount.ToString());// + endl;
                        HasProblems = true;
                        continue;
                    }
                }
            }

            RGIFile.Close();

            if (HasProblems)
            {
                throw (new Exception("There are errors in the Requirements Guide"));
            }// throw (xmsg);

        }

        public TParseLine.LineClass LineClassType //Peek()
        {
            get
            {
                return (m_CurrentLinePosPos + 1 < base.Count) ? base[(m_CurrentLinePosPos + 1)].GetLineClass() : TParseLine.LineClass.EndOfFile;
            }
        }//  ;
        public TParseLine GetLine()
        {
            m_CurrentLinePosPos++;
            return (m_CurrentLinePosPos < this.Count) ? base[m_CurrentLinePosPos] : null;
        }

        public TParseLine CurrentLineObject()
        {
            return (m_CurrentLinePosPos + 1 < this.Count) ? base[m_CurrentLinePosPos + 1] : null;
        }// ;

        public long GetCurrentLine()
        {
            return base[m_CurrentLinePosPos].GetLineNumber();
        }

        void Preparse(ref string pText, ref TParseLine.LineClass pLineClass) //throw (xmsg)
        {
            switch (Rgtoken.GetRGToken(ref pText))
            {
                case RGTokenType.tokBREAK:
                    if (pText.Length != 0)
                        throw (new Exception("BREAK command has some trailing junk"));
                    pLineClass = TParseLine.LineClass.lcBreak;
                    break;

                case RGTokenType.tokCAPTION:
                    if (pText.Length == 0)
                        throw (new Exception("CAPTION command is missing caption"));
                    pLineClass = TParseLine.LineClass.lcCaption;
                    break;

                case RGTokenType.tokDATE:
                    if (pText.Length == 0)
                        throw (new Exception("DATE command is missing date or DEFAULT"));
                    pLineClass = TParseLine.LineClass.lcDate;
                    break;

                case RGTokenType.tokDEFINITION:
                    //if (pText.IndexOf("Industrial user") > -1)
                    //{
                    //    string s = "";
                    //}
                    if (pText.Length == 0)
                        throw (new Exception("DEFINITION command is missing key value"));
                    pLineClass = TParseLine.LineClass.lcDefinition;
                    break;

                case RGTokenType.tokEND:
                    switch (Rgtoken.GetRGToken(ref pText))
                    {
                        case RGTokenType.tokLIST:
                            if (pText.Length != 0)
                                throw (new Exception("END LIST command has some trailing junk"));
                            pLineClass = TParseLine.LineClass.lcEndList;
                            break;

                        case RGTokenType.tokTABLE:
                            if (pText.Length != 0)
                                throw (new Exception("END TABLE command has some trailing junk"));
                            pLineClass = TParseLine.LineClass.lcEndTable;
                            break;

                        default:
                            throw (new Exception("Unknown END command"));
                    }
                    break;

                case RGTokenType.tokSECTION:
                    if (pText.Length == 0)
                        throw (new Exception("SECTION command missing [nn] specifier"));
                    pLineClass = TParseLine.LineClass.lcSection;
                    break;

                case RGTokenType.tokKEY:
                    if (pText.Length == 0)
                        throw (new Exception("KEY command is missing key value"));
                    pLineClass = TParseLine.LineClass.lcKey;
                    break;

                case RGTokenType.tokLIST:
                    pLineClass = TParseLine.LineClass.lcList;
                    break;

                case RGTokenType.tokINDENT:
                    pLineClass = TParseLine.LineClass.lcIndent;
                    break;

                case RGTokenType.tokSUBHEADER:
                    if (pText.Length == 0)
                        throw (new Exception("SUBHEADER command is missing subheader text"));
                    pLineClass = TParseLine.LineClass.lcSubHeader;
                    break;

                case RGTokenType.tokTABLE:
                    if (pText.Length != 0)
                        throw (new Exception("TABLE command has some trailing junk"));
                    pLineClass = TParseLine.LineClass.lcTable;
                    break;

                default:
                    throw (new Exception("Bad command"));
            }
        }

        private static int CompareTParseLine(TParseLine line1, TParseLine line2)
        {
            if (line1 == null)
            {
                if (line2 == null)
                {
                    return 0;
                }
                else
                {
                    return -1;
                }
            }
            else
            {
                if (line2 == null)
                {
                    return 1;
                }
                else
                {
                    const int len = 20;
                    string s1 = string.Empty;
                    string s2 = string.Empty;
                    if (line1.Text.Length > len)
                    {
                        s1 = line1.Text.Substring(0, len);
                    }
                    else
                    {
                        s1 = line1.Text;
                    }

                    if (line2.Text.Length > len)
                    {
                        s2 = line2.Text.Substring(0, len);
                    }
                    else
                    {
                        s2 = line2.Text;
                    }

                    //return UTIL.CmpareString(s1, s2);
                    //return string.Compare(s1, s2, StringComparison.Ordinal);
                    return StringLogicalComparer.Compare(s1, s2);
                }
            }
        }
        private void SortLine()
        {
            base.Sort(CompareTParseLine);
        }

    }

}
