using System;
using System.Collections.Generic;
using System.Text;

namespace RGTools_New
{
    class TSerialMapItem
    {
        protected string _OldNumber;
        protected string _NewNumber;

        public TSerialMapItem(string pOldNumber, string pNewNumber)
        {
            _OldNumber=pOldNumber;
            _NewNumber = pNewNumber;
        }
        public TSerialMapItem(string pOldNumber)
        {
            string pNewNumber = string.Empty;
            _OldNumber = pOldNumber;
            _NewNumber = pNewNumber;
        }

        public TSerialMapItem(long pOldNumber, long pNewNumber)
        {
            char[] ts = new char[35];
            //ltoa(pOldNumber, ts, 10);
            _OldNumber = pOldNumber.ToString();

            //ltoa(pNewNumber, ts, 10);
            _NewNumber = pNewNumber.ToString();
        }

        public string GetOldNumber() { return _OldNumber; }
        public string OldNumber
        {
            get
            {
                return _OldNumber;
            }
        }
        public string GetNewNumber() { return _NewNumber; }
        public string NewNumber
        {
            get
            {
                return _NewNumber;
            }
        }
        public static bool operator ==(TSerialMapItem MapItem1, TSerialMapItem MapItem2)
        {
            if (IsNull(MapItem1) && IsNull(MapItem2))
            {
                return true;
            }
            else if (IsNull(MapItem1) || IsNull(MapItem2))
            {
                return false;
            }
            else
            {
                return MapItem1.OldNumber == MapItem2.OldNumber ? true : false;
            }
        }
        public static bool IsNull(TSerialMapItem MapItem)
        {
            return TSerialMapItem.Equals(MapItem, null);
        }
        public static bool operator !=(TSerialMapItem MapItem1, TSerialMapItem MapItem2)
        {
            if (IsNull(MapItem1) && IsNull(MapItem2))
            {
                return false;
            }
            else if (IsNull(MapItem1) || IsNull(MapItem2))
            {
                return true;
            }
            else
            {
                return MapItem1.OldNumber != MapItem2.OldNumber ? true : false;
            }
        }

        public override bool Equals(object MapItem)
        {
            if (IsNull(MapItem as TSerialMapItem))
            {
                return false;
            }
            else
            {
                return this.OldNumber == (MapItem as TSerialMapItem).OldNumber ? true : false;
            }
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

    }

    class TSerialMap : List<TSerialMapItem>
    {

        public TSerialMap() { }

        public bool Map(string OldNumber, ref string NewNumber)
        {
            TSerialMapItem pSMI = FindFirst(new TSerialMapItem(OldNumber));
            if (pSMI!=null)
            {
                NewNumber = pSMI.GetNewNumber();// NewNumber;
                return true;
            }
            else
            {
                return false;
            }
        }
        public long Lookup(long OldNumber)
        {
            //        char[] ts=new char[35];
            //ltoa (OldNumber, ts, 10);
            string sOldNumber = OldNumber.ToString();
            string sNewNumber=string.Empty;
            if (Map(sOldNumber, ref  sNewNumber))
                return long.Parse(sNewNumber);
            else
                return OldNumber;
        }

        private static TSerialMapItem _MapItem = null;
        private static bool match(TSerialMapItem MapItem)
        {
            if (MapItem.GetOldNumber() == _MapItem.GetOldNumber())
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public TSerialMapItem FindFirst(TSerialMapItem MapItem)
        {
            _MapItem = MapItem;

            return base.Find(match);
        }

    }
}
