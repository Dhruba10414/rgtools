using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ODBCMngr;
using System.Data;

namespace RGTools_New
{
    class DBCheck
    {
        const string Fix_av_collision_1 = "update applicabilityvariable set applicsn = -applicsn where applicsn >= 20000   and modulesn = 11570";
        const string Fix_av_collision_2 = "update templaterule set setsn = -setsn where modulesn = 11570 and setsn >= 20000";
        const string Fix_av_collision_3 = "update templaterule set compasn = -compasn where modulesn = 11570 and compasn >= 20000";
        const string Fix_av_collision_4 = "delete from blob where (class = 2 or class = 3)     and SN = 11570   and (ModuleVersionSN  >= 33)";
        const string Fix_av_collision_5 = "update applicabilityvariable set applicsn = -applicsn where applicsn >= 50000   and modulesn = 33778";
        const string Fix_av_collision_6 = "update templaterule set setsn = -setsn where modulesn = 33778 and setsn >= 50000";
        const string Fix_av_collision_7 = "update templaterule set compasn = -compasn where modulesn = 33778 and compasn >= 50000";
        const string Fix_av_collision_8 = "delete from blob where (class = 2 or class = 3) and SN = 33778   and (ModuleVersionSN  >= 33)";
        const string commit = "commit";

        const string Dup_state_domainsn = "select * from StateDomainStructure a1 where exists (select *  from DomainStructure a2 where a2.DomainSN = a1.StateDomainSN)";
        const string duplicateappsn = "select * from applicabilityvariable a1 where exists (select * from applicabilityvariable a2 where a2.applicsn = a1.applicsn and a2.modulesn <> a1.modulesn) order by modulesn";
        const string ApplicabilityRangeMap2 = "SELECT ModuleSN, MIN(ApplicSN) AS Minimum_ApplicSN, MAX(ApplicSN) AS Maximum_ApplicSN , MAX(ApplicSN) - Min(ApplicSN) AS ApplicSN_Difference FROM applicabilityvariable Group BY ModuleSN Order By ModuleSN";

        const string LookForDuplicateQuestionLinkText_1 = "select * from sysobjects where id = object_id('UniqueLinkView')";
        const string LookForDuplicateQuestionLinkText_2 = "drop view UniqueLinkView";
        const string LookForDuplicateQuestionLinkText_3 = "CREATE VIEW UniqueLinkView AS SELECT DISTINCT QuestionSN, LinkSN, LinkText From aw_Hyperlink";
        const string LookForDuplicateQuestionLinkText_4 = "SELECT UniqueLinkView.LinkSN, UniqueLinkView.LinkText, UniqueLinkView.QuestionSN, QuestionBody.StdText, QuestionBody.NoteText, QuestionBody.ListAnswer FROM Question, QuestionBody, UniqueLinkView WHERE Question.QuestionBodySN = QuestionBody.QuestionBodySN AND UniqueLinkView.QuestionSN = Question.QuestionSN AND CAST(QuestionBody.StdText AS varchar(8000))  + CAST(QuestionBody.NoteText AS varchar(8000))  + CAST(QuestionBody.ListAnswer AS varchar(8000)) LIKE ('%' + UniqueLinkView.LinkText  + '%' +  UniqueLinkView.LinkText  + '%')";

        const string MissingLink = "SELECT aw_Hyperlink.QuestionSN, aw_Hyperlink.LinkText, aw_Hyperlink.LinkSN, aw_Hyperlink.LinkType, aw_Hyperlink.VarSN, aw_Hyperlink.ModuleSN, aw_Hyperlink.ChildP, aw_Hyperlink.ModuleVersionSN, QuestionBody.QuestionBodySN, QuestionBody.StdText, QuestionBody.NoteText, QuestionBody.ListAnswer, QuestionBody.DataType, QuestionBody.Properties FROM DBA.aw_Hyperlink aw_Hyperlink, DBA.QuestionBody QuestionBody WHERE aw_Hyperlink.QuestionSN = QuestionBody.QuestionBodySN AND ((QuestionBody.StdText Not Like '%'+aw_HyperLink.LinkText+'%') AND (QuestionBody.ListAnswer Not Like '%'+aw_HyperLink.LinkText+'%') AND (QuestionBody.NoteText Not Like '%'+aw_HyperLink.LinkText+'%'))";

        private frmMain _main = null;
        string SQL = string.Empty;
        DataSybase sybase = null;

        internal string DBName = string.Empty;
        internal PageType pgType = PageType.DBCheck;

        public DBCheck(frmMain Main)
        {
            _main = Main;
            sybase = new DataSybase(_main.DSNName, _main.SybaseUser, _main.SybasePW);
            sybase.callBack += new DataSybase.Display(sybase_callBack);
            pgType = PageType.DBCheck;
            //DBName = _main.txtDBCheckDB.Text.Trim();
        }

        
        private void sybase_callBack(string message)
        {
            _main.OutMsg(pgType, message);
        }

        private void ErrorThrow(string message)
        {
            if (message != string.Empty)
            {
                _main.OutMsg(pgType, message + ".\r\n");
            }
        }

        public void DoProcessFixAv()
        {
            if (_main.originalPathForCurrentDB != DBName)
            {
                if (!File.Exists(DBName))
                {
                    _main.OutMsg(pgType, "The db " +
                            DBName + " Does not exist!");

                    return;
                }

                ODBCManager.ChangeODBCDatasource(_main.DSNName, DBName);
            }

            string[] SQL = new string[16];
            string[] MSG = new string[16];

            // We must call first the base class method.
            //--------------------------------------------------------------
            SQL[0] = Fix_av_collision_1;
            MSG[0] = "update applicabilityvariable.\r\n";

            SQL[1] = commit;
            MSG[1] = "";

            SQL[2] = Fix_av_collision_2;
            MSG[2] = "update templaterule set setsn.\r\n";

            SQL[3] = commit;
            MSG[3] = "";

            SQL[4] = Fix_av_collision_3;
            MSG[4] = "update templaterule set compasn.\r\n";

            SQL[5] = commit;
            MSG[5] = "";

            SQL[6] = Fix_av_collision_4;
            MSG[6] = "delete from blob.\r\n";

            SQL[7] = commit;
            MSG[7] = "";

            SQL[8] = Fix_av_collision_5;
            MSG[8] = "update applicabilityvariable.\r\n";

            SQL[9] = commit;
            MSG[9] = "";

            SQL[10] = Fix_av_collision_6;
            MSG[10] = "update templaterule set setsn.\r\n";

            SQL[11] = commit;
            MSG[11] = "";

            SQL[12] = Fix_av_collision_7;
            MSG[12] = "update templaterule set compasn.\r\n";

            SQL[13] = commit;
            MSG[13] = "";

            SQL[14] = Fix_av_collision_8;
            MSG[14] = "delete from blob.\r\n";

            SQL[15] = commit;
            MSG[15] = "";

            string ret = sybase.RunSQL(SQL, MSG);
            if (ret != string.Empty)
            {
                ErrorThrow(ret);
            }
        }
        public void DoProcessDupAppSN()
        {
            if (_main.originalPathForCurrentDB != DBName)
            {
                if (!File.Exists(DBName))
                {
                    _main.OutMsg(pgType, "The db " +
                            DBName + " Does not exist!");

                    return;
                }

                ODBCManager.ChangeODBCDatasource(_main.DSNName, DBName);
            }

            DataSet ds = sybase.GetDataSet(duplicateappsn);

            if (ds.Tables.Count > 0)
            {
                _main.OutMsg(pgType, "Duplicates Application SN:\r\n");
                if (ds.Tables[0].Rows.Count > 0)
                {
                    _main.OutMsg(pgType, "ApplicSN\t AClass\t ASN\t Applicability\t ModuleSN\t ModuleVersionSN\r\n");
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        _main.OutMsg(pgType, row["ApplicSN"].ToString() + "\t" +
                                row["AClass"].ToString() + "\t" +
                                row["ASN"].ToString() + "\t" +
                                row["Applicability"].ToString() + "\t" +
                                row["ModuleSN"].ToString() + "\t" +
                                row["ModuleVersionSN"].ToString() + "\r\n");
                    }
                }
                else
                {
                    _main.OutMsg(pgType, "No result output.\r\n");
                }
            }
        }
        public void DoProcessDupDomainSN()
        {
            if (_main.originalPathForCurrentDB != DBName)
            {
                if (!File.Exists(DBName))
                {
                    _main.OutMsg(pgType, "The db " +
                            DBName + " Does not exist!");

                    return;
                }

                ODBCManager.ChangeODBCDatasource(_main.DSNName, DBName);
            }

            DataSet ds = sybase.GetDataSet(Dup_state_domainsn);

            if (ds.Tables.Count > 0)
            {
                _main.OutMsg(pgType, "Duplicates State Domain SN:\r\n");
                if (ds.Tables[0].Rows.Count > 0)
                {
                    _main.OutMsg(pgType, "StateVersionSN\t StateDomainSN\t ModuleSN\t ModuleVersionSN\t Heading\t ChildOrder\t ParentSN\r\n");
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        _main.OutMsg(pgType, row["StateVersionSN"].ToString() + "\t" +
                                row["StateDomainSN"].ToString() + "\t" +
                                row["ModuleSN"].ToString() + "\t" +
                                row["ModuleVersionSN"].ToString() + "\t" +
                                row["Heading"].ToString() + "\t" +
                                row["ChildOrder"].ToString() + "\t" +
                                row["ParentSN"].ToString() + "\r\n");
                    }
                }
                else
                {
                    _main.OutMsg(pgType, "No result output.\r\n");
                }
            }
        }
        public void DoProcessDupRangeMap()
        {
            if (_main.originalPathForCurrentDB != DBName)
            {
                if (!File.Exists(DBName))
                {
                    _main.OutMsg(pgType, "The db " +
                            DBName + " Does not exist!");

                    return;
                }

                ODBCManager.ChangeODBCDatasource(_main.DSNName, DBName);
            }

            DataSet ds = sybase.GetDataSet(ApplicabilityRangeMap2);

            if (ds.Tables.Count > 0)
            {
                _main.OutMsg(pgType, "Applicability RangeMap:\r\n");
                if (ds.Tables[0].Rows.Count > 0)
                {
                    _main.OutMsg(pgType, "ModuleSN\t Minimum_ApplicSN\t Maximum_ApplicSN\t ApplicSN_Difference\r\n");
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        _main.OutMsg(pgType, row["ModuleSN"].ToString() + "\t" +
                                row["Minimum_ApplicSN"].ToString() + "\t" +
                                row["Maximum_ApplicSN"].ToString() + "\t" +
                                row["ApplicSN_Difference"].ToString() + "\r\n");
                    }
                }
                else
                {
                    _main.OutMsg(pgType, "No result output.\r\n");
                }
            }
        }
        public void DoProcessMissingLink()
        {
            if (_main.originalPathForCurrentDB != DBName)
            {
                if (!File.Exists(DBName))
                {
                    _main.OutMsg(pgType, "The db " +
                            DBName + " Does not exist!");

                    return;
                }

                ODBCManager.ChangeODBCDatasource(_main.DSNName, DBName);
            }

            DataSet ds = sybase.GetDataSet(MissingLink);

            if (ds.Tables.Count > 0)
            {
                _main.OutMsg(pgType, "Missing Link:\r\n");
                if (ds.Tables[0].Rows.Count > 0)
                {
                    _main.OutMsg(pgType, "QuestionSN\t LinkText\t LinkSN\t LinkType\t VarSN\t ModuleSN\t " +
                               "ChildP\t ModuleVersionSN\t QuestionBodySN\t StdText\t NoteText\t ListAnswer\t DataType\t Properties\r\n");
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        _main.OutMsg(pgType, row["aw_Hyperlink.QuestionSN"].ToString() + "\t" +
                                row["aw_Hyperlink.LinkText"].ToString() + "\t" +
                                row["aw_Hyperlink.LinkSN"].ToString() + "\t" +
                                row["aw_Hyperlink.LinkType"].ToString() + "\t" +
                                row["aw_Hyperlink.VarSN"].ToString() + "\t" +
                                row["aw_Hyperlink.ModuleSN"].ToString() + "\t" +
                                row["aw_Hyperlink.ChildP"].ToString() + "\t" +
                                row["aw_Hyperlink.ModuleVersionSN"].ToString() + "\t" +
                                row["QuestionBody.QuestionBodySN"].ToString() + "\t" +
                                row["QuestionBody.StdText"].ToString() + "\t" +
                                row["QuestionBody.NoteText"].ToString() + "\t" +
                                row["QuestionBody.ListAnswer"].ToString() + "\t" +
                                row["QuestionBody.DataType"].ToString() + "\t" +
                                row["QuestionBody.Properties"].ToString() + "\r\n");
                    }
                }
                else
                {
                    _main.OutMsg(pgType, "No result output.\r\n");
                }
            }
        }
        public void DoProcessDupQuestLink()
        {
            if (_main.originalPathForCurrentDB != DBName)
            {
                if (!File.Exists(DBName))
                {
                    _main.OutMsg(pgType, "The db " +
                            DBName + " Does not exist!");

                    return;
                }

                ODBCManager.ChangeODBCDatasource(_main.DSNName, DBName);
            }

            DataSet ds = sybase.GetDataSet(LookForDuplicateQuestionLinkText_1);
            if (ds.Tables.Count > 0)
            {
                sybase.RunSQL(LookForDuplicateQuestionLinkText_2);
            }

            sybase.RunSQL(LookForDuplicateQuestionLinkText_3);
            ds = sybase.GetDataSet(LookForDuplicateQuestionLinkText_4);

            if (ds.Tables.Count > 0)
            {
                _main.OutMsg(pgType, "Duplicates Question Link:\r\n");
                if (ds.Tables[0].Rows.Count > 0)
                {
                    _main.OutMsg(pgType, "LinkSN\t LinkText\t QuestionSN\t StdText\t NoteText\t ListAnswer\r\n");
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        _main.OutMsg(pgType, row["LinkSN"].ToString() + "\t" +
                                row["LinkText"].ToString() + "\t" +
                                row["QuestionSN"].ToString() + "\t" +
                                row["StdText"].ToString() + "\t" +
                                row["NoteText"].ToString() + "\t" +
                                row["ListAnswer"].ToString() + "\r\n");
                    }
                }
                else
                {
                    _main.OutMsg(pgType, "No result output.\r\n");
                }
            }
        }

        private bool CheckForCancel
        {
            get
            {
                return _main.cancelPressed;
            }
        }

        internal string CheckDBName(string FileName, string FolderName)
        {
            if (FileName == string.Empty)
            {
                return string.Empty;
            }

            string ParentDir = Path.GetDirectoryName(FileName);// GetParentPath (ModuleName));

            if (ParentDir != string.Empty)
            {
                if (!Directory.Exists(ParentDir))
                {
                    return string.Empty;
                }
            }
            else
            {
                return Path.Combine(FolderName, FileName);
            }

            return FileName;
        }

    }
}
