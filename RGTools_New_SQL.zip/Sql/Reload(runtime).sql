%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This command file reloads a database that was unloaded using "dbunload".
%
% (version:  5.5.00 Build #1073)
%

SET OPTION Statistics = 3
go
SET OPTION Date_order = 'YMD'
go


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    Create userids and grant user permissions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

GRANT CONNECT TO "DBA" IDENTIFIED BY ENCRYPTED '\xF0\x75\xCE\xF7\x20\xD7\x29\x8E\xAA\x79\xE8\xE5\x91\x69\xA2\x1B\x14\x76\x09\x22\x0A\xD6\xD9\xE4\x4F\xBC\xBA\x0B\xD3\x01\x4D\xFA\x26\xBF\x2E\x04'
go
% GRANT RESOURCE, DBA, SCHEDULE TO "DBA"
% go
GRANT CONNECT TO "DBO"
go
GRANT GROUP TO "DBO"
go
GRANT RESOURCE, DBA TO "DBO"
go
commit work
go


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    Create user-defined types
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

commit work
go


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    Create tables
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

CREATE TABLE "DBA"."Version"
(
	"VersionID"     		char(6) NOT NULL,
	PRIMARY KEY ("VersionID")
)
go
CREATE TABLE "DBA"."Module"
(
	"ModuleSN"      		integer NOT NULL,
	"MasterModuleID"        	smallint NULL DEFAULT 0,
	"MasterGroupID" 		smallint NULL DEFAULT 0,
	"MasterClassID" 		smallint NULL DEFAULT 0,
	"ModuleName"    		char(50) NOT NULL,
	PRIMARY KEY ("ModuleSN")
)
go
CREATE TABLE "DBA"."ModuleVersion"
(
	"ModuleVersionSN"       	smallint NOT NULL,
	"ModuleSN"      		integer NOT NULL,
	"VersionName"   		char(25) NOT NULL,
	"DTRevision"    		timestamp NULL DEFAULT current timestamp,
	"BNAVersionName"        	char(25) NULL,
	"DAResearchDate"        	integer NULL DEFAULT 0,
	"BNAResearchDate"       	integer NULL DEFAULT 0,
	PRIMARY KEY ("ModuleVersionSN", "ModuleSN")
)
go

%CREATE TABLE "DBA"."DomainStructure"
%(
%	"DomainSN"      		integer NOT NULL,
%	"ModuleSN"      		integer NOT NULL,
%	"ModuleVersionSN"       	smallint NOT NULL,
%	"NQuestions"    		integer NULL DEFAULT 0,
%	"SubQuestion"   		char(1) NULL DEFAULT 'N',
%	"Marked"        		char(1) NULL DEFAULT 'N',
%	"ParentSN"      		integer NOT NULL,
%	"ChildOrder"    		integer NOT NULL,
%	"Heading"       		char(80) NULL,
%	PRIMARY KEY ("DomainSN", "ModuleSN", "ModuleVersionSN"),
%	check((SubQuestion in('Y','N')) and
%(Marked in('Y','N')))
%)
%go
%ALTER TABLE "DBA"."DomainStructure" ADD UNIQUE ( "ModuleSN", "ModuleVersionSN", "ParentSN", "ChildOrder"
%)
%go

CREATE TABLE "DBA"."Blob"
(
	"Class" 			smallint NOT NULL,
	"SN"    			integer NOT NULL,
	"ModuleVersionSN"       	smallint NOT NULL,
	"Sequence"      		smallint NOT NULL DEFAULT 0,
	"Blob"  			long binary NULL,
	PRIMARY KEY ("Class", "SN", "ModuleVersionSN", "Sequence")
)
go
CREATE TABLE "DBA"."Question"
(
	"QuestionSN"    		integer NOT NULL,
	"RFValue"       		smallint NULL,
	"RGKeyWordList" 		long varchar NULL,
	"QuestionBodySN"        	integer NULL,
	PRIMARY KEY ("QuestionSN")
)
go

%CREATE TABLE "DBA"."QDLink"
%(
%	"ModuleSN"      		integer NOT NULL,
%	"ModuleVersionSN"       	smallint NOT NULL,
%	"DomainSN"      		integer NOT NULL,
%	"QDOrder"       		integer NOT NULL DEFAULT 1,
%	"QuestionSN"    		integer NOT NULL,
%	"QSSN"  			integer NULL DEFAULT -1,
%	PRIMARY KEY ("ModuleSN", "ModuleVersionSN", "DomainSN", "QDOrder")
%)
%go
%ALTER TABLE "DBA"."QDLink" ADD UNIQUE ( "ModuleSN", "ModuleVersionSN", "DomainSN", "QuestionSN"
%)
%go

%CREATE TABLE "DBA"."QSLink"
%(
%	"ModuleSN"      		integer NOT NULL,
%	"ModuleVersionSN"       	smallint NOT NULL,
%	"QSSN"  			integer NOT NULL,
%	"QSOrder"       		smallint NOT NULL DEFAULT 1,
%	"SubQuestionDomainSN"   	integer NOT NULL,
%	PRIMARY KEY ("ModuleSN", "ModuleVersionSN", "QSSN", "QSOrder")
%)
%go
%ALTER TABLE "DBA"."QSLink" ADD UNIQUE ( "ModuleSN", "ModuleVersionSN", "QSSN", "SubQuestionDomainSN"
%)
%go

%CREATE TABLE "DBA"."ApplicabilityVariable"
%(
%	"ApplicSN"      		integer NOT NULL,
%	"ModuleSN"      		integer NOT NULL,
%	"ModuleVersionSN"       	smallint NOT NULL,
%	"AClass"        		char(1) NULL,
%	"ASN"   			integer NOT NULL,
%	"Applicability" 		char(1) NULL,
%	PRIMARY KEY ("ApplicSN", "ModuleSN", "ModuleVersionSN"),
%	check((AClass in('N','D','I','Q','C','S')) and
%(Applicability in('A','N','U','P')))
%)
%go

CREATE TABLE "DBA"."ScreenGoal"
(
	"ModuleSN"      		integer NOT NULL,
	"ModuleVersionSN"       	smallint NOT NULL,
	"GoalOrder"     		integer NOT NULL,
	"ApplicSN"      		integer NOT NULL,
	PRIMARY KEY ("ModuleSN", "ModuleVersionSN", "GoalOrder")
)
go
%ALTER TABLE "DBA"."ScreenGoal" ADD UNIQUE ( "ModuleSN", "ModuleVersionSN", "ApplicSN"
%)
%go

%CREATE TABLE "DBA"."TemplateRule"
%(
%	"RuleSN"        		integer NOT NULL,
%	"ModuleSN"      		integer NOT NULL,
%	"ModuleVersionSN"       	smallint NOT NULL,
%	"SetSN" 			integer NULL,
%	"Op"    			integer NULL,
%	"CompASN"       		integer NULL,
%	"CompBSN"       		integer NULL,
%	PRIMARY KEY ("RuleSN", "ModuleSN", "ModuleVersionSN"),
%	check(Op in(1,2,3,4,5))
%)
%go

CREATE TABLE "DBA"."RGSection"
(
	"SectionSN"     		integer NOT NULL,
	"ModuleSN"      		integer NULL,
	"Heading"       		char(120) NULL,
	"TextBlock"     		long varchar NULL,
	"TagDate"       		long binary NULL,
	"Sequence"      		integer NULL,
	PRIMARY KEY ("SectionSN")
)
go
CREATE TABLE "DBA"."RGKeyword"
(
	"ReferenceSN"   		integer NOT NULL,
	"KeyWord"       		char(66) NULL,
	"SectionSN"     		integer NULL,
	"PStart"        		integer NULL,
	"ModuleSN"      		integer NULL,
	"TagDate"       		integer NULL DEFAULT 0,
	PRIMARY KEY ("ReferenceSN")
)
go
CREATE TABLE "DBA"."QRLink"
(
	"QuestionSN"    		integer NOT NULL,
	"Sequence"      		integer NOT NULL,
	"ReferenceSN"   		integer NOT NULL,
	PRIMARY KEY ("QuestionSN", "Sequence")
)
go
%ALTER TABLE "DBA"."QRLink" ADD UNIQUE ( "QuestionSN", "ReferenceSN"
%)
%go
CREATE TABLE "DBA"."RGTOC"
(
	"ModuleSN"      		integer NOT NULL,
	"Sequence"      		integer NOT NULL,
	"SectionSN"     		integer NOT NULL,
	"Depth" 			smallint NULL,
	"HeadingNo"     		char(10) NULL,
	"HeadingText"   		char(110) NULL,
	"TagDate"       		integer NULL DEFAULT 0,
	"PStart"        		integer NULL DEFAULT 0,
	PRIMARY KEY ("ModuleSN", "Sequence")
)
go
CREATE TABLE "DBA"."State"
(
	"StateSN"       		smallint NOT NULL,
	"StateName"     		char(25) NOT NULL DEFAULT ' ',
	"PostalCode"    		char(2) NOT NULL DEFAULT ' ',
	"MasterModuleID"        	smallint NULL DEFAULT 0,
	"MasterGroupID" 		smallint NULL DEFAULT 0,
	"MasterClassID" 		smallint NULL DEFAULT 0,
	PRIMARY KEY ("StateSN")
)
go
CREATE TABLE "DBA"."StateVersion"
(
	"StateVersionSN"        	smallint NOT NULL,
	"VersionName"   		char(25) NULL,
	"DTRevision"    		timestamp NULL DEFAULT current timestamp,
	PRIMARY KEY ("StateVersionSN")
)
go
CREATE TABLE "DBA"."SDVLink"
(
	"StateVersionSN"        	smallint NOT NULL,
	"StateDomainSN" 		integer NOT NULL,
	PRIMARY KEY ("StateVersionSN", "StateDomainSN")
)
go
CREATE TABLE "DBA"."StateDomainStructure"
(
	"StateVersionSN"        	smallint NOT NULL,
	"StateDomainSN" 		integer NOT NULL,
	"ModuleSN"      		integer NOT NULL,
	"ModuleVersionSN"       	smallint NOT NULL,
	"ChildOrder"    		integer NOT NULL,
	"ParentSN"      		integer NOT NULL,
	"Heading"       		char(80) NULL,
	PRIMARY KEY ("StateVersionSN", "StateDomainSN", "ModuleSN", "ModuleVersionSN")
)
go
%ALTER TABLE "DBA"."StateDomainStructure" ADD UNIQUE ( "StateVersionSN", "ModuleSN", "ModuleVersionSN", "ChildOrder", "ParentSN"
%)
%go
CREATE TABLE "DBA"."QDStateLink"
(
	"StateSN"       		smallint NOT NULL,
	"StateVersionSN"        	smallint NOT NULL,
	"StateDomainSN" 		integer NOT NULL,
	"QDOrder"       		integer NOT NULL,
	"QuestionSN"    		integer NOT NULL,
	PRIMARY KEY ("StateSN", "StateVersionSN", "StateDomainSN", "QDOrder")
)
go
%ALTER TABLE "DBA"."QDStateLink" ADD UNIQUE ( "StateSN", "StateVersionSN", "StateDomainSN", "QuestionSN"
%)
%go
CREATE TABLE "DBA"."QCountState"
(
	"StateSN"       		smallint NOT NULL,
	"StateVersionSN"        	smallint NOT NULL,
	"StateDomainSN" 		integer NOT NULL,
	"QCount"        		smallint NULL,
	"TagDate"       		integer NULL DEFAULT 0,
	PRIMARY KEY ("StateSN", "StateVersionSN", "StateDomainSN")
)
go
CREATE TABLE "DBA"."StateSection"
(
	"StateDomainSN" 		integer NOT NULL,
	"StateSN"       		smallint NOT NULL,
	"SectionSN"     		integer NOT NULL,
	"StateVersionSN"        	smallint NOT NULL,
	"TagDate"       		integer NULL DEFAULT 0,
	PRIMARY KEY ("StateDomainSN", "StateSN", "StateVersionSN")
)
go
CREATE TABLE "DBA"."StateModule"
(
	"ModuleSN"      		integer NOT NULL,
	"ModuleVersionSN"       	smallint NOT NULL DEFAULT 0,
	"StateVersionSN"        	smallint NOT NULL,
	PRIMARY KEY ("ModuleSN", "ModuleVersionSN", "StateVersionSN")
)
go
CREATE TABLE "DBA"."QuestionBody"
(
	"QuestionBodySN"        	integer NOT NULL,
	"StdText"       		long varchar NULL,
	"NoteText"      		long varchar NULL,
	"ListAnswer"    		long varchar NULL,
	"DataType"      		char(1) NULL,
	"Properties"    		integer NULL DEFAULT 0,
	PRIMARY KEY ("QuestionBodySN")
)
go
CREATE TABLE "DBA"."BlobState"
(
	"Class" 			smallint NOT NULL,
	"StateSN"       		smallint NOT NULL,
	"StateVersionSN"        	smallint NOT NULL DEFAULT 0,
	"ModuleSN"      		integer NOT NULL DEFAULT 0,
	"ModuleVersionSN"       	smallint NOT NULL DEFAULT 0,
	"Sequence"      		smallint NOT NULL DEFAULT 0,
	"Blob"  			long binary NULL,
	PRIMARY KEY ("Class", "StateSN", "StateVersionSN", "ModuleSN", "ModuleVersionSN", "Sequence")
)
go

%CREATE TABLE "DBA"."aw_Hyperlink"
%(
%	"QuestionSN"    		integer NULL,
%	"LinkText"      		varchar(66) NULL,
%	"LinkSN"        		integer NOT NULL,
%	"LinkType"      		char(1) NULL,
%	"VarSN" 			integer NULL,
%	"ModuleSN"      		integer NULL,
%	"ChildP"        		char(1) NULL,
%	"ModuleVersionSN"       	smallint NULL
%)
%go

%CREATE TABLE "DBA"."aw_InfoOnly"
%(
%	"QuestionSN"    		integer NOT NULL,
%	"ReferenceSN"   		integer NOT NULL,
%	"ModuleSN"      		integer NOT NULL,
%	"ModuleVersionSN"       	smallint NOT NULL
%)
%go
commit work
go


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    Reload data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

LOAD TABLE "DBA"."Version"
	FROM 'C:\\TMPRGT\\UNLOAD\\161.dat'
	FORMAT 'ASCII'
	QUOTES ON ESCAPES ON STRIP OFF
	DELIMITED BY ','
go
LOAD TABLE "DBA"."Module"
	FROM 'C:\\TMPRGT\\UNLOAD\\162.dat'
	FORMAT 'ASCII'
	QUOTES ON ESCAPES ON STRIP OFF
	DELIMITED BY ','
go
LOAD TABLE "DBA"."ModuleVersion"
	FROM 'C:\\TMPRGT\\UNLOAD\\163.dat'
	FORMAT 'ASCII'
	QUOTES ON ESCAPES ON STRIP OFF
	DELIMITED BY ','
go
%LOAD TABLE "DBA"."DomainStructure"
%	FROM 'C:\\TMPRGT\\UNLOAD\\164.dat'
%	FORMAT 'ASCII'
%	QUOTES ON ESCAPES ON STRIP OFF
%	DELIMITED BY ','
%go
LOAD TABLE "DBA"."Blob"
	FROM 'C:\\TMPRGT\\UNLOAD\\165.dat'
	FORMAT 'ASCII'
	QUOTES ON ESCAPES ON STRIP OFF
	DELIMITED BY ','
go
LOAD TABLE "DBA"."Question"
	FROM 'C:\\TMPRGT\\UNLOAD\\166.dat'
	FORMAT 'ASCII'
	QUOTES ON ESCAPES ON STRIP OFF
	DELIMITED BY ','
go
%LOAD TABLE "DBA"."QDLink"
%	FROM 'C:\\TMPRGT\\UNLOAD\\167.dat'
%	FORMAT 'ASCII'
%	QUOTES ON ESCAPES ON STRIP OFF
%	DELIMITED BY ','
%go
%LOAD TABLE "DBA"."QSLink"
%	FROM 'C:\\TMPRGT\\UNLOAD\\168.dat'
%	FORMAT 'ASCII'
%	QUOTES ON ESCAPES ON STRIP OFF
%	DELIMITED BY ','
%go
%LOAD TABLE "DBA"."ApplicabilityVariable"
%	FROM 'C:\\TMPRGT\\UNLOAD\\169.dat'
%	FORMAT 'ASCII'
%	QUOTES ON ESCAPES ON STRIP OFF
%	DELIMITED BY ','
%go
LOAD TABLE "DBA"."ScreenGoal"
	FROM 'C:\\TMPRGT\\UNLOAD\\170.dat'
	FORMAT 'ASCII'
	QUOTES ON ESCAPES ON STRIP OFF
	DELIMITED BY ','
go
%LOAD TABLE "DBA"."TemplateRule"
%	FROM 'C:\\TMPRGT\\UNLOAD\\171.dat'
%	FORMAT 'ASCII'
%	QUOTES ON ESCAPES ON STRIP OFF
%	DELIMITED BY ','
%go
LOAD TABLE "DBA"."RGSection"
	FROM 'C:\\TMPRGT\\UNLOAD\\172.dat'
	FORMAT 'ASCII'
	QUOTES ON ESCAPES ON STRIP OFF
	DELIMITED BY ','
go
LOAD TABLE "DBA"."RGKeyword"
	FROM 'C:\\TMPRGT\\UNLOAD\\173.dat'
	FORMAT 'ASCII'
	QUOTES ON ESCAPES ON STRIP OFF
	DELIMITED BY ','
go
LOAD TABLE "DBA"."QRLink"
	FROM 'C:\\TMPRGT\\UNLOAD\\174.dat'
	FORMAT 'ASCII'
	QUOTES ON ESCAPES ON STRIP OFF
	DELIMITED BY ','
go
LOAD TABLE "DBA"."RGTOC"
	FROM 'C:\\TMPRGT\\UNLOAD\\175.dat'
	FORMAT 'ASCII'
	QUOTES ON ESCAPES ON STRIP OFF
	DELIMITED BY ','
go
LOAD TABLE "DBA"."State"
	FROM 'C:\\TMPRGT\\UNLOAD\\176.dat'
	FORMAT 'ASCII'
	QUOTES ON ESCAPES ON STRIP OFF
	DELIMITED BY ','
go
LOAD TABLE "DBA"."StateVersion"
	FROM 'C:\\TMPRGT\\UNLOAD\\177.dat'
	FORMAT 'ASCII'
	QUOTES ON ESCAPES ON STRIP OFF
	DELIMITED BY ','
go
LOAD TABLE "DBA"."SDVLink"
	FROM 'C:\\TMPRGT\\UNLOAD\\178.dat'
	FORMAT 'ASCII'
	QUOTES ON ESCAPES ON STRIP OFF
	DELIMITED BY ','
go
LOAD TABLE "DBA"."StateDomainStructure"
	FROM 'C:\\TMPRGT\\UNLOAD\\179.dat'
	FORMAT 'ASCII'
	QUOTES ON ESCAPES ON STRIP OFF
	DELIMITED BY ','
go
LOAD TABLE "DBA"."QDStateLink"
	FROM 'C:\\TMPRGT\\UNLOAD\\180.dat'
	FORMAT 'ASCII'
	QUOTES ON ESCAPES ON STRIP OFF
	DELIMITED BY ','
go
LOAD TABLE "DBA"."QCountState"
	FROM 'C:\\TMPRGT\\UNLOAD\\181.dat'
	FORMAT 'ASCII'
	QUOTES ON ESCAPES ON STRIP OFF
	DELIMITED BY ','
go
LOAD TABLE "DBA"."StateSection"
	FROM 'C:\\TMPRGT\\UNLOAD\\182.dat'
	FORMAT 'ASCII'
	QUOTES ON ESCAPES ON STRIP OFF
	DELIMITED BY ','
go
LOAD TABLE "DBA"."StateModule"
	FROM 'C:\\TMPRGT\\UNLOAD\\183.dat'
	FORMAT 'ASCII'
	QUOTES ON ESCAPES ON STRIP OFF
	DELIMITED BY ','
go
LOAD TABLE "DBA"."QuestionBody"
	FROM 'C:\\TMPRGT\\UNLOAD\\184.dat'
	FORMAT 'ASCII'
	QUOTES ON ESCAPES ON STRIP OFF
	DELIMITED BY ','
go
LOAD TABLE "DBA"."BlobState"
	FROM 'C:\\TMPRGT\\UNLOAD\\185.dat'
	FORMAT 'ASCII'
	QUOTES ON ESCAPES ON STRIP OFF
	DELIMITED BY ','
go
%LOAD TABLE "DBA"."aw_Hyperlink"
%	FROM 'C:\\TMPRGT\\UNLOAD\\186.dat'
%	FORMAT 'ASCII'
%	QUOTES ON ESCAPES ON STRIP OFF
%	DELIMITED BY ','
%go
%LOAD TABLE "DBA"."aw_InfoOnly"
%	FROM 'C:\\TMPRGT\\UNLOAD\\187.dat'
%	FORMAT 'ASCII'
%	QUOTES ON ESCAPES ON STRIP OFF
%	DELIMITED BY ','
%go
commit work
go


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    Add foreign key definitions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%ALTER TABLE "DBA"."ModuleVersion"
%	ADD FOREIGN KEY "Module" ("ModuleSN") 
%	REFERENCES "DBA"."Module" ("ModuleSN")
%go

%ALTER TABLE "DBA"."DomainStructure"
%	ADD FOREIGN KEY "ModuleVersion" ("ModuleVersionSN","ModuleSN") 
%	REFERENCES "DBA"."ModuleVersion" ("ModuleVersionSN","ModuleSN")
%go

%CREATE INDEX "DomainChild" ON "DBA"."DomainStructure"
%(
%	"ModuleSN" ASC,
%	"ModuleVersionSN" ASC,
%	"ParentSN" ASC,
%	"ChildOrder" ASC
%)
%go

ALTER TABLE "DBA"."Question"
	ADD FOREIGN KEY "QuestionBody" ("QuestionBodySN") 
	REFERENCES "DBA"."QuestionBody" ("QuestionBodySN")
go

%ALTER TABLE "DBA"."QDLink"
%	ADD FOREIGN KEY "Question" ("QuestionSN") 
%	REFERENCES "DBA"."Question" ("QuestionSN")
%go

%ALTER TABLE "DBA"."QDLink"
%	ADD FOREIGN KEY "DomainStructure" ("DomainSN","ModuleSN","ModuleVersionSN") 
%	REFERENCES "DBA"."DomainStructure" ("DomainSN","ModuleSN","ModuleVersionSN")
%go

%CREATE INDEX "DomainQuestion" ON "DBA"."QDLink"
%(
%	"ModuleSN" ASC,
%	"ModuleVersionSN" ASC,
%	"QuestionSN" ASC
%)
%go

%ALTER TABLE "DBA"."QSLink"
%	ADD FOREIGN KEY "DomainStructure" ("SubQuestionDomainSN","ModuleSN","ModuleVersionSN") 
%	REFERENCES "DBA"."DomainStructure" ("DomainSN","ModuleSN","ModuleVersionSN")
%go

%ALTER TABLE "DBA"."ApplicabilityVariable"
%	ADD FOREIGN KEY "ModuleVersion" ("ModuleVersionSN","ModuleSN") 
%	REFERENCES "DBA"."ModuleVersion" ("ModuleVersionSN","ModuleSN")
%go

%ALTER TABLE "DBA"."ScreenGoal"
%	ADD FOREIGN KEY "ApplicabilityVariable" ("ApplicSN","ModuleSN","ModuleVersionSN") 
%	REFERENCES "DBA"."ApplicabilityVariable" ("ApplicSN","ModuleSN","ModuleVersionSN")
%go

%ALTER TABLE "DBA"."ScreenGoal"
%	ADD FOREIGN KEY "ModuleVersion" ("ModuleVersionSN","ModuleSN") 
%	REFERENCES "DBA"."ModuleVersion" ("ModuleVersionSN","ModuleSN")
%go

%ALTER TABLE "DBA"."TemplateRule"
%	ADD FOREIGN KEY "ModuleVersion" ("ModuleVersionSN","ModuleSN") 
%	REFERENCES "DBA"."ModuleVersion" ("ModuleVersionSN","ModuleSN")
%go

CREATE INDEX "RGSectionSequence" ON "DBA"."RGSection"
(
	"Sequence" ASC
)
go

%ALTER TABLE "DBA"."RGKeyword"
%	ADD FOREIGN KEY "Module" ("ModuleSN") 
%	REFERENCES "DBA"."Module" ("ModuleSN")
%go

%ALTER TABLE "DBA"."RGKeyword"
%	ADD FOREIGN KEY "RGSection" ("SectionSN") 
%	REFERENCES "DBA"."RGSection" ("SectionSN")
%go
CREATE INDEX "ModuleRGKeyWord" ON "DBA"."RGKeyword"
(
	"ModuleSN" ASC
)
go

%ALTER TABLE "DBA"."QRLink"
%	ADD FOREIGN KEY "Question" ("QuestionSN") 
%	REFERENCES "DBA"."Question" ("QuestionSN")
%go

ALTER TABLE "DBA"."QRLink"
	ADD FOREIGN KEY "RGKeyword" ("ReferenceSN") 
	REFERENCES "DBA"."RGKeyword" ("ReferenceSN")
go

%ALTER TABLE "DBA"."RGTOC"
%	ADD FOREIGN KEY "Module" ("ModuleSN") 
%	REFERENCES "DBA"."Module" ("ModuleSN")
%go

%ALTER TABLE "DBA"."RGTOC"
%	ADD FOREIGN KEY "RGSection" ("SectionSN") 
%	REFERENCES "DBA"."RGSection" ("SectionSN")
%go

CREATE INDEX "StateAbrName" ON "DBA"."State"
(
	"PostalCode" ASC
)
go

%ALTER TABLE "DBA"."SDVLink"
%	ADD FOREIGN KEY "StateVersion" ("StateVersionSN") 
%	REFERENCES "DBA"."StateVersion" ("StateVersionSN")
%go

%ALTER TABLE "DBA"."StateDomainStructure"
%	ADD FOREIGN KEY "SDVLink" ("StateVersionSN","StateDomainSN") 
%	REFERENCES "DBA"."SDVLink" ("StateVersionSN","StateDomainSN")
%go

%ALTER TABLE "DBA"."StateDomainStructure"
%	ADD FOREIGN KEY "ModuleVersion" ("ModuleVersionSN","ModuleSN") 
%	REFERENCES "DBA"."ModuleVersion" ("ModuleVersionSN","ModuleSN")
%go

%CREATE INDEX "StateModule" ON "DBA"."StateDomainStructure"
%(
%	"StateVersionSN" ASC,
%	"ModuleSN" ASC,
%	"ModuleVersionSN" ASC,
%	"ParentSN" ASC,
%	"ChildOrder" ASC
%)
%go

%ALTER TABLE "DBA"."QDStateLink"
%	ADD FOREIGN KEY "State" ("StateSN") 
%	REFERENCES "DBA"."State" ("StateSN")
%go

%ALTER TABLE "DBA"."QDStateLink"
%	ADD FOREIGN KEY "SDVLink" ("StateVersionSN","StateDomainSN") 
%	REFERENCES "DBA"."SDVLink" ("StateVersionSN","StateDomainSN")
%go

ALTER TABLE "DBA"."QDStateLink"
	ADD FOREIGN KEY "Question" ("QuestionSN") 
	REFERENCES "DBA"."Question" ("QuestionSN")
go
CREATE INDEX "QDStateDomain" ON "DBA"."QDStateLink"
(
	"StateDomainSN" ASC,
	"StateSN" ASC
)
go
CREATE INDEX "QDStateQuestion" ON "DBA"."QDStateLink"
(
	"QuestionSN" ASC
)
go

%ALTER TABLE "DBA"."QCountState"
%	ADD FOREIGN KEY "State" ("StateSN") 
%	REFERENCES "DBA"."State" ("StateSN")
%go

%ALTER TABLE "DBA"."QCountState"
%	ADD FOREIGN KEY "SDVLink" ("StateVersionSN","StateDomainSN") 
%	REFERENCES "DBA"."SDVLink" ("StateVersionSN","StateDomainSN")
%go

ALTER TABLE "DBA"."StateSection"
	ADD FOREIGN KEY "StateVersion" ("StateVersionSN") 
	REFERENCES "DBA"."StateVersion" ("StateVersionSN")
go

ALTER TABLE "DBA"."StateSection"
	ADD FOREIGN KEY "State" ("StateSN") 
	REFERENCES "DBA"."State" ("StateSN")
go

ALTER TABLE "DBA"."StateSection"
	ADD FOREIGN KEY "RGSection" ("SectionSN") 
	REFERENCES "DBA"."RGSection" ("SectionSN")
go

%CREATE INDEX "StateSectionSN" ON "DBA"."StateSection"
%(
%	"SectionSN" ASC
%)
%go

CREATE INDEX "StateSectionI2" ON "DBA"."StateSection"
(
	"StateSN" ASC,
	"SectionSN" ASC
)
go

%ALTER TABLE "DBA"."StateModule"
%	ADD FOREIGN KEY "ModuleVersion" ("ModuleVersionSN","ModuleSN") 
%	REFERENCES "DBA"."ModuleVersion" ("ModuleVersionSN","ModuleSN")
%go

%ALTER TABLE "DBA"."StateModule"
%	ADD FOREIGN KEY "StateVersion" ("StateVersionSN") 
%	REFERENCES "DBA"."StateVersion" ("StateVersionSN")
%go
commit work
go


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    Create functions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

commit work
go


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    Create views
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

commit work
go


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    Set option values
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


SET OPTION Statistics =
go
SET OPTION Date_order =
go


%
%SQL Option Statements for user 
%

SET OPTION "DBA"."Bell" = 'Off'
go


%
%SQL Option Statements for user 
%

SET OPTION "PUBLIC"."Blocking" = 'On'
go
SET OPTION "PUBLIC"."Checkpoint_time" = '60'
go
SET OPTION "PUBLIC"."Conversion_error" = 'On'
go
SET OPTION "PUBLIC"."Timestamp_format" = 'YYYY-MM-DD HH:NN:SS.SSS'
go
SET OPTION "PUBLIC"."Time_format" = 'HH:NN:SS.SSS'
go
SET OPTION "PUBLIC"."Date_format" = 'YYYY-MM-DD'
go
SET OPTION "PUBLIC"."Date_order" = 'YMD'
go
SET OPTION "PUBLIC"."Isolation_level" = '0'
go
SET OPTION "PUBLIC"."Precision" = '30'
go
SET OPTION "PUBLIC"."Recovery_time" = '2'
go
SET OPTION "PUBLIC"."Replicate_all" = 'Off'
go
SET OPTION "PUBLIC"."Row_counts" = 'Off'
go
SET OPTION "PUBLIC"."Scale" = '6'
go
SET OPTION "PUBLIC"."Thread_count" = '0'
go
SET OPTION "PUBLIC"."Wait_for_commit" = 'Off'
go
SET OPTION "PUBLIC"."Quoted_identifier" = 'On'
go
SET OPTION "PUBLIC"."Allow_nulls_by_default" = 'On'
go
SET OPTION "PUBLIC"."Automatic_timestamp" = 'Off'
go
SET OPTION "PUBLIC"."Query_plan_on_open" = 'Off'
go
SET OPTION "PUBLIC"."Cooperative_commits" = 'On'
go
SET OPTION "PUBLIC"."Cooperative_commit_timeout" = '250'
go
SET OPTION "PUBLIC"."Delayed_commits" = 'Off'
go
SET OPTION "PUBLIC"."Delayed_commit_timeout" = '500'
go
SET OPTION "PUBLIC"."Non_keywords" = ''
go
SET OPTION "PUBLIC"."SQL_flagger_error_level" = 'W'
go
SET OPTION "PUBLIC"."SQL_flagger_warning_level" = 'W'
go
SET OPTION "PUBLIC"."ANSI_blanks" = 'Off'
go
SET OPTION "PUBLIC"."String_rtruncation" = 'Off'
go
SET OPTION "PUBLIC"."ANSI_integer_overflow" = 'Off'
go
SET OPTION "PUBLIC"."Ansinull" = 'On'
go
SET OPTION "PUBLIC"."Ansi_permissions" = 'On'
go
SET OPTION "PUBLIC"."Close_on_endtrans" = 'On'
go
SET OPTION "PUBLIC"."Tsql_variables" = 'Off'
go
SET OPTION "PUBLIC"."Division_by_zero_error" = 'On'
go
SET OPTION "PUBLIC"."Ri_trigger_time" = 'After'
go
SET OPTION "PUBLIC"."Tsql_hex_constant" = 'On'
go
SET OPTION "PUBLIC"."Chained" = 'On'
go
SET OPTION "PUBLIC"."Nearest_century" = '0'
go
SET OPTION "PUBLIC"."Auto_commit" = 'Off'
go
SET OPTION "PUBLIC"."Auto_refetch" = 'On'
go
SET OPTION "PUBLIC"."Bell" = 'On'
go
SET OPTION "PUBLIC"."Commit_on_exit" = 'On'
go
SET OPTION "PUBLIC"."Echo" = 'On'
go
SET OPTION "PUBLIC"."Headings" = 'On'
go
SET OPTION "PUBLIC"."Input_format" = 'ASCII'
go
SET OPTION "PUBLIC"."ISQL_log" = ''
go
SET OPTION "PUBLIC"."NULLS" = '(NULL)'
go
SET OPTION "PUBLIC"."On_error" = 'Prompt'
go
SET OPTION "PUBLIC"."Output_format" = 'ASCII'
go
SET OPTION "PUBLIC"."Output_length" = '0'
go
SET OPTION "PUBLIC"."Screen_format" = 'Text'
go
SET OPTION "PUBLIC"."Statistics" = '3'
go
SET OPTION "PUBLIC"."Truncation_length" = '30'
go
SET OPTION "PUBLIC"."Command_delimiter" = ';'
go
SET OPTION "PUBLIC"."Output_nulls" = ''
go
SET OPTION "PUBLIC"."Verify_all_columns" = 'Off'
go
SET OPTION "PUBLIC"."Delete_old_logs" = 'Off'
go
SET OPTION "PUBLIC"."Replication_error" = ''
go
SET OPTION "PUBLIC"."Verify_threshold" = '1000'
go
commit work
go


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    Create SQL remote definitions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

CREATE REMOTE TYPE "FILE" ADDRESS ''
go
CREATE REMOTE TYPE "MAPI" ADDRESS ''
go
CREATE REMOTE TYPE "VIM" ADDRESS ''
go
CREATE REMOTE TYPE "SMTP" ADDRESS ''
go
commit work
go


DROP OPTIMIZER STATISTICS

commit work
go
