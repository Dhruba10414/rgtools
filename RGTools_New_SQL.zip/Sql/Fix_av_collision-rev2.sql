update applicabilityvariable
set applicsn = -applicsn
where applicsn >= 20000
  and modulesn = 11570;
commit;

update templaterule
set setsn = -setsn
where modulesn = 11570
and setsn >= 20000;
commit;

update templaterule
set compasn = -compasn
where modulesn = 11570
and compasn >= 20000;
commit;

update templaterule
set compbsn = -compbsn
where modulesn = 11570
and compbsn >= 20000;
commit;

delete from blob
where (class = 2 or class = 3)
    and SN = 11570
  and (ModuleVersionSN  >= 33);
commit;

update applicabilityvariable
set applicsn = -applicsn
where applicsn >= 50000
  and modulesn = 33778;
commit;

update templaterule
set setsn = -setsn
where modulesn = 33778
and setsn >= 50000;
commit;

update templaterule
set compasn = -compasn
where modulesn = 33778
and compasn >= 50000;
commit;

update templaterule
set compbsn = -compbsn
where modulesn = 33778
and compbsn >= 50000;
commit;

delete from blob
where (class = 2 or class = 3)
    and SN = 33778
  and (ModuleVersionSN  >= 33);
commit;