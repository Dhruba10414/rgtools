select * from StateDomainStructure a1 where exists
 (select *  from DomainStructure a2 where a2.DomainSN = a1.StateDomainSN)  
