SELECT aw_Hyperlink.QuestionSN, aw_Hyperlink.LinkText, aw_Hyperlink.LinkSN, aw_Hyperlink.LinkType, aw_Hyperlink.VarSN, aw_Hyperlink.ModuleSN, aw_Hyperlink.ChildP, aw_Hyperlink.ModuleVersionSN, QuestionBody.QuestionBodySN, QuestionBody.StdText, QuestionBody.NoteText, QuestionBody.ListAnswer, QuestionBody.DataType, QuestionBody.Properties
FROM DBA.aw_Hyperlink aw_Hyperlink, DBA.QuestionBody QuestionBody
WHERE aw_Hyperlink.QuestionSN = QuestionBody.QuestionBodySN 
AND ((QuestionBody.StdText Not Like '%'+aw_HyperLink.LinkText+'%') 
AND (QuestionBody.ListAnswer Not Like '%'+aw_HyperLink.LinkText+'%') 
AND (QuestionBody.NoteText Not Like '%'+aw_HyperLink.LinkText+'%'))