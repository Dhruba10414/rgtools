START ENGINE AS DB1 STARTLINE 'dbstart -b -c 4096K -ga';
START DATABASE 'c:\tmprgt\03_2010_UpdateStd2.db' AS DB1 ON DB1;
CONNECT TO DB1 DATABASE DB1 AS DB1 USER dba IDENTIFIED BY sql;

--UNLOAD table blob TO 'C:\TmpRgt\161.dat'
UNLOAD TABLE "DBA"."Version"
	TO 'C:\\TMPRGT\\161.dat'
go
UNLOAD TABLE "DBA"."Module"
	TO 'C:\\TMPRGT\\162.dat'
go
UNLOAD TABLE "DBA"."ModuleVersion"
	TO 'C:\\TMPRGT\\163.dat'
go
UNLOAD TABLE "DBA"."DomainStructure"
	TO 'C:\\TMPRGT\\164.dat'
go
UNLOAD TABLE "DBA"."Blob"
	TO 'C:\\TMPRGT\\165.dat'
go
UNLOAD TABLE "DBA"."Question"
	TO 'C:\\TMPRGT\\166.dat'
go
UNLOAD TABLE "DBA"."QDLink"
	TO 'C:\\TMPRGT\\167.dat'
go
UNLOAD TABLE "DBA"."QSLink"
	TO 'C:\\TMPRGT\\168.dat'
go
UNLOAD TABLE "DBA"."ApplicabilityVariable"
	TO 'C:\\TMPRGT\\169.dat'
go
UNLOAD TABLE "DBA"."ScreenGoal"
	TO 'C:\\TMPRGT\\170.dat'
go
UNLOAD TABLE "DBA"."TemplateRule"
	TO 'C:\\TMPRGT\\171.dat'
go
UNLOAD TABLE "DBA"."RGSection"
	TO 'C:\\TMPRGT\\172.dat'
go
UNLOAD TABLE "DBA"."RGKeyword"
	TO 'C:\\TMPRGT\\173.dat'
go
UNLOAD TABLE "DBA"."QRLink"
	TO 'C:\\TMPRGT\\174.dat'
go
UNLOAD TABLE "DBA"."RGTOC"
	TO 'C:\\TMPRGT\\175.dat'
go
UNLOAD TABLE "DBA"."State"
	TO 'C:\\TMPRGT\\176.dat'
go
UNLOAD TABLE "DBA"."StateVersion"
	TO 'C:\\TMPRGT\\177.dat'
go
UNLOAD TABLE "DBA"."SDVLink"
	TO 'C:\\TMPRGT\\178.dat'
go
UNLOAD TABLE "DBA"."StateDomainStructure"
	TO 'C:\\TMPRGT\\179.dat'
go
UNLOAD TABLE "DBA"."QDStateLink"
	TO 'C:\\TMPRGT\\180.dat'
go
UNLOAD TABLE "DBA"."QCountState"
	TO 'C:\\TMPRGT\\181.dat'
go
UNLOAD TABLE "DBA"."StateSection"
	TO 'C:\\TMPRGT\\182.dat'
go
UNLOAD TABLE "DBA"."StateModule"
	TO 'C:\\TMPRGT\\183.dat'
go
UNLOAD TABLE "DBA"."QuestionBody"
	TO 'C:\\TMPRGT\\184.dat'
go
UNLOAD TABLE "DBA"."BlobState"
	TO 'C:\\TMPRGT\\185.dat'
go
UNLOAD TABLE "DBA"."aw_Hyperlink"
	TO 'C:\\TMPRGT\\186.dat'
go
UNLOAD TABLE "DBA"."aw_InfoOnly"
	TO 'C:\\TMPRGT\\187.dat'
GO
STOP DATABASE DB1 ON DB1 UNCONDITIONALLY;
