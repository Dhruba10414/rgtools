select * from applicabilityvariable a1 where exists (select * from applicabilityvariable a2 where a2.applicsn = a1.applicsn and a2.modulesn <> a1.modulesn) order by modulesn




