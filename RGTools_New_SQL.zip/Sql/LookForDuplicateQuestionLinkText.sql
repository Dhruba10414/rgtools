--Query to find multiple instances of link text in a question

--Run this query on a module and it will list the LinkSN, LinkText, QuestionSN and fields for the question where it found duplicates.

--It does not differentiate based on Case, so there may be cases where it will show a duplicate, but due to a difference in case,

--There really is not a duplicate.

--Written By Brooks Pollock

-- 4/28/2005

if exists (select * from sysobjects where id = object_id('UniqueLinkView') )

drop view UniqueLinkView

CREATE VIEW UniqueLinkView AS SELECT DISTINCT QuestionSN, LinkSN, LinkText From aw_Hyperlink

GO

SELECT UniqueLinkView.LinkSN, UniqueLinkView.LinkText, UniqueLinkView.QuestionSN, 

QuestionBody.StdText, QuestionBody.NoteText, QuestionBody.ListAnswer 

 FROM Question, QuestionBody, UniqueLinkView

WHERE Question.QuestionBodySN = QuestionBody.QuestionBodySN

AND UniqueLinkView.QuestionSN = Question.QuestionSN

AND CAST(QuestionBody.StdText AS varchar(8000))  + CAST(QuestionBody.NoteText AS varchar(8000))  + CAST(QuestionBody.ListAnswer AS varchar(8000)) 

	LIKE ('%' + UniqueLinkView.LinkText  + '%' +  UniqueLinkView.LinkText  + '%')




