update applicabilityvariable
set applicsn = -applicsn
where applicsn >= 20000
  and modulesn = 11570
  and (moduleversionSN = 0 or moduleversionSN >=105);

commit;

update templaterule
set setsn = -setsn
where modulesn = 11570
and setsn >= 20000
and (moduleversionSN = 0 or moduleversionSN >=105);

commit;

update templaterule
set compasn = -compasn
where modulesn = 11570
and compasn >= 20000
and (moduleversionSN = 0 or moduleversionSN >=105);
commit;

update templaterule
set compbsn = -compbsn
where modulesn = 11570
and compbsn >= 20000
and (moduleversionSN = 0 or moduleversionSN >=105);
commit;

delete from blob
where (class = 2 or class = 3)
    and SN = 11570
  and (moduleversionSN = 0 or moduleversionSN >=105);
commit;

update applicabilityvariable
set applicsn = -applicsn  - 800000
where applicsn >= 50000
  and modulesn = 33778
  and (moduleversionSN = 0 or moduleversionSN >=105);
commit;

update templaterule
set setsn = -setsn - 800000
where modulesn = 33778
and setsn >= 50000
and (moduleversionSN = 0 or moduleversionSN >=105);
commit;

update templaterule
set compasn = -compasn - 800000
where modulesn = 33778 
and compasn >= 50000
and (moduleversionSN = 0 or moduleversionSN >=105);
commit;

update templaterule
set compbsn = -compbsn - 800000
where modulesn = 33778
and compbsn >= 50000
and (moduleversionSN = 0 or moduleversionSN >=105);
commit;

delete from blob
where (class = 2 or class = 3)
    and SN = 33778
  and (moduleversionSN >=105);
commit;

--Added on Feb 13, 2012
--------------------------------------------
update applicabilityvariable
set applicsn = -applicsn  - 1000000
where applicsn >= 610000 
  and modulesn = 600000
  and (moduleversionSN = 0 or moduleversionSN >=119);
commit;

update templaterule
set setsn = -setsn - 1000000
where modulesn = 600000
and setsn >= 610000
and (moduleversionSN = 0 or moduleversionSN >=119);
commit;

update templaterule
set compasn = -compasn - 1000000
where modulesn = 600000 
and compasn >= 610000
and (moduleversionSN = 0 or moduleversionSN >=119);
commit;

update templaterule
set compbsn = -compbsn - 1000000
where modulesn = 600000
and compbsn >= 610000
and (moduleversionSN = 0 or moduleversionSN >=119);
commit;

delete from blob
where (class = 2 or class = 3)
    and SN = 600000
  and (moduleversionSN >=119);
commit;