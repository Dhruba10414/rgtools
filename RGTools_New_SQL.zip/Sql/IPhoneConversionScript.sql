﻿use DAKREF_IPOD

--DROP TABLE Version 
--DROP TABLE module  
--DROP TABLE DomainStructure 
--DROP TABLE drlink 
--DROP TABLE RGKeyword 
--DROP TABLE RGSection 
--DROP TABLE rgsectionHtml 

--IPhone DB Script
--This script is to create from a blank db the tables needed for the IPhone.
--You create a blank DB where there is a current DAKREF in the same DB engine
--And then execute this.

--Put in Version info
select * into Version
FROM dakref.dbo.Version
GO 

--Add module data for federal modules only
select moduleSN, ModuleName  
INTO module 
from dakref.dbo.module
where MasterClassID = 1
GO

-- Add DomainStructure table
SELECT ds.DomainSN, ds.modulesn, ds.ParentSN, ds.ChildOrder, ds.Heading, ds.DomainPath 
INTO DomainStructure
FROM DAKREF.dbo.DomainStructure AS ds
INNER JOIN Module AS mod
ON mod.ModuleSN = ds.ModuleSN
INNER JOIN dakref.dbo.Version AS ver
ON ver.ModuleVersionSN = ds.ModuleVersionSN
WHERE Subquestion = 'N'
GO

-- DRLink table links domains to all references at that domain and below
-- create domain - reference link table

SELECT DISTINCT qrl.referenceSN, ds.domainSN, ds.ModuleSN, rgk.keyword 
INTO drlink
from dakref.dbo.domainstructure AS ds
Inner Join Module as mod
ON mod.ModuleSN = ds.ModuleSN
Inner Join dakref.dbo.domainstructure AS ds2
ON ds2.ModuleSN = ds.ModuleSN
AND ds2.ModuleVersionSN = ds.ModuleVersionSN
AND ds2.DomainPath LIKE ds.DomainPath + '%'
INNER JOIN dakref.dbo.qdlink AS qdl
ON qdl.DomainSN = ds2.DomainSN
AND qdl.ModuleSN = ds2.ModuleSN
AND qdl.ModuleVersionSN = ds2.ModuleVersionSN
INNER JOIN dakref.dbo.qrlink AS qrl
ON qrl.QuestionSN = qdl.QuestionSN
INNER JOIN dakref.dbo.RGKeyword AS rgk
ON rgk.ReferenceSN = qrl.ReferenceSN
where ds.ModuleVersionSN = 107
--AND ds.DomainSN = 11570
AND ds.SubQuestion = 'N'


order by moduleSN, ds.domainSN, rgk.keyword

Alter Table drlink
Drop Column keyword 

--Add RGKeyword table
select distinct rgk.ReferenceSN, keyword, SectionSN, PStart, rgk.ModuleSN, TagDate 
INTO RGKeyword
from dakref.dbo.rgkeyword as rgk
inner join drlink AS drl
ON drl.referencesn = rgk.referencesn 
and drl.modulesn = rgk.modulesn


-- Add RGSection Table
-- Can't use distinct with a text block so you have to add that later

select distinct rgs.SectionSN, rgs.ModuleSN, rgs.Heading,  rgs.Sequence 
INTO RGSection
from dakref.dbo.rgsection AS rgs
inner join RGKeyword AS rgk
ON rgk.moduleSN = rgs.modulesn
and rgk.SectionSN = rgk.SectionSN 
--Add RGSection Table
Alter Table RGSection
	ADD TEXTBLOCK TEXT NULL;

--Add the TextBlock
UPDATE RGSection
SET TextBlock = rgs.TextBlock
FROM RGSection AS rg1
INNER JOIN dakref.dbo.RGSection AS rgs
ON rgs.SectionSN = rg1.SectionSN
AND rgs.ModuleSN = rg1.ModuleSN

--select * --into rgsectionHtml
--FROM bw1.dbo.rgsectionHtml
--GO 
