SELECT ModuleSN, MIN(ApplicSN) AS Minimum_ApplicSN, MAX(ApplicSN) AS Maximum_ApplicSN , MAX(ApplicSN) - Min(ApplicSN) AS ApplicSN_Difference
FROM applicabilityvariable
Group BY ModuleSN
Order By ModuleSN