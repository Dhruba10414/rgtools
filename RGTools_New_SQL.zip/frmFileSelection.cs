using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using System.Windows; 

namespace RGTools_New
{
    public partial class frmFileSelection : Form
    {
        DataAccess access = new DataAccess();
        private List<FolderSelStatus> _colFiles;
        private string _path = string.Empty;
        private bool isDirty = false;

        public frmFileSelection()
        {
            InitializeComponent();
            SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
            
            // setup DoubleBuffering for the CheckedListBox
            var prop = typeof(Control).GetProperty(nameof(DoubleBuffered),
                BindingFlags.Instance | BindingFlags.NonPublic);
            prop?.SetValue(checkedListBox1, true, null);
        }

        public List<FolderSelStatus> CollectionFiles
        {
            set
            {
                _colFiles = value;

                //_colFiles[0].Selected = true;
            }
            get
            {
                return _colFiles;
            }
        }
        public string DirPath
        {
            get
            {
                return _path;
            }
            set
            {
                _path = value;
            }
        }
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            access.SetDirStatus(_path, _colFiles);
            checkedListBox1.Items.Clear();

            for (var i = 0; i < _colFiles.Count; i++)
            {
                checkedListBox1.Items.Add(_colFiles[i].FolderName, _colFiles[i].Selected);
            }
        }


        private void saveStatus()
        {
            for (var i = 0; i < checkedListBox1.Items.Count; ++i)
                _colFiles[i].Selected = checkedListBox1.GetItemChecked(i);

        }

        private void btnSelAll_Click(object sender, EventArgs e)
        {
            for (var i = 0; i < checkedListBox1.Items.Count; ++i)
                checkedListBox1.SetItemChecked(i, true);
            
            isDirty = true;
        }

        private void btnUnSel_Click(object sender, EventArgs e)
        {
            for (var i = 0; i < checkedListBox1.Items.Count; ++i)
                checkedListBox1.SetItemChecked(i, false);

            isDirty = true;
        }

        internal void btnOk_Click(object sender, EventArgs e)
        {
            saveStatus();

            if (isDirty)
            {
                access.SaveDirStatus(_path, _colFiles);
            }

            this.Close();
        }

        internal void setStatus(List<ModuleListItem> lstModItems)
        {
            for (var i = 0; i < checkedListBox1.Items.Count; ++i)
            {
                var shouldCheck = false;

                long moduleSN;
                try
                {
                    var path = (string)checkedListBox1.Items[i];
                    moduleSN = MODULE.GetModuleSN(path);
                }
                catch
                {
                    continue;
                }

                foreach (var lstItem in lstModItems)
                {
                    if (moduleSN == lstItem.ModuleSN)
                    {
                        shouldCheck = true;
                        break;
                    }
                }

                checkedListBox1.SetItemChecked(i, shouldCheck);
                _colFiles[i].Selected = shouldCheck;
            }

        }


        private void checkedListBox1_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            isDirty = true;
        }

        private void frmFileSelection_FormClosed(object sender, FormClosedEventArgs e)
        {
            isDirty = false;
            checkedListBox1.Items.Clear();
        }
    }
}