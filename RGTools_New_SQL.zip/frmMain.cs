using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Odbc;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Configuration;
using System.Threading;
using System.Runtime.InteropServices;
using System.Collections;
using DbAccess;
using Converter;
using System.Globalization;
using System.Data.OleDb;
using System.Reflection;

namespace RGTools_New
{
    enum PageType
    {
        BuildREM,
        BuildMODULE,
        BlobsCreation,
        MergeFederal,
        MergeState,
        ModuleDeletion,
        DeleteState,
        MergeFederalMaster,
        MergeFederalModule,
        Log,
        AutoProcess,
        Dakref,
        DakrefSource,
        DakrefTaget,
        VewDB,
        IPone,
        Configuration,
        ConfigBackup,
        ConfigRestore,
        ImportExport,
        Import,
        Export,
        DBCheck,
        Upload,
        All
    }
    internal enum ProcessStatus { Done, Failed, Exit };
    public enum EnumSQLError
    {
        DB_NOERROR = 1,  // No error.
        DB_NOTFOUND,     // Query returns no record selected (may be normal situation).
        DB_MULTIPLEROW
    }
    delegate void MessageCallBack(string text, string caption, MessageBoxButtons Buttons, MessageBoxIcon Icon);

    public partial class frmMain : Form
    {
        internal DialogResult dResult = DialogResult.Abort;
        internal ProcessStatus processStatus = ProcessStatus.Done;    //for processing
        const int EM_LINESCROLL = 0x00B6;
        [DllImport("user32.dll")]
        static extern int SetScrollPos(IntPtr hWnd, int nBar, int nPos, bool bRedraw);
        [DllImport("user32.dll")]
        static extern int SendMessage(IntPtr hWnd, int wMsg, int wParam, int lParam);

        private List<FolderSelStatus> colFiles = new List<FolderSelStatus>();
        private bool pathChanged = false;

        private StringBuilder sbOut = new StringBuilder();

        internal TRGToolsSheet toolSheet = new TRGToolsSheet();

        internal bool isProcessing = false;

        internal string SQLUser;// = ConfigurationManager.AppSettings["SQLUser"];
        internal string SQLPW;// = ConfigurationManager.AppSettings["SQLPW"];
        internal string SQLServer;// = ConfigurationManager.AppSettings["SQLServer"];
        internal string SQLDB;//= ConfigurationManager.AppSettings["SQLDB"];

        internal string ModuleUser = "";
        internal string ModulePW = "";

        internal string BlobUser = "";
        internal string BlobPW = "";

        internal string MergeSTUser = "";
        internal string MergeSTPW = "";

        internal string MergeFMMasterUser = "";
        internal string MergeFMMasterPW = "";

        internal string MergeFMModuleUser = "";
        internal string MergeFMModulePW = "";


        internal string DelStateUser = "";
        internal string DelStatePW = "";

        internal string DelModuleUser = "";
        internal string DelModulePW = "";

        internal string ImportUser = "";
        internal string ImportPW = "";

        internal string ExportUser = "";
        internal string ExportPW = "";

        internal string IPhoneUser = "";
        internal string IPhonePW = "";

        internal string ViewDBUser = "";
        internal string ViewDBPW = "";

        internal string DakrefSrcDBUser = "";
        internal string DakrefSrcDBPW = "";

        internal string DakrefTagDBUser = "";
        internal string DakrefTagDBPW = "";

        internal string ExcelTagDBUser = "";
        internal string ExcelTagDBPW = "";

        internal string ConfigBakDBUser = "";
        internal string ConfigBakDBPW = "";

        internal string ConfigResDBUser = "";
        internal string ConfigResDBPW = "";

        internal bool SQLIntegrated
        {
            get
            {
                return (SQLUser == "") ? true : false;
            }
        }

        private bool initializing = false;

        public frmMain()
        {
            InitializeComponent();

            initializing = true;

            this.txtBuildREMDir.Text = ConfigurationManager.AppSettings["SourceTextDirectory"];
            this.txtModuleDir.Text = ConfigurationManager.AppSettings["ModuleRootDirectory"];
            this.txtDelStDB.Text = ConfigurationManager.AppSettings["DelStateDirectory"];

            this.txtMergeSTSateRoot.Text = ConfigurationManager.AppSettings["MergeState_StateRootDir"];
            this.txtMergeSTModuleRoot.Text = ConfigurationManager.AppSettings["MergeState_ModuleRootDir"];

            this.txtMergeFMMasterServer.Text = ConfigurationManager.AppSettings["MergeFederalMasterServer"];
            this.txtMergeFMMasterDB.Text = ConfigurationManager.AppSettings["MergeFederalMasterDB"];
            MergeFMMasterUser = (ConfigurationManager.AppSettings["MergeFederalMasterUser"] != null) ?
                    ConfigurationManager.AppSettings["MergeFederalMasterUser"] : "";
            MergeFMMasterPW = (ConfigurationManager.AppSettings["MergeFederalMasterPW"] != null) ?
                    ConfigurationManager.AppSettings["MergeFederalMasterPW"] : "";

            this.txtMergeFMModuleServer.Text = ConfigurationManager.AppSettings["MergeFederalModuleServer"];
            this.txtMergeFMModuleDB.Text = ConfigurationManager.AppSettings["MergeFederalModuleDB"];
            MergeFMModuleUser = (ConfigurationManager.AppSettings["MergeFederalModuleUser"] != null) ?
                    ConfigurationManager.AppSettings["MergeFederalModuleUser"] : "";
            MergeFMModulePW = (ConfigurationManager.AppSettings["MergeFederalModulePW"] != null) ?
                    ConfigurationManager.AppSettings["MergeFederalModulePW"] : "";

            this.txtBlobsDB.Text = ConfigurationManager.AppSettings["BlobsCreationDB"];


            this.txtIPhoneREMDir.Text = ConfigurationManager.AppSettings["IPhoneSourceDirectory"];
            this.txtSQLitePath.Text = ConfigurationManager.AppSettings["IPhoneSQLLitePath"];

            this.txtIPhoneServer.Text = ConfigurationManager.AppSettings["IPhoneServer"];
            this.txtIPhoneDB.Text = ConfigurationManager.AppSettings["IPhoneDB"];
            IPhoneUser = (ConfigurationManager.AppSettings["IPhoneDBUser"] != null) ?
                    ConfigurationManager.AppSettings["IPhoneDBUser"] : "";
            IPhonePW = (ConfigurationManager.AppSettings["IPhoneDBPW"] != null) ?
                    ConfigurationManager.AppSettings["IPhoneDBPW"] : "";

            this.txtImServer.Text = ConfigurationManager.AppSettings["ImportServer"];
            this.txtImDB.Text = ConfigurationManager.AppSettings["ImportDB"];
            ImportUser = (ConfigurationManager.AppSettings["ImportDBUser"] != null) ?
                       ConfigurationManager.AppSettings["ImportDBUser"] : "";
            ImportPW = (ConfigurationManager.AppSettings["ImportDBPW"] != null) ?
                      ConfigurationManager.AppSettings["ImportDBPW"] : "";
            this.txtImDataPath.Text = ConfigurationManager.AppSettings["ImprtDatDirectory"];

            this.txtExServer.Text = ConfigurationManager.AppSettings["ExportServer"];
            this.txtExDB.Text = ConfigurationManager.AppSettings["ExportDB"];
            ExportUser = (ConfigurationManager.AppSettings["ExportDBUser"] != null) ?
                       ConfigurationManager.AppSettings["ExportDBUser"] : "";
            ExportPW = (ConfigurationManager.AppSettings["ExportDBPW"] != null) ?
                      ConfigurationManager.AppSettings["ExportDBPW"] : "";
            this.txtExDataPath.Text = ConfigurationManager.AppSettings["ExprtDatDirectory"];

            this.txtModuleServer.Text = ConfigurationManager.AppSettings["BuldModuleServer"];
            this.txtModuleDB.Text = ConfigurationManager.AppSettings["BuldModuleDB"];
            ModuleUser = (ConfigurationManager.AppSettings["BuldModuleDBUser"] != null) ?
                       ConfigurationManager.AppSettings["BuldModuleDBUser"] : "";
            ModulePW = (ConfigurationManager.AppSettings["BuldModuleDBPW"] != null) ?
                      ConfigurationManager.AppSettings["BuldModuleDBPW"] : "";


            this.txtDelModServer.Text = ConfigurationManager.AppSettings["DelModuleServer"];
            this.txtDelModDB.Text = ConfigurationManager.AppSettings["DelModuleDB"];
            DelModuleUser = (ConfigurationManager.AppSettings["DelModuleDBUser"] != null) ?
                       ConfigurationManager.AppSettings["DelModuleDBUser"] : "";
            DelModulePW = (ConfigurationManager.AppSettings["DelModuleDBPW"] != null) ?
                      ConfigurationManager.AppSettings["DelModuleDBPW"] : "";

            this.txtDelStServer.Text = ConfigurationManager.AppSettings["DelStateServer"];
            this.txtDelStDB.Text = ConfigurationManager.AppSettings["DelStateDB"];
            DelStateUser = (ConfigurationManager.AppSettings["DelStateDBUser"] != null) ?
                        ConfigurationManager.AppSettings["DelStateDBUser"] : "";
            DelStatePW = (ConfigurationManager.AppSettings["DelStateDBPW"] != null) ?
                        ConfigurationManager.AppSettings["DelStateDBPW"] : "";

            this.txtMergeSTServer.Text = ConfigurationManager.AppSettings["MergeStateServer"];
            this.txtMergeSTDB.Text = ConfigurationManager.AppSettings["MergeStateDB"];
            MergeSTUser = (ConfigurationManager.AppSettings["MergeStateDBUser"] != null) ?
                         ConfigurationManager.AppSettings["MergeStateDBUser"] : "";
            MergeSTPW = (ConfigurationManager.AppSettings["MergeStateDBPW"] != null) ?
                         ConfigurationManager.AppSettings["MergeStateDBPW"] : "";

            this.txtBlobsServer.Text = ConfigurationManager.AppSettings["MergeStateServer"];
            this.txtBlobsDB.Text = ConfigurationManager.AppSettings["MergeStateDB"];
            BlobUser = (ConfigurationManager.AppSettings["MergeStateDBUser"] != null) ?
                           ConfigurationManager.AppSettings["MergeStateDBUser"] : "";
            BlobPW = (ConfigurationManager.AppSettings["MergeStateDBPW"] != null) ?
                          ConfigurationManager.AppSettings["MergeStateDBPW"] : "";

            this.txtVewDBServer.Text = ConfigurationManager.AppSettings["ViewDBServer"];
            this.txtVewDBDB.Text = ConfigurationManager.AppSettings["ViewDBDB"];
            ViewDBUser = (ConfigurationManager.AppSettings["ViewDBUser"] != null) ?
                             ConfigurationManager.AppSettings["ViewDBUser"] : "";
            ViewDBPW = (ConfigurationManager.AppSettings["ViewDBPW"] != null) ?
                             ConfigurationManager.AppSettings["ViewDBPW"] : "";

            this.txtDakrefSrcServer.Text = ConfigurationManager.AppSettings["DakrefSrcDBServer"];
            this.txtDakrefSrcDB.Text = ConfigurationManager.AppSettings["DakrefSrcDB"];
            DakrefSrcDBUser = (ConfigurationManager.AppSettings["DakrefSrcDBUser"] != null) ?
                             ConfigurationManager.AppSettings["DakrefSrcDBUser"] : "";
            DakrefSrcDBPW = (ConfigurationManager.AppSettings["DakrefSrcDBPW"] != null) ?
                             ConfigurationManager.AppSettings["DakrefSrcDBPW"] : "";

            this.txtDakrefTagServer.Text = ConfigurationManager.AppSettings["DakrefTagDBServer"];
            this.txtDakrefTagDB.Text = ConfigurationManager.AppSettings["DakrefTagDB"];
            DakrefTagDBUser = (ConfigurationManager.AppSettings["DakrefTagDBUser"] != null) ?
                             ConfigurationManager.AppSettings["DakrefTagDBUser"] : "";
            DakrefTagDBPW = (ConfigurationManager.AppSettings["DakrefTagDBPW"] != null) ?
                             ConfigurationManager.AppSettings["DakrefTagDBPW"] : "";

            this.txtConfigResServerName.Text = ConfigurationManager.AppSettings["ConfigResDBServer"];
            this.txtConfigResDBName.Text = ConfigurationManager.AppSettings["ConfigResDB"];
            ConfigResDBUser = (ConfigurationManager.AppSettings["ConfigResDBUser"] != null) ?
                             ConfigurationManager.AppSettings["ConfigResDBUser"] : "";
            ConfigResDBPW = (ConfigurationManager.AppSettings["ConfigResDBPW"] != null) ?
                             ConfigurationManager.AppSettings["ConfigResDBPW"] : "";

            this.txtConfigBakServerName.Text = ConfigurationManager.AppSettings["ConfigBakDBServer"];
            this.txtConfigBakDBName.Text = ConfigurationManager.AppSettings["ConfigBakDB"];
            ConfigBakDBUser = (ConfigurationManager.AppSettings["ConfigBakDBUser"] != null) ?
                             ConfigurationManager.AppSettings["ConfigBakDBUser"] : "";
            ConfigBakDBPW = (ConfigurationManager.AppSettings["ConfigBakDBPW"] != null) ?
                             ConfigurationManager.AppSettings["ConfigBakDBPW"] : "";

            this.txtDakrefBack.Text = ConfigurationManager.AppSettings["DakrefBakPath"];
            this.txtConfigBakPath.Text = ConfigurationManager.AppSettings["ConfigBakPath"];
            this.txtConfigResPath.Text = ConfigurationManager.AppSettings["ConfigResPath"];

            if (txtModuleServer.Text.Trim() == "")
            {
                txtModuleServer.Text = SQLServer;
            }
            if (txtModuleDB.Text.Trim() == "")
            {
                txtModuleDB.Text = SQLDB;
            }

            this.txtDakrefWhatNew.Text = ConfigurationManager.AppSettings["DakrefWhatsnewPath"];
            this.txtDakrefMigration.Text = ConfigurationManager.AppSettings["DakrefMigrationPath"];
            this.txtDakrefModuleOrder.Text = ConfigurationManager.AppSettings["DakrefModuleOrderPath"];

            //this.txtExcelTagServer.Text = ConfigurationManager.AppSettings["ExcelTagDBServer"];
            //this.txtExcelTagDB.Text = ConfigurationManager.AppSettings["ExcelTagDB"];
            ExcelTagDBUser = (ConfigurationManager.AppSettings["ExcelTagDBUser"] != null) ?
                 ConfigurationManager.AppSettings["ExcelTagDBUser"] : "";
            ExcelTagDBPW = (ConfigurationManager.AppSettings["ExcelTagDBPW"] != null) ?
                             ConfigurationManager.AppSettings["ExcelTagDBPW"] : "";
            //this.txtExcelRetiredQues.Text = ConfigurationManager.AppSettings["ExcelRequiredQuestPath"];

            lblConfigBakMsg.Text = "";
            lblConfigResMsg.Text = "";

            InitConfiguration();

            initializing = false;

            txtIPhoneREMDir_TextChanged(this, null);

            //ChkIntegratedCheckedChanged(null, null);

            chkLstBox.CheckOnClick = true;

            //SQLUser = (ConfigurationManager.AppSettings["SQLUser"] != null) ? ConfigurationManager.AppSettings["SQLUser"] : "";
            //SQLPW = (ConfigurationManager.AppSettings["SQLPW"] != null) ? ConfigurationManager.AppSettings["SQLPW"] : "";
            //SQLServer = (ConfigurationManager.AppSettings["SQLServer"] != null) ? ConfigurationManager.AppSettings["SQLServer"] : "";
            //SQLDB = (ConfigurationManager.AppSettings["SQLDB"] != null) ? ConfigurationManager.AppSettings["SQLDB"] : "";

            //tabControl.SelectedTab = tpPgIPhoneDB;

        }

        private void brnBrowse_Click(object sender, EventArgs e)
        {
            if (isProcessing)
            {
                return;
            }

            FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
            folderBrowserDialog.RootFolder = Environment.SpecialFolder.MyComputer;
            folderBrowserDialog.ShowNewFolderButton = false;

            folderBrowserDialog.SelectedPath = this.txtBuildREMDir.Text;
            DialogResult result = folderBrowserDialog.ShowDialog(this);
            if (result == DialogResult.OK)
            {
                this.txtBuildREMDir.Text = folderBrowserDialog.SelectedPath;

                selDirectories();
            }

            if (Directory.Exists(this.txtBuildREMDir.Text))
            {
                lblMsg.Text = string.Empty;
            }
            else
            {
                lblMsg.Text = "Invalid Directory!";
            }
        }

        private void selDirectories(string path)
        {
            lblMsg.Text = string.Empty;
            //lblAutoMsg.Text = string.Empty; 
            if (Directory.Exists(path))
            {
                pathChanged = true;
                if (pathChanged || colFiles.Count == 0)
                {
                    string[] dirs = Directory.GetDirectories(path, toolSheet.DirBeginWith + "*");
                    colFiles.Clear();

                    foreach (string str in dirs)
                    {
                        FolderSelStatus status = new FolderSelStatus(str);
                        colFiles.Add(status);
                    }

                    pathChanged = false;
                }
                frmFileSelection _frmSel = new frmFileSelection();

                _frmSel.CollectionFiles = colFiles;
                _frmSel.DirPath = path;
                _frmSel.ShowDialog(this);
                _frmSel.Dispose();
            }
            else
            {
                lblMsg.Text = "Invalid Directory!";
                //lblAutoMsg.Text = "Invalid Directory!";
            }
        }
        private void selDirectories()
        {
            DataAccess access = new DataAccess();
            string path = txtBuildREMDir.Text;
            lblMsg.Text = string.Empty;

            if (Directory.Exists(path))
            {
                string[] dirs = Directory.GetDirectories(path, toolSheet.DirBeginWith + "*");
                colFiles.Clear();

                foreach (string str in dirs)
                {
                    FolderSelStatus status = new FolderSelStatus(str);
                    colFiles.Add(status);
                }

                access.SetDirStatus(path, colFiles);
                SaveConfig("SourceTextDirectory", path);
            }
            else
            {
                lblMsg.Text = "Invalid Directory!";
            }
        }
        private void selDirectoriesIPhone(string path)
        {
            lblMsg.Text = string.Empty;
            //lblAutoMsg.Text = string.Empty; 
            if (Directory.Exists(path))
            {
                pathChanged = true;
                if (pathChanged || colFiles.Count == 0)
                {
                    string[] dirs = Directory.GetDirectories(path, toolSheet.DirBeginWith + "*");
                    colFiles.Clear();

                    foreach (string str in dirs)
                    {
                        FolderSelStatus status = new FolderSelStatus(str);
                        colFiles.Add(status);
                    }

                    pathChanged = false;
                }
                frmFileSelection _frmSel = new frmFileSelection();

                _frmSel.CollectionFiles = colFiles;
                _frmSel.DirPath = path;
                _frmSel.Show(this);
                _frmSel.setStatus(selPhoneModules);
                _frmSel.btnOk_Click(this, null);
                _frmSel.Dispose();

            }
            else
            {
                lblMsg.Text = "Invalid Directory!";
                //lblAutoMsg.Text = "Invalid Directory!";
            }
        }

        private void btnSel_Click(object sender, EventArgs e)
        {
            selDirectories(txtBuildREMDir.Text);
        }

        private void txtDir_TextChanged(object sender, EventArgs e)
        {
            if (initializing) return;

            pathChanged = true;
            selDirectories();
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            BuildForIphone = false;

            DoBuildREMProcess(sender, e);
        }

        List<string> lstErrModules = new List<string>();
        private void DoBuildREMProcess(object sender, EventArgs e)
        {
            isProcessing = true;
            //this.txtBuildREMOutput.Text = string.Empty;
            OutMsg(PageType.BuildREM, Environment.NewLine);
            btnBuildREMProcess.Enabled = false;
            btnBuildREMBrowse.Enabled = false;
            btnBuildREMSel.Enabled = false;
            cancelPressed = false;
            processFailed = false;

            btnBuildREMProcess.Visible = false;
            btnBuildREMCancel.Visible = true;

            bool AnySelected = false;

            lstErrModules.Clear();

            foreach (FolderSelStatus folder in colFiles)
            {
                if (folder.Selected)
                {
                    GlobalStructures.InitTableListActive();
                    AnySelected = true;

                    RebuildDirectory = folder.FolderName;

                    SNDir = toolSheet.SNDir;
                    DoNSerial = chkBuildREMCalculate.Checked;
                    IsMainSite = toolSheet.MainSite;

                    //BuildREM();

                    Thread tr = new Thread(new ThreadStart(BuildREM));

                    //invokingCount = 0;
                    tr.Start();

                    while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
                    {
                        if (cancelPressed)
                        {
                            tr.Abort();

                            //OutMsg(PageType.BuildREM, "Process terminated!" + Environment.NewLine);

                            //break;

                            OutMsg(PageType.BuildREM, "Cancelling");
                            while (tr.IsAlive)
                            {
                                Application.DoEvents();
                                Thread.Sleep(300);
                                OutMsg(PageType.BuildREM, ".");

                                OutMsg();

                            }
                        }
                        Application.DoEvents();

                        OutMsg();

                        //Thread.Sleep(200);
                    }
                    if (cancelPressed)
                    {
                        break;
                    }

                    //FixREM(RebuildDirectory);

                    long maxSN = 0;
                    long minSN = 0;
                    if (GetModuleSNRange(ref minSN, ref maxSN, folder.FolderName))
                    {
                        if (minSN == long.MaxValue)
                        {
                            minSN = 0;
                        }

                        OutMsg(PageType.BuildREM, "The MAX SN is " + maxSN.ToString() +
                            ", and the MIN SN is " + minSN.ToString() + Environment.NewLine);
                    }

                    else
                    {
                        //OutMsg(PageType.BuildREM, "There are some incorrect SN in file RGKEYWD.REM!" + Environment.NewLine);
                    }

                    OutMsg(PageType.BuildREM, "Process ended at: " + DateTime.Now.ToString() + Environment.NewLine + Environment.NewLine);

                }
            }

            btnBuildREMSel.Enabled = true;
            btnBuildREMProcess.Enabled = true;
            btnBuildREMBrowse.Enabled = true;

            btnBuildREMProcess.Visible = true;
            btnBuildREMCancel.Visible = false;

            OutMsg();

            if (!AnySelected)
            {
                OutMsg(PageType.BuildREM, "No Selected Directory!" + Environment.NewLine);
            }
            else
            {
                if (processFailed && isAutoProcess)
                {
                    MessageBox.Show(this, "Build REM failed in AutoProcess!", "Build REM", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                if (!cancelPressed && !isAutoProcess)
                {
                    if (processFailed)
                    {
                        MessageBox.Show(this, "Build REM failed", "Build REM", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        if (!BuildForIphone)
                        {
                            try
                            {
                                MessageBox.Show(this, "Build REM done!", "Build REM");
                            }
                            catch
                            {
                                //MessageBox.Show("Abnormal program termination!", "Build REM");
                            }
                        }
                    }
                }
                else
                {
                    if (!BuildForIphone)
                    {
                        cancelPressed = false;
                    }
                }
            }

            isProcessing = false;

            OutMsg();
        }

        private bool GetModuleSNRange(ref long minSN, ref long maxSN, string path)
        {
            minSN = long.MaxValue;
            maxSN = long.MinValue;

            string fileName = Path.Combine(path, "RGKEYWD.REM");
            if (File.Exists(fileName))
            {
                try
                {
                    StreamReader sr = new StreamReader(fileName);

                    string InputLine = string.Empty;
                    while ((InputLine = sr.ReadLine()) != null)
                    {
                        string[] arr = InputLine.Split(new char[] { ',' });
                        if (arr.Length > 5)
                        {
                            long _SN = 0;
                            try
                            {
                                _SN = long.Parse(arr[0]);

                                if (_SN > maxSN)
                                {
                                    maxSN = _SN;
                                }

                                if (_SN < minSN)
                                {
                                    minSN = _SN;
                                }
                            }
                            catch
                            {
                            }
                        }
                        else
                        {
                            return false;
                        }
                    }

                    sr.Close();
                    return true;
                }
                catch
                {
                    MessageBox.Show(this, "Can't open the file " + fileName + "!");

                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        string RebuildDirectory;
        string SNDir;
        bool DoNSerial;
        bool IsMainSite;

        delegate void changeText(PageType pType, string result);
        private void OutMsg(string msg)
        {
            PageType pType = PageType.BuildREM;
            OutMsg(pType, msg);
        }

        internal int invokingCount
        {
            get
            {
                return msgQueue.Count;
            }
        }
        internal void ClearDisplayQueue()
        {
            lock (msgQueue)
            {
                msgQueue.Clear();
            }
        }
        internal Queue<MsgInfo> msgQueue = new Queue<MsgInfo>();

        internal void OutMsg(PageType pType, string msg)
        {
            lock (msgQueue)
            {
                if (msg == ".")
                {
                    msgQueue.Enqueue(new MsgInfo(pType, msg));
                    //if (isAutoProcess && pType != PageType.AutoProcess)
                    //{
                    //    msgQueue.Enqueue(new MsgInfo(PageType.AutoProcess, msg));
                    //}
                }
                else
                {
                    msgQueue.Enqueue(new MsgInfo(pType, "(" + DateTime.Now.ToString("hh:mm:ss") + ") " + msg));

                    //if (isAutoProcess && pType != PageType.AutoProcess)
                    //{
                    //    msgQueue.Enqueue(new MsgInfo(PageType.AutoProcess, "(" + DateTime.Now.ToString("hh:mm:ss") + ") " + msg));
                    //}
                }
            }
            //invokingCount = msgQueue.Count;
        }

        private bool isCalling = false;

        TextBox currTxtBox = null;
        PageType currPgType = PageType.All;
        private void OutMsg()
        {
            StringBuilder sbMsg = new StringBuilder();
            if (isCalling)
            {
                return;
            }

            isCalling = true;

            try
            {
                if (msgQueue == null)
                {
                    isCalling = false;
                    return;
                }

                //sbMsg.Remove(0, sbMsg.Length);

                while (msgQueue.Count > 0)
                {
                    Application.DoEvents();

                    MsgInfo mInfo = null;
                    lock (msgQueue)
                    {
                        mInfo = msgQueue.Dequeue();
                    }
                    if (mInfo == null)
                    {
                        mInfo = new MsgInfo(PageType.BuildREM, "incorrect queue");
                    }

                    PageType pType = mInfo.pType;
                    string msg = mInfo.Msg;

                    if (pType == currPgType)
                    {
                        sbMsg.Append(msg);
                    }
                    else
                    {
                        if (currTxtBox != null && sbMsg.Length > 0)
                        {
                            currTxtBox.Text += sbMsg.ToString();
                            SetScrollPos(currTxtBox.Handle, 1, currTxtBox.Lines.Length - 1, true);
                            SendMessage(currTxtBox.Handle, EM_LINESCROLL, 0, currTxtBox.Lines.Length - 1);
                            //sbMsg.Remove(0, sbMsg.Length);

                            if (isAutoProcess && currPgType != PageType.AutoProcess)
                            {
                                txtAutoOut.Text += sbMsg.ToString();
                                SetScrollPos(txtAutoOut.Handle, 1, txtAutoOut.Lines.Length - 1, true);
                                SendMessage(txtAutoOut.Handle, EM_LINESCROLL, 0, currTxtBox.Lines.Length - 1);
                            }

                        }

                        sbMsg.Remove(0, sbMsg.Length);

                        currPgType = pType;
                        sbMsg.Append(msg);

                        switch (pType)
                        {
                            case PageType.BuildREM:
                                currTxtBox = txtBuildREMOutput;
                                break;
                            case PageType.BuildMODULE:
                                currTxtBox = txtModuleOut;
                                break;
                            case PageType.ModuleDeletion:
                                currTxtBox = txtDelModOut;
                                break;

                            case PageType.DeleteState:
                                currTxtBox = txtDelStOut;
                                break;

                            case PageType.MergeState:
                                currTxtBox = txtMergeSTOut;
                                break;
                            case PageType.MergeFederal:
                            case PageType.MergeFederalMaster:
                            case PageType.MergeFederalModule:
                                currTxtBox = txtMergeFdOut;
                                break;
                            case PageType.BlobsCreation:
                                currTxtBox = txtBlobsOut;
                                break;
                            case PageType.AutoProcess:
                                currTxtBox = txtAutoOut;
                                break;
                            case PageType.VewDB:
                                currTxtBox = txtVewDBResult;
                                break;
                            case PageType.IPone:
                                currTxtBox = txtIPhoneOut;
                                break;
                            case PageType.Import:
                            case PageType.Export:
                            case PageType.ImportExport:
                                currTxtBox = txtImExOut;
                                break;
                            case PageType.Dakref:
                            case PageType.DakrefSource:
                            case PageType.DakrefTaget:
                                currTxtBox = txtDakrefOut;
                                break;
                            case PageType.Upload:
                                //currTxtBox = txtExcelOut;
                                break;
                            default:
                                currTxtBox = null;
                                break;
                        }
                    }

                    //if (!msg.Equals("."))
                    //{
                    //    DataAccess da = new DataAccess();
                    //    //da.SaveLog(pType.ToString(), msg.Replace("\r\n", ""));
                    //}
                }
                if (currTxtBox != null && sbMsg.Length > 0)
                {
                    currTxtBox.Text += sbMsg.ToString();
                    SetScrollPos(currTxtBox.Handle, 1, currTxtBox.Lines.Length - 1, true);
                    SendMessage(currTxtBox.Handle, EM_LINESCROLL, 0, currTxtBox.Lines.Length - 1);

                    if (isAutoProcess && currPgType != PageType.AutoProcess)
                    {
                        txtAutoOut.Text += sbMsg.ToString();
                        SetScrollPos(txtAutoOut.Handle, 1, txtAutoOut.Lines.Length - 1, true);
                        SendMessage(txtAutoOut.Handle, EM_LINESCROLL, 0, currTxtBox.Lines.Length - 1);
                    }

                    sbMsg.Remove(0, sbMsg.Length);
                }
            }
            catch { }

            isCalling = false;

        }
        private void OutMsg1()
        {
            if (isCalling)
            {
                return;
            }

            isCalling = true;

            try
            {
                if (msgQueue == null)
                {
                    //MessageBox.Show("msgQueue is null!");
                    isCalling = false;
                    return;
                }

                while (msgQueue.Count > 0)
                {
                    Application.DoEvents();

                    MsgInfo mInfo = null;
                    lock (msgQueue)
                    {
                        mInfo = msgQueue.Dequeue();
                    }
                    if (mInfo == null)
                    {
                        //MessageBox.Show("mInfo is null!" + msgQueue.Count.ToString());

                        //isCalling = false;
                        //return;

                        mInfo = new MsgInfo(PageType.BuildREM, "incorrect queue");
                    }

                    PageType pType = mInfo.pType;
                    string msg = mInfo.Msg;

                    switch (pType)
                    {
                        case PageType.BuildREM:
                            this.txtBuildREMOutput.Text += msg;
                            SetScrollPos(txtBuildREMOutput.Handle, 1, txtBuildREMOutput.Lines.Length - 1, true);
                            SendMessage(txtBuildREMOutput.Handle, EM_LINESCROLL, 0, txtBuildREMOutput.Lines.Length - 1);
                            break;
                        case PageType.BuildMODULE:
                            this.txtModuleOut.Text += msg;
                            SetScrollPos(txtModuleOut.Handle, 1, txtModuleOut.Lines.Length - 1, true);
                            SendMessage(txtModuleOut.Handle, EM_LINESCROLL, 0, txtModuleOut.Lines.Length - 1);
                            break;
                        case PageType.ModuleDeletion:
                            this.txtDelModOut.Text += msg;
                            SetScrollPos(txtDelModOut.Handle, 1, txtDelModOut.Lines.Length - 1, true);
                            SendMessage(txtDelModOut.Handle, EM_LINESCROLL, 0, txtDelModOut.Lines.Length - 1);
                            break;

                        case PageType.DeleteState:
                            this.txtDelStOut.Text += msg;
                            SetScrollPos(txtDelStOut.Handle, 1, txtDelStOut.Lines.Length - 1, true);
                            SendMessage(txtDelStOut.Handle, EM_LINESCROLL, 0, txtDelStOut.Lines.Length - 1);
                            break;

                        case PageType.MergeState:
                            this.txtMergeSTOut.Text += msg;
                            SetScrollPos(txtMergeSTOut.Handle, 1, txtMergeSTOut.Lines.Length - 1, true);
                            SendMessage(txtMergeSTOut.Handle, EM_LINESCROLL, 0, txtMergeSTOut.Lines.Length - 1);
                            break;
                        case PageType.MergeFederal:
                            this.txtMergeFdOut.Text += msg;
                            SetScrollPos(txtMergeFdOut.Handle, 1, txtMergeFdOut.Lines.Length - 1, true);
                            SendMessage(txtMergeFdOut.Handle, EM_LINESCROLL, 0, txtMergeFdOut.Lines.Length - 1);
                            break;
                        case PageType.BlobsCreation:
                            this.txtBlobsOut.Text += msg;
                            SetScrollPos(txtBlobsOut.Handle, 1, txtBlobsOut.Lines.Length - 1, true);
                            SendMessage(txtBlobsOut.Handle, EM_LINESCROLL, 0, txtBlobsOut.Lines.Length - 1);
                            break;
                        //case PageType.DBCheck:
                        //    //this.txtDBCheckOut.Text += msg;
                        //    //SetScrollPos(txtDBCheckOut.Handle, 1, txtDBCheckOut.Lines.Length - 1, true);
                        //    //SendMessage(txtDBCheckOut.Handle, EM_LINESCROLL, 0, txtDBCheckOut.Lines.Length - 1);
                        //    break;
                        case PageType.AutoProcess:
                            this.txtAutoOut.Text += msg;
                            SetScrollPos(txtAutoOut.Handle, 1, txtAutoOut.Lines.Length - 1, true);
                            SendMessage(txtAutoOut.Handle, EM_LINESCROLL, 0, txtAutoOut.Lines.Length - 1);
                            break;
                        //case PageType.CompareDB:
                        //    this.txtBlobsOut.Text += msg;
                        //    SetScrollPos(txtBlobsOut.Handle, 1, txtBlobsOut.Lines.Length - 1, true);
                        //    SendMessage(txtBlobsOut.Handle, EM_LINESCROLL, 0, txtBlobsOut.Lines.Length - 1);
                        //    break;
                        case PageType.VewDB:
                            this.txtVewDBResult.Text += msg;
                            break;
                        default:
                            break;
                    }

                    if (!msg.Equals("."))
                    {
                        DataAccess da = new DataAccess();
                        da.SaveLog(pType.ToString(), msg.Replace("\r\n", ""));
                    }
                }
            }
            catch { }

            isCalling = false;

        }
        internal void OutMsg(PageType pType, string msg, bool IsImm)
        {
            lock (msgQueue)
            {
                msgQueue.Enqueue(new MsgInfo(pType, "(" + DateTime.Now.ToString("hh:mm:ss") + ") " + msg));
            }

            if (IsImm)
            {
                OutMsg();
            }
        }

        //internal void OutMsg(PageType pType, string msg)
        //{
        //    if (this.InvokeRequired)
        //    {
        //        object[] parm = new object[2];
        //        parm[0] = pType;
        //        parm[1] = msg;

        //        invokingCount++;
        //        this.BeginInvoke(new changeText(OutMsg), parm);
        //    }
        //    else
        //    {

        //        if (invokingCount > 0)
        //        {
        //            invokingCount--;
        //        }

        //        switch (pType)
        //        {
        //            case PageType.BuildREM:
        //                this.txtBuildREMOutput.Text += msg;
        //                SetScrollPos(txtBuildREMOutput.Handle, 1, txtBuildREMOutput.Lines.Length - 1, true);
        //                SendMessage(txtBuildREMOutput.Handle, EM_LINESCROLL, 0, txtBuildREMOutput.Lines.Length - 1);
        //                break;
        //            case PageType.BuildMODULE:
        //                this.txtModuleOut.Text += msg;
        //                SetScrollPos(txtModuleOut.Handle, 1, txtModuleOut.Lines.Length - 1, true);
        //                SendMessage(txtModuleOut.Handle, EM_LINESCROLL, 0, txtModuleOut.Lines.Length - 1);
        //                break;
        //            case PageType.ModuleDeletion:
        //                this.txtDelModOut.Text += msg;
        //                SetScrollPos(txtDelModOut.Handle, 1, txtDelModOut.Lines.Length - 1, true);
        //                SendMessage(txtDelModOut.Handle, EM_LINESCROLL, 0, txtDelModOut.Lines.Length - 1);
        //                break;
        //            case PageType.RunTimeCreation:
        //                this.txtRunTimeCreationOut.Text += msg;
        //                SetScrollPos(txtRunTimeCreationOut.Handle, 1, txtRunTimeCreationOut.Lines.Length - 1, true);
        //                SendMessage(txtRunTimeCreationOut.Handle, EM_LINESCROLL, 0, txtRunTimeCreationOut.Lines.Length - 1);
        //                break;
        //            case PageType.DeleteState:
        //                this.txtDelStOut.Text += msg;
        //                SetScrollPos(txtDelStOut.Handle, 1, txtDelStOut.Lines.Length - 1, true);
        //                SendMessage(txtDelStOut.Handle, EM_LINESCROLL, 0, txtDelStOut.Lines.Length - 1);
        //                break;
        //            case PageType.UnloadReload:
        //                this.txtLdOut.Text += msg;
        //                SetScrollPos(txtBuildREMOutput.Handle, 1, txtBuildREMOutput.Lines.Length - 1, true);
        //                SendMessage(txtBuildREMOutput.Handle, EM_LINESCROLL, 0, txtBuildREMOutput.Lines.Length - 1);
        //                break;
        //            case PageType.MergeState:
        //                this.txtMergeSTOut.Text += msg;
        //                SetScrollPos(txtMergeSTOut.Handle, 1, txtMergeSTOut.Lines.Length - 1, true);
        //                SendMessage(txtMergeSTOut.Handle, EM_LINESCROLL, 0, txtMergeSTOut.Lines.Length - 1);
        //                break;
        //            case PageType.MergeFederal:
        //                this.txtMergeFdOut.Text += msg;
        //                SetScrollPos(txtMergeFdOut.Handle, 1, txtMergeFdOut.Lines.Length - 1, true);
        //                SendMessage(txtMergeFdOut.Handle, EM_LINESCROLL, 0, txtMergeFdOut.Lines.Length - 1);
        //                break;
        //            case PageType.BlobsCreation:
        //                this.txtBlobsOut.Text += msg;
        //                SetScrollPos(txtBlobsOut.Handle, 1, txtBlobsOut.Lines.Length - 1, true);
        //                SendMessage(txtBlobsOut.Handle, EM_LINESCROLL, 0, txtBlobsOut.Lines.Length - 1);
        //                break;
        //            //case PageType.DBCheck:
        //            //    //this.txtDBCheckOut.Text += msg;
        //            //    //SetScrollPos(txtDBCheckOut.Handle, 1, txtDBCheckOut.Lines.Length - 1, true);
        //            //    //SendMessage(txtDBCheckOut.Handle, EM_LINESCROLL, 0, txtDBCheckOut.Lines.Length - 1);
        //            //    break;
        //            case PageType.AutoProcess:
        //                this.txtAutoOut.Text += msg;
        //                SetScrollPos(txtAutoOut.Handle, 1, txtAutoOut.Lines.Length - 1, true);
        //                SendMessage(txtAutoOut.Handle, EM_LINESCROLL, 0, txtAutoOut.Lines.Length - 1);
        //                break;
        //            case PageType.CompareDB:
        //                this.txtBlobsOut.Text += msg;
        //                SetScrollPos(txtBlobsOut.Handle, 1, txtBlobsOut.Lines.Length - 1, true);
        //                SendMessage(txtBlobsOut.Handle, EM_LINESCROLL, 0, txtBlobsOut.Lines.Length - 1);
        //                break;
        //            case PageType.VewDB:
        //                this.txtVewDBResult.Text += msg;
        //                break;
        //            default:
        //                break;
        //        }
        //        //Application.DoEvents();
        //        if (!msg.Equals("."))
        //        {
        //            DataAccess da = new DataAccess();
        //            da.SaveLog(pType.ToString(), msg.Replace("\r\n", ""));
        //        }

        //    }
        //}

        internal string defaultServer = "HS2";
        internal string defaultDB = "Dakref_Ipod";

        internal void OutVer(PageType pType, string msg)
        {
            if (this.InvokeRequired)
            {
                object[] parm = new object[2];
                parm[0] = pType;
                parm[1] = msg;

                this.BeginInvoke(new changeText(OutVer), parm);
            }
            else
            {
                if (msg == "")
                {
                    string s = CVTHEX.LongToHex(123);
                }

                switch (pType)
                {
                    case PageType.BuildREM:
                        break;
                    case PageType.BuildMODULE:
                        this.txtModuleVer.Text = msg;
                        txtModuleVer.Focus();
                        break;
                    case PageType.ModuleDeletion:
                        this.txtDelModVer.Text = msg;
                        txtDelModVer.Focus();
                        break;
                    case PageType.DeleteState:
                        this.txtDelStVer.Text = msg;
                        txtDelStVer.Focus();
                        break;
                    case PageType.MergeState:
                        this.txtMergeSTVer.Text = msg;
                        txtMergeSTVer.Focus();
                        break;
                    case PageType.MergeFederalMaster:
                        this.txtMergeFMasterVer.Text = msg;
                        txtMergeFMasterVer.Focus();
                        break;
                    case PageType.MergeFederalModule:
                        this.txtMergeFModuleVer.Text = msg;
                        txtMergeFModuleVer.Focus();
                        break;
                    case PageType.BlobsCreation:
                        this.txtBlobsVer.Text = msg;
                        txtBlobsVer.Focus();
                        break;
                    case PageType.VewDB:
                        this.txtVewDBVer.Text = msg;
                        txtVewDBVer.Focus();
                        break;
                    case PageType.AutoProcess:
                        break;
                    case PageType.DakrefSource:
                        this.txtDakrefSrcVer.Text = msg;
                        txtDakrefSrcVer.Focus();
                        break;
                    case PageType.DakrefTaget:
                        this.txtDakrefTagVer.Text = msg;
                        txtDakrefTagVer.Focus();
                        break;
                    case PageType.Upload:
                        //this.txtExcelTagVer.Text = msg;
                        //txtExcelTagVer.Focus();
                        break;
                    case PageType.Import:
                        this.txtImVersion.Text = msg;
                        txtImVersion.Focus();
                        break;
                    case PageType.Export:
                        this.txtExVersion.Text = msg;
                        txtExVersion.Focus();
                        break;
                    case PageType.ConfigBackup:
                        this.txtConfigBakVer.Text = msg;
                        txtConfigBakVer.Focus();
                        break;
                    case PageType.ConfigRestore:
                        this.txtConfigResVer.Text = msg;
                        txtConfigResVer.Focus();
                        break;
                    default:
                        break;
                }
            }
        }

        delegate void changeList(CMModuleSet Module, PageType pgType);

        internal void ListRefresh(CMModuleSet Module, PageType pgType)
        {
            if (this.InvokeRequired)
            {
                object[] parm = new object[2];
                parm[0] = Module;
                parm[1] = pgType;

                this.BeginInvoke(new changeList(ListRefresh), parm);
            }
            else
            {
                switch (pgType)
                {
                    case PageType.ModuleDeletion:
                        lstDelModAvail.Items.Clear();
                        lstDelModSel.Items.Clear();

                        if (Module != null)
                        {
                            while (Module.FetchNextDS() != EnumSQLError.DB_NOTFOUND)
                            {
                                string _moduleName = Module.GetModuleName();
                                long _modulesSN = Module.GetModuleSN();

                                if (_modulesSN != 0)
                                {
                                    ModuleListItem _item = new ModuleListItem(_moduleName, _modulesSN);
                                    lstDelModAvail.Items.Add(_item);
                                }
                            }

                            Module.ClearAllFields();

                            lstDelModAvail.Sorted = true;
                        }
                        break;
                    case PageType.VewDB:
                        lstVewDBModule.Items.Clear();

                        if (Module != null)
                        {
                            while (Module.FetchNextDS() != EnumSQLError.DB_NOTFOUND)
                            {
                                string _moduleName = Module.GetModuleName();
                                long _modulesSN = Module.GetModuleSN();

                                if (_modulesSN != 0)
                                {

                                    ModuleListItem _item = new ModuleListItem(_moduleName, _modulesSN);
                                    lstVewDBModule.Items.Add(_item);
                                }
                            }

                            Module.ClearAllFields();

                            lstVewDBModule.Sorted = true;
                        }

                        DataSql sybase = new DataSql(txtVewDBServer.Text, txtVewDBDB.Text, ViewDBUser, ViewDBPW);
                        sybase.Open();
                        DataSet ds = sybase.GetDataSet("select max(ModuleVersionSN) FROM ModuleVersion");
                        if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                        {
                            txtVewDBVerSN.Text = ds.Tables[0].Rows[0][0].ToString();
                        }

                        ds = sybase.GetDataSet("SELECT max(StateVersionSN)  FROM StateVersion");
                        if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                        {
                            txtVewDBSTVerSN.Text = ds.Tables[0].Rows[0][0].ToString();
                        }
                        sybase.Close();
                        break;
                    default:
                        break;

                }
            }
        }

        private void BuildREM()
        {
            BuildREM(PageType.BuildREM);
        }
        private void BuildREM(PageType pgType)
        {
            //isAutoProcess = true;

            string BogueFileName = RebuildDirectory + @"\STATUS.TXT";
            TDomainTable DomainTable = new TDomainTable();
            TParserFood ParserFood = new TParserFood();
            TParser Parser = new TParser(SNDir);
            TRefLib RefLib = new TRefLib();

            if (BuildForIphone)
            {
                RefLib.m_SectionList.MainForm = this;
            }

            TParseDoc RawGuide = new TParseDoc();

            StreamWriter BogueFile;

            OutMsg(pgType, "Process for folder " + RebuildDirectory + " started at: " +
                    DateTime.Now.ToString() + Environment.NewLine);

            try
            {
                BogueFile = new StreamWriter(BogueFileName, false, Encoding.Default);
            }
            catch (Exception e)
            {

                OutMsg(pgType, e.Message + Environment.NewLine);
                //MessageBox.Show(this, "Error Raised: " + e.Message + Environment.NewLine + "Application will be restarted!");
                //Application.Restart();
                BogueFile = null;
            }

            string errMessage = "";
            try
            {
                BogueFile.WriteLine("***********************************************");
                BogueFile.WriteLine("** SERIAL NUMBER UPDATING                    **");
                BogueFile.WriteLine("***********************************************");
                OutMsg(pgType, "Serial Number Updating\r\n");
                OutMsg(pgType, "  Update Question serial numbers.\r\n");

                try
                {
                    NSERIAL.UpdateQuestion(RebuildDirectory, BogueFile, SNDir, IsMainSite);
                }
                catch (Exception ee)
                {
                    if (!isAutoProcess)
                    {
                        throw (ee);
                    }
                    else
                    {
                        errMessage += ee.Message + "\r\n";
                    }
                }

                OutMsg(pgType, "  Update Domain serial numbers.\r\n");

                try
                {
                    NSERIAL.UpdateDomain(RebuildDirectory, BogueFile, SNDir, IsMainSite);
                }
                catch (Exception ee)
                {
                    if (!isAutoProcess)
                    {
                        throw (ee);
                    }
                    else
                    {
                        errMessage += ee.Message + "\r\n";
                    }
                }

                OutMsg(pgType, "Serial Numbers updated successfully.\r\n");

                long ModuleSN = -1;
                try
                {
                    ModuleSN = MODULE.GetModuleSN(RebuildDirectory);
                }
                catch (Exception ee)
                {
                    if (!isAutoProcess)
                    {
                        throw (ee);
                    }
                    else
                    {
                        errMessage += ee.Message + "\r\n";
                    }
                }

                GlobalStructures.SetModuleSN(ModuleSN);

                string ModuleName = "";
                try
                {
                    ModuleName = MODULE.GetModuleName(RebuildDirectory);
                }
                catch (Exception ee)
                {
                    if (!isAutoProcess)
                    {
                        throw (ee);
                    }
                    else
                    {
                        errMessage += ee.Message + "\r\n";
                    }
                }

                GlobalStructures.SetModuleName(ModuleName);

                // Reset master key sequencer
                TKey.SetMasterSequence(-1L);

                long SNStart = 0; ;
                try
                {
                    DomainTable.LoadModuleTable(RebuildDirectory, ref SNStart, BogueFile);
                }
                catch (Exception ee)
                {
                    if (!isAutoProcess)
                    {
                        throw (ee);
                    }
                    else
                    {
                        errMessage += ee.Message + "\r\n";
                    }
                }

                TSymbol.BaseSN = SNStart;
                TRule.InitRuleBound(SNStart);

                BogueFile.WriteLine();
                BogueFile.WriteLine("***********************************************");
                BogueFile.WriteLine("** RULE GENERATION (WABSORB)                 **");
                BogueFile.WriteLine("***********************************************");
                BogueFile.WriteLine();

                OutMsg(pgType, "\r\nRule Generation (WAbsorb)\r\n");
               
                try
                {
                    ParserFood.Load(RebuildDirectory);
                }
                catch (Exception ee)
                {
                    if (!isAutoProcess)
                    {
                        throw (ee);
                    }
                    else
                    {
                        errMessage += ee.Message + "\r\n";
                    }
                }

                try
                {
                    DomainTable.LoadDomainTable(RebuildDirectory, ParserFood.SymbolTable, BogueFile);
                }
                catch (Exception ee)
                {
                    if (!isAutoProcess)
                    {
                        throw (ee);
                    }
                    else
                    {
                        errMessage += ee.Message + "\r\n";
                    }
                }

                OutMsg(pgType, "  Parsing document.\r\n");
                try
                {
                    Parser.DigestQDOC(ParserFood, DomainTable, BogueFile);
                }
                catch (Exception ee)
                {
                    if (!isAutoProcess)
                    {
                        throw (ee);
                    }
                    else
                    {
                        errMessage += ee.Message + "\r\n";
                    }
                }

                OutMsg(pgType, "  Generating questions.\r\n");
                try
                {
                    Parser.GenerateQuestions(RebuildDirectory, BogueFile);
                }
                catch (Exception ee)
                {
                    if (!isAutoProcess)
                    {
                        throw (ee);
                    }
                    else
                    {
                        errMessage += ee.Message + "\r\n";
                    }
                }

                OutMsg(pgType, "  Merging rules.\r\n");
                try
                {
                    Parser.RuleList.MergeRules(ParserFood.SymbolTable);
                }
                catch (Exception ee)
                {
                    if (!isAutoProcess)
                    {
                        throw (ee);
                    }
                    else
                    {
                        errMessage += ee.Message + "\r\n";
                    }
                }

                OutMsg(pgType, "  Resolving Target Duplicates.\r\n");
                try
                {
                    Parser.RuleList.ResolveTargetDuplicates(ParserFood.SymbolTable);
                }
                catch (Exception ee)
                {
                    if (!isAutoProcess)
                    {
                        throw (ee);
                    }
                    else
                    {
                        errMessage += ee.Message + "\r\n";
                    }
                }

                OutMsg(pgType, "  Cleaning Set Statements.\r\n");
                try
                {
                    Parser.RuleList.CleanSetStatements(ParserFood.SymbolTable);
                }
                catch (Exception ee)
                {
                    if (!isAutoProcess)
                    {
                        throw (ee);
                    }
                    else
                    {
                        errMessage += ee.Message + "\r\n";
                    }
                }

                OutMsg(pgType, "  Imposing Hierarchy.\r\n");
                try
                {
                    Parser.RuleList.ImposeHierarchy(DomainTable, ParserFood.SymbolTable);
                }
                catch (Exception ee)
                {
                    if (!isAutoProcess)
                    {
                        throw (ee);
                    }
                    else
                    {
                        errMessage += ee.Message + "\r\n";
                    }
                }
                
                OutMsg(pgType, "  Generating Applicablity Variables.\r\n");
                try
                {
                    Parser.GenerateApplicabilityVariables(RebuildDirectory);
                }
                catch (Exception ee)
                {
                    if (!isAutoProcess)
                    {
                        throw (ee);
                    }
                    else
                    {
                        errMessage += ee.Message + "\r\n";
                    }
                }

                try
                {
                    Parser.GenerateNamedVariables(RebuildDirectory);
                }
                catch (Exception ee)
                {
                    if (!isAutoProcess)
                    {
                        throw (ee);
                    }
                    else
                    {
                        errMessage += ee.Message + "\r\n";
                    }
                }

                OutMsg(pgType, "  Generating Rules.\r\n");
                try
                {
                    Parser.RuleList.Dump(RebuildDirectory);
                }
                catch (Exception ee)
                {
                    if (!isAutoProcess)
                    {
                        throw (ee);
                    }
                    else
                    {
                        errMessage += ee.Message + "\r\n";
                    }
                }

                try
                {
                    Parser.RuleList.Generate(RebuildDirectory, ParserFood.SymbolTable);
                }
                catch (Exception ee)
                {
                    if (!isAutoProcess)
                    {
                        throw (ee);
                    }
                    else
                    {
                        errMessage += ee.Message + "\r\n";
                    }
                }

                // Generating Hierarchy, must be done after generating questions.
                OutMsg(pgType, "  Generating Hierarchy.\r\n");
                try
                {
                    DomainTable.GenerateHierarchy(RebuildDirectory);
                }
                catch (Exception ee)
                {
                    if (!isAutoProcess)
                    {
                        throw (ee);
                    }
                    else
                    {
                        errMessage += ee.Message + "\r\n";
                    }
                }

                OutMsg(pgType, "  Generating Goals.\r\n");
                try
                {
                    TGOAL.GenerateGoals(this, BogueFile, RebuildDirectory, ParserFood.SymbolTable);
                }
                catch (Exception ee)
                {
                    if (!isAutoProcess)
                    {
                        throw (ee);
                    }
                    else
                    {
                        BogueFile.WriteLine(ee.Message + "\r\n");
                        errMessage += ee.Message + "\r\n";
                    }
                }

                OutMsg(pgType, "Rule Generation Completed successfully.\r\n");

                BogueFile.WriteLine();
                BogueFile.WriteLine("***********************************************");
                BogueFile.WriteLine("** REFERENCE LIBRARY GENERATION (FUGUE)      **");
                BogueFile.WriteLine("***********************************************");
                BogueFile.WriteLine();
                OutMsg(pgType, "\r\nBuilding Reference Library\r\n");

                try
                {
                    RawGuide.DigestRefLib(RebuildDirectory, BogueFile);
                }
                catch (Exception ee)
                {
                    if (!isAutoProcess)
                    {
                        throw (ee);
                    }
                    else
                    {
                        errMessage += ee.Message + "\r\n";
                    }
                }

                try
                {
                    RefLib.Build(this, RawGuide, BogueFile);
                }
                catch (Exception ee)
                {
                    if (!isAutoProcess)
                    {
                        throw (ee);
                    }
                    else
                    {
                        errMessage += ee.Message + "\r\n";
                    }
                }

                try
                {
                    RefLib.GenerateSQL(RebuildDirectory, BogueFile);
                }
                catch (Exception ee)
                {
                    if (!isAutoProcess)
                    {
                        throw (ee);
                    }
                    else
                    {
                        errMessage += ee.Message + "\r\n";
                    }
                }

                OutMsg(pgType, "Reference Library Generation completed successfully.\r\n");

                //2) It does not indicate anywhere that the box for Calculate Domain/questions Changes should NOT be checked on the BuildREM tab 
                //when running AutoProcess.  If this box is checked, any module F7folder which does not contain *.old files  will cause the 
                //AutoProcess tool to fail since the Calculate Changes option is looking for these *.old files to make comparisons and document them 
                //in Status.txt for each module.
                if (DoNSerial && !isAutoProcess)
                {
                    BogueFile.WriteLine("***********************************************");
                    BogueFile.WriteLine("** QUESTION/DOMAIN CHANGES (NSERIAL)         **");
                    BogueFile.WriteLine("***********************************************");
                    OutMsg(pgType, "\r\nQuestion/Domain Change Comparision\r\n");
                    OutMsg(pgType, "  Comparing Domains\r\n");
                    NSTATUS.TranslateModule(BogueFile, RebuildDirectory, TMClass.tmDomain);
                    OutMsg(pgType, "  Comparing Questions\r\n");
                    NSTATUS.TranslateModule(BogueFile, RebuildDirectory, TMClass.tmQuestion);
                    OutMsg(pgType, "Comparisions completed successfully.\r\n");
                }

                if (isAutoProcess && errMessage != "")
                {
                    try
                    {
                        BogueFile.WriteLine(errMessage);
                    }
                    catch { }

                    OutMsg(pgType, errMessage);
                    OutMsg(pgType, "\r\nThere were errors, see STATUS.TXT.\r\n");

                    lstErrModules.Add(RebuildDirectory);
                    processFailed = true;
                }
            }
            catch (Exception e)
            {
                try
                {
                    BogueFile.WriteLine(e.Message);
                }
                catch { }

                OutMsg(pgType, e.Message);
                OutMsg(pgType, "\r\nThere were errors, see STATUS.TXT.\r\n");

                processFailed = true;
            }
            finally
            {
                if (BogueFile != null)
                {
                    BogueFile.Close();
                }
                //OutMsg(pgType, "Process ended at: " + DateTime.Now.ToString() + Environment.NewLine + Environment.NewLine);
            }
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            //CVTHEX.LongToHex(-1);
            UTIL._main = this;

            //if (!Directory.Exists(toolSheet.SNDir))
            //{
            //    toolSheet.SNDir = Application.StartupPath + "\\Serial";
            //}
            //if (!Directory.Exists(toolSheet.SNDir))
            //{
            //    try
            //    {
            //        Directory.CreateDirectory(toolSheet.SNDir);
            //    }
            //    catch { }
            //}

            DataAccess da = new DataAccess();

            colFiles.Clear();
            da.GetDirStatus(txtBuildREMDir.Text, colFiles);

            cobStartStep.SelectedIndex = 0;
            cboVewDBQuery.SelectedIndex = 0;

            if (!Directory.Exists(toolSheet.TempDir))
            {
                try
                {
                    Directory.CreateDirectory(toolSheet.TempDir);
                    lblConfigTmpDirMsg.Text = string.Empty;
                }
                catch
                {
                    MessageBox.Show("Temporary Directory not existing!" + Environment.NewLine +
                            "Please set correct this first!", "Satrting...", MessageBoxButtons.OK);

                    isProcessing = false;
                    tabControl.SelectedTab = tbPgConfig;
                    isProcessing = true;

                    return;
                }
            }

            if (!Directory.Exists(toolSheet.SNDir))
            {
                MessageBox.Show("Serial Directory not existing!" + Environment.NewLine +
                        "Please set correct this first!", "Satrting...", MessageBoxButtons.OK);

                isProcessing = false;
                tabControl.SelectedTab = tbPgConfig;
                isProcessing = true;
            }

            btnImport.Enabled = (lblImMsg.Text == "");
        }

        internal bool cancelPressed = false;
        internal bool copyFailed = false;
        private bool autoProcessCancel = false;
        internal bool processFailed = false;    //for processing
        internal bool processError = false; //for DB open
        private void btnCancel_Click(object sender, EventArgs e)
        {
            cancelPressed = true;
            autoProcessCancel = true;
        }

        private void lstModuleAval_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstModuleAval.SelectedItems.Count > 0)
            {
                btnModuleAdd.Enabled = true;
            }
            else
            {
                btnModuleAdd.Enabled = false;
            }
        }

        private void lstModuleSel_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstModuleSel.SelectedItems.Count > 0)
            {
                btnModuleRemove.Enabled = true;
            }
            else
            {
                btnModuleRemove.Enabled = false;
            }
        }

        private void btnModuleBrowse_Click(object sender, EventArgs e)
        {
            if (isProcessing)
            {
                return;
            }

            FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
            folderBrowserDialog.RootFolder = Environment.SpecialFolder.MyComputer;
            folderBrowserDialog.ShowNewFolderButton = false;

            folderBrowserDialog.SelectedPath = this.txtModuleDir.Text;
            DialogResult result = folderBrowserDialog.ShowDialog(this);
            if (result == DialogResult.OK)
            {
                this.txtModuleDir.Text = folderBrowserDialog.SelectedPath;

                SaveConfig("ModuleRootDirectory", folderBrowserDialog.SelectedPath);

            }

            if (Directory.Exists(this.txtModuleDir.Text))
            {
                InitListModule(PageType.BuildMODULE);
                lblModuleMsg.Text = string.Empty;
            }
            else
            {
                lblModuleMsg.Text = "Invalid Directory!";
            }
        }

        private void tabControl_SelectedIndexChanged(object sender, EventArgs e)
        {
            TabControl tbCtrl = (TabControl)sender;
            TabPage tbPg = tbCtrl.SelectedTab;

            switch (tbPg.Name)
            {
                case "tbPgBuildREM":
                    break;
                case "tbPgBuildMODULE":
                    InitListModule(PageType.BuildMODULE);
                    break;
                case "tbPgModuleDel":
                    InitListModule(PageType.ModuleDeletion);
                    break;
                case "tpPgIPhoneDB":
                    InitListModule(PageType.IPone);
                    break;
                case "tbPgDelState":
                    InitListModule(PageType.DeleteState);
                    break;
                //case "tbPgUpload":
                //    InitListModule(PageType.UnloadReload);
                //    break;
                case "tbPgMergSt":
                    InitListModule(PageType.MergeState);
                    break;
                case "tbPgMergFederal":
                    InitListModule(PageType.MergeFederal);
                    break;
                case "tbPgBlobsCreat":
                    InitListModule(PageType.BlobsCreation);
                    break;
                case "tbPgLog":
                    //if (this.txtLogOut.Text == string.Empty)
                    //{
                    //    //DateTime dt = DateTime.Now;
                    //    //dtpLog.Text = dt.ToString("MM/dd/yyyy");
                    //    //DisplayLog(dt);
                    //}

                    break;
                case "tbPgConfig":
                    InitListModule(PageType.Configuration);
                    break;
                case "tpPgImEx":
                    InitListModule(PageType.ImportExport);
                    break;
                case "tbPgAbout":
                    object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyCopyrightAttribute), false);

                    if (attributes.Length != 0)
                    {
                        this.lblPgAboutDate.Text = ((AssemblyCopyrightAttribute)attributes[0]).Copyright;
                    }
                    if (System.Deployment.Application.ApplicationDeployment.IsNetworkDeployed)
                    {
                        System.Deployment.Application.ApplicationDeployment ad = System.Deployment.Application.ApplicationDeployment.CurrentDeployment;

                        this.lblPgAboutVer.Text = "Version: " + ad.CurrentVersion.ToString();
                    }
                    else
                    {
                        this.lblPgAboutVer.Text = "Version: " + Assembly.GetExecutingAssembly().GetName().Version.ToString();
                    }

                    break;
                default:
                    break;
            }
        }

        private void DisplayLog(DateTime date)
        {
            DisplayLog(date, PageType.All);
        }
        private void DisplayLog(DateTime date, PageType pType)
        {
            DataAccess da = new DataAccess();

            DataSet ds = da.GetLogData(date, pType);

            if (ds != null && ds.Tables.Count > 0)
            {
                StringBuilder sb = new StringBuilder();
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    sb.Append(row["Message"].ToString() + Environment.NewLine);
                    //this.txtLogOut.Text += row["Message"].ToString() + Environment.NewLine;
                }
                //this.txtLogOut.Text = sb.ToString();
            }
        }

        private void InitListModule(PageType pType)
        {
            string dbPath = string.Empty;
            switch (pType)
            {
                case PageType.BuildMODULE:
                    string DirModule = txtModuleDir.Text.Trim();
                    string DirBeginWith = toolSheet.DirBeginWith;

                    if (txtModuleServer.Text.Trim() == "")
                    {
                        txtModuleServer.Text = SQLServer;
                    }
                    if (txtModuleDB.Text.Trim() == "")
                    {
                        txtModuleDB.Text = SQLDB;
                    }

                    if (!Directory.Exists(DirModule))
                    {
                        return;
                    }

                    string[] dirs = Directory.GetDirectories(DirModule, toolSheet.DirBeginWith + "*");
                    lstModuleAval.Items.Clear();
                    //            lstModuleSel.Items.Clear();

                    foreach (string dirName in dirs)
                    {
                        string fName = Path.GetFileName(dirName);
                        lstModuleAval.Items.Add(fName);
                    }

                    lstModuleAval.Sorted = true;

                    string[] delSelItems = new string[lstModuleSel.Items.Count];
                    string[] delAvlItems = new string[lstModuleSel.Items.Count];

                    for (int i = 0; i < lstModuleSel.Items.Count; i++)
                    {
                        //string item = lstModuleAval.Items[i].ToString();
                        string item = lstModuleSel.Items[i].ToString();

                        if (lstModuleAval.FindStringExact(item) == ListBox.NoMatches)
                        {
                            delSelItems[i] = item;
                        }
                        else
                        {
                            delAvlItems[i] = item;
                        }
                    }

                    foreach (string str in delSelItems)
                    {
                        if (str != string.Empty)
                        {
                            lstModuleSel.Items.Remove(str);
                        }
                    }

                    foreach (string str in delAvlItems)
                    {
                        if (str != string.Empty)
                        {
                            lstModuleAval.Items.Remove(str);
                        }
                    }

                    break;
                case PageType.BlobsCreation:
                    //txtBlobsServer.Text = SQLServer;
                    //txtBlobsDB.Text = SQLDB;

                    this.btnBlobsOpen.Enabled = true;
                    this.txtBlobsVer.Text = string.Empty;
                    this.btnBlobsProcess.Enabled = false;

                    break;
                case PageType.DeleteState:
                    dbPath = this.txtDelStDB.Text.Trim();
                    break;
                case PageType.MergeState:
                    break;
                case PageType.MergeFederalMaster:
                    if (txtMergeFMMasterServer.Text != "" && txtMergeFMMasterDB.Text != "")
                    {
                        this.btnMergeFMasterOpen.Enabled = true;
                        //this.txtMergeFMasterVer.Text = string.Empty;
                        this.btnMergeFProcess.Enabled = false;
                    }

                    if (txtMergeFMModuleServer.Text != "" && txtMergeFMModuleDB.Text != "")
                    {
                        this.btnMergeFModuleOpen.Enabled = true;
                        //this.txtMergeFModuleVer.Text = string.Empty;
                        this.btnMergeFProcess.Enabled = false;
                    }
                    break;
                case PageType.MergeFederalModule:
                    break;
                case PageType.ModuleDeletion:

                    break;

                case PageType.DBCheck:
                    break;
                case PageType.VewDB:
                    //dbPath = this.txtVewDBName.Text.Trim();

                    break;
                case PageType.IPone:
                    //txtIPhoneREMDir_TextChanged(this, null);
                    break;
                case PageType.ImportExport:
                    //txtImServer.Text = SQLServer;
                    //txtImDB.Text = SQLDB;
                    break;
                default:
                    break;
            }
        }

        private void btnModuleAdd_Click(object sender, EventArgs e)
        {
            string[] delItems = new string[lstModuleAval.SelectedItems.Count];

            for (int i = 0; i < lstModuleAval.SelectedItems.Count; i++)
            {
                string item = lstModuleAval.SelectedItems[i].ToString();

                if (item.ToLower().EndsWith("air") || item.ToLower().EndsWith("waste"))
                {
                    cmdFixAirREM.Enabled = true;
                }

                if (lstModuleSel.FindStringExact(item) == ListBox.NoMatches)
                {
                    lstModuleSel.Items.Add(item);
                }

                delItems[i] = item;
            }

            foreach (string str in delItems)
            {
                lstModuleAval.Items.Remove(str);
            }
            lstModuleSel.Sorted = true;
        }

        private void btnModuleRemove_Click(object sender, EventArgs e)
        {
            string[] delItems = new string[lstModuleSel.SelectedItems.Count];
            for (int i = 0; i < lstModuleSel.SelectedItems.Count; i++)
            {
                delItems[i] = lstModuleSel.SelectedItems[i].ToString();
            }

            foreach (string str in delItems)
            {
                lstModuleSel.Items.Remove(str);
                if (lstModuleAval.FindStringExact(str) == ListBox.NoMatches)
                {
                    lstModuleAval.Items.Add(str);
                }
            }

            cmdFixAirREM.Enabled = false;
            foreach (string str in lstModuleSel.Items)
            {
                if (str.ToLower().EndsWith("air") || str.ToLower().EndsWith("waste"))
                {
                    cmdFixAirREM.Enabled = true;
                    break;
                }
            }
            lstModuleAval.Sorted = true;
        }

        private void lstModuleAval_DoubleClick(object sender, EventArgs e)
        {
            string[] delItems = new string[lstModuleAval.SelectedItems.Count];
            for (int i = 0; i < lstModuleAval.SelectedItems.Count; i++)
            {
                string item = lstModuleAval.SelectedItems[i].ToString();
                if (item.ToLower().EndsWith("air") || item.ToLower().EndsWith("waste"))
                {
                    cmdFixAirREM.Enabled = true;
                }

                if (lstModuleSel.FindStringExact(item) == ListBox.NoMatches)
                {
                    lstModuleSel.Items.Add(item);
                }

                delItems[i] = item;
            }

            foreach (string str in delItems)
            {
                lstModuleAval.Items.Remove(str);
            }

            lstModuleSel.Sorted = true;
        }

        private void lstModuleSel_DoubleClick(object sender, EventArgs e)
        {
            string[] delItems = new string[lstModuleSel.SelectedItems.Count];
            for (int i = 0; i < lstModuleSel.SelectedItems.Count; i++)
            {
                delItems[i] = lstModuleSel.SelectedItems[i].ToString();
            }

            foreach (string str in delItems)
            {
                lstModuleSel.Items.Remove(str);
                if (lstModuleAval.FindStringExact(str) == ListBox.NoMatches)
                {
                    lstModuleAval.Items.Add(str);
                }
            }

            cmdFixAirREM.Enabled = false;
            foreach (string str in lstModuleSel.Items)
            {
                if (str.ToLower().EndsWith("air") || str.ToLower().EndsWith("waste"))
                {
                    cmdFixAirREM.Enabled = true;
                    break;
                }
            }

            lstModuleAval.Sorted = true;
        }

        private void btnModuleRemoveAll_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lstModuleSel.Items.Count; i++)
            {
                string item = lstModuleSel.Items[i].ToString();

                if (lstModuleAval.FindStringExact(item) == ListBox.NoMatches)
                {
                    lstModuleAval.Items.Add(item);
                }
            }

            lstModuleAval.Sorted = true;

            lstModuleSel.Items.Clear();
            cmdFixAirREM.Enabled = false;
        }

        private void btnModuleAddAll_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lstModuleAval.Items.Count; i++)
            {
                string item = lstModuleAval.Items[i].ToString();

                if (item.ToLower().EndsWith("air") || item.ToLower().EndsWith("waste"))
                {
                    cmdFixAirREM.Enabled = true;
                }

                if (lstModuleSel.FindStringExact(item) == ListBox.NoMatches)
                {
                    lstModuleSel.Items.Add(item);
                }
            }

            lstModuleAval.Items.Clear();
            lstModuleSel.Sorted = true;
        }
        private void txtModuleDir_TextChanged(object sender, EventArgs e)
        {
            if (initializing) return;

            if (Directory.Exists(this.txtModuleDir.Text))
            {
                SaveConfig("ModuleRootDirectory", this.txtModuleDir.Text);

                lblModuleMsg.Text = string.Empty;
                InitListModule(PageType.BuildMODULE);
            }
            else
            {
                lblModuleMsg.Text = "Invalid Directory!";

                lstModuleAval.Items.Clear();
                lstModuleSel.Items.Clear();
            }
        }

        private void btnModuleStart_Click(object sender, EventArgs e)
        {
            lblModuleMsg.Text = "";
            
            SetServer(PageType.BuildMODULE);

            if (isAutoProcess && chkAutoFixAirREMS.Checked && cmdFixAirREM.Enabled)
            {
                cmdFixAirREM_Click(this, new EventArgs());
            }

            if (!ValidSqlServerConfiguration)
            {
                MessageBox.Show(this, "Incorrect SQL server configuration!",
                        "Building Module DB", MessageBoxButtons.OK, MessageBoxIcon.Error);

                return;
            }
            else
            {
                Babu.Windows.Forms.MessageBox messageBox = new Babu.Windows.Forms.MessageBox();
                messageBox.Caption = "Information";
                messageBox.CheckBoxEnabled = false;
                messageBox.CheckBoxText = null;
                messageBox.Icon = System.Windows.Forms.MessageBoxIcon.Asterisk;
                messageBox.IsTimedOut = false;

                if (isAutoProcess)
                {
                    messageBox.Timeout = 15;
                }
                else
                {
                    messageBox.Timeout = 0;// 15;
                }

                messageBox.Message = " All data in " + SQLServer + ":" + SQLDB + " will be deleted!" +
                        Environment.NewLine + "Do you want to continue?";

                messageBox.Options = null;
                messageBox.Buttons = MessageBoxButtons.OKCancel;

                DialogResult result = messageBox.ShowDialog(this);

                if (result == DialogResult.Cancel)
                {
                    autoProcessCancel = true;
                    return;
                }
            }

            UTIL.RemoveFilesInDir(toolSheet.TempDir);

            isProcessing = true;

            OutMsg(PageType.BuildMODULE, "\r\n");
            OutMsg(PageType.BuildMODULE, "Process started at: " + DateTime.Now.ToShortTimeString() + ".\r\n");


            this.btnModuleStart.Enabled = false;

            cancelPressed = false;
            processFailed = false;

            btnModuleStart.Visible = false;
            btnModuleCancel.Visible = true;

            //if (CheckDirModule())
            {

                this.toolSheet.CreateTemp();

                TPageBuildModule pageBuild = new TPageBuildModule(this);

                Thread tr = new Thread(new ThreadStart(pageBuild.DoProcess));

                //invokingCount = 0;
                tr.Start();
                while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
                {
                    if (cancelPressed)
                    {
                        //tr.Abort();

                        OutMsg(PageType.BuildMODULE, "Cancelling");
                        while (tr.IsAlive)
                        {
                            Application.DoEvents();
                            Thread.Sleep(300);
                            OutMsg(PageType.BuildMODULE, ".");

                            OutMsg();

                        }
                    }
                    Application.DoEvents();

                    OutMsg();

                    //Thread.Sleep(200);
                }

                OutMsg(PageType.BuildMODULE, "Process ended at: " + DateTime.Now.ToShortTimeString() + ".\r\n");

                if (!processFailed && !cancelPressed)
                {
                    DataSql sqlbase = null;// new DataSql();

                    if (SQLIntegrated)
                    {
                        sqlbase = new DataSql(SQLServer, SQLDB);
                    }
                    else
                    {
                        sqlbase = new DataSql(SQLServer, SQLDB, SQLUser, SQLPW);
                    }

                    //DataSet ds = sqlbase.GetDataSet("SELECT modulesn, modulename FROM Module where modulesn>0");
                    //DisplayData(ds, PageType.BuildMODULE);
                }

                OutMsg();

                if (processFailed && isAutoProcess)
                {
                    MessageBox.Show(this, "Build MODULE failed in AutoProcess!", "Build MODULE", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                if (!cancelPressed && !isAutoProcess)
                {
                    if (processFailed)
                    {
                        MessageBox.Show(this, "Build MODULE failed", "Build MODULE", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        MessageBox.Show(this, "Build MODULE done!", "Build MODULE");
                    }
                }
                else
                {
                    cancelPressed = false;
                }

                OutMsg();
            }

            //UTIL.RemoveFilesInDir(toolSheet.TempDir);

            btnModuleStart.Enabled = true;

            btnModuleStart.Visible = true;
            btnModuleCancel.Visible = false;

            isProcessing = false;

            OutMsg();
        }

        private void btnModuleCancel_Click(object sender, EventArgs e)
        {
            cancelPressed = true;
            autoProcessCancel = true;
        }

        private void cmdFixAirREM_Click(object sender, EventArgs e)
        {
            string DirModule;

            string msg1 = "", msg2 = "";
            if (lstModuleSel.FindStringExact(toolSheet.DirBeginWith + "Air") != ListBox.NoMatches)
            {
                DirModule = txtModuleDir.Text.Trim();
                if (!DirModule.EndsWith(@"\"))
                {
                    DirModule += @"\";
                }

                DirModule += toolSheet.DirBeginWith + @"Air";
                msg1 = FixREM(DirModule, "10");
                OutMsg(PageType.BuildMODULE, "Fix Air REM query has been run the database.\r\n");
            }

            if (lstModuleSel.FindStringExact(toolSheet.DirBeginWith + "Waste") != ListBox.NoMatches)
            {
                DirModule = txtModuleDir.Text.Trim();
                if (!DirModule.EndsWith(@"\"))
                {
                    DirModule += @"\";
                }

                DirModule += toolSheet.DirBeginWith + @"Waste";
                msg2 = FixREM(DirModule, "72");
                OutMsg(PageType.BuildMODULE, "Fix Waste REM query has been run the database.\r\n");
            }

            if (!isAutoProcess)
            {
                if (msg1 == "" && msg2 == "")
                {
                    MessageBox.Show(this, "Done!");
                }
                if (msg1 != "" )
                {
                    MessageBox.Show(this, msg1);
                }
                
                if (msg2 != "")
                {
                    MessageBox.Show(this, msg2);
                }
            }

            OutMsg();
            
            return;
        }

//Jan 25, 2017 Messages from Brooks
//We have figured out the reason why Waste and all other modules need to be treated differently than Air when remapping reference serial numbers. As it turns out, in our production code that goes to customers, we actually have a clause that treats air differently when querying for aw_infoOnly LEFT JOIN dakref.aw_InfoOnly AS ino (NOLOCK)
//ON ino.ModuleSN = am.ModuleSN
//AND ino.ModuleVersionSN = am.ModuleVersionSN
//AND ino.QuestionSN = aq.QuestionSN
//AND ((ino.ModuleSN = 11570 AND (ino.ReferenceSN + 1000000 = dak.ReferenceSN ))
//OR (ino.ModuleSN <> 11570 AND (ino.ReferenceSN = dak.ReferenceSN)))
        private string FixREM(string DirModule, string AddedChr)
        {
            if (!Directory.Exists(DirModule))
            {
                return "Directory '" + DirModule + "' not Existing!";
            }

            if (!File.Exists(Path.Combine(DirModule, "RGKEYWD.REM")))
            {
                return "File 'RGKEYWD.REM' not Existing!";
            }
            if (!File.Exists(Path.Combine(DirModule, "QRLINK.REM")))
            {
                return "File 'QRLINK.REM' not Existing!";
            }
            if (!DirModule.ToLower().EndsWith("air"))
            {

                if (!File.Exists(Path.Combine(DirModule, "INFOONLY.REM")))
                {
                    return "File 'INFOONLY.REM' not Existing!";
                }
            }

            string dt = DateTime.Now.ToString("yyyyMMddhhmm");
            if (!UTIL.FileCopy(Path.Combine(DirModule, "RGKEYWD.REM"),
                    Path.Combine(DirModule, dt + "RGKEYWD.REM"), TypeFlagCopy.CreateMode))
            {
                return "Failed making backup for RGKEYWD.REM!";
            }

            if (!UTIL.FileCopy(Path.Combine(DirModule, "QRLINK.REM"),
                    Path.Combine(DirModule, dt + "QRLINK.REM"), TypeFlagCopy.CreateMode))
            {
                return "Failed making backup for QRLINK.REM!";
            }

            if (!DirModule.ToLower().EndsWith("air"))
            {
                if (!UTIL.FileCopy(Path.Combine(DirModule, "INFOONLY.REM"),
                        Path.Combine(DirModule, dt + "INFOONLY.REM"), TypeFlagCopy.CreateMode))
                {
                    return "Failed making backup for INFOONLY.REM!";
                }
            }

            StreamReader sr = null;
            StreamWriter sw = null;

            try
            {
                sw = new StreamWriter(Path.Combine(DirModule, "RGKEYWD.REM"), false, Encoding.Default);
                sr = new StreamReader(Path.Combine(DirModule, dt + "RGKEYWD.REM"), Encoding.Default);

                string inputline = string.Empty;
                while ((inputline = sr.ReadLine()) != null)
                {
                    if (!inputline.StartsWith(AddedChr))
                    {
                        inputline = AddedChr + inputline;
                    }
                    sw.WriteLine(inputline);
                }

                sw.Close();
                sr.Close();

                sw = new StreamWriter(Path.Combine(DirModule, "QRLINK.REM"), false, Encoding.Default);
                sr = new StreamReader(Path.Combine(DirModule, dt + "QRLINK.REM"), Encoding.Default);

                inputline = string.Empty;
                while ((inputline = sr.ReadLine()) != null)
                {
                    string[] arrQR = inputline.Split(',');
                    if (arrQR.Length == 3)
                    {
                        if (!arrQR[1].StartsWith(AddedChr))
                        {

                            arrQR[1] = AddedChr + arrQR[1];
                        }

                        inputline = arrQR[0] + "," + arrQR[1] + "," + arrQR[2];
                        sw.WriteLine(inputline);
                    }
                    else
                    {
                        throw (new Exception("Format of QRLINK.REM is not correct!"));
                    }
                }

                sw.Close();
                sr.Close();

                if (!DirModule.ToLower().EndsWith("air"))
                {
                    sw = new StreamWriter(Path.Combine(DirModule, "INFOONLY.REM"), false, Encoding.Default);
                    sr = new StreamReader(Path.Combine(DirModule, dt + "INFOONLY.REM"), Encoding.Default);

                    inputline = string.Empty;
                    while ((inputline = sr.ReadLine()) != null)
                    {
                        string[] arrQR = inputline.Split(',');
                        if (arrQR.Length == 3)
                        {
                            if (!arrQR[1].StartsWith(AddedChr))
                            {

                                arrQR[1] = AddedChr + arrQR[1];
                            }

                            inputline = arrQR[0] + "," + arrQR[1] + "," + arrQR[2];
                            sw.WriteLine(inputline);
                        }
                        else
                        {
                            throw (new Exception("Format of INFOONLY.REM is not correct!"));
                        }
                    }

                    sw.Close();
                    sr.Close();
                }
            }
            catch (Exception ee)
            {
                try
                {
                    sw.Close();
                    sr.Close();
                }
                catch
                { }

                return ee.Message;
            }

            return "";
        }

        private void lstDelModAvail_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstDelModAvail.SelectedItems.Count > 0)
            {

                btnDelModAdd.Enabled = true;
            }
            else
            {
                btnDelModAdd.Enabled = false;
            }
        }

        private void btnDelModOpen_Click(object sender, EventArgs e)
        {
            this.lstDelModAvail.Items.Clear();
            this.lstDelModSel.Items.Clear();

            btnDelModOpen.Enabled = false;
            processError = false;

            SetServer(PageType.ModuleDeletion);

            if (this.btnDelModOpen.Text == "&Open")
            {
                if (isAutoProcess)
                {
                    GetDbInfo(PageType.ModuleDeletion);
                }
                else
                {

                    Thread tr = new Thread(new ParameterizedThreadStart(GetDbInfo));
                    //invokingCount = 0;
                    tr.Start(PageType.ModuleDeletion);

                    while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
                    {
                        Application.DoEvents();
                        OutMsg();
                        //Thread.Sleep(200);
                    }
                }
                this.btnDelModOpen.Text = "&Clear";
                this.btnDelModProcess.Enabled = true;
            }
            else
            {
                this.btnDelModOpen.Text = "&Open";
                this.btnDelModProcess.Enabled = false;
            }

            btnDelModOpen.Enabled = true;
            OutMsg();
        }

        private void btnDelModAdd_Click(object sender, EventArgs e)
        {
            ModuleListItem[] delItems = new ModuleListItem[lstDelModAvail.SelectedItems.Count];

            for (int i = 0; i < lstDelModAvail.SelectedItems.Count; i++)
            {
                ModuleListItem item = (ModuleListItem)lstDelModAvail.SelectedItems[i];
                if (lstDelModSel.FindStringExact(item.ToString()) == ListBox.NoMatches)
                {
                    lstDelModSel.Items.Add(item);
                }

                delItems[i] = item;
            }

            foreach (ModuleListItem itm in delItems)
            {
                lstDelModAvail.Items.Remove(itm);
            }

            lstDelModSel.Sorted = true;

        }

        private void btnDelModRemove_Click(object sender, EventArgs e)
        {
            ModuleListItem[] delItems = new ModuleListItem[lstDelModSel.SelectedItems.Count];
            for (int i = 0; i < lstDelModSel.SelectedItems.Count; i++)
            {
                delItems[i] = (ModuleListItem)lstDelModSel.SelectedItems[i];
            }

            foreach (ModuleListItem str in delItems)
            {
                lstDelModSel.Items.Remove(str);

                if (lstDelModAvail.FindStringExact(str.ToString()) == ListBox.NoMatches)
                {
                    lstDelModAvail.Items.Add(str);
                }
            }

            lstDelModAvail.Sorted = true;

        }

        private void btnDelModRemAll_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lstDelModSel.Items.Count; i++)
            {
                ModuleListItem item = lstDelModSel.Items[i] as ModuleListItem;

                if (lstDelModAvail.FindStringExact(item.ToString()) == ListBox.NoMatches)
                {
                    lstDelModAvail.Items.Add(item);
                }
            }

            lstDelModAvail.Sorted = true;
            lstDelModSel.Items.Clear();
        }

        private void btnDelModAddAll_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lstDelModAvail.Items.Count; i++)
            {
                ModuleListItem item = lstDelModAvail.Items[i] as ModuleListItem;

                if (lstDelModSel.FindStringExact(item.ToString()) == ListBox.NoMatches)
                {
                    lstDelModSel.Items.Add(item);
                }
            }

            lstDelModAvail.Items.Clear();
            lstDelModSel.Sorted = true;

        }

        private void lstDelModSel_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstDelModSel.SelectedItems.Count > 0)
            {
                btnDelModRemove.Enabled = true;
            }
            else
            {
                btnDelModRemove.Enabled = false;
            }
        }

        private void lstDelModAvail_DoubleClick(object sender, EventArgs e)
        {
            ModuleListItem[] delItems = new ModuleListItem[lstDelModAvail.SelectedItems.Count];
            for (int i = 0; i < lstDelModAvail.SelectedItems.Count; i++)
            {
                ModuleListItem item = lstDelModAvail.SelectedItems[i] as ModuleListItem;

                if (lstDelModSel.FindStringExact(item.ToString()) == ListBox.NoMatches)
                {
                    lstDelModSel.Items.Add(item);
                }

                delItems[i] = item;
            }

            foreach (ModuleListItem str in delItems)
            {
                lstDelModAvail.Items.Remove(str);
            }

            lstDelModSel.Sorted = true;

        }

        private void lstDelModSel_DoubleClick(object sender, EventArgs e)
        {
            ModuleListItem[] delItems = new ModuleListItem[lstDelModSel.SelectedItems.Count];
            for (int i = 0; i < lstDelModSel.SelectedItems.Count; i++)
            {
                delItems[i] = lstDelModSel.SelectedItems[i] as ModuleListItem;
            }

            foreach (ModuleListItem str in delItems)
            {
                lstDelModSel.Items.Remove(str);
                if (lstDelModAvail.FindStringExact(str.ToString()) == ListBox.NoMatches)
                {
                    lstDelModAvail.Items.Add(str);
                }
            }

            lstDelModAvail.Sorted = true;

        }

        private void btnDelModPro_Click(object sender, EventArgs e)
        {
            if (lstDelModSel.Items.Count < 1)
            {
                MessageBox.Show(this, "No selected module(s) to be deleted!");

                return;
            }

            isProcessing = true;

            this.toolSheet.CreateTemp();

            OutMsg(PageType.ModuleDeletion, "\r\n");
            OutMsg(PageType.ModuleDeletion, "Process started at: " + DateTime.Now.ToShortTimeString() + ".\r\n");

            btnDelModProcess.Visible = false;
            btnDelModCancel.Visible = true;
            btnDelModOpen.Enabled = false;
            btnDelModRemAll.Enabled = false;
            btnDelModAddAll.Enabled = false;

            TPageDelmod delModule = new TPageDelmod(this);
            Thread tr = new Thread(new ThreadStart(delModule.DoProcess));
            cancelPressed = false;
            processFailed = false;

            txtDelModOut.Clear();
            //invokingCount = 0;
            tr.Start();

            while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
            {
                if (cancelPressed)
                {
                    //tr.Abort();
                    //OutMsg(PageType.ModuleDeletion, "Process terminated!" + Environment.NewLine);
                    OutMsg(PageType.ModuleDeletion, "Cancelling");
                    while (tr.IsAlive)
                    {
                        Application.DoEvents();
                        Thread.Sleep(300);
                        OutMsg(PageType.ModuleDeletion, ".");

                        OutMsg();

                    }
                }

                Application.DoEvents();
                OutMsg();
                //Thread.Sleep(200);
            }       

            if (!cancelPressed && !isAutoProcess)
            {
                OutMsg(PageType.ModuleDeletion, "Process ended at: " + DateTime.Now.ToShortTimeString() + ".\r\n");

                if (processFailed)
                {
                    MessageBox.Show(this, "Delete Module failed", "Module Deletion", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(this, "Delete Module done!", "Module Deletion");

                    for (int i = 0; i < this.lstDelModSel.Items.Count; i++)
                    {
                        ModuleListItem item = (ModuleListItem)lstDelModSel.Items[i];

                        lstDelModAvail.Items.Remove(item);
                    }

                    lstDelModSel.Items.Clear();
                }
            }
            else
            {
                cancelPressed = false;
                OutMsg(PageType.ModuleDeletion, "Process is cancelled at: " + DateTime.Now.ToShortTimeString() + ".\r\n");
            }

            OutMsg();

            btnDelModProcess.Visible = true;
            btnDelModCancel.Visible = false;
            btnDelModOpen.Enabled = true;
            btnDelModRemAll.Enabled = true;
            btnDelModAddAll.Enabled = true;

            OutMsg();
            isProcessing = false;
        }

        private void btnDelModCancel_Click(object sender, EventArgs e)
        {
            cancelPressed = true;
            autoProcessCancel = true;
        }

        private void btnDelStCancel_Click(object sender, EventArgs e)
        {
            cancelPressed = true;
            autoProcessCancel = true;
        }

        private void btnDelStBrowse_Click(object sender, EventArgs e)
        {
            if (isProcessing)
            {
                return;
            }

            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            try
            {
                openFileDialog1.InitialDirectory = Path.GetDirectoryName(this.txtDelStDB.Text);
            }
            catch
            {
                openFileDialog1.InitialDirectory = @"C:\";
            }

            openFileDialog1.Filter = "DB files (*.db)|*.db|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog(this) == DialogResult.OK)
            {
                this.txtDelStDB.Text = openFileDialog1.FileName;

                SaveConfig("DelStateDirectory", openFileDialog1.FileName);

                lblDelStMsg.Text = string.Empty;
                InitListModule(PageType.DeleteState);
            }
            else
            {
                if (this.txtDelStDB.Text.Trim() == string.Empty || !File.Exists(this.txtDelStDB.Text))
                {
                    this.lblDelStMsg.Text = "Invalid File!";
                }
            }
        }

        private void btnDelStProcess_Click(object sender, EventArgs e)
        {
            isProcessing = true;
            this.toolSheet.CreateTemp();

            OutMsg(PageType.DeleteState, "\r\n");
            OutMsg(PageType.DeleteState, "Process started at: " + DateTime.Now.ToShortTimeString() + ".\r\n");
            this.btnDelStProcess.Visible = false;
            this.btnDelStOpen.Enabled = false;
            this.btnDelStCancel.Visible = true;

            cancelPressed = false;
            processFailed = false;

            TPageDelState pageDelSt = new TPageDelState(this);

            //pageDelSt.DoProcess();

            Thread tr = new Thread(new ThreadStart(pageDelSt.DoProcess));
            //invokingCount = 0;
            tr.Start();

            while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
            {
                if (cancelPressed)
                {
                    OutMsg(PageType.DeleteState, "Cancelling");
                    while (tr.IsAlive)
                    {
                        Application.DoEvents();
                        Thread.Sleep(300);
                        OutMsg(PageType.DeleteState, ".");

                        OutMsg();

                    }
                    OutMsg(PageType.DeleteState, "\r\n");

                }
                Application.DoEvents();
                OutMsg();
            }

            OutMsg(PageType.DeleteState, "Process ended at: " + DateTime.Now.ToShortTimeString() + ".\r\n");
            OutMsg();

            if (!cancelPressed && !isAutoProcess)
            {
                if (processFailed)
                {
                    MessageBox.Show(this, "Delete State failed", "Delete State", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(this, "Delete State done!", "Delete State");
                }
            }
            else
            {
                cancelPressed = false;
            }

            this.btnDelStProcess.Visible = true;
            this.btnDelStOpen.Enabled = true;
            this.btnDelStCancel.Visible = false;

            isProcessing = false;
            OutMsg();
        }

        private void btnDelStOpen_Click(object sender, EventArgs e)
        {
            this.toolSheet.CreateTemp();

            btnDelStOpen.Enabled = false;
            btnDelStProcess.Enabled = false;
            processError = false;

            SetServer(PageType.DeleteState);

            if (isAutoProcess)
            {
                GetDbInfo(PageType.DeleteState);
            }
            else
            {
                Thread tr = new Thread(new ParameterizedThreadStart(GetDbInfo));
                //invokingCount = 0;
                tr.Start(PageType.DeleteState);

                while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
                {
                    Application.DoEvents();
                    OutMsg();
                    //Thread.Sleep(200);
                }
            }

            btnDelStOpen.Enabled = true;
            if (!processError)
            {
                btnDelStProcess.Enabled = true;
            }
            else
            {
                processError = false;
            }
            OutMsg();
        }

        private void frmMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            SaveConfig("MergeState_StateRootDir", txtMergeSTSateRoot.Text.Trim());
            SaveConfig("MergeState_ModuleRootDir", txtMergeSTModuleRoot.Text.Trim());
        }

        private void btnLdCancel_Click(object sender, EventArgs e)
        {
            cancelPressed = true;
            autoProcessCancel = true;
        }

        private void btnMergeSTOpen_Click(object sender, EventArgs e)
        {
            btnMergeSTOpen.Enabled = false;
            btnMergeSTProcess.Enabled = false;
            processError = false;

            SetServer(PageType.MergeState);

            if (isAutoProcess)
            {
                GetDbInfo(PageType.MergeState);
            }
            else
            {
                Thread tr = new Thread(new ParameterizedThreadStart(GetDbInfo));
                //invokingCount = 0;
                tr.Start(PageType.MergeState);

                while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
                {
                    Application.DoEvents();
                    OutMsg();
                    //Thread.Sleep(200);
                }
            }

            if (!processError)
            {
                //btnMergeSTProcess.Enabled = true;
                EnableMergeStButton();
            }
            else
            {
                processError = false;
            }
            btnMergeSTOpen.Enabled = true;
            Application.DoEvents();
            //  RefreshPage();
            OutMsg();
        }

        private void btnMergeSTCancel_Click(object sender, EventArgs e)
        {
            cancelPressed = true;
            autoProcessCancel = true;
        }

        internal string msg = "";
        internal bool NeedMessage = false;
        internal DialogResult msgResult = DialogResult.None;

        internal void ClearMsgRequest()
        {
            //string msg = "";
            //bool NeedMessage = false;
            //DialogResult msgResult = DialogResult.None;
        }

        private void btnMergeSTProcess_Click(object sender, EventArgs e)
        {
            lblMergeStMsg.Text = "";
            this.btnMergeSTOpen_Click(this, null);

            Application.DoEvents();

            if (txtMergeSTVer.Text.Trim() == "")
            {
                lblMergeStMsg.Text = "Can't open the DB!";
                processError = true;
                return;
            }

            isProcessing = true;
            this.toolSheet.CreateTemp();

            OutMsg(PageType.MergeState, "\r\n");
            OutMsg(PageType.MergeState, "Process started at: " + DateTime.Now.ToShortTimeString() + ".\r\n");

            this.chkMergeSynCheck.Enabled = false;
            this.btnMergeSTRemove.Enabled = false;
            this.btnMergeSTAdd.Enabled = false;
            this.btnMergeSTAddAll.Enabled = false;
            this.btnMergeSTRemoveAll.Enabled = false;
            this.btnMergeSTProcess.Visible = false;
            this.btnMergeSTCancel.Visible = true;
            this.btnMergeSTOpen.Enabled = false;
            this.btnMergeSTConfig.Enabled = false;

            cancelPressed = false;
            processFailed = false;
            processStatus = ProcessStatus.Done;

            ClearMsgRequest();

            TPageMergeState pageMergeState = new TPageMergeState(this);
            pageMergeState.MessageShow += new MessageCallBack(DisplayMessageBox);
            //pageMergeState.DoProcess();

            Thread tr = new Thread(new ThreadStart(pageMergeState.DoProcess));
            //invokingCount = 0;
            tr.Start();

            while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
            {
                if (cancelPressed)
                {
                    //tr.Abort();
                    msgQueue.Clear();
                    OutMsg(PageType.MergeState, "Cancelling");

                    while (tr.IsAlive)
                    {
                        Application.DoEvents();
                        OutMsg(PageType.MergeState, ".");
                        OutMsg();

                        Thread.Sleep(300);
                    }
                    OutMsg(PageType.MergeState, "\r\n");

                    //break;
                }
                Application.DoEvents();

                OutMsg();

            }

            pageMergeState = null;
            GC.Collect();

            OutMsg(PageType.MergeState, "Process ended at: " + DateTime.Now.ToShortTimeString() + ".\r\n");
            OutMsg();

            if (processFailed && isAutoProcess)
            {
                MessageBox.Show(this, "Merge State failed in AutoProcess!", "Merge State", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            if (!cancelPressed && !isAutoProcess)
            {
                if (processFailed)
                {
                    if (processStatus == ProcessStatus.Exit)
                    {
                        MessageBox.Show(this, "Merge State Exit!", "Merge State", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show(this, "Merge State failed!", "Merge State", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show(this, "Merge State done!", "Merge State");
                }
            }
            else
            {
                cancelPressed = false;
            }

            this.chkMergeSynCheck.Enabled = true;
            this.btnMergeSTRemove.Enabled = true;
            this.btnMergeSTAdd.Enabled = true;
            this.btnMergeSTAddAll.Enabled = true;
            this.btnMergeSTRemoveAll.Enabled = true;
            this.btnMergeSTProcess.Visible = true;
            this.btnMergeSTCancel.Visible = false;
            this.btnMergeSTOpen.Enabled = true;
            this.btnMergeSTConfig.Enabled = true;
            this.EnableMergeStButton();
            isProcessing = false;

            OutMsg();
        }

        private void GetDbInfo(object obj)
        {
            DataSql _data = null;

            PageType pType = (PageType)obj;
            CSQLDBUI m_DBUI = null;

            SetServer(pType);
            _data = new DataSql(SQLServer, SQLDB, SQLUser, SQLPW);

            try
            {
                _data.Open();
                m_DBUI = new CSQLDBUI(this);

                string TmpStr = string.Empty;
                switch (m_DBUI.DBType)
                {
                    case CSQLDBUI.eDBType.ModuleDev:
                        TmpStr = "Module (Development) ";
                        break;
                    case CSQLDBUI.eDBType.ModuleRT:
                        TmpStr = "Module (Run-Time) ";
                        break;
                    case CSQLDBUI.eDBType.Audit:
                        TmpStr = "Audit Session ";
                        break;
                    case CSQLDBUI.eDBType.Other:
                        if (m_DBUI.DBVersionSN == "")
                        {
                            TmpStr = "Not Regulatory Database";
                        }
                        else
                        {
                            //TmpStr = "DakRef ";
                        }
                        break;
                    default:
                        break;
                }

                TmpStr += m_DBUI.DBVersionSN;

                if (m_DBUI.DBCurrentSN != "" && TmpStr != m_DBUI.DBVersionSN)
                {
                    TmpStr += " - VSN " + m_DBUI.DBCurrentSN;
                }
                //OutVer(pType, TmpStr);

                if (pType != PageType.DakrefTaget && pType != PageType.Upload && pType != PageType.ConfigRestore && pType != PageType.ConfigBackup)
                //if (pType != PageType.ConfigBackup && pType != PageType.ConfigRestore)
                {
                    switch (m_DBUI.DBStatus)
                    {
                        case CSQLDBUI.eDBStatus.DuplicatedKeys:
                            OutMsg(pType, "There are dulicated keys in some tables." + Environment.NewLine);
                            TmpStr = "";
                            break;
                        case CSQLDBUI.eDBStatus.MissingTables:
                            OutMsg(pType, "Some tables are missing in this database." + Environment.NewLine);
                            TmpStr = "";
                            break;
                        default:
                            break;
                    }
                }

                OutVer(pType, TmpStr);

                switch (pType)
                {
                    case PageType.ModuleDeletion:
                    case PageType.VewDB:
                        CMModuleSet MModule = new CMModuleSet("Module");// DSNName, SybaseUser, SybasePW);
                        ListRefresh(MModule, pType);
                        break;
                    default:
                        break;
                }

                _data.Close();
            }
            catch (Exception e)
            {
                OutMsg(pType, e.Message + Environment.NewLine);
                processError = true;
            }
        }

        private void btnMergeSTAdd_Click(object sender, EventArgs e)
        {
            string[] delItems = new string[lstMergeSTAvaiSt.SelectedItems.Count];

            for (int i = 0; i < this.lstMergeSTAvaiSt.SelectedItems.Count; i++)
            {
                string item = (string)lstMergeSTAvaiSt.SelectedItems[i];

                if (this.lstMergeSTStates.FindStringExact(item) == ListBox.NoMatches)
                {
                    lstMergeSTStates.Items.Add(item);
                }

                delItems[i] = item;
            }

            foreach (string str in delItems)
            {
                lstMergeSTAvaiSt.Items.Remove(str);
            }

            lstMergeSTStates.Sorted = true;

            EnableMergeStButton();
        }

        private void btnMergeSTRemove_Click(object sender, EventArgs e)
        {
            string[] delItems = new string[lstMergeSTStates.SelectedItems.Count];
            for (int i = 0; i < lstMergeSTStates.SelectedItems.Count; i++)
            {
                delItems[i] = (string)lstMergeSTStates.SelectedItems[i];
            }

            foreach (string str in delItems)
            {
                lstMergeSTStates.Items.Remove(str);

                if (lstMergeSTAvaiSt.FindStringExact(str) == ListBox.NoMatches)
                {
                    lstMergeSTAvaiSt.Items.Add(str);
                }
            }

            lstMergeSTAvaiSt.Sorted = true;

            EnableMergeStButton();
        }

        private void btnMergeSTAddAll_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lstMergeSTAvaiSt.Items.Count; i++)
            {
                string item = (string)lstMergeSTAvaiSt.Items[i];

                if (lstMergeSTStates.FindStringExact(item.ToString()) == ListBox.NoMatches)
                {
                    lstMergeSTStates.Items.Add(item);
                }
            }

            lstMergeSTAvaiSt.Items.Clear();
            lstMergeSTStates.Sorted = true;

            EnableMergeStButton();
        }

        private void btnMergeSTRemoveAll_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lstMergeSTStates.Items.Count; i++)
            {
                string item = lstMergeSTStates.Items[i].ToString();

                if (lstMergeSTAvaiSt.FindStringExact(item) == ListBox.NoMatches)
                {
                    lstMergeSTAvaiSt.Items.Add(item);
                }
            }

            lstMergeSTAvaiSt.Sorted = true;
            lstMergeSTStates.Items.Clear();

            EnableMergeStButton();
        }

        private void txtMergeSTSateRoot_TextChanged(object sender, EventArgs e)
        {
            if (Directory.Exists(this.txtMergeSTSateRoot.Text))
            {
                SaveConfig("MergeState_StateRootDir", this.txtMergeSTSateRoot.Text);

                lblMergeSTSateRoot.Text = string.Empty;
            }
            else
            {
                lblMergeSTSateRoot.Text = "Invalid Directory!";
            }

            RefreshPage();
        }

        private void txtMergeSTDate_TextChanged(object sender, EventArgs e)
        {
            EnableControlMergeSt();
            EnableMergeStButton();
        }

        private void InitListState()
        {
            // First, empty the list of available modules.
            // Empty the list of modules to delete.
            lstMergeSTAvaiSt.Items.Clear();
            lstMergeSTStates.Items.Clear();

            // Get the list of available states from the State Root Directory.
            string DirState = txtMergeSTSateRoot.Text.Trim();

            // First, see if this directory exists.
            if (!Directory.Exists(DirState))
            {
                return;
            }
            // Now, get the list of sub-directories.  The right directories would be two characters long (state postal code).
            //struct ffblk  fBlock;

            // FA_DIREC indicates to search only for directories.
            //if (findfirst ((DirState + "\\*.*").c_str (), &fBlock, FA_DIREC) == -1) return;

            string[] dirs = Directory.GetDirectories(DirState);

            foreach (string SubDir in dirs)
            {
                string dirName = SubDir;
                int pos = SubDir.LastIndexOf('\\');
                if (pos > -1)
                {
                    dirName = SubDir.Substring(pos + 1);
                }

                if (dirName.Trim(new char[] { ' ' }).Length == 2 && dirName != "..")
                {
                    lstMergeSTAvaiSt.Items.Add(dirName.Trim(new char[] { ' ' }).ToUpper());
                    //m_pStateAvailable. (SubDir.c_str ());
                }

            } //while (findnext (&fBlock) == 0);

            lstMergeSTAvaiSt.Sorted = true;
            EnableMergeStButton();
        }
        //******************************************************************
        private bool CheckDate(TextBox TBox)
        {
            if (!UTIL.IsADate(TBox.Text.Trim()))
            {
                MessageBox.Show(this, "The Research Date is not valid.");
                TBox.Focus();
                return false;
            }

            return true;
        }

        private void CheckDirMergeSt()
        {
            string DirModule = txtMergeSTModuleRoot.Text.Trim();

            if (DirModule != string.Empty)
            {
                if (!Directory.Exists(DirModule))
                {
                    OutMsg(PageType.MergeState, DirModule + " doesn't exist.\r\n");
                    //DisplayMessage(DirModule + " doesn't exist.");
                    txtMergeSTModuleRoot.Focus();
                    return;
                }
            }

            string DirState = txtMergeSTSateRoot.Text.Trim();
            if (DirState != string.Empty)
            {
                if (!Directory.Exists(DirState))
                {
                    OutMsg(PageType.MergeState, DirState + " doesn't exist.\r\n");
                    //DisplayMessage(DirState + " doesn't exist.");
                    txtMergeSTSateRoot.Focus();
                    return;
                }
                string fileName = string.Empty;

                if (DirState.EndsWith("\\"))
                {
                    fileName = DirState + "BlrTitle.txt";
                }
                else
                {
                    fileName = DirState + "\\BlrTitle.txt";
                }
                if (!File.Exists(fileName))
                {
                    OutMsg(PageType.MergeState, fileName + " doesn't exist.\r\n");
                    txtMergeSTSateRoot.Focus();
                    //SetFocusDlgField(this, IDC_DIRSTATE);
                    return;
                }

                if (DirState.EndsWith("\\"))
                {
                    fileName = DirState + "DADomain.txt";
                }
                else
                {
                    fileName = DirState + "\\DADomain.txt";
                }
                if (!File.Exists(fileName))
                {
                    OutMsg(PageType.MergeState, fileName + " doesn't exis.\r\n");
                    txtMergeSTSateRoot.Focus();
                    //SetFocusDlgField(this, IDC_DIRSTATE);
                    return;
                }
                EnableControlMergeSt();
                EnableMergeStButton();
            }
        }
        private void EnableControlMergeSt()
        {
            if (this.txtMergeSTDate.Text.Trim() == string.Empty && this.txtMergeSTVer.Text != string.Empty)
            {
                // Set the State Research Date to the last federal Research Date as a default.
                DataSql sqlbase = new DataSql(txtMergeSTServer.Text, txtMergeSTDB.Text, SQLUser, SQLPW);
                sqlbase.Open();
                CMModuleVersionSet MModuleVersion = new CMModuleVersionSet("ModuleVersion");
                //"DAResearchDate"
                MModuleVersion.SelectDAResearchDateVersion();
                if (MModuleVersion.FetchNext() != EnumSQLError.DB_NOTFOUND)
                {
                    string sDate = MModuleVersion.GetResearchDate().ToString();// reader.GetString(3);

                    try
                    {
                        int yyyy = int.Parse(sDate.Substring(0, 4));
                        int mm = int.Parse(sDate.Substring(4, 2));
                        int dd = int.Parse(sDate.Substring(6, 2));

                        DateTime dt = new DateTime(yyyy, mm, dd);
                        this.txtMergeSTDate.Text = dt.ToShortDateString();
                    }
                    catch
                    { }
                }
                MModuleVersion.ClearAllFields();
                sqlbase.Close();
            }
        }

        //******************************************************************
        private void RefreshPage()
        {
            // Refresh the list of available modules.
            InitListState();
        }

        private void lstMergeSTAvaiSt_SelectedIndexChanged(object sender, EventArgs e)
        {
            EnableMergeStButton();
        }

        private void lstMergeSTStates_SelectedIndexChanged(object sender, EventArgs e)
        {
            EnableMergeStButton();
        }

        private void txtMergeSTSateRoot_Leave(object sender, EventArgs e)
        {
            CheckDirMergeSt();
            RefreshPage();
        }

        private void txtMergeSTDate_Leave(object sender, EventArgs e)
        {
            CheckDate(txtMergeSTDate);
            EnableControlMergeSt();
        }

        private void EnableMergeStButton()
        {
            btnMergeSTProcess.Enabled = (lstMergeSTStates.Items.Count > 0) &&
                                        (txtMergeSTSateRoot.Text.Trim() != string.Empty) &&
                                        (txtMergeSTModuleRoot.Text.Trim() != string.Empty) &&
                                        (txtMergeSTVer.Text.Trim() != string.Empty) &&
                                        (txtMergeSTDate.Text.Trim() != string.Empty);
            btnMergeSTAdd.Enabled = (lstMergeSTAvaiSt.SelectedItems.Count > 0);
            btnMergeSTRemove.Enabled = (lstMergeSTStates.SelectedItems.Count > 0);
        }

        private void txtMergeSTModuleRoot_TextChanged(object sender, EventArgs e)
        {
            if (Directory.Exists(this.txtMergeSTModuleRoot.Text))
            {
                SaveConfig("MergeState_ModuleRootDir", this.txtMergeSTModuleRoot.Text);

                lblMergeSTModuleRoot.Text = string.Empty;
            }
            else
            {
                lblMergeSTModuleRoot.Text = "Invalid Directory!";
            }
        }

        private void txtMergeSTModuleRoot_Leave(object sender, EventArgs e)
        {
            EnableMergeStButton();
        }

        private void lstMergeSTAvaiSt_DoubleClick(object sender, EventArgs e)
        {
            string[] delItems = new string[lstMergeSTAvaiSt.SelectedItems.Count];
            for (int i = 0; i < lstMergeSTAvaiSt.SelectedItems.Count; i++)
            {
                string item = (string)lstMergeSTAvaiSt.SelectedItems[i];

                if (this.lstMergeSTStates.FindStringExact(item) == ListBox.NoMatches)
                {
                    lstMergeSTStates.Items.Add(item);
                }

                delItems[i] = item;
            }

            foreach (string str in delItems)
            {
                lstMergeSTAvaiSt.Items.Remove(str);
            }

            lstMergeSTStates.Sorted = true;

            EnableMergeStButton();
        }

        private void lstMergeSTStates_DoubleClick(object sender, EventArgs e)
        {
            string[] delItems = new string[lstMergeSTStates.SelectedItems.Count];
            for (int i = 0; i < lstMergeSTStates.SelectedItems.Count; i++)
            {
                delItems[i] = (string)lstMergeSTStates.SelectedItems[i];
            }

            foreach (string str in delItems)
            {
                lstMergeSTStates.Items.Remove(str);

                if (lstMergeSTAvaiSt.FindStringExact(str) == ListBox.NoMatches)
                {
                    lstMergeSTAvaiSt.Items.Add(str);
                }

            }

            lstMergeSTAvaiSt.Sorted = true;

            EnableMergeStButton();
        }

        private void btnMergeFMasterOpen_Click(object sender, EventArgs e)
        {
            btnMergeFMasterOpen.Enabled = false;
            btnMergeFModuleOpen.Enabled = false;
            btnMergeFProcess.Enabled = false;
            processError = false;

            SetServer(PageType.MergeFederalMaster);

            if (isAutoProcess)
            {
                GetDbInfo(PageType.MergeFederalMaster);
            }
            else
            {
                Thread tr = new Thread(new ParameterizedThreadStart(GetDbInfo));
                //invokingCount = 0;
                tr.Start(PageType.MergeFederalMaster);

                while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
                {
                    Application.DoEvents();
                    OutMsg();
                    //Thread.Sleep(200);
                }
            }

            if (!processError)
            {
                btnMergeFProcess.Enabled = true;
            }
            else
            {
                processError = false;
            }
            btnMergeFMasterOpen.Enabled = true;
            btnMergeFModuleOpen.Enabled = true;
            Application.DoEvents();
            EnableMergeFdButton();
            OutMsg();
        }

        private void btnMergeFModuleOpen_Click(object sender, EventArgs e)
        {
            btnMergeFMasterOpen.Enabled = false;
            btnMergeFModuleOpen.Enabled = false;
            btnMergeFProcess.Enabled = false;
            processError = false;

            SetServer(PageType.MergeFederalModule);

            if (isAutoProcess)
            {
                GetDbInfo(PageType.MergeFederalModule);
            }
            else
            {
                //GetDbInfo(PageType.MergeFederalModule);
                Thread tr = new Thread(new ParameterizedThreadStart(GetDbInfo));
                //invokingCount = 0;
                tr.Start(PageType.MergeFederalModule);

                while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
                {
                    Application.DoEvents();
                    OutMsg();
                    //Thread.Sleep(200);
                }
            }

            if (!processError)
            {
                btnMergeFProcess.Enabled = true;
            }
            else
            {
                processError = false;
            }
            btnMergeFMasterOpen.Enabled = true;
            btnMergeFModuleOpen.Enabled = true;
            Application.DoEvents();
            EnableMergeFdButton();
            OutMsg();
        }

        private void btnMergeFProcess_Click(object sender, EventArgs e)
        {
            lblMergeFMasterMsg.Text = "";
            btnMergeFMasterOpen_Click(this, null);

            lblMergeFModuleMsg.Text = "";
            btnMergeFModuleOpen_Click(this, null);

            Application.DoEvents();

            if (txtMergeFMasterVer.Text.Trim() == "")
            {
                lblMergeFMasterMsg.Text = "Can't open the Master DB!";
                processError = true;
                return;
            }

            if (txtMergeFModuleVer.Text.Trim() == "")
            {
                lblMergeFModuleMsg.Text = "Can't open the Module DB!";
                processError = true;
                return;
            }

            isProcessing = true;
            this.toolSheet.CreateTemp();

            OutMsg(PageType.MergeFederal, "\r\n");
            OutMsg(PageType.MergeFederal, "Process started at: " + DateTime.Now.ToShortTimeString() + ".\r\n");

            btnMergeFMasterOpen.Enabled = false;
            btnMergeFModuleOpen.Enabled = false;
            btnMergeFProcess.Visible = false;
            btnMergeFCancel.Visible = true;

            //btnMergeFMMasterConfig.Enabled = false;
            //btnMergeFMModuleConfig.Enabled = false;

            cancelPressed = false;
            processFailed = false;

            TPageMergeFederal pageMergeFederal = new TPageMergeFederal(this);

            //pageMergeFederal.DoProcess();

            Thread tr = new Thread(new ThreadStart(pageMergeFederal.DoProcess));
            //invokingCount = 0;
            tr.Start();

            while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
            {
                if (cancelPressed)
                {
                    //tr.Abort();

                    OutMsg(PageType.MergeFederal, ".");
                    while (tr.IsAlive)
                    {
                        Application.DoEvents();
                        OutMsg(PageType.MergeFederal, ".");
                        OutMsg();
                        Thread.Sleep(300);
                    }
                    OutMsg(PageType.MergeFederal, ".");

                    //break;
                }
                Application.DoEvents();
                OutMsg();
            }

            OutMsg(PageType.MergeFederal, "Process ended at: " + DateTime.Now.ToShortTimeString() + ".\r\n");
            OutMsg();

            if (processFailed && isAutoProcess)
            {
                MessageBox.Show(this, "Merge Federal failed in AutoProcess!", "Merge Federal", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            if (!cancelPressed && !isAutoProcess)
            {
                if (processFailed)
                {
                    MessageBox.Show(this, "Merge Federal failed", "Merge Federal", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(this, "Merge Federal done!", "Merge Fedreal");
                }
            }
            else
            {
                cancelPressed = false;
            }

            btnMergeFMasterOpen.Enabled = true;
            btnMergeFModuleOpen.Enabled = true;
            btnMergeFProcess.Visible = true;
            btnMergeFCancel.Visible = false;

            //btnMergeFMMasterConfig.Enabled = true;
            //btnMergeFMModuleConfig.Enabled = true;

            isProcessing = false;

            pageMergeFederal = null;
            GC.Collect();
            OutMsg();
        }

        private void txtDateDA_Leave(object sender, EventArgs e)
        {
            CheckDate(this.txtDateDA);
        }

        private void txtDateSC_Leave(object sender, EventArgs e)
        {
            CheckDate(this.txtDateSC);
        }

        private void EnableMergeFdButton()
        {
            btnMergeFProcess.Enabled = (txtVNameSC.Text.Trim() != string.Empty) &&
                                        (txtVNameDA.Text.Trim() != string.Empty) &&
                                        (txtMergeFMasterVer.Text.Trim() != string.Empty) &&
                                        (txtMergeFModuleVer.Text.Trim() != string.Empty);
        }

        private void EnableBlobButton()
        {
            btnBlobsProcess.Enabled = (txtBlobsVer.Text.Trim() != string.Empty);
        }
        private void txtVNameDA_Leave(object sender, EventArgs e)
        {
            EnableMergeFdButton();
        }

        private void txtVNameSC_Leave(object sender, EventArgs e)
        {
            EnableMergeFdButton();
        }

        private void btnBlobsOpen_Click(object sender, EventArgs e)
        {
            btnBlobsOpen.Enabled = false;
            btnBlobsProcess.Enabled = false;
            processError = false;

            SetServer(PageType.BlobsCreation);

            if (isAutoProcess)
            {
                GetDbInfo(PageType.BlobsCreation);
            }
            else
            {
                Thread tr = new Thread(new ParameterizedThreadStart(GetDbInfo));
                //invokingCount = 0;
                tr.Start(PageType.BlobsCreation);

                while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
                {
                    Application.DoEvents();
                    OutMsg();
                    //Thread.Sleep(200);
                }
            }

            if (!processError)
            {
                btnBlobsProcess.Enabled = true;
            }
            else
            {
                processError = false;
            }

            btnBlobsOpen.Enabled = true;

            btnBlobsProcess.Enabled = (txtBlobsVer.Text.Trim() != "");
            //btnBlobsProcess.Enabled = true;
            OutMsg();
        }

        private void btnBlobsProcess_Click(object sender, EventArgs e)
        {
            lblBlobsMsg.Text = "";
            btnBlobsOpen_Click(this, null);

            Application.DoEvents();

            if (txtBlobsVer.Text.Trim() == "")
            {
                lblBlobsMsg.Text = "Can't open the DB!";
                processError = true;
                return;
            }

            isProcessing = true;

            this.toolSheet.CreateTemp();
            //this.txtBlobsOut.Text = string.Empty;
            OutMsg(PageType.BlobsCreation, "\r\n");
            OutMsg(PageType.BlobsCreation, "Process started at: " + DateTime.Now.ToShortTimeString() + ".\r\n");

            btnBlobsOpen.Enabled = false;
            btnBlobsProcess.Visible = false;
            btnBlobsCancel.Visible = true;

            cancelPressed = false;
            processFailed = false;

            TPageBlobit pageBlobit = new TPageBlobit(this);

            //pageBlobit.DoProcess();

            Thread tr = new Thread(new ThreadStart(pageBlobit.DoProcess));
            //tr.Priority = ThreadPriority.Highest;
            //invokingCount = 0;
            tr.Start();

            while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
            {
                if (cancelPressed)
                {
                    //tr.Abort();

                    OutMsg(PageType.BlobsCreation, "\r\nCancelling");
                    while (tr.IsAlive)
                    {
                        Application.DoEvents();
                        OutMsg(PageType.BlobsCreation, ".");
                        Thread.Sleep(300);
                    }
                    OutMsg(PageType.BlobsCreation, "\r\n");

                    //break;
                }
                Application.DoEvents();
                OutMsg();
            }

            OutMsg(PageType.BlobsCreation, "Process ended at: " + DateTime.Now.ToShortTimeString() + ".\r\n");
            OutMsg();

            if (processFailed && isAutoProcess)
            {
                MessageBox.Show(this, "Blobs Creation failed in AutoProcess!", "Blob Creation", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            if (!cancelPressed && !isAutoProcess)
            {
                if (processFailed)
                {
                    MessageBox.Show(this, "Blobs Creation failed", "Blob Creation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(this, "Blobs Creation done!", "Blob Creation");
                }
            }
            else
            {
                cancelPressed = false;
            }

            btnBlobsOpen.Enabled = true;
            btnBlobsProcess.Visible = true;
            btnBlobsCancel.Visible = false;

            isProcessing = false;

            pageBlobit = null;
            GC.Collect();
            OutMsg();
        }

        private void btnBlobsCancel_Click(object sender, EventArgs e)
        {
            cancelPressed = true;
            autoProcessCancel = true;
        }

        private void btnAutoCancel_Click(object sender, EventArgs e)
        {
            cancelPressed = true;
            autoProcessCancel = true;
        }

        internal bool isAutoProcess = false;
        private void btnAutoProcess_Click(object sender, EventArgs e)
        {
            isAutoProcess = true;
            autoProcessCancel = false;
            cancelPressed = false;
            cobStartStep.Enabled = false;

            bool blCorrectParameter = true;

            btnAutoProcess.Enabled = false;
            btnAutoCancel.Enabled = !btnAutoProcess.Enabled;

            if (cobStartStep.SelectedIndex < 1)
            {
                if (txtBuildREMDir.Text.Trim() == "" || !Directory.Exists(txtBuildREMDir.Text))
                {
                    blCorrectParameter = false;
                    OutMsg(PageType.AutoProcess, "Incorrect Directory in tab Build REM Files!" + Environment.NewLine);
                }

                if (colFiles.Count == 0)
                {
                    blCorrectParameter = false;
                    OutMsg(PageType.AutoProcess, "No sub directory(s) involved in tab Build REM Files!" + Environment.NewLine);
                }
            }

            if (cobStartStep.SelectedIndex < 2)
            {
                if (lstModuleSel.Items.Count == 0)
                {
                    blCorrectParameter = false;
                    OutMsg(PageType.AutoProcess, "No module selected in tab Build Module DB!" + Environment.NewLine);
                }

                if (this.txtModuleServer.Text.Trim() == "" || this.txtModuleDB.Text.Trim() == "")
                {
                    blCorrectParameter = false;
                    OutMsg(PageType.AutoProcess, "Empty Sever/DB name in tab Build Module DB!" + Environment.NewLine);
                }
            }

            if (cobStartStep.SelectedIndex < 8)
            {
                if (this.txtMergeFMMasterDB.Text.Trim() == "" || this.txtMergeFMMasterServer.Text.Trim() == "")
                {
                    blCorrectParameter = false;
                    OutMsg(PageType.AutoProcess, "Empty Sever/DB name for Master Modules in tab Merge Federal!" + Environment.NewLine);
                }

                if (txtVNameDA.Text.Trim() == "" || txtVNameSC.Text.Trim() == "")
                {
                    blCorrectParameter = false;
                    OutMsg(PageType.AutoProcess, "Empty version name in tab Merge Federal!" + Environment.NewLine);
                }

                if (txtDateDA.Text.Trim() == "" || txtDateSC.Text.Trim() == "")
                {
                    blCorrectParameter = false;
                    OutMsg(PageType.AutoProcess, "Empty research date in tab Merge Federal!" + Environment.NewLine);
                }
            }

            if (cobStartStep.SelectedIndex < 13)
            {
                if (lstMergeSTStates.Items.Count == 0)
                {
                    blCorrectParameter = false;
                    OutMsg(PageType.AutoProcess, "No state selected in tab Merge State!" + Environment.NewLine);
                }

                if (txtMergeSTDate.Text.Trim() == "")
                {
                    blCorrectParameter = false;
                    OutMsg(PageType.AutoProcess, "No reaeach date input in tab Merge State!" + Environment.NewLine);
                }

                if (!Directory.Exists(txtMergeSTModuleRoot.Text))
                {
                    blCorrectParameter = false;
                    OutMsg(PageType.AutoProcess, "Module Root Directory in tab Merge State not existing!" + Environment.NewLine);
                }

                if (!Directory.Exists(txtMergeSTSateRoot.Text))
                {
                    blCorrectParameter = false;
                    OutMsg(PageType.AutoProcess, "State Root Directory in tab Merge State not existing!" + Environment.NewLine);
                }
            }

            if (!blCorrectParameter)
            {
                OutMsg(PageType.AutoProcess, "Some parameters are missing!" + Environment.NewLine);
                MessageBox.Show(this, "Some parameters are missing!", "Auto Process");

                ResetAutoStatus();

                OutMsg();
                return;
            }

            OutMsg(PageType.AutoProcess, Environment.NewLine);
            OutMsg(PageType.AutoProcess, "Auto process starting at: "
                    + DateTime.Now.ToShortTimeString() + Environment.NewLine);
            InitLogwindows();

            DataSql sybase = new DataSql();

            DataSet ds = null;
            string tagFolder = string.Empty;
            string tagPath = string.Empty;

            if (cobStartStep.SelectedIndex < 1)
            {
                OutMsg(PageType.AutoProcess, "Step 1: Building REM files." + Environment.NewLine);
                tabControl.SelectedTab = tbPgBuildREM;
                btnProcess_Click(this, new EventArgs());
                if (CheckProcessStatus(PageType.BuildREM))
                {
                    ResetAutoStatus();
                    return;
                }

                txtModuleDir.Text = txtBuildREMDir.Text;
            }

            if (cobStartStep.SelectedIndex < 2)
            {
                OutMsg(PageType.AutoProcess, "Step 2: Building Module DB." + Environment.NewLine);
                tabControl.SelectedTab = tbPgBuildMODULE;

                if (!Directory.Exists(txtModuleDir.Text))
                {
                    OutMsg(PageType.AutoProcess, "Module root directory not existing in Building Module DB." + Environment.NewLine);
                    ResetAutoStatus();
                    return;
                }

                btnModuleStart_Click(this, new EventArgs());
                if (CheckProcessStatus(PageType.BuildMODULE))
                {
                    ResetAutoStatus();
                    return;
                }
            }
            //return;
            if (cobStartStep.SelectedIndex < 3)
            {
                tabControl.SelectedTab = tbPgAutoProcess;
                OutMsg(PageType.AutoProcess, "Step 3: Fix av collision." + Environment.NewLine);

                btnModuleOpen_Click(this, new EventArgs());
                Application.DoEvents();
                if (this.txtModuleVer.Text.Trim() == "")
                {
                    tabControl.SelectedTab = tbPgAutoProcess;
                    OutMsg(PageType.AutoProcess, "DB can't be opened in Step 3: Fix av collision." + Environment.NewLine);

                    ResetAutoStatus();
                    return;
                }

                sybase.callBack += new DataSql.Display(autoprocess_callBack);

                sybase.SetServer(txtModuleServer.Text, txtModuleDB.Text, ModuleUser, ModulePW);
                sybase.Open();
                sybase.RunSQL(Query.Fix_av_collision_rev3);
                sybase.Close();

                txtBlobsServer.Text = txtModuleServer.Text;
                txtBlobsDB.Text = txtModuleDB.Text;
                BlobUser = ModuleUser;
                BlobPW = ModulePW;
            }

            if (cobStartStep.SelectedIndex < 4)
            {

                OutMsg(PageType.AutoProcess, "Step 4: Blob DB." + Environment.NewLine);
                tabControl.SelectedTab = tbPgBlobsCreat;

                optAllTheBlobs.Checked = true;
                //btnBlobsOpen_Click(this, new EventArgs());
                //if (txtBlobsVer.Text.Trim() == "")
                //{
                //    tabControl.SelectedTab = tbPgAutoProcess;
                //    OutMsg(PageType.AutoProcess, "DB can't be opened in Step 4: Blob DB." + Environment.NewLine);
                //    MessageBox.Show("DB can't be opened!");

                //    ResetAutoStatus();
                //    return;
                //}

                btnBlobsProcess_Click(this, new EventArgs());
                if (CheckProcessStatus(PageType.BlobsCreation))
                {
                    ResetAutoStatus();
                    return;
                }

            }

            if (cobStartStep.SelectedIndex < 5)
            {
                OutMsg(PageType.AutoProcess, "Step 5: Dup appsn." + Environment.NewLine);

                btnBlobsOpen_Click(this, new EventArgs());
                Application.DoEvents();
                if (txtBlobsVer.Text.Trim() == "")
                {
                    tabControl.SelectedTab = tbPgAutoProcess;
                    OutMsg(PageType.AutoProcess, "DB can't be opened in Step 5: Dup appsn." + Environment.NewLine);

                    ResetAutoStatus();
                    return;
                }

                sybase.SetServer(txtBlobsServer.Text, txtBlobsDB.Text, BlobUser, BlobPW);
                sybase.Open();
                ds = sybase.GetDataSet(Query.duplicateappsn2);
                sybase.Close();
                DisplayData(ds);
            }

            if (cobStartStep.SelectedIndex < 6)
            {
                OutMsg(PageType.AutoProcess, "Step 6: Look For Duplicate Question Link Text." + Environment.NewLine);

                btnBlobsOpen_Click(this, new EventArgs());
                Application.DoEvents();
                if (txtBlobsVer.Text.Trim() == "")
                {
                    tabControl.SelectedTab = tbPgAutoProcess;
                    OutMsg(PageType.AutoProcess, "DB can't be opened in Step 6: Look For Duplicate Question Link Text." + Environment.NewLine);

                    ResetAutoStatus();
                    return;
                }

                sybase.SetServer(txtBlobsServer.Text, txtBlobsDB.Text, BlobUser, BlobPW);
                sybase.Open();
                sybase.RunSQL(Query.LookForDuplicateQuestionLinkText1);
                ds = sybase.GetDataSet(Query.LookForDuplicateQuestionLinkText2);
                sybase.Close();
                DisplayData(ds);
            }

            if (cobStartStep.SelectedIndex < 7)
            {
                OutMsg(PageType.AutoProcess, "Step 7: Missing Link." + Environment.NewLine);

                btnBlobsOpen_Click(this, new EventArgs());
                Application.DoEvents();
                if (txtBlobsVer.Text.Trim() == "")
                {
                    tabControl.SelectedTab = tbPgAutoProcess;
                    OutMsg(PageType.AutoProcess, "DB can't be opened in Step 6: Missing Link." + Environment.NewLine);

                    ResetAutoStatus();
                    return;
                }

                sybase.SetServer(txtBlobsServer.Text, txtBlobsDB.Text, BlobUser, BlobPW);
                sybase.Open();
                ds = sybase.GetDataSet(Query.MissingLink);
                sybase.Close();
                DisplayData(ds);

                txtMergeFMModuleServer.Text = txtBlobsServer.Text;
                txtMergeFMModuleDB.Text = txtBlobsDB.Text;
                MergeFMModuleUser = BlobUser;
                MergeFMModulePW = BlobPW;
            }

            if (cobStartStep.SelectedIndex < 8)
            {
                OutMsg(PageType.AutoProcess, "Step 8: Merge Federal." + Environment.NewLine);
                tabControl.SelectedTab = tbPgMergFederal;

                //btnMergeFMasterOpen_Click(this, new EventArgs());
                //btnMergeFModuleOpen_Click(this, new EventArgs());

                //if (txtMergeFMasterVer.Text.Trim() == "" || txtMergeFModuleVer.Text.Trim() == "")
                //{
                //    tabControl.SelectedTab = tbPgAutoProcess;
                //    OutMsg(PageType.AutoProcess, "DB can't be opened in Step 8: Merge Federal." + Environment.NewLine);
                //    MessageBox.Show("DB can't be opened!");

                //    ResetAutoStatus();
                //    return;
                //}

                btnMergeFProcess_Click(this, new EventArgs());
                if (CheckProcessStatus(PageType.MergeFederal))
                {
                    ResetAutoStatus();
                    return;
                }

                OutMsg(PageType.AutoProcess, "Vesion Names of Dakota Auditor: " + txtVNameDA.Text + ".\r\n");
                OutMsg(PageType.AutoProcess, "Vesion Names of Smart Cite: " + txtVNameSC.Text + ".\r\n");

            }

            if (cobStartStep.SelectedIndex < 9)
            {
                tabControl.SelectedTab = tbPgAutoProcess;
                OutMsg(PageType.AutoProcess, "Step 9: Fix av collision." + Environment.NewLine);

                btnMergeFMasterOpen_Click(this, new EventArgs());
                Application.DoEvents();
                if (txtMergeFMasterVer.Text.Trim() == "")
                {
                    tabControl.SelectedTab = tbPgAutoProcess;
                    OutMsg(PageType.AutoProcess, "DB can't be opened in Step 9: Merge Federal." + Environment.NewLine);

                    ResetAutoStatus();
                    return;
                }

                sybase.SetServer(txtMergeFMMasterServer.Text, txtMergeFMMasterDB.Text, MergeFMMasterUser, MergeFMMasterPW);
                sybase.Open();
                sybase.RunSQL(Query.Fix_av_collision_rev3);
                sybase.Close();

                txtBlobsServer.Text = txtMergeFMMasterServer.Text;
                txtBlobsDB.Text = txtMergeFMMasterDB.Text;
                BlobUser = MergeFMMasterUser;
                BlobPW = MergeFMModulePW;
            }

            if (cobStartStep.SelectedIndex < 10)
            {
                OutMsg(PageType.AutoProcess, "Step 10: Blob DB." + Environment.NewLine);
                tabControl.SelectedTab = tbPgBlobsCreat;

                optMissingBlobs.Checked = true;
                //btnBlobsOpen_Click(this, new EventArgs());
                //if (txtBlobsVer.Text.Trim() == "")
                //{
                //    OutMsg(PageType.AutoProcess, "DB can't be opened in Step 10: Blob DB." + Environment.NewLine);
                //    OutMsg();
                //    MessageBox.Show("DB can't be opened!");

                //    ResetAutoStatus();
                //    return;
                //}

                btnBlobsProcess_Click(this, new EventArgs());
                if (CheckProcessStatus(PageType.BlobsCreation))
                {
                    ResetAutoStatus();
                    return;
                }

            }

            if (cobStartStep.SelectedIndex < 11)
            {
                tabControl.SelectedTab = tbPgAutoProcess;
                OutMsg(PageType.AutoProcess, "Step 11: Dup appsn." + Environment.NewLine);

                btnBlobsOpen_Click(this, new EventArgs());
                Application.DoEvents();
                if (txtBlobsVer.Text.Trim() == "")
                {
                    OutMsg(PageType.AutoProcess, "DB can't be opened in Step 10: Dup appsn." + Environment.NewLine);
                    OutMsg();

                    ResetAutoStatus();
                    return;
                }


                sybase.SetServer(txtBlobsServer.Text, txtBlobsDB.Text, BlobUser, BlobPW);
                sybase.Open();
                ds = sybase.GetDataSet(Query.duplicateappsn2);
                sybase.Close();
                DisplayData(ds);
            }

            if (cobStartStep.SelectedIndex < 12)
            {
                tabControl.SelectedTab = tbPgAutoProcess;
                OutMsg(PageType.AutoProcess, "Step 12: Applicability Range Map." + Environment.NewLine);
                OutMsg();

                btnBlobsOpen_Click(this, new EventArgs());
                Application.DoEvents();
                if (txtBlobsVer.Text.Trim() == "")
                {
                    OutMsg(PageType.AutoProcess, "DB can't be opened in Step 12: Applicability Range Map." + Environment.NewLine);
                    OutMsg();
                    MessageBox.Show(this, "DB can't be opened!", "Auto Process");

                    ResetAutoStatus();
                    return;
                }

                sybase.SetServer(txtBlobsServer.Text, txtBlobsDB.Text, BlobUser, BlobPW);
                sybase.Open();
                ds = sybase.GetDataSet(Query.ApplicabilityRangeMap2);
                sybase.Close();
                DisplayData(ds);

                txtMergeSTServer.Text = txtBlobsServer.Text;
                txtMergeSTDB.Text = txtBlobsDB.Text;
                MergeSTUser = BlobUser;
                MergeSTPW = BlobPW;
            }

            if (cobStartStep.SelectedIndex < 13)
            {
                OutMsg(PageType.AutoProcess, "Step 13: Merge State." + Environment.NewLine);
                tabControl.SelectedTab = tbPgMergSt;

                //btnMergeSTOpen_Click(this, new EventArgs());
                //if (txtMergeSTVer.Text.Trim() == "")
                //{
                //    OutMsg(PageType.AutoProcess, "DB can't be opened in Step 14: Merge State." + Environment.NewLine);

                //    ResetAutoStatus();
                //    return;
                //}

                chkMergeSynCheck.Checked = false;
                btnMergeSTProcess_Click(this, new EventArgs());
                if (CheckProcessStatus(PageType.MergeState))
                {
                    ResetAutoStatus();
                    return;
                }

                OutMsg(PageType.AutoProcess, "State Version Name: " + txtMergeSTVerName.Text + ".\r\n");

                txtBlobsServer.Text = txtMergeSTServer.Text;
                txtBlobsDB.Text = txtMergeSTDB.Text;
                BlobUser = MergeSTUser;
                BlobPW = MergeSTPW;
            }

            if (cobStartStep.SelectedIndex < 14)
            {
                OutMsg(PageType.AutoProcess, "Step 14: Blob DB." + Environment.NewLine);
                tabControl.SelectedTab = tbPgBlobsCreat;

                //btnBlobsOpen_Click(this, new EventArgs());
                //if (txtBlobsVer.Text.Trim() == "")
                //{
                //    OutMsg(PageType.AutoProcess, "DB can't be opened in Step 15: Blob DB." + Environment.NewLine);
                //    //MessageBox.Show("DB can't be opened!");

                //    ResetAutoStatus();
                //    return;
                //}

                optMissingBlobs.Checked = true;
                btnBlobsProcess_Click(this, new EventArgs());
                if (CheckProcessStatus(PageType.BlobsCreation))
                {
                    ResetAutoStatus();
                    return;
                }
            }

            if (cobStartStep.SelectedIndex < 15)
            {
                tabControl.SelectedTab = tbPgAutoProcess;
                OutMsg(PageType.AutoProcess, "Step 15: Dup state domainsn." + Environment.NewLine);
                btnBlobsOpen_Click(this, new EventArgs());
                Application.DoEvents();
                if (txtBlobsVer.Text.Trim() == "")
                {
                    OutMsg(PageType.AutoProcess, "DB can't be opened in Step 15: Dup state domainsn." + Environment.NewLine);

                    ResetAutoStatus();
                    return;
                }

                sybase.SetServer(txtMergeSTServer.Text, txtMergeSTDB.Text, MergeSTUser, MergeSTPW);
                sybase.Open();
                ds = sybase.GetDataSet(Query.Dup_state_domainsn);
                sybase.Close();
                DisplayData(ds);

            }

            tabControl.SelectedTab = tbPgAutoProcess;
            OutMsg(PageType.AutoProcess, "Auto Process Done at: " + DateTime.Now.ToShortTimeString() + Environment.NewLine);

            MessageBox.Show(this, "Auto Process Done!");

            ResetAutoStatus();
            OutMsg();
        }
        private void ResetAutoStatus()
        {
            isAutoProcess = false;
            btnAutoProcess.Enabled = true;
            btnAutoCancel.Enabled = !btnAutoProcess.Enabled;
            cobStartStep.Enabled = true;

            tabControl.SelectedTab = tbPgAutoProcess;
            OutMsg();
        }
        private void autoprocess_callBack(string message)
        {
            OutMsg(PageType.AutoProcess, message);
        }
        private void dbinfo_callBack(string message)
        {
            OutMsg(PageType.VewDB, message);
        }

        private void CopyInTread(string PathFileOrig, string PathFileDest)
        {
            Thread tr = new Thread(UTIL.FileCopy);

            string[] PathFile = new string[] { PathFileOrig, PathFileDest };
            //invokingCount = 0;
            tr.Start(PathFile);

            while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
            {
                if (cancelPressed)
                {
                    //tr.Abort();

                    OutMsg(PageType.AutoProcess, "Cancelling");
                    while (tr.IsAlive)
                    {
                        Application.DoEvents();
                        OutMsg();
                        Thread.Sleep(300);

                        OutMsg(PageType.AutoProcess, ".");
                    }

                    OutMsg(PageType.AutoProcess, "\r\n");

                    //break;
                }

                Application.DoEvents();
                OutMsg();
            }
        }
        internal void DisplayData(DataSet ds)
        {
            DisplayData(ds, PageType.AutoProcess);
        }
        internal void DisplayData(DataSet ds, PageType page_type)
        {
            //return;
            if (UTIL.CheckDataSet(ds))
            {
                string colNames = "";
                for (int i = 0; i < ds.Tables[0].Columns.Count; i++)
                {
                    colNames += ds.Tables[0].Columns[i].ColumnName + ",   ";
                }

                colNames = colNames.Trim();
                colNames = colNames.Substring(0, colNames.Length - 1);

                OutMsg(page_type, colNames + Environment.NewLine);
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    colNames = "";
                    foreach (DataColumn col in ds.Tables[0].Columns)
                    {
                        colNames += row[col].ToString() + ",   ";
                    }

                    colNames = colNames.Trim();
                    colNames = colNames.Substring(0, colNames.Length - 1);
                    OutMsg(page_type, colNames + Environment.NewLine);
                }

            }
            else
            {
                OutMsg(page_type, "No records!" + Environment.NewLine);
            }
        }
        private void InitLogwindows()
        {
            this.txtDelStOut.Text = "";
            this.txtMergeSTOut.Text = "";
            this.txtMergeFdOut.Text = "";
            this.txtBlobsOut.Text = string.Empty;
            this.txtBuildREMOutput.Text = string.Empty;
            this.txtModuleOut.Text = string.Empty;
        }
        private bool CheckProcessStatus(PageType pType)
        {
            if (autoProcessCancel)
            {
                tabControl.SelectedTab = tbPgAutoProcess;
                OutMsg(PageType.AutoProcess, "Cancelled by user!" + Environment.NewLine);
                return true;
            }

            if (processFailed || processError)
            {
                string msg = "";
                switch (pType)
                {
                    case PageType.BuildREM:
                        msg = "There were some errors while building REM files in follow modules:";
                        foreach (string name in lstErrModules)
                        {
                            msg += Environment.NewLine + name;
                        }
                        break;
                    case PageType.BuildMODULE:
                        msg = "There were some errors while building module DB.";
                        break;
                    case PageType.BlobsCreation:
                        msg = "There were some errors while blobs crating.";
                        break;
                    case PageType.MergeFederal:
                        msg = "There were some errors while merging federal DB.";
                        break;
                    case PageType.MergeState:
                        msg = "There were some errors while merging state.";
                        break;
                    default:
                        msg = "There were some errors while processing.";
                        break;
                }

                tabControl.SelectedTab = tbPgAutoProcess;
                OutMsg(PageType.AutoProcess, msg + Environment.NewLine);
                return true;
            }

            return false;
        }

        internal void SaveConfig(string key, string value)
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            if (config.AppSettings.Settings[key] == null)
            {
                config.AppSettings.Settings.Add(key, value);
            }
            else
            {
                config.AppSettings.Settings[key].Value = value;
            }

            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");
        }

        private void btnMergeFCancel_Click(object sender, EventArgs e)
        {
            cancelPressed = true;
            autoProcessCancel = true;
        }

        private void txtMergeSTDate_DoubleClick(object sender, EventArgs e)
        {
            EnableControlMergeSt();
            EnableMergeStButton();
        }

        private void tabControl_Deselecting(object sender, TabControlCancelEventArgs e)
        {
            if (isProcessing)
            {
                e.Cancel = true;
            }
        }

        private void btnMergeSTSateRoot_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;

            FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
            folderBrowserDialog.RootFolder = Environment.SpecialFolder.MyComputer;
            folderBrowserDialog.ShowNewFolderButton = false;

            folderBrowserDialog.SelectedPath = this.txtMergeSTSateRoot.Text;
            DialogResult result = folderBrowserDialog.ShowDialog(this);
            if (result == DialogResult.OK)
            {
                this.txtMergeSTSateRoot.Text = folderBrowserDialog.SelectedPath;
            }

            if (Directory.Exists(this.txtMergeSTSateRoot.Text))
            {
                lblMergeSTSateRoot.Text = string.Empty;
            }
            else
            {
                lblMergeSTSateRoot.Text = "Invalid Directory!";
            }
        }

        private void btnMergeSTModuleRoot_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;

            FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
            folderBrowserDialog.RootFolder = Environment.SpecialFolder.MyComputer;
            folderBrowserDialog.ShowNewFolderButton = false;

            folderBrowserDialog.SelectedPath = this.txtMergeSTModuleRoot.Text;
            DialogResult result = folderBrowserDialog.ShowDialog(this);
            if (result == DialogResult.OK)
            {
                this.txtMergeSTModuleRoot.Text = folderBrowserDialog.SelectedPath;
            }

            if (Directory.Exists(this.txtMergeSTModuleRoot.Text))
            {
                lblMergeSTModuleRoot.Text = string.Empty;
            }
            else
            {
                lblMergeSTModuleRoot.Text = "Invalid Directory!";
            }
        }

        private void btnConfigTmpDirBrowse_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;

            FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
            folderBrowserDialog.RootFolder = Environment.SpecialFolder.MyComputer;
            folderBrowserDialog.ShowNewFolderButton = true;

            folderBrowserDialog.SelectedPath = this.txtConfigTempDir.Text;
            DialogResult result = folderBrowserDialog.ShowDialog(this);
            if (result == DialogResult.OK)
            {
                this.txtConfigTempDir.Text = folderBrowserDialog.SelectedPath;
            }

            if (Directory.Exists(this.txtConfigTempDir.Text))
            {
                this.lblConfigTmpDirMsg.Text = string.Empty;
            }
            else
            {
                lblConfigTmpDirMsg.Text = "Invalid Directory!";
            }
        }

        private void txtConfigTempDir_TextChanged(object sender, EventArgs e)
        {
            if (Directory.Exists(this.txtConfigTempDir.Text))
            {
                lblConfigTmpDirMsg.Text = string.Empty;
                SaveConfig("TempDir", this.txtConfigTempDir.Text);
                toolSheet.TempDir = ConfigurationManager.AppSettings["TempDir"];
            }
            else
            {
                lblConfigTmpDirMsg.Text = "Invalid Directory!";
            }

            isProcessing = !((lblConfigSerDirMsg.Text == string.Empty) && (lblConfigTmpDirMsg.Text == string.Empty));

        }

        private void btnConfigSave_Click(object sender, EventArgs e)
        {
            bool SaveSuccess = true;

            if (lblConfigSerDirMsg.Text == string.Empty)
            {
                SaveConfig("SNDir", this.txtConfigSerDir.Text);
                toolSheet.SNDir = ConfigurationManager.AppSettings["SNDir"];
            }
            else
            {
                SaveSuccess = false;
            }

            if (lblConfigTmpDirMsg.Text == string.Empty)
            {
                SaveConfig("TempDir", this.txtConfigTempDir.Text);
                toolSheet.TempDir = ConfigurationManager.AppSettings["TempDir"];
            }
            else
            {
                SaveSuccess = false;
            }
            if (SaveSuccess)
            {
                MessageBox.Show(this, "Saved successfully!", "Configuration", MessageBoxButtons.OK);
                isProcessing = false;
            }
            else
            {
                MessageBox.Show(this, "There is error(s) in configuration", "Configuration", MessageBoxButtons.OK);
                isProcessing = true;
            }
        }

        private void InitConfiguration()
        {
            this.txtConfigTempDir.Text = string.Empty;
            this.txtConfigSerDir.Text = string.Empty;

            try
            {
                this.txtConfigTempDir.Text = ConfigurationManager.AppSettings["TempDir"];
            }
            catch
            { }

            try
            {
                this.txtConfigSerDir.Text = ConfigurationManager.AppSettings["SNDir"];
            }
            catch
            { }

        }

        private void btnVewDBOpen_Click(object sender, EventArgs e)
        {
            this.lstVewDBModule.Items.Clear();

            btnVewDBOpen.Enabled = false;
            processError = false;

            if (isAutoProcess)
            {
                GetDbInfo(PageType.VewDB);
            }
            else
            {

                Thread tr = new Thread(new ParameterizedThreadStart(GetDbInfo));
                //invokingCount = 0;
                tr.Start(PageType.VewDB);

                //txtDelModOut.Clear();

                while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
                {
                    Application.DoEvents();
                    OutMsg();
                    //Thread.Sleep(200);
                }
            }

            btnVewDBOpen.Enabled = true;
            OutMsg();
        }

        private void cboVewDBQuery_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (txtVewDBVer.Text == string.Empty)
            {
                return;
            }

            Thread tr = null;
            DataSql sybase = new DataSql(SQLServer, SQLDB, SQLUser, SQLPW);
            DataSet ds = new DataSet();
            sybase.callBack += new DataSql.Display(dbinfo_callBack);

            txtVewDBResult.Text = string.Empty;

            sybase.Open();

            switch (cboVewDBQuery.SelectedIndex)
            {
                case 0:
                    tr = new Thread(new ParameterizedThreadStart(sybase.GetDataSet));
                    tr.Start(new Parameters(Query.ApplicabilityRangeMap2, ds));

                    this.Enabled = false;
                    while (tr.ThreadState != ThreadState.Stopped)
                    {
                        Application.DoEvents();
                        OutMsg();
                        //Thread.Sleep(200);
                    }
                    this.Enabled = true;

                    DisplayData(ds, PageType.VewDB);
                    break;
                case 1:
                    tr = new Thread(new ParameterizedThreadStart(sybase.GetDataSet));
                    tr.Start(new Parameters(Query.duplicateappsn2, ds));

                    this.Enabled = false;
                    while (tr.ThreadState != ThreadState.Stopped)
                    {
                        Application.DoEvents();
                        OutMsg();
                        //Thread.Sleep(200);
                    }
                    this.Enabled = true;

                    DisplayData(ds, PageType.VewDB);

                    break;
                case 2:
                    tr = new Thread(new ParameterizedThreadStart(sybase.GetDataSet));
                    tr.Start(new Parameters(Query.Dup_state_domainsn, ds));

                    this.Enabled = false;
                    while (tr.ThreadState != ThreadState.Stopped)
                    {
                        Application.DoEvents();
                        OutMsg();
                        //Thread.Sleep(200);
                    }
                    this.Enabled = true;

                    DisplayData(ds, PageType.VewDB);
                    break;
                case 3:
                    tr = new Thread(new ParameterizedThreadStart(sybase.RunSQL));
                    tr.Start(Query.Fix_av_collision_rev3);

                    this.Enabled = false;
                    while (tr.ThreadState != ThreadState.Stopped)
                    {
                        Application.DoEvents();
                        OutMsg();
                        //Thread.Sleep(200);
                    }

                    this.Enabled = true;

                    break;
                case 4:
                    tr = new Thread(new ParameterizedThreadStart(sybase.RunSQL));
                    tr.Start(Query.LookForDuplicateQuestionLinkText1);

                    this.Enabled = false;
                    while (tr.ThreadState != ThreadState.Stopped)
                    {
                        Application.DoEvents();
                        OutMsg();
                        //Thread.Sleep(200);
                    }

                    tr = new Thread(new ParameterizedThreadStart(sybase.GetDataSet));
                    tr.Start(new Parameters(Query.LookForDuplicateQuestionLinkText2, ds));

                    while (tr.ThreadState != ThreadState.Stopped)
                    {
                        Application.DoEvents();
                        OutMsg();
                        //Thread.Sleep(200);
                    }

                    this.Enabled = true;

                    DisplayData(ds, PageType.VewDB);
                    break;
                case 5:
                    tr = new Thread(new ParameterizedThreadStart(sybase.GetDataSet));
                    tr.Start(new Parameters(Query.MissingLink, ds));

                    this.Enabled = false;
                    while (tr.ThreadState != ThreadState.Stopped)
                    {
                        Application.DoEvents();
                        OutMsg();
                        //Thread.Sleep(200);
                    }
                    this.Enabled = true;

                    DisplayData(ds, PageType.VewDB);
                    break;
                default:
                    break;
            }

            OutMsg();
            sybase.Close();
        }

        private void btnConfigSerDirBrowse_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;

            FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
            folderBrowserDialog.RootFolder = Environment.SpecialFolder.MyComputer;
            folderBrowserDialog.ShowNewFolderButton = true;

            folderBrowserDialog.SelectedPath = this.txtConfigSerDir.Text;
            DialogResult result = folderBrowserDialog.ShowDialog(this);
            if (result == DialogResult.OK)
            {
                this.txtConfigSerDir.Text = folderBrowserDialog.SelectedPath;
            }

            if (Directory.Exists(this.txtConfigSerDir.Text))
            {
                this.lblConfigSerDirMsg.Text = string.Empty;
            }
            else
            {
                lblConfigSerDirMsg.Text = "Invalid Directory!";
            }
        }

        private void txtConfigSerDir_TextChanged(object sender, EventArgs e)
        {
            if (Directory.Exists(this.txtConfigSerDir.Text))
            {
                lblConfigSerDirMsg.Text = string.Empty;
                SaveConfig("SNDir", this.txtConfigSerDir.Text);
                toolSheet.SNDir = ConfigurationManager.AppSettings["SNDir"];
            }
            else
            {
                lblConfigSerDirMsg.Text = "Invalid Directory!";
            }

            isProcessing = !((lblConfigSerDirMsg.Text == string.Empty) && (lblConfigTmpDirMsg.Text == string.Empty));

        }

        private void tabControl_Selecting(object sender, TabControlCancelEventArgs e)
        {
            TabControl tbCtrl = (TabControl)sender;
            TabPage tbPg = tbCtrl.SelectedTab;

            if (!isProcessing && !BuildForIphone)
            {
                // if (tbPg.Name != "tpPgIPhoneDB" && tbPg.Name != "tbPgAbout" && tbPg.Name != "tbPgConfig") e.Cancel = true;
            }

            switch (tbPg.Name)
            {
                case "tpPgVewDB":
                    //e.Cancel = true;
                    break;
                case "tbPgAutoProcess":
                    //e.Cancel = true;
                    break;
                case "tpPgIPhoneDB":
                    //e.Cancel = true;
                    break;
                case "tbPgExcel":
                    //e.Cancel = true;
                    break;
                default:
                    break;
            }
        }

        private void btnIPhoneBrowseTextPath_Click(object sender, EventArgs e)
        {
            if (isProcessing)
            {
                return;
            }

            FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
            folderBrowserDialog.RootFolder = Environment.SpecialFolder.MyComputer;
            folderBrowserDialog.ShowNewFolderButton = false;

            folderBrowserDialog.SelectedPath = this.txtIPhoneREMDir.Text;
            DialogResult result = folderBrowserDialog.ShowDialog(this);
            if (result == DialogResult.OK)
            {
                this.txtIPhoneREMDir.Text = folderBrowserDialog.SelectedPath;

                //selDirectories();
            }

            if (Directory.Exists(this.txtIPhoneREMDir.Text))
            {
                lblIPhoneMsg.Text = string.Empty;
            }
            else
            {
                lblIPhoneMsg.Text = "Invalid Directory!";
            }

        }

        private void txtIPhoneREMDir_TextChanged(object sender, EventArgs e)
        {
            if (initializing) return;

            string path = txtIPhoneREMDir.Text;
            lblIPhoneMsg.Text = string.Empty;

            if (Directory.Exists(path))
            {
                SaveConfig("IPhoneSourceDirectory", this.txtIPhoneREMDir.Text);
                SetIPhoneModules(path);
            }
            else
            {
                lblIPhoneMsg.Text = "Invalid Directory!";
            }


            pathChanged = true;
            //selDirectories();

        }

        private void txtSQLitePath_TextChanged(object sender, EventArgs e)
        {
            if (initializing) return;

            if (this.txtSQLitePath.Text == "") return;

            string _dir = Path.GetDirectoryName(this.txtSQLitePath.Text);

            if (Directory.Exists(_dir))
            {
                SaveConfig("IPhoneSQLLitePath", this.txtSQLitePath.Text);

                lblIPhoneMsg.Text = string.Empty;
            }
            else
            {
                lblIPhoneMsg.Text = _dir + ": not existing!";
            }
        }

        long[] asn ={11570,
                    21156,
                    33778,
                    50552,
                    60532,
                    70636,
                    81870,
                    100422,
                    120332,
                    142862,
                    160514,
                    191854,
                    222562};

        private void SetIPhoneModules(string TextPath)
        {
            chkLstBox.Items.Clear();

            if (Directory.Exists(TextPath))
            {
                string[] dirs = Directory.GetDirectories(TextPath, toolSheet.DirBeginWith + "*");
                long _moduleSN = -1;
                string _moduleName = null;
                foreach (string str in dirs)
                {
                    try
                    {
                        _moduleSN = MODULE.GetModuleSN(str);
                        _moduleName = MODULE.GetModuleName(str);

                        if (_moduleSN != -1 && _moduleName.Trim() != "")
                        {
                            bool found = false;
                            foreach (long i in asn)
                            {
                                if (i == _moduleSN)
                                {
                                    chkLstBox.Items.Add(new ModuleListItem(_moduleName, _moduleSN), true);
                                    found = true;
                                    break;
                                }
                            }

                            if (!found)
                            {
                                //chkLstBox.Items.Add(new ModuleListItem(_moduleName, _moduleSN), false);
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        OutMsg(PageType.IPone, e.Message + Environment.NewLine);
                    }
                }

            }
            OutMsg();
        }

        //internal string defaultServer = ConfigurationManager.AppSettings["defaultServer"].ToLower().Trim();
        //internal string defaultDB = ConfigurationManager.AppSettings["defaultDB"].ToLower().Trim();

        private string GetSqlServerConnectionString(string address, string db)
        {
            string res = @"Data Source=" + address.Trim() +
                    ";Initial Catalog=" + db.Trim() + ";Integrated Security=SSPI;";
            return res;
        }
        private string GetSqlServerConnectionString(string address, string db, string user, string pass)
        {
            string res = @"Data Source=" + address.Trim() +
                ";Initial Catalog=" + db.Trim() + ";User ID=" + user.Trim() + ";Password=" + pass.Trim();
            return res;
        }

        internal bool BuildForIphone = false;

        private void btnIPhoneBrowseSQLitePath_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;

            DialogResult res = saveFileDialog1.ShowDialog(this);
            if (res == DialogResult.Cancel)
                return;

            string fpath = saveFileDialog1.FileName;
            txtSQLitePath.Text = fpath;
            pbrProgress.Value = 0;
            lblIPhoneMsg.Text = string.Empty;
        }

        private void chkLstBox_Click(object sender, EventArgs e)
        {

        }

        internal List<ModuleListItem> selPhoneModules = new List<ModuleListItem>();

        private void btnIPhoneProcess_Click(object sender, EventArgs e)
        {
            btnIPhoneProcess.Visible = false;
            btnIPhoneCancel.Visible = true;

            if (IPhoneParametersValid)
            {
                OutMsg(PageType.IPone, "Process started at: " + DateTime.Now.ToString() + Environment.NewLine);
                //IntegratedSecurity = this.chkIPhoneIntegrated.Checked;
                ClearIPhoneSQLDB();

                ModuleListItem lstModule = null;
                selPhoneModules.Clear();
                foreach (object obj in chkLstBox.CheckedItems)
                {
                    lstModule = obj as ModuleListItem;
                    selPhoneModules.Add(lstModule);
                }

                OutMsg(PageType.IPone, "Building source files..." + Environment.NewLine);
                OutMsg();

                BuildForIphone = true;
                tabControl.SelectedTab = tbPgBuildREM;

                txtBuildREMDir.Text = txtIPhoneREMDir.Text;
                selDirectoriesIPhone(txtBuildREMDir.Text);


                DoBuildREMProcess(this, null);

                tabControl.SelectedTab = tbPgIPhoneDB;

                if (!processFailed && !cancelPressed)
                {
                    isProcessing = true;

                    OutMsg(PageType.IPone, "Build source successfuly." + Environment.NewLine);
                    OutMsg(PageType.IPone, "Creating IPhone DB in SQL SQL sever..." + Environment.NewLine);
                    OutMsg();

                    SetServer(PageType.IPone);
                    Thread tr = new Thread(new ThreadStart(CreateIPhoneSQLDB));
                    tr.Start();

                    while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
                    {
                        if (cancelPressed)
                        {
                            OutMsg(PageType.IPone, "Cancelling");
                            while (tr.IsAlive)
                            {
                                Application.DoEvents();
                                Thread.Sleep(300);
                                OutMsg(PageType.IPone, ".");

                                OutMsg();
                            }
                        }
                        Application.DoEvents();

                        OutMsg();

                        Thread.Sleep(200);
                    }

                    if (!cancelPressed)
                    {
                        OutMsg(PageType.IPone, "Converting SQL server DB in SQLite");
                        OutMsg();


                        tr = new Thread(new ThreadStart(SqlConverter));
                        tr.Start();

                        while (tr.ThreadState != ThreadState.Stopped)
                        {
                            if (cancelPressed)
                            {
                                OutMsg(PageType.IPone, "Cancelling");
                                while (tr.IsAlive)
                                {
                                    Application.DoEvents();
                                    Thread.Sleep(300);
                                    OutMsg(PageType.IPone, ".");

                                    OutMsg();

                                }
                            }
                            Application.DoEvents();

                            OutMsg();

                            Thread.Sleep(200);
                        }


                        if (!processFailed && !cancelPressed)
                        {
                            OutMsg(PageType.IPone, "Process ended at: " + DateTime.Now.ToString() + Environment.NewLine + Environment.NewLine);


                            MessageBox.Show(this, "Process successfuly done!", "Create IPhone DB",
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }

                if (processFailed && !cancelPressed)
                {
                    OutMsg(PageType.IPone, "Build source files failed!" + Environment.NewLine);

                    MessageBox.Show(this, "Process failed!", "Create IPhone DB",
                                      MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                if (cancelPressed)
                {
                    OutMsg(PageType.IPone, Environment.NewLine + "Process cancelled!" + Environment.NewLine);
                }

                cancelPressed = false;
                isProcessing = false;
            }


            OutMsg();

            BuildForIphone = false;
            btnIPhoneProcess.Visible = true;
            btnIPhoneCancel.Visible = false;
        }

        private void ClearIPhoneSQLDB()
        {
            string dakrefconnstring = null;
            if (IPhoneUser == "")
            {
                dakrefconnstring = "packet size=4096;data source=" + txtIPhoneServer.Text +
                        ";Timeout=30;Integrated Security=SSPI;initial catalog=" + txtIPhoneDB.Text;
            }
            else
            {
                dakrefconnstring = "packet size=4096;user id=" + IPhoneUser +
                        ";PASSWORD=" + IPhonePW + ";data source=" + txtIPhoneServer.Text +
                        ";Timeout=30;persist security info=False;initial catalog=" + txtIPhoneDB.Text;
            }

            SqlConnection _conn = new SqlConnection(dakrefconnstring);

            try
            {
                string SQL = "BEGIN TRY DROP TABLE rgsectionHtml END TRY BEGIN CATCH END CATCH";
                _conn.Open();
                ExecuteNonQuery(SQL, _conn);
                _conn.Close();

            }
            catch { }
        }

        private void CreateIPhoneSQLDB()
        {
            string dakrefconnstring = null;
            if (IPhoneUser == "")
            {
                dakrefconnstring = "packet size=4096;data source=" + txtIPhoneServer.Text +
                        ";Timeout=30;Integrated Security=SSPI;initial catalog=" + txtIPhoneDB.Text;
            }
            else
            {
                dakrefconnstring = "packet size=4096;user id=" + IPhoneUser +
                        ";PASSWORD=" + IPhonePW + ";data source=" + txtIPhoneServer.Text +
                        ";Timeout=30;persist security info=False;initial catalog=" + txtIPhoneDB.Text;
            }

            SqlConnection _conn = new SqlConnection(dakrefconnstring);

            try
            {
                string SQL = "select ModuleVersionSN FROM dakref.dbo.Version";
                _conn.Open();

                DataSet ds = GetDataSet(SQL, _conn);

                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    string ModuleVersionSN = ds.Tables[0].Rows[0][0].ToString();

                    foreach (string str in Query.CreateIPhoneTables)
                    {
                        ExecuteNonQuery(str.Replace("******", ModuleVersionSN), _conn);

                        if (cancelPressed)
                        {
                            break;
                        }
                    }

                    foreach (string str in Query.CreateIPhoneIndexes)
                    {
                        ExecuteNonQuery(str, _conn);
                        if (cancelPressed)
                        {
                            break;
                        }
                    }
                }

                _conn.Close();

            }
            catch { }
        }

        private DataSet GetDataSet(string strSQL, SqlConnection conn)
        {
            SqlDataAdapter dataAdapter = new SqlDataAdapter();
            DataSet dataSet = null;
            SqlCommand command = new SqlCommand();
            try
            {
                command.Connection = conn;
                command.CommandType = CommandType.Text;
                command.CommandText = strSQL;
                dataSet = new DataSet("Temp");
                dataSet.Locale = new System.Globalization.CultureInfo("en-US");
                dataAdapter.SelectCommand = command;
                dataAdapter.Fill(dataSet);
                return dataSet;
            }
            catch //(SqlException e)
            {
                return null;
            }
            finally
            {
                command.Dispose();
                dataAdapter.Dispose();
            }
        }
        private bool ExecuteNonQuery(string strSQL, SqlConnection conn)
        {
            SqlCommand command;
            command = new SqlCommand();
            try
            {
                command.Connection = conn;
                command.CommandText = strSQL;
                command.CommandTimeout = 60;
                command.ExecuteNonQuery();
            }
            catch //(SqlException e)
            {
                return false;
            }
            finally
            {
                command.Dispose();
            }

            return true;
        }

        private bool IPhoneParametersValid
        {
            get
            {
                if (txtSQLitePath.Text.Trim() == "")
                {
                    MessageBox.Show(this, "Empty SQLite path!", "Create IPhone Database",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

                if (txtIPhoneREMDir.Text.Trim() == "")
                {
                    MessageBox.Show(this, "Empty source path!", "Create IPhone Database",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

                if (!Directory.Exists(txtIPhoneREMDir.Text))
                {
                    MessageBox.Show(this, "Incorrect source path!", "Create IPhone Database",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

                FileInfo fInfo = new FileInfo(txtSQLitePath.Text);
                string fDir = fInfo.DirectoryName;
                if (!Directory.Exists(fDir))
                {
                    MessageBox.Show(this, "Incorrect SQLite path!", "Create IPhone Database",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

                if (txtIPhoneDB.Text == "")
                {
                    MessageBox.Show(this, "No taget DB selected!", "Create IPhone Database",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

                return true;
            }
        }
        private void btnIPhoneSelAll_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chkLstBox.Items.Count; i++)
            {
                chkLstBox.SetItemChecked(i, true);
            }
        }
        private void btnIPhoneUnSel_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chkLstBox.Items.Count; i++)
            {
                chkLstBox.SetItemChecked(i, false);
            }
        }
        private void btnIPhoneDeSel_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chkLstBox.Items.Count; i++)
            {
                if (chkLstBox.GetItemChecked(i))
                {
                    chkLstBox.SetItemChecked(i, false);
                }
                else
                {
                    chkLstBox.SetItemChecked(i, true);
                }
            }
        }

        private void btnIPhoneDefSel_Click(object sender, EventArgs e)
        {
            ModuleListItem moduleItem = null;
            for (int i = 0; i < chkLstBox.Items.Count; i++)
            {
                moduleItem = chkLstBox.Items[i] as ModuleListItem;
                bool found = false;
                foreach (long l in asn)
                {

                    if (l == moduleItem.ModuleSN)
                    {
                        chkLstBox.SetItemChecked(i, true);
                        found = true;
                        break;
                    }
                }

                if (!found)
                {
                    chkLstBox.SetItemChecked(i, false);
                }
            }
        }

        private void UpdateSensitivity()
        {
            //if (txtSQLitePath.Text.Trim().Length > 0 && cboDatabases.Enabled &&
            //    (!cbxEncrypt.Checked || txtPassword.Text.Trim().Length > 0))
            //    btnStart.Enabled = true && !SqlServerToSQLite.IsActive;
            //else
            //    btnStart.Enabled = false;

            //btnSet.Enabled = txtSqlAddress.Text.Trim().Length > 0 && !SqlServerToSQLite.IsActive;
            //btnCancel.Visible = SqlServerToSQLite.IsActive;
            //txtSqlAddress.Enabled = !SqlServerToSQLite.IsActive;
            //txtSQLitePath.Enabled = !SqlServerToSQLite.IsActive;
            //btnBrowseSQLitePath.Enabled = !SqlServerToSQLite.IsActive;
            //cbxEncrypt.Enabled = !SqlServerToSQLite.IsActive;
            //cboDatabases.Enabled = cboDatabases.Items.Count > 0 && !SqlServerToSQLite.IsActive;
            //txtPassword.Enabled = cbxEncrypt.Checked && cbxEncrypt.Enabled;
            //cbxIntegrated.Enabled = !SqlServerToSQLite.IsActive;
            //txtPassDB.Enabled = !SqlServerToSQLite.IsActive;
            //txtUserDB.Enabled = !SqlServerToSQLite.IsActive;
        }

        private void SqlConverter()
        {
            //pbrProgress.Visible = true;
            string sqlConnString = null;
            if (IPhoneUser == "")
            {
                sqlConnString = GetSqlServerConnectionString(txtIPhoneServer.Text, txtIPhoneDB.Text);
            }
            else
            {
                sqlConnString = GetSqlServerConnectionString(txtIPhoneServer.Text, txtIPhoneDB.Text, IPhoneUser, IPhonePW);
            }


            string sqlitePath = txtSQLitePath.Text.Trim();
            //this.Cursor = Cursors.WaitCursor;
            SqlConversionHandler handler = new SqlConversionHandler(delegate(bool done,
                    bool success, int percent, string msg)
            {
                Invoke(new MethodInvoker(delegate()
                {
                    OutMsg(PageType.IPone, msg);
                    //OutMsg(PageType.IPone, Environment.NewLine);
                }));
            });
            SqlTableSelectionHandler selectionHandler = new SqlTableSelectionHandler(delegate(List<TableSchema> schema)
            {
                List<TableSchema> updated = null;
                Invoke(new MethodInvoker(delegate
                {
                    // Allow the user to select which tables to include by showing him the 
                    // table selection dialog.
                    TableSelectionDialog dlg = new TableSelectionDialog();
                    DialogResult res = dlg.ShowTables(schema, this);
                    if (res == DialogResult.OK)
                        updated = dlg.IncludedTables;
                }));
                return updated;
            });

            FailedViewDefinitionHandler viewFailureHandler = new FailedViewDefinitionHandler(delegate(ViewSchema vs)
            {
                string updated = null;
                Invoke(new MethodInvoker(delegate
                {
                    ViewFailureDialog dlg = new ViewFailureDialog();
                    dlg.View = vs;
                    DialogResult res = dlg.ShowDialog(this);
                    if (res == DialogResult.OK)
                        updated = dlg.ViewSQL;
                    else
                        updated = null;
                }));

                return updated;
            });

            //SqlServerToSQLite.ConvertSqlServerToSQLiteDatabase(sqlConnString, sqlitePath, selectionHandler, handler,
            SqlServerToSQLite.ConvertSqlServerToSQLiteDatabase(sqlConnString, sqlitePath, null, handler,
                     selectionHandler, viewFailureHandler, false);

            //pbrProgress.Visible = false;
        }

        internal bool ValidSqlServerConfiguration
        {
            get
            {
                if (SQLServer == null || SQLServer.Trim() == "")
                {
                    return false;
                }

                if (SQLDB == null || this.SQLDB.Trim() == "")
                {
                    return false;
                }

                return true;
            }
        }

        private void btnBlobsDBConfig_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;

            frmDBConfig _frmDBCfig = new frmDBConfig();

            SetServer(PageType.BlobsCreation);

            _frmDBCfig._parent = this;
            _frmDBCfig.ShowDialog(this);

            if (SQLConfigSubmitted)
            {
                GetServer(PageType.BlobsCreation);
                EnableBlobButton();
            }
        }

        private void btnModuleDBConfig_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;
            frmDBConfig _frmDBCfig = new frmDBConfig();

            SetServer(PageType.BuildMODULE);

            _frmDBCfig._parent = this;
            _frmDBCfig.ShowDialog(this);

            if (SQLConfigSubmitted)
            {
                GetServer(PageType.BuildMODULE);
            }
        }

        private void btnConfigConfig_Click(object sender, EventArgs e)
        {
            //frmDBConfig _frmDBCfig = new frmDBConfig();

            //_frmDBCfig._parent = this;
            //_frmDBCfig.ShowDialog(this);

            //if (SQLConfigSubmitted)
            //{
            //    txtConfigServer.Text = SQLServer;
            //    txtConfigDB.Text = SQLDB;
            //}
        }

        private bool CheckDBExists(string dbname)
        {
            DataSql dbsql = new DataSql(SQLServer, "master", SQLUser, SQLPW);

            try
            {
                dbsql.Open();
                string SQL = "SELECT name FROM sys.databases WHERE name = N'" + dbname + "'";
                DataSet ds = dbsql.GetDataSet(SQL);
                dbsql.Close();

                if (UTIL.CheckDataSet(ds))
                    return true;
                else
                    return false;
            }
            catch (Exception e)
            {
                MessageBox.Show(this, e.Message, "Error", MessageBoxButtons.OK);
                return false;
            }
        }

        internal string ImportedDBName
        {
            get
            {
                if (chkImCreateNewDB.Checked)
                {
                    return txtImNewDB.Text;
                }
                else
                {
                    return txtImDB.Text;
                }
            }
        }
        private void btnImport_Click(object sender, EventArgs e)
        {
            SetServer(PageType.Import);
            for (int i = 162; i < 188; i++)
            {
                string file_path = Path.Combine(txtImDataPath.Text, i.ToString().Trim() + ".dat");

                if (!File.Exists(file_path))
                {
                    lblImMsg.Text = "Not including all dat files!";
                    return;
                }
            }

            if (CheckDBExists(ImportedDBName))
            {
                DialogResult result = MessageBox.Show(this, "The databae " + ImportedDBName + " already exists." +
                       Environment.NewLine + "Do you want to replace it?", "Import",
                       MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.No)
                {
                    return;
                }
            }

            btnImport.Visible = false;
            btnImCancel.Visible = true;

            btnImConfig.Enabled = false;
            btnImOpen.Enabled = false;

            isProcessing = true;
            cancelPressed = false;
            processFailed = false;

            this.toolSheet.CreateTemp();

            OutMsg(PageType.ImportExport, "\r\n");
            OutMsg(PageType.ImportExport, "Process started at: " + DateTime.Now.ToShortTimeString() + ".\r\n");

            SetServer(PageType.Import);
            ImportExport imex = new ImportExport(this);
            Thread tr = new Thread(new ThreadStart(imex.LoadSybaseData));

            tr.Start();
            while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
            {
                if (cancelPressed)
                {
                    OutMsg(PageType.ImportExport, "Cancelling");
                    while (tr.IsAlive)
                    {
                        Application.DoEvents();
                        Thread.Sleep(300);
                        OutMsg(PageType.ImportExport, ".");

                        OutMsg();

                    }
                }
                Application.DoEvents();

                OutMsg();
            }

            OutMsg(PageType.ImportExport, "Process ended at: " + DateTime.Now.ToShortTimeString() + ".\r\n");
            OutMsg();

            if (!cancelPressed && !isAutoProcess)
            {
                if (processFailed)
                {
                    MessageBox.Show(this, "Import data failed", "Import", MessageBoxButtons.OK, MessageBoxIcon.Error);


                }
                else
                {
                    MessageBox.Show(this, "Import data done!");
                }
            }
            else
            {
                cancelPressed = false;
            }

            isProcessing = false;

            btnImport.Visible = true;
            btnImCancel.Visible = false;

            btnImConfig.Enabled = true;
            btnImOpen.Enabled = true;

            OutMsg();
        }

        private void btnImCancel_Click(object sender, EventArgs e)
        {
            cancelPressed = true;
            autoProcessCancel = true;
        }

        private void txtImDataPath_TextChanged(object sender, EventArgs e)
        {
            if (initializing) return;

            lblImMsg.Text = ""; ;

            if (Directory.Exists(txtImDataPath.Text))
            {
                SaveConfig("ImprtDatDirectory", txtExDataPath.Text);

                for (int i = 161; i < 188; i++)
                {
                    string file_path = Path.Combine(txtImDataPath.Text, i.ToString().Trim() + ".dat");

                    if (!File.Exists(file_path))
                    {
                        lblImMsg.Text = "Not including all dat files!";
                        btnImport.Enabled = false;
                        return;
                    }
                }
                btnImport.Enabled = true;
            }
            else
            {
                btnImport.Enabled = false;
                lblImMsg.Text = "Invalid Directory!";
            }
        }
        private void btnImDataDirBrowse_Click(object sender, EventArgs e)
        {
            if (isProcessing)
            {
                return;
            }

            FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
            folderBrowserDialog.RootFolder = Environment.SpecialFolder.MyComputer;
            folderBrowserDialog.ShowNewFolderButton = false;

            folderBrowserDialog.SelectedPath = this.txtImDataPath.Text;
            DialogResult result = folderBrowserDialog.ShowDialog(this);
            if (result == DialogResult.OK)
            {
                this.txtImDataPath.Text = folderBrowserDialog.SelectedPath;
            }

            if (Directory.Exists(this.txtImDataPath.Text))
            {
                if (lblImMsg.Text != "Not including all dat files!")
                {
                    lblImMsg.Text = string.Empty;
                }
            }
            else
            {
                lblImMsg.Text = "Invalid Directory!";
            }
        }

        private void btnImExConfig_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;
            frmDBConfig _frmDBCfig = new frmDBConfig();

            _frmDBCfig._parent = this;

            SetServer(PageType.Import);
            _frmDBCfig.ShowDialog(this);

            if (SQLConfigSubmitted)
            {
                GetServer(PageType.Import);
                EnableImportButton();
            }
        }

        private void btnImExOpen_Click(object sender, EventArgs e)
        {
            btnImport.Enabled = false;
            processError = false;

            if (isAutoProcess)
            {
                GetDbInfo(PageType.Import);
            }
            else
            {
                Thread tr = new Thread(new ParameterizedThreadStart(GetDbInfo));
                //invokingCount = 0;
                tr.Start(PageType.Import);

                while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
                {
                    Application.DoEvents();
                    OutMsg();
                    //Thread.Sleep(200);
                }
            }

            if (!processError)
            {
                //btnBlobsProcess.Enabled = true;
                btnImport.Enabled = true;
            }
            else
            {
                processError = false;
                btnImport.Enabled = false;
            }

            //btnImport.Enabled = (txtImVersion.Text.Trim() != "");

            //btnImport.Enabled = true;
            OutMsg();
        }

        private void btnMergeFMMasterConfig_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;
            frmDBConfig _frmDBCfig = new frmDBConfig();

            _frmDBCfig._parent = this;

            SetServer(PageType.MergeFederalMaster);
            _frmDBCfig.ShowDialog(this);

            if (SQLConfigSubmitted)
            {
                GetServer(PageType.MergeFederalMaster);
                EnableMergeFdButton();
            }
        }

        internal bool SQLConfigSubmitted = false;
        private void btnMergeFMModuleConfig_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;
            frmDBConfig _frmDBCfig = new frmDBConfig();

            _frmDBCfig._parent = this;

            SetServer(PageType.MergeFederalModule);

            _frmDBCfig.ShowDialog(this);

            if (SQLConfigSubmitted)
            {
                GetServer(PageType.MergeFederalModule);
                EnableMergeFdButton();

                //txtMergeFMModuleServer.Text = SQLServer;
                //txtMergeFMModuleDB.Text = SQLDB;

                //MergeFMModuleUser = SQLUser;
                //MergeFMModulePW = SQLPW;

                //SaveConfig("MergeFederalModuleServer", SQLServer);
                //SaveConfig("MergeFederalModuleDB", SQLDB);
                //SaveConfig("MergeFederalModuleUser", SQLUser);
                //SaveConfig("MergeFederalModulePW", SQLPW);
            }
        }

        private void MergeFMMouduleServerDB_Changed(object sender, EventArgs e)
        {
            //txtMergeFModuleVer.Text = "";
            //EnableMergeFdButton();
        }

        private void btnMergeSTConfig_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;
            frmDBConfig _frmDBCfig = new frmDBConfig();

            _frmDBCfig._parent = this;

            SetServer(PageType.MergeState);

            _frmDBCfig.ShowDialog(this);

            if (SQLConfigSubmitted)
            {
                GetServer(PageType.MergeState);
                EnableMergeStButton();
            }
        }

        private void EnableDelModButton()
        {
            btnDelModProcess.Enabled = (txtDelModVer.Text.Trim() != string.Empty);
        }

        private void EnableImportButton()
        {
            btnImport.Enabled = (txtImVersion.Text.Trim() != string.Empty);
        }
        private void EnableExportButton()
        {
            btnExport.Enabled = (txtExVersion.Text.Trim() != string.Empty);
        }
        private void btnDelModConfig_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;
            frmDBConfig _frmDBCfig = new frmDBConfig();

            _frmDBCfig._parent = this;

            SetServer(PageType.ModuleDeletion);

            _frmDBCfig.ShowDialog(this);

            if (SQLConfigSubmitted)
            {
                GetServer(PageType.ModuleDeletion);
                EnableDelModButton();
            }
        }
        private void EnableDelStButton()
        {
            btnDelStProcess.Enabled = (txtDelStVer.Text.Trim() != string.Empty);
        }

        private void btnDelStConfig_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;
            frmDBConfig _frmDBCfig = new frmDBConfig();

            _frmDBCfig._parent = this;

            SetServer(PageType.DeleteState);

            _frmDBCfig.ShowDialog(this);

            if (SQLConfigSubmitted)
            {
                GetServer(PageType.DeleteState);
                EnableDelStButton();
            }
        }

        private void btnExConfig_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;
            frmDBConfig _frmDBCfig = new frmDBConfig();

            _frmDBCfig._parent = this;

            SetServer(PageType.Export);

            _frmDBCfig.ShowDialog(this);

            if (SQLConfigSubmitted)
            {
                GetServer(PageType.Export);
                EnableExportButton();
            }
        }

        private void btnExOpen_Click(object sender, EventArgs e)
        {
            btnExport.Enabled = false;
            processError = false;

            SetServer(PageType.Export);

            if (isAutoProcess)
            {
                GetDbInfo(PageType.Export);
            }
            else
            {
                Thread tr = new Thread(new ParameterizedThreadStart(GetDbInfo));
                //invokingCount = 0;
                tr.Start(PageType.Export);

                while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
                {
                    Application.DoEvents();
                    OutMsg();
                    //Thread.Sleep(200);
                }
            }

            if (!processError)
            {
                //btnBlobsProcess.Enabled = true;
            }
            else
            {
                processError = false;
            }

            btnExport.Enabled = (txtExVersion.Text.Trim() != "");
            //btnExport.Enabled = true;
            OutMsg();
        }

        private void txtExDataPath_TextChanged(object sender, EventArgs e)
        {
            if (initializing) return;

            lblExMsg.Text = "";

            if (Directory.Exists(txtExDataPath.Text))
            {
                btnExport.Enabled = true;
                SaveConfig("ExprtDatDirectory", txtExDataPath.Text);
            }
            else
            {
                btnExport.Enabled = false;
                lblExMsg.Text = "Invalid Directory!";
            }
        }

        private void btnExBrowse_Click(object sender, EventArgs e)
        {
            if (isProcessing)
            {
                return;
            }

            FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
            folderBrowserDialog.RootFolder = Environment.SpecialFolder.MyComputer;
            folderBrowserDialog.ShowNewFolderButton = false;

            folderBrowserDialog.SelectedPath = this.txtExDataPath.Text;
            DialogResult result = folderBrowserDialog.ShowDialog(this);
            if (result == DialogResult.OK)
            {
                this.txtExDataPath.Text = folderBrowserDialog.SelectedPath;
            }

            if (Directory.Exists(this.txtExDataPath.Text))
            {
                //if (lblExMsg.Text != "Not including all dat files!")
                //{
                //    lblExMsg.Text = string.Empty;
                //}
            }
            else
            {
                lblExMsg.Text = "Invalid Directory!";
            }
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            lblExMsg.Text = "";
            btnExOpen_Click(this, null);

            Application.DoEvents();

            if (txtExVersion.Text.Trim() == "")
            {
                lblExMsg.Text = "Can't open the DB!";
                return;
            }


            lblExMsg.Text = "";
            if (txtExDataPath.Text.Trim() == "" || !Directory.Exists(txtExDataPath.Text))
            {
                lblExMsg.Text = "Export folder not existing!";

                return;
            }

            btnExport.Visible = false;
            btnExCancel.Visible = true;

            btnExConfig.Enabled = false;
            btnExOpen.Enabled = false;

            isProcessing = true;
            cancelPressed = false;
            processFailed = false;

            this.toolSheet.CreateTemp();

            OutMsg(PageType.ImportExport, "\r\n");
            OutMsg(PageType.ImportExport, "Process started at: " + DateTime.Now.ToShortTimeString() + ".\r\n");

            SetServer(PageType.Export);
            ImportExport imex = new ImportExport(this);
            Thread tr = new Thread(new ThreadStart(imex.UnloadToSybaseData));

            //invokingCount = 0;
            tr.Start();
            while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
            {
                if (cancelPressed)
                {
                    OutMsg(PageType.ImportExport, "Cancelling");
                    while (tr.IsAlive)
                    {
                        Application.DoEvents();
                        Thread.Sleep(300);
                        OutMsg(PageType.ImportExport, ".");

                        OutMsg();

                    }
                }
                Application.DoEvents();

                OutMsg();
            }

            OutMsg(PageType.ImportExport, "Process ended at: " + DateTime.Now.ToShortTimeString() + ".\r\n");
            OutMsg();

            if (!cancelPressed && !isAutoProcess)
            {
                if (processFailed)
                {
                    MessageBox.Show(this, "Export data failed", "Export", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(this, "Export data done!", "Export", MessageBoxButtons.OK, MessageBoxIcon.None);
                }
            }
            else
            {
                cancelPressed = false;
            }

            isProcessing = false;

            btnExport.Visible = true;
            btnExCancel.Visible = false;

            btnExConfig.Enabled = true;
            btnExOpen.Enabled = true;

            OutMsg();
        }

        private void btnExCancel_Click(object sender, EventArgs e)
        {
            cancelPressed = true;
            autoProcessCancel = true;
        }

        private void SetServer(PageType pType)
        {
            pgType = pType;
            switch (pType)
            {
                case PageType.BuildMODULE:
                    SQLServer = txtModuleServer.Text;
                    SQLDB = txtModuleDB.Text;
                    SQLUser = ModuleUser;
                    SQLPW = ModulePW;
                    break;
                case PageType.BlobsCreation:
                    SQLServer = txtBlobsServer.Text;
                    SQLDB = txtBlobsDB.Text;
                    SQLUser = BlobUser;
                    SQLPW = BlobPW;
                    break;
                case PageType.Export:
                    SQLServer = txtExServer.Text;
                    SQLDB = txtExDB.Text;
                    SQLUser = ExportUser;
                    SQLPW = ExportPW;
                    break;
                case PageType.Import:
                    SQLServer = txtImServer.Text;
                    SQLDB = txtImDB.Text;
                    SQLUser = ImportUser;
                    SQLPW = ImportPW;
                    break;
                case PageType.MergeFederalMaster:
                    SQLServer = txtMergeFMMasterServer.Text;
                    SQLDB = txtMergeFMMasterDB.Text;
                    SQLUser = MergeFMMasterUser; ;
                    SQLPW = MergeFMMasterPW;
                    break;
                case PageType.MergeFederalModule:
                    SQLServer = txtMergeFMModuleServer.Text;
                    SQLDB = txtMergeFMModuleDB.Text;
                    SQLUser = MergeFMModuleUser;
                    SQLPW = MergeFMModulePW;
                    break;
                case PageType.MergeState:
                    SQLServer = txtMergeSTServer.Text;
                    SQLDB = txtMergeSTDB.Text;
                    SQLUser = MergeSTUser;
                    SQLPW = MergeSTPW;
                    break;
                case PageType.ModuleDeletion:
                    SQLServer = txtDelModServer.Text;
                    SQLDB = txtDelModDB.Text;
                    SQLUser = DelModuleUser;
                    SQLPW = DelStatePW;
                    break;
                case PageType.IPone:
                    SQLServer = txtIPhoneServer.Text;
                    SQLDB = txtIPhoneDB.Text;
                    SQLUser = IPhoneUser;
                    SQLPW = IPhonePW;
                    break;
                case PageType.DeleteState:
                    SQLServer = txtDelStServer.Text;
                    SQLDB = txtDelStDB.Text;
                    SQLUser = DelModuleUser;
                    SQLPW = DelStatePW;
                    break;
                case PageType.VewDB:
                    SQLServer = txtVewDBServer.Text;
                    SQLDB = txtVewDBDB.Text;
                    SQLUser = ViewDBUser;
                    SQLPW = ViewDBPW;
                    break;
                case PageType.DakrefSource:
                    SQLServer = txtDakrefSrcServer.Text;
                    SQLDB = txtDakrefSrcDB.Text;
                    SQLUser = DakrefSrcDBUser;
                    SQLPW = DakrefSrcDBPW;
                    break;
                case PageType.DakrefTaget:
                    SQLServer = txtDakrefTagServer.Text;
                    SQLDB = txtDakrefTagDB.Text;
                    SQLUser = DakrefTagDBUser;
                    SQLPW = DakrefTagDBPW;
                    break;
                case PageType.Upload:
                    //SQLServer = txtExcelTagServer.Text;
                    //SQLDB = txtExcelTagDB.Text;
                    SQLUser = ExcelTagDBUser;
                    SQLPW = ExcelTagDBPW;
                    break;
                case PageType.ConfigBackup:
                    SQLServer = txtConfigBakServerName.Text;
                    SQLDB = txtConfigBakDBName.Text;
                    SQLUser = ConfigBakDBUser;
                    SQLPW = ConfigBakDBPW;
                    break;
                case PageType.ConfigRestore:
                    SQLServer = txtConfigResServerName.Text;
                    SQLDB = txtConfigResDBName.Text;
                    SQLUser = ConfigResDBUser;
                    SQLPW = ConfigResDBPW;
                    break;
                default:
                    break;
            }
        }
        private void GetServer(PageType pType)
        {
            switch (pType)
            {
                case PageType.BuildMODULE:
                    txtModuleServer.Text = SQLServer;
                    txtModuleDB.Text = SQLDB;
                    ModuleUser = SQLUser;
                    ModulePW = SQLPW;

                    SaveConfig("BuldModuleServer", SQLServer);
                    SaveConfig("BuldModuleDB", SQLDB);
                    SaveConfig("BuldModuleDBUser", SQLUser);
                    SaveConfig("BuldModuleDBPW", SQLPW);

                    txtModuleVer.Text = "";
                    break;
                case PageType.BlobsCreation:
                    txtBlobsServer.Text = SQLServer;
                    txtBlobsDB.Text = SQLDB;
                    BlobUser = SQLUser;
                    BlobPW = SQLPW;

                    SaveConfig("BlobServer", SQLServer);
                    SaveConfig("BlobDB", SQLDB);
                    SaveConfig("BlobDBUser", SQLUser);
                    SaveConfig("BlobDBPW", SQLPW);

                    txtBlobsVer.Text = "";
                    break;
                case PageType.Export:
                    txtExServer.Text = SQLServer;
                    txtExDB.Text = SQLDB;
                    ExportUser = SQLUser;
                    ExportPW = SQLPW;

                    SaveConfig("ExportServer", SQLServer);
                    SaveConfig("ExportDB", SQLDB);
                    SaveConfig("ExportDBUser", SQLUser);
                    SaveConfig("ExportDBPW", SQLPW);

                    txtExVersion.Text = "";
                    break;
                case PageType.Import:
                    txtImServer.Text = SQLServer;
                    txtImDB.Text = SQLDB;
                    ImportUser = SQLUser;

                    SaveConfig("ImportServer", SQLServer);
                    SaveConfig("ImportDB", SQLDB);
                    SaveConfig("ImportDBUser", SQLUser);
                    SaveConfig("ImportDBPW", SQLPW);
                    ImportPW = SQLPW;

                    txtImVersion.Text = "";
                    break;
                case PageType.MergeFederalMaster:
                    txtMergeFMMasterServer.Text = SQLServer;
                    txtMergeFMMasterDB.Text = SQLDB;
                    MergeFMMasterUser = SQLUser;
                    MergeFMMasterPW = SQLPW;

                    SaveConfig("MergeFederalMasterServer", SQLServer);
                    SaveConfig("MergeFederalMasterDB", SQLDB);
                    SaveConfig("MergeFederalMasterUser", SQLUser);
                    SaveConfig("MergeFederalMasterPW", SQLPW);

                    txtMergeFMasterVer.Text = "";
                    break;
                case PageType.MergeFederalModule:
                    txtMergeFMModuleServer.Text = SQLServer;
                    txtMergeFMModuleDB.Text = SQLDB;
                    MergeFMModuleUser = SQLUser;
                    MergeFMModulePW = SQLPW;

                    SaveConfig("MergeFederalModuleServer", SQLServer);
                    SaveConfig("MergeFederalModuleDB", SQLDB);
                    SaveConfig("MergeFederalModuleUser", SQLUser);
                    SaveConfig("MergeFederalModulePW", SQLPW);

                    txtMergeFModuleVer.Text = "";
                    break;
                case PageType.MergeState:
                    txtMergeSTServer.Text = SQLServer;
                    txtMergeSTDB.Text = SQLDB;
                    MergeSTUser = SQLUser;
                    MergeSTPW = SQLPW;

                    SaveConfig("MergeStateServer", SQLServer);
                    SaveConfig("MergeStateDB", SQLDB);
                    SaveConfig("MergeStateDBUser", SQLUser);
                    SaveConfig("MergeStateDBPW", SQLPW);

                    txtMergeSTVer.Text = "";
                    break;
                case PageType.ModuleDeletion:
                    txtDelModServer.Text = SQLServer;
                    txtDelModDB.Text = SQLDB;
                    DelModuleUser = SQLUser;
                    DelStatePW = SQLPW;

                    SaveConfig("DelModuleServer", SQLServer);
                    SaveConfig("DelModuleDB", SQLDB);
                    SaveConfig("DelModuleDBUser", SQLUser);
                    SaveConfig("DelModuleDBPW", SQLPW);

                    txtDelModVer.Text = "";
                    break;
                case PageType.IPone:
                    txtIPhoneServer.Text = SQLServer;
                    txtIPhoneDB.Text = SQLDB;
                    IPhoneUser = SQLUser;
                    IPhonePW = SQLPW;

                    SaveConfig("IPhoneServer", SQLServer);
                    SaveConfig("IPhoneDB", SQLDB);
                    SaveConfig("IPhoneDBUser", SQLUser);
                    SaveConfig("IPhoneDBPW", SQLPW);

                    break;
                case PageType.DeleteState:
                    txtDelStServer.Text = SQLServer;
                    txtDelStDB.Text = SQLDB;
                    DelStateUser = SQLUser;
                    DelStatePW = SQLPW;

                    SaveConfig("DelStateServer", SQLServer);
                    SaveConfig("DelStateDB", SQLDB);
                    SaveConfig("DelStateDBUser", SQLUser);
                    SaveConfig("DelStateDBPW", SQLPW);

                    txtDelStVer.Text = "";
                    break;
                case PageType.VewDB:
                    txtVewDBServer.Text = SQLServer;
                    txtVewDBDB.Text = SQLDB;
                    ViewDBUser = SQLUser;
                    ViewDBPW = SQLPW;

                    SaveConfig("ViewDBServer", SQLServer);
                    SaveConfig("ViewDBDB", SQLDB);
                    SaveConfig("ViewDBUser", SQLUser);
                    SaveConfig("ViewDBPW", SQLPW);

                    txtVewDBVer.Text = "";
                    break;
                case PageType.DakrefSource:
                    txtDakrefSrcServer.Text = SQLServer;
                    txtDakrefSrcDB.Text = SQLDB;
                    DakrefSrcDBUser = SQLUser;
                    DakrefSrcDBPW = SQLPW;

                    SaveConfig("DakrefSrcDBServer", SQLServer);
                    SaveConfig("DakrefSrcDB", SQLDB);
                    SaveConfig("DakrefSrcDBUser", SQLUser);
                    SaveConfig("DakrefSrcDBPW", SQLPW);

                    txtDakrefSrcVer.Text = "";
                    break;
                case PageType.DakrefTaget:
                    txtDakrefTagServer.Text = SQLServer;
                    txtDakrefTagDB.Text = SQLDB;
                    DakrefTagDBUser = SQLUser;
                    DakrefTagDBPW = SQLPW;

                    SaveConfig("DakrefTagDBServer", SQLServer);
                    SaveConfig("DakrefTagDB", SQLDB);
                    SaveConfig("DakrefTagDBUser", SQLUser);
                    SaveConfig("DakrefTagDBPW", SQLPW);

                    txtDakrefTagVer.Text = "";
                    break;
                case PageType.Upload:
                    //txtExcelTagServer.Text = SQLServer;
                    //txtExcelTagDB.Text = SQLDB;
                    ExcelTagDBUser = SQLUser;
                    ExcelTagDBPW = SQLPW;

                    SaveConfig("ExcelTagDBServer", SQLServer);
                    SaveConfig("ExcelTagDB", SQLDB);
                    SaveConfig("ExcelTagDBUser", SQLUser);
                    SaveConfig("ExcelTagDBPW", SQLPW);

                    txtDakrefTagVer.Text = "";
                    break;
                case PageType.ConfigBackup:
                    txtConfigBakServerName.Text = SQLServer;
                    txtConfigBakDBName.Text = SQLDB;
                    ConfigBakDBUser = SQLUser;
                    ConfigBakDBPW = SQLPW;

                    SaveConfig("ConfigBakDBServer", SQLServer);
                    SaveConfig("ConfigBakDB", SQLDB);
                    SaveConfig("ConfigBakDBUser", SQLUser);
                    SaveConfig("ConfigBakDBPW", SQLPW);

                    txtConfigBakVer.Text = "";
                    break;
                case PageType.ConfigRestore:
                    txtConfigResServerName.Text = SQLServer;
                    txtConfigResDBName.Text = SQLDB;
                    ConfigResDBUser = SQLUser;
                    ConfigResDBPW = SQLPW;

                    SaveConfig("ConfigResDBServer", SQLServer);
                    SaveConfig("ConfigResDB", SQLDB);
                    SaveConfig("ConfigResDBUser", SQLUser);
                    SaveConfig("ConfigResDBPW", SQLPW);

                    txtConfigResVer.Text = "";
                    break;
                default:
                    break;
            }
        }

        private void btnModuleOpen_Click(object sender, EventArgs e)
        {
            btnModuleOpen.Enabled = false;
            btnModuleStart.Enabled = false;
            processError = false;

            SetServer(PageType.BuildMODULE);

            if (isAutoProcess)
            {
                GetDbInfo(PageType.BuildMODULE);
            }
            else
            {
                Thread tr = new Thread(new ParameterizedThreadStart(GetDbInfo));
                tr.Start(PageType.BuildMODULE);

                while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
                {
                    Application.DoEvents();
                    OutMsg();
                    Thread.Sleep(200);
                }
            }

            if (!processError)
            {
                btnModuleStart.Enabled = true;
            }
            else
            {
                processError = false;
            }

            btnModuleOpen.Enabled = true;
            btnModuleStart.Enabled = true;
            OutMsg();
        }

        private void btnIPhoneConfig_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;
            frmDBConfig _frmDBCfig = new frmDBConfig();

            _frmDBCfig._parent = this;

            SetServer(PageType.IPone);

            _frmDBCfig.ShowDialog(this);

            if (SQLConfigSubmitted)
            {
                GetServer(PageType.IPone);
            }
        }

        private void btnIPhoneCancel_Click(object sender, EventArgs e)
        {
            cancelPressed = true;
            SqlServerToSQLite.CancelConversion();
        }

        private void btnViewDBConfig_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;
            frmDBConfig _frmDBCfig = new frmDBConfig();

            SetServer(PageType.VewDB);

            _frmDBCfig._parent = this;
            _frmDBCfig.ShowDialog(this);

            if (SQLConfigSubmitted)
            {
                GetServer(PageType.VewDB);
            }
        }

        internal void DisplayMessageBox(string text, string caption, MessageBoxButtons Buttons, MessageBoxIcon Icon)
        {
            if (this.InvokeRequired)
            {
                object[] parm = new object[4];
                parm[0] = text;
                parm[1] = caption;
                parm[2] = Buttons;
                parm[3] = Icon;
                this.BeginInvoke(new MessageCallBack(DisplayMessageBox), parm);
            }
            else
            {
                dResult = MessageBox.Show(this, text, caption, Buttons, Icon);
            }
        }

        private void chkImCreateNewDB_CheckedChanged(object sender, EventArgs e)
        {
            txtImNewDB.Enabled = chkImCreateNewDB.Checked;

            btnImport.Enabled = (lblImMsg.Text == "");
        }

        private void EnableDakrefButton()
        {
            if (chkDakrefVerTest.Checked)
            {
                btnDakrefProcess.Enabled = (txtDakrefSrcVer.Text.Trim() != string.Empty) &&
                                              (txtDakrefTagVer.Text.Trim() != string.Empty) &&
                                              (txtDakrefNewVer.Text.Trim() != string.Empty);
            }
            else
            {
                btnDakrefProcess.Enabled = (txtDakrefSrcVer.Text.Trim() != string.Empty) &&
                                                   (txtDakrefTagVer.Text.Trim() != string.Empty) &&
                                                   (txtDakrefNewVer.Text.Trim() != string.Empty) &&
                                                   (txtDakrefMigration.Text.Trim() != string.Empty) &&
                                                   (txtDakrefModuleOrder.Text.Trim() != string.Empty) &&
                                                   (txtDakrefWhatNew.Text.Trim() != string.Empty);
            }
        }

        private void btnDakrefSrcConfig_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;
            frmDBConfig _frmDBCfig = new frmDBConfig();

            _frmDBCfig._parent = this;

            SetServer(PageType.DakrefSource);

            _frmDBCfig.ShowDialog(this);

            if (SQLConfigSubmitted)
            {
                GetServer(PageType.DakrefSource);
                EnableDakrefButton();
            }
        }

        private void btnDakrefTagConfig_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;
            frmDBConfig _frmDBCfig = new frmDBConfig();

            _frmDBCfig._parent = this;

            SetServer(PageType.DakrefTaget);

            _frmDBCfig.ShowDialog(this);

            if (SQLConfigSubmitted)
            {
                GetServer(PageType.DakrefTaget);
                EnableDakrefButton();
            }
        }

        private void btnDakrefSrcOpen_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;
            btnDakrefProcess.Enabled = false;
            processError = false;

            SetServer(PageType.DakrefSource);

            Thread tr = new Thread(new ParameterizedThreadStart(GetDbInfo));
            //invokingCount = 0;
            tr.Start(PageType.DakrefSource);

            while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
            {
                Application.DoEvents();
                OutMsg();
                //Thread.Sleep(200);
            }

            if (!processError)
            {
                //btnBlobsProcess.Enabled = true;
            }
            else
            {
                processError = false;
            }

            EnableDakrefButton();
            //btnDakrefProcess.Enabled = true;
            OutMsg();
        }

        private void btnDakrefTagOpen_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;
            btnDakrefProcess.Enabled = false;
            processError = false;

            SetServer(PageType.DakrefTaget);

            Thread tr = new Thread(new ParameterizedThreadStart(GetDbInfo));
            //invokingCount = 0;
            tr.Start(PageType.DakrefTaget);

            while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
            {
                Application.DoEvents();
                OutMsg();
                //Thread.Sleep(200);
            }

            if (!processError)
            {
                //btnBlobsProcess.Enabled = true;
            }
            else
            {
                processError = false;
            }
            EnableDakrefButton();
            //btnDakrefProcess.Enabled = true;
            OutMsg();
        }

        DataSql _dSqlTag = null;
        DataSql _dSqlSrc = null;

        //'check to see if some basics are present before allowing the application to run
        private bool VerifySqlObjects()
        {
            //        'check if its possible to connect to dakref_full
            //string strResult = _dSqlTag.RunSQL("exec usp_DakRefFullBuild_VerifyObjects");
            string strResult = _dSqlTag.RunSQL("exec usp_DakRefFullBuild_VerifyObjects");
            if (strResult != "")
            {
                MessageBox.Show(this, strResult, "Verify Sql Objects");

                return false;
            }

            SqlDataReader _reader = null;

            //        'make sure all the stored procedures are present
            _reader = _dSqlTag.GetReader("select count(name) from sysobjects where xtype = 'P' and name like 'usp_DakRefFullBuild_%'");
            if (_reader != null)
            {
                if (_reader.Read())
                {
                    if (_reader.GetInt32(0) < 25)
                    {
                        MessageBox.Show(this, "The database does not have the proper amount of stored procedures.", "Verify Sql Objects");
                        _reader.Close();
                        return false;
                    }
                }
                _reader.Close();
                return true;
            }

            return false;
        }

        int iModuleVersion = -1;
        int iStateVersion = -1;
        private bool GetModuleVersion()
        {
            SqlDataReader _reader = null;
            iModuleVersion = -1;
            iStateVersion = -1;
            bool result = true;

            try
            {
                _dSqlSrc.Open();
                //'This function updates the VERSION table with the latest version id, module version sn, and state version sn.
                _reader = _dSqlSrc.GetReader("SELECT MAX(ModuleVersionSN) FROM ModuleVersion");
                if (_reader == null)
                {
                    MessageBox.Show(this, "Can't connect to DB!", "Module Version Retrieve",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

                if (_reader.Read())
                {
                    try
                    {
                        iModuleVersion = int.Parse(_reader.GetValue(0).ToString());
                    }
                    catch
                    {
                        MessageBox.Show(this, "ModuleVersionSN was not found",
                                    "Module Version Retrieve", MessageBoxButtons.OK, MessageBoxIcon.Error);

                        result = false;
                    }
                }
                else
                {
                    MessageBox.Show("ModuleVersionSN was not found", "Module Version Retrieve", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    result = false;
                }
                _reader.Close();

                _reader = _dSqlSrc.GetReader("SELECT MAX(StateVersionSN) FROM StateModule");
                if (_reader == null)
                {
                    MessageBox.Show(this, "Can't connect to DB!", "State Version Retrieve", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

                if (_reader.Read())
                {
                    try
                    {
                        iStateVersion = int.Parse(_reader.GetValue(0).ToString());
                    }
                    catch
                    {
                        MessageBox.Show(this, "StateVersionSN was not found", "State Version Retrieve", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        result = false;
                    }
                }
                else
                {
                    MessageBox.Show("StateVersionSN was not found", "State Version Retrieve", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    result = false;
                }

                _reader.Close();

                //if (result && iModuleVersion > -1)
                //{
                //    string ret = _dSqlSrc.RunSQL("UPDATE Version SET VersionID = " + iModuleVersion.ToString());
                //    if (ret != "")
                //    {
                //        MessageBox.Show(this, ret, "Update Version", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //        result = false;
                //    }
                //}
            }
            catch
            {
                result = false;
            }
            finally
            {
                _dSqlSrc.Close();
            }
            return result;
        }

        private bool CleanUpDatabase()
        {
            _dSqlTag.Open();
            string result = _dSqlTag.RunSQL("exec usp_DakRefFullBuild_CleanUp " + iModuleVersion.ToString());
            _dSqlTag.Close();

            if (result == "")
            {
                return true;
            }
            else
            {
                MessageBox.Show(this, result, "Clean Up Database");
                return false;
            }
        }

        private void btnDakrefProcess_Click(object sender, EventArgs e)
        {
            cancelPressed = false;
            processFailed = false;

            if (ValidateFormDakref)
            {
                if (_dSqlTag == null)
                {
                    _dSqlTag = new DataSql(txtDakrefTagServer.Text,
                            txtDakrefTagDB.Text, DakrefTagDBUser, DakrefTagDBPW);
                    _dSqlTag.checkCancel += new DataSql.IsCancel(IsCancel);
                }
                else
                {
                    _dSqlTag.SetServer(txtDakrefTagServer.Text,
                            txtDakrefTagDB.Text, DakrefTagDBUser, DakrefTagDBPW);
                }

                if (_dSqlSrc == null)
                {
                    _dSqlSrc = new DataSql(txtDakrefSrcServer.Text,
                            txtDakrefSrcDB.Text, DakrefSrcDBUser, DakrefSrcDBPW);
                    _dSqlSrc.checkCancel += new DataSql.IsCancel(IsCancel);
                }
                else
                {
                    _dSqlSrc.SetServer(txtDakrefSrcServer.Text,
                            txtDakrefSrcDB.Text, DakrefSrcDBUser, DakrefSrcDBPW);
                }

                _dSqlTag.Open();

                OutMsg(PageType.Dakref, "Process started at: " + DateTime.Now.ToString("hh:mm:ss") + ".\r\n");

                //_dSqlTag.RunSQL(Query.DakRefFull_SP);
                _dSqlTag.RunSQL(Query.DakRefFull_SP_Unicode);

                //'verify the database is ready to go.
                OutMsg(PageType.Dakref, "Verify Sql Objects " + Environment.NewLine, true);

                if (!VerifySqlObjects())
                {
                    _dSqlTag.Close();
                    OutMsg(PageType.Dakref, "The database does not have the proper amount of stored procedures." + Environment.NewLine, true);
                    return;
                }
                _dSqlTag.Close();

                OutMsg(PageType.Dakref, "Retrieving Module Version " + Environment.NewLine, true);

                if (!GetModuleVersion())
                {
                    OutMsg(PageType.Dakref, "Retrive module version failed!" + Environment.NewLine, true);
                    return;
                }

                OutMsg(PageType.Dakref, "Clean Up DakRef " + Environment.NewLine, true);
                if (!CleanUpDatabase())
                {
                    OutMsg(PageType.Dakref, "Transfer Data cancelled.\r\n", true);
                    return;
                }

                isProcessing = true;
                SetDakrefButtonStatus(false);

                OutMsg(PageType.Dakref, "Transfering data." + Environment.NewLine, true);

                Thread tr = new Thread(new ThreadStart(LaunchDTS));
                tr.Start();

                while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
                {
                    if (cancelPressed)
                    {
                        OutMsg(PageType.Dakref, "Cancelling");
                        while (tr.IsAlive)
                        {
                            Application.DoEvents();
                            OutMsg(PageType.Dakref, ".");
                            OutMsg();
                            Thread.Sleep(300);
                        }
                        OutMsg(PageType.Dakref, ".");
                    }
                    Application.DoEvents();
                    OutMsg();
                }

                DateTime dt = DateTime.Now;

                if (!cancelPressed)
                {
                    if (processFailed)
                    {
                        MessageBox.Show(this, "Transfer Data failed", "Transfer Data", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        OutMsg(PageType.Dakref, "Transfer Data failed.\r\n", true);
                    }
                    else
                    {
                        //MessageBox.Show(this, "Transfer Data done!", "Transfer Data");
                        OutMsg(PageType.Dakref, "Transfer Data done.\r\n", true);
                    }
                }
                else
                {
                    OutMsg(PageType.Dakref, "Transfer Data cancelled.\r\n", true);
                    //cancelPressed = false;
                }

                if (!processFailed && !cancelPressed)
                {
                    //UpdateDakRefFull();
                    OutMsg(PageType.Dakref, "Updating data. Starting at:" + DateTime.Now.ToString("hh:mm:ss") + Environment.NewLine, true);

                    tr = new Thread(new ThreadStart(UpdateDakRefFull));
                    tr.Start();

                    while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
                    {
                        if (cancelPressed)
                        {
                            OutMsg(PageType.Dakref, "Cancelling");
                            while (tr.IsAlive)
                            {
                                Application.DoEvents();
                                OutMsg(PageType.Dakref, ".");
                                OutMsg();
                                Thread.Sleep(300);
                            }
                            OutMsg(PageType.Dakref, ".");
                        }
                        Application.DoEvents();
                        OutMsg();
                    }

                    dt = DateTime.Now;

                    if (!cancelPressed)
                    {
                        if (processFailed)
                        {
                            MessageBox.Show(this, "Update Data failed", "Transfer Data", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            OutMsg(PageType.Dakref, "Update Data failed.\r\n", true);
                        }
                        else
                        {
                            MessageBox.Show(this, "Update Data done!", "Transfer Data");
                        }
                    }
                    else
                    {
                        OutMsg(PageType.Dakref, "Update Data cancelled.\r\n", true);
                        cancelPressed = false;
                    }
                }

                SetDakrefButtonStatus(true);
                isProcessing = false;
                cancelPressed = false;
                OutMsg(PageType.Dakref, "Process ended at: " + dt.ToString("hh:mm:ss") + ".\r\n", true);
            }
        }

        //'this sub is tied to the thread for processing the database
        private bool CreateAbridgedDomains()
        {
            if (_dSqlTag.RunSQL("exec usp_DakRefFullBuild_Abridged") == "")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private bool TagDateCleanUp()
        {
            if (_dSqlTag.RunSQL("exec usp_DakRefFullBuild_TagDateCleanUp") == "")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private bool CalculateActionableTagDates()
        {
            string ret = _dSqlTag.RunSQL("exec usp_DakRefFullBuild_Calculate_Actionable_TagDates", 0);
            if (ret == "")
            {
                return true;
            }
            else
            {
                OutMsg(PageType.Dakref, ret + ".\r\n", true);
                return false;
            }
        }
        private bool AddKeywordsQuestion()
        {
            if (_dSqlTag.RunSQL("exec usp_DakRefFullBuild_AddActiveKeywordsQuestion") == "")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private bool CreateQuestionLink()
        {
            if (_dSqlTag.RunSQL("exec usp_DakRefFullBuild_CreateQuestionLink @ModuleVersionSN = "
                    + iModuleVersion.ToString()) == "")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private string ProcessByteArrToString(string sTagDate)
        {
            StringBuilder sbTagDate = new StringBuilder();
            string sTemp = null;
            byte[] bArr = null;

            for (int i = 0; i < sTagDate.Length; i++)
            {
                if (sTagDate[i] == '\\')
                {
                    if (i < sTagDate.Length - 1)
                    {
                        if (sTagDate[i + 1] == '\\')
                        {
                            sbTagDate.Append(sTagDate[i].ToString());

                            i++;
                            continue;
                        }
                    }

                    if (i < sTagDate.Length - 3)
                    {
                        if (sTagDate[i + 1] == 'x' || sTagDate[i + 1] == 'X')
                        {
                            //try
                            //{
                            int iTmp1 = int.Parse(sTagDate[i + 2].ToString(), NumberStyles.HexNumber);
                            int iTmp2 = int.Parse(sTagDate[i + 3].ToString(), NumberStyles.HexNumber);
                            string str = ASCIIEncoding.Default.GetString(new byte[] { (byte)(iTmp1 * 16 + iTmp2) });

                            sbTagDate.Append(str);
                            i += 3;
                            //}
                            //catch (Exception e)
                            //{
                            //}
                        }
                        else
                        {
                            sbTagDate.Append(sTagDate[i].ToString());
                        }
                    }
                    else
                    {
                        sbTagDate.Append(sTagDate[i].ToString());
                    }
                }
                else
                {
                    sbTagDate.Append(sTagDate[i].ToString());
                }
            }

            bArr = ASCIIEncoding.Default.GetBytes(sbTagDate.ToString());


            sbTagDate.Remove(0, sbTagDate.Length);
            for (int i = 0; i < bArr.Length; i++)
            {
                sTemp = CVTHEX.ByteToHex(bArr[i]); //Hex(bArr(x))

                if (sTemp.Length == 1)
                {
                    sTemp = "0" + sTemp;
                }

                sbTagDate.Append(sTemp);
            }

            return sbTagDate.ToString();
        }
        private string CreateChangeXml(string sTagDate, int iSectionSN, int iModuleSN)
        {
            StringBuilder sbTemp = new StringBuilder();
            StringBuilder sbXml = new StringBuilder();
            int iStartDate = -1;
            int iStart = -1;
            int iLength = -1;

            while (sTagDate.Length > 0)
            {
                //'Parse over Hex string to get the change date, start point, and the length.
                sbTemp.Remove(0, sbTemp.Length);
                sbTemp.Append(sTagDate.Substring(6, 2));
                sbTemp.Append(sTagDate.Substring(4, 2));
                sbTemp.Append(sTagDate.Substring(2, 2));
                sbTemp.Append(sTagDate.Substring(0, 2));
                if (sbTemp.Length > 0)
                {
                    iStartDate = Int32.Parse(sbTemp.ToString(), NumberStyles.HexNumber);

                }
                else
                {
                    iStartDate = 0;
                }

                sbTemp.Remove(0, sbTemp.Length);
                sbTemp.Append(sTagDate.Substring(14, 2));
                sbTemp.Append(sTagDate.Substring(12, 2));
                sbTemp.Append(sTagDate.Substring(10, 2));
                sbTemp.Append(sTagDate.Substring(8, 2));
                if (sbTemp.Length > 0)
                {
                    iStart = Int32.Parse(sbTemp.ToString(), NumberStyles.HexNumber);
                }
                else
                {
                    iStart = 0;
                }

                //if (sbTemp.ToString() == "3F5D0000")
                //{
                //    string s = "";
                //}

                sbTemp.Remove(0, sbTemp.Length);
                sbTemp.Append(sTagDate.Substring(22, 2));
                sbTemp.Append(sTagDate.Substring(20, 2));
                sbTemp.Append(sTagDate.Substring(18, 2));
                sbTemp.Append(sTagDate.Substring(16, 2));
                if (sbTemp.Length > 0)
                {
                    iLength = Int32.Parse(sbTemp.ToString(), NumberStyles.HexNumber);
                }
                else
                {
                    iLength = 0;
                }

                //'build the xml for each record to be inserted.
                sbXml.Append("<record>");
                sbXml.Append("<sectionsn>");
                sbXml.Append(iSectionSN.ToString());
                sbXml.Append("</sectionsn>");
                sbXml.Append("<modulesn>");
                sbXml.Append(iModuleSN.ToString());
                sbXml.Append("</modulesn>");
                sbXml.Append("<changedate>");
                sbXml.Append(iStartDate.ToString());
                sbXml.Append("</changedate>");
                sbXml.Append("<start>");
                sbXml.Append(iStart.ToString());
                sbXml.Append("</start>");
                sbXml.Append("<length>");
                sbXml.Append(iLength.ToString());
                sbXml.Append("</length>");
                sbXml.Append("</record>");

                sTagDate = sTagDate.Remove(0, 24);

                //if (iStartDate == 20004688)
                //{
                //    string s = "";
                //}

                //if (iStartDate > 20111212)
                //{
                //    string s = "";
                //}
            }

            return sbXml.ToString();
        }
        private bool GetTagDate()
        {
            StringBuilder sbSql = new StringBuilder();
            StringBuilder sbXml = new StringBuilder();
            SqlDataReader _reader = _dSqlTag.GetReader("SELECT SectionSN,TagDate,ModuleSN FROM RGSection");

            if (_reader == null)
            {
                return false;
            }

            int iSectionSN = -1;
            int iModuleSN = -1;

            try
            {
                while (_reader.Read())
                {
                    if (!_reader.IsDBNull(_reader.GetOrdinal("SectionSN")))
                    {
                        iSectionSN = _reader.GetInt32(_reader.GetOrdinal("SectionSN"));

                        if (!_reader.IsDBNull(_reader.GetOrdinal("ModuleSN")))
                        {
                            iModuleSN = _reader.GetInt32(_reader.GetOrdinal("ModuleSN"));
                        }

                        if (!_reader.IsDBNull(_reader.GetOrdinal("TagDate")))
                        {
                            string sTagDate = _reader.GetString(_reader.GetOrdinal("TagDate"));

                            sTagDate = ProcessByteArrToString(sTagDate);
                            sbXml.Append(CreateChangeXml(sTagDate, iSectionSN, iModuleSN));
                        }
                    }
                    else
                    {
                        iSectionSN = 0;
                    }
                }
                _reader.Close();

                if (sbXml.Length > 0)
                {
                    sbSql.Remove(0, sbSql.Length);
                    sbSql.Append("usp_DakRefFullBuild_ChangeRecords '<records>");
                    sbSql.Append(sbXml.ToString());
                    sbSql.Append("</records>'");

                    string result = _dSqlTag.RunSQL(sbSql.ToString());

                    if (result != "")
                    {
                        return false;
                    }
                }
                return true;
            }
            catch //(Exception e)
            {
                _reader.Close();
                return false;
            }
            finally
            {
            }
        }
        private bool FederalSubQuestionUpdate()
        {
            if (_dSqlTag.RunSQL("exec usp_DakRefFullBuild_InsertFedSubQuestions @LastModuleVersionSN = " +
                    iModuleVersion.ToString()) == "")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private bool ConvertApplicability()
        {
            if (_dSqlTag.RunSQL("exec usp_DakRefFullBuild_ConvertApplicability @LastModuleVersionSN = " +
                    iModuleVersion.ToString()) == "")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private bool UpdateSubQuestions()
        {
            if (_dSqlTag.RunSQL("exec usp_DakRefFullBuild_UpdateSubQuestions @LastModuleVersionSN = " +
                    iModuleVersion.ToString()) == "")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private bool RenumberChildOrder()
        {
            if (_dSqlTag.RunSQL("exec usp_DakRefFullBuild_RenumberChildOrder @ModuleVersionSN = " +
                    iModuleVersion.ToString()) == "")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private bool WmiLinksUpdate()
        {
            if (_dSqlTag.RunSQL("exec usp_DakRefFullBuild_WmiLinks_Upd") == "")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private bool QuestionCleanUp()
        {
            StringBuilder sbSql = new StringBuilder();
            string sText = null;
            int iStart = -1;
            int iEnd = -1;

            Hashtable htQuestions = new Hashtable();

            sbSql.Append("select QuestionBodySN,StdText from questionbody ");
            sbSql.Append("WHERE stdText LIKE '%COMPARISON:%STATE VS. FEDERAL' + char(10) + char(10) + 'Rules.%'");

            SqlDataReader _reader = _dSqlTag.GetReader(sbSql.ToString());
            if (_reader == null)
            {
                return false;
            }

            while (_reader.Read())
            {
                if (!_reader.IsDBNull(_reader.GetOrdinal("QuestionBodySN")))
                {
                    if (!_reader.IsDBNull(_reader.GetOrdinal("StdText")))
                    {
                        htQuestions.Add(_reader.GetInt32(_reader.GetOrdinal("QuestionBodySN")), _reader.GetString(_reader.GetOrdinal("StdText")));
                    }
                }
            }
            _reader.Close();

            foreach (DictionaryEntry deItem in htQuestions)
            {
                sbSql.Remove(0, sbSql.Length);

                sbSql.Append("UPDATE QuestionBody SET StdText = '");

                sText = deItem.Value.ToString();
                iStart = sText.IndexOf("comparison:");//,StringComparison. CompareMethod.Text)
                iEnd = sText.IndexOf("State VS. Federal");//, CompareMethod.Text)
                iStart = iStart + "comparison:".Length;

                if (iStart > 0 && iEnd > 0)
                {
                    sText = sText.Replace("Comparison:" + Space(iEnd, iStart) + "State VS. Federal\n\nRules.",
                            "COMPARISON: STATE VS. FEDERAL\n");
                }

                sbSql.Append(sText.Replace("'", "''"));
                sbSql.Append("' WHERE QuestionBodySN = ");
                sbSql.Append(deItem.Key.ToString());

                if (_dSqlTag.RunSQL(sbSql.ToString()) != "")
                {
                    return false;
                }
            }

            sbSql.Remove(0, sbSql.Length);
            htQuestions.Clear();

            sbSql.Append("SELECT QuestionBodySN,StdText ");
            sbSql.Append("FROM QuestionBody ");
            sbSql.Append("WHERE stdText LIKE '%COMPARISON: STATE VS. FEDERAL%'+ char(10) + 'administration and enforcement.%'");

            _reader = _dSqlTag.GetReader(sbSql.ToString());
            if (_reader == null)
            {
                return false;
            }

            while (_reader.Read())
            {
                if (!_reader.IsDBNull(_reader.GetOrdinal("QuestionBodySN")))
                {
                    if (!_reader.IsDBNull(_reader.GetOrdinal("StdText")))
                    {
                        htQuestions.Add(_reader.GetInt32(_reader.GetOrdinal("QuestionBodySN")),
                            _reader.GetString(_reader.GetOrdinal("StdText")));
                    }
                }
            }

            _reader.Close();

            foreach (DictionaryEntry deItem in htQuestions)
            {
                sbSql.Remove(0, sbSql.Length);

                sbSql.Append("UPDATE QuestionBody SET StdText = '");

                sText = deItem.Value.ToString();
                iStart = sText.IndexOf("\nAdministration and enforcement.");
                if (sText.IndexOf("(cRev", iStart + 1) > 0)
                {
                    iEnd = sText.IndexOf("(cRev", iStart + 1);
                }
                else
                {
                    if (sText.IndexOf("(Rev", iStart + 1) > 0)
                    {
                        iEnd = sText.IndexOf("(Rev", iStart + 1);
                    }
                    else
                    {
                        iEnd = 0;
                    }
                }

                if (iStart > 0)
                {
                    if (iEnd == 0)
                    {
                        sText = sText.Remove(iStart, sText.Length - iStart);
                    }
                    else
                    {
                        sText = sText.Remove(iStart, (iEnd - 1) - iStart);
                    }
                }

                sbSql.Append(sText.Replace("'", "''"));

                sbSql.Append("' WHERE QuestionBodySN = ");
                sbSql.Append(deItem.Key.ToString());

                _dSqlTag.RunSQL(sbSql.ToString());
                if (_dSqlTag.RunSQL(sbSql.ToString()) != "")
                {
                    return false;
                }
            }

            return true;
        }
        private string Space(int iStart, int iEnd)
        {
            StringBuilder sb = new StringBuilder();

            for (int i = iStart; i < iEnd; i++)
            {
                sb.Append(" ");
            }

            return sb.ToString();
        }
        private bool CleanupRGSectionLinks()
        {
            if (_dSqlTag.RunSQL("exec usp_DakRefFullBuild_Cleanup_RGSection_Links") == "")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private bool DatabaseOptimize()
        {
            if (_dSqlTag.RunSQL(Query.Optimize) == "")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private bool DomainPathUpdate()
        {
            string SQL = "exec usp_DakRefFullBuild_DomainPath " + "@ModuleVersionSN = " + iModuleVersion.ToString();
            string retval;
            retval = _dSqlTag.RunSQL(SQL);
            if (retval == "")
            {
                return true;
            }
            else
            {
                OutMsg(PageType.Dakref, retval + "\r\n");
                return false;
            }
        }
        private bool DomainStructureUpdate()
        {
            if (_dSqlTag.RunSQL("exec usp_DakRefFullBuild_DomainStrucUpdate") == "")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private bool VersionUpdate()
        {

            //string SQL = "exec usp_DakRefFullBuild_VersionUpdate  @ModuleVersion = " + iModuleVersion.ToString()
            //        + ", @StateVersion = " + iStateVersion.ToString()
            //        + ", @VersionNumber = '" + txtDakrefNewVer.Text + "'";

            string[] SQL = new string[]{ "exec usp_DakRefFullBuild_VersionUpdate  @ModuleVersion = " + iModuleVersion.ToString()
                    + ", @StateVersion = " + iStateVersion.ToString()
                    + ", @VersionNumber = '" + txtDakrefNewVer.Text + "'",
                    "INSERT INTO dbo.aw_version_moduleSN (VersionName,ModuleVersionSN) VALUES ('"+txtDakrefNewVer.Text+"',"+iModuleVersion.ToString()+")"};

            if (_dSqlTag.RunSQL(SQL) == "")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private bool FinalStep()
        {
            if (_dSqlTag.RunSQL(Query.DakRefFull_FinalStep) == "")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        //'make sure the child tag dates are set properly
        private bool GetStats()
        {
            if (_dSqlTag.RunSQL("exec usp_DakRefFullBuild_TagDateCleanUp") == "")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private bool BuildCiteCounts()
        {
            if (_dSqlTag.RunSQL("exec usp_DakRefFullBuild_Build_Cites_Counts", 0) == "")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void UpdateDakRefFull()
        {
            try
            {
                _dSqlTag.Open();

                OutMsg(PageType.Dakref, "Create Abridged Domains " + Environment.NewLine);
                if (!CreateAbridgedDomains())
                {
                    processFailed = true;
                    OutMsg(PageType.Dakref, "Create Abridged Domains  FAILED" + Environment.NewLine);
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "State Domain tag date clean up. " + Environment.NewLine);
                if (!TagDateCleanUp())
                {
                    processFailed = true;
                    OutMsg(PageType.Dakref, "State Domain tag date clean up.  FAILED" + Environment.NewLine);
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Add Question Keywords " + Environment.NewLine);
                if (!AddKeywordsQuestion())
                {
                    processFailed = true;
                    OutMsg(PageType.Dakref, "Add Question Keywords  FAILED" + Environment.NewLine);
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Create Question Link " + Environment.NewLine);
                if (!CreateQuestionLink())
                {
                    processFailed = true;
                    OutMsg(PageType.Dakref, "Create Question Link  FAILED" + Environment.NewLine);
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Get Tag Date " + Environment.NewLine);
                if (!GetTagDate())
                {
                    processFailed = true;
                    OutMsg(PageType.Dakref, "Get Tag Date  FAILED" + Environment.NewLine);
                    return;
                }

                //'09.30.08 bws: The following two steps have been moved into the DTS package.

                //''09.29.08 bws:  This step used to come after the next one but that order was incorrect.
                //''The next step depends on this one for the domain path.
                //'OutMsg(PageType.Dakref,"Domain Path Update " & Now.ToShortTimeString)
                //'if(! DomainPathUpdate() )
                //'    bFailure = True
                //'    OutMsg(PageType.Dakref,"Domain Path Update  FAILED")
                //'    
                //'}

                //''09.29.08 bws:  This step used to come before the previous one but that order was incorrect.
                //''This step depends on the previous one for the domain path.
                //'OutMsg(PageType.Dakref,"Domain Structure Update " & Now.ToShortTimeString)
                //'if(! DomainStructureUpdate() )
                //'    bFailure = True
                //'    OutMsg(PageType.Dakref,"Domain Structure Update  FAILED")
                //'    
                //'}

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Federal Sub Question Update " + Environment.NewLine);
                if (!FederalSubQuestionUpdate())
                {
                    processFailed = true;
                    OutMsg(PageType.Dakref, "Federal Sub Question Update  FAILED" + Environment.NewLine);

                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Convert Applicability " + Environment.NewLine);
                if (!ConvertApplicability())
                {
                    processFailed = true;
                    OutMsg(PageType.Dakref, "Convert Applicability  FAILED" + Environment.NewLine);
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Update Sub Question " + Environment.NewLine);
                if (!UpdateSubQuestions())
                {
                    processFailed = true;
                    OutMsg(PageType.Dakref, "Update Sub Question  FAILED" + Environment.NewLine);
                    return;

                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Renumber Child Order " + Environment.NewLine);
                if (!RenumberChildOrder())
                {
                    processFailed = true;
                    OutMsg(PageType.Dakref, "Renumber Child Order  FAILED" + Environment.NewLine);
                    return;

                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "WMI Links Update " + Environment.NewLine);
                if (!WmiLinksUpdate())
                {
                    processFailed = true;
                    OutMsg(PageType.Dakref, "WMI Links Update  FAILED" + Environment.NewLine);
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Question Text Update " + Environment.NewLine);
                if (!QuestionCleanUp())
                {
                    processFailed = true;
                    OutMsg(PageType.Dakref, "Question Text Update  FAILED" + Environment.NewLine);
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                ////''03.17.09 bws: 
                ////''11.12.08 bws:  Removed this from the DTS package and put it here.
                //OutMsg(PageType.Dakref, "Build Cite Counts " + Environment.NewLine);
                //if (!BuildCiteCounts())
                //{
                //    processFailed = true;
                //    OutMsg(PageType.Dakref, "Build Cite Counts  FAILED");

                //    return;
                //}

                //if (processFailed || cancelPressed)
                //{
                //    return;
                //}

                //''11.12.08 bws:  Removed this from the DTS package and put it here.
                OutMsg(PageType.Dakref, "Calculate Actionable TagDates " + Environment.NewLine);
                if (!CalculateActionableTagDates())
                {
                    processFailed = true;
                    OutMsg(PageType.Dakref, "Calculate Actionable TagDates  FAILED" + Environment.NewLine);
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                //'11.12.08 bws:  Removed from the manual list of things to do and put here.
                OutMsg(PageType.Dakref, "Clean up RGSection links" + Environment.NewLine);
                if (!CleanupRGSectionLinks())
                {
                    processFailed = true;
                    OutMsg(PageType.Dakref, "Clean up RGSection links  FAILED" + Environment.NewLine);
                    return;
                }

                //'had to be removed due at request of brooks. 5/23/06
                //'OutMsg(PageType.Dakref,"Url Clean Up " & Now.ToShortTimeString)
                //'If UrlCleanUp() )
                //'    bFailure = False
                //'    OutMsg(PageType.Dakref,"Url Clean Up  FAILED",true);
                //'    
                //'}

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Collecting Statistics " + Environment.NewLine);
                if (!GetStats())
                {
                    processFailed = true;
                    OutMsg(PageType.Dakref, "Collecting Statistics  FAILED" + Environment.NewLine);
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Optimizing Database " + Environment.NewLine);
                if (!DatabaseOptimize())
                {
                    processFailed = true;
                    OutMsg(PageType.Dakref, "Optimizing Database  FAILED" + Environment.NewLine);
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Version Update " + Environment.NewLine);
                if (!VersionUpdate())
                {
                    processFailed = true;
                    OutMsg(PageType.Dakref, "Version Update FAILED" + Environment.NewLine);
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                //01-20-2012 move to last step.
                OutMsg(PageType.Dakref, "Build Cite Counts " + Environment.NewLine);
                if (!BuildCiteCounts())
                {
                    processFailed = true;
                    OutMsg(PageType.Dakref, "Build Cite Counts  FAILED");

                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Final Step " + Environment.NewLine);
                if (!FinalStep())
                {
                    processFailed = true;
                    OutMsg(PageType.Dakref, "Final Step FAILED" + Environment.NewLine);
                    return;
                }
            }
            catch
            {
                processFailed = true;
            }
            finally
            {
                _dSqlTag.Close();
            }
        }

        private void btnDakrefCancel_Click(object sender, EventArgs e)
        {
            cancelPressed = true;
        }

        private void btnDakrefRestore_Click(object sender, EventArgs e)
        {
            cancelPressed = false;
            processFailed = false;

            if (ValidateFormDakrefBackup)
            {
                backPath = txtDakrefBack.Text;
                SetServer(PageType.DakrefTaget);

                OutMsg(PageType.Dakref, "Process started at: " + DateTime.Now.ToShortTimeString() + ".\r\n");
                OutMsg(PageType.Dakref, "Restoring DAKREF..." + Environment.NewLine, true);
                isProcessing = true;
                SetDakrefButtonStatus(false);

                Thread tr = new Thread(new ThreadStart(RestoreDb));
                tr.Start();

                while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
                {
                    //if (cancelPressed)
                    //{
                    //    tr.Abort();

                    //    OutMsg(PageType.Dakref, "Cancelling");
                    //    while (tr.IsAlive)
                    //    {
                    //        Application.DoEvents();
                    //        OutMsg(PageType.Dakref, ".");
                    //        OutMsg();
                    //        Thread.Sleep(300);
                    //    }
                    //    OutMsg(PageType.Dakref, ".");
                    //}
                    Application.DoEvents();
                    OutMsg();
                }

                DateTime dt = DateTime.Now;

                if (!cancelPressed)
                {
                    if (processFailed)
                    {
                        MessageBox.Show(this, "Restore DAKREF failed", "Restore DAKREF ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        OutMsg(PageType.Dakref, "Restore DAKREF failed.\r\n", true);
                    }
                    else
                    {
                        MessageBox.Show(this, "Restore DAKREF  done!", "Restore DAKREF ");
                    }
                }
                else
                {
                    OutMsg(PageType.Dakref, "Restore DAKREF cancelled.\r\n", true);
                    cancelPressed = false;
                }

                SetDakrefButtonStatus(true);
                isProcessing = false;
                OutMsg(PageType.Dakref, "Process ended at: " + dt.ToShortTimeString() + ".\r\n", true);

                txtDakrefTagVer.Text = "";
                blDakrefReleaseDone = false;
            }
            else
            {
                //MessageBox.Show(this, "Incorrect backup file name!", "Restore DAKREF", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //txtDakrefBack.Focus();
            }

            txtDakrefBack.Focus();
        }

        private void SetDakrefButtonStatus(bool Status)
        {
            btnDakrefCancel.Visible = !Status;
            btnDakrefMigrationBrowse.Enabled = Status;
            btnDakrefProcess.Visible = Status;
            btnDakrefReleaseInfo.Enabled = Status;
            btnDakrefRestore.Enabled = Status;
            btnDakrefRestoreBrowse.Enabled = Status;
            btnDakrefSrcConfig.Enabled = Status;
            btnDakrefSrcOpen.Enabled = Status;
            btnDakrefTagConfig.Enabled = Status;
            btnDakrefTagOpen.Enabled = Status;
            btnDakrefUnicode.Enabled = Status;
            btnDakrefWhatNewBrowse.Enabled = Status;
            btnDakrefModuleOrderBrowse.Enabled = Status;
        }
        string backPath = "";
        PageType pgType = PageType.Dakref;

        private void RestoreDb()
        {
            try
            {
                if (_dSqlTag == null)
                {
                    _dSqlTag = new DataSql(SQLServer, SQLDB, SQLUser, SQLPW);
                    _dSqlTag.checkCancel += new DataSql.IsCancel(IsCancel);
                }
                else
                {
                    _dSqlTag.SetServer(SQLServer, SQLDB, SQLUser, SQLPW);
                }

                _dSqlTag.Open();

                string[] arrPath = _dSqlTag.GetDBPhysicalPath(backPath);//.DBPhysicalPath;
                string[] arrSql = new string[]{"USE master", 
                    "DECLARE @Processes TABLE(Spid INT,UniqueID INT IDENTITY(1,1) PRIMARY KEY CLUSTERED) DECLARE @Count as INT DECLARE @Max as INT DECLARE @Sql as Varchar(300) INSERT INTO @Processes (Spid) SELECT spid FROM Master.dbo.SysProcesses sp INNER JOIN Master.dbo.SysDatabases sd ON sd.dbid = sp.dbid WHERE sd.NAME = '"+
                    SQLDB + "' SELECT @Sql = '' SELECT @Count = 1 SELECT @Max = MAX(UniqueID) FROM @Processes WHILE @Count <= @Max BEGIN SELECT @Sql = 'KILL ' + CONVERT(varchar(30),Spid) FROM @Processes WHERE UniqueID = @Count EXEC(@Sql) SELECT @Sql = '' SELECT @Count = @Count + 1 END",
                    "restore database " + SQLDB + " from disk='" + backPath + "' with move '" + arrPath[0] + "' to '" + arrPath[1]+
                    "',move '"+arrPath[2]+"' to '"+arrPath[3]+"',REPLACE",
                    "USE " + SQLDB};

                string ret = _dSqlTag.RunSQL(arrSql);
                if (ret == "")
                {
                    OutMsg(pgType, "Restore database successfuly!" + Environment.NewLine);
                }
                else
                {
                    processFailed = true;
                    OutMsg(pgType, ret + Environment.NewLine);
                }
            }
            catch (Exception e)
            {
                processFailed = true;
                OutMsg(pgType, e.Message + Environment.NewLine);
            }
            finally
            {
                _dSqlTag.Close();
            }
        }
        private void BackupDb()
        {
            try
            {
                if (_dSqlTag == null)
                {
                    _dSqlTag = new DataSql(SQLServer, SQLDB, SQLUser, SQLPW);
                    _dSqlTag.checkCancel += new DataSql.IsCancel(IsCancel);
                }
                else
                {
                    _dSqlTag.SetServer(SQLServer, SQLDB, SQLUser, SQLPW);
                }

                _dSqlTag.Open();

                string[] arrSql = new string[]{"USE master", 
                    "DBCC SHRINKDATABASE ("+SQLDB+", TRUNCATEONLY)",
                    "BACKUP database " + SQLDB + " TO disk='" + backPath + "'  WITH INIT",
                    "USE " + SQLDB};

                string ret = _dSqlTag.RunSQL(arrSql);
                if (ret == "")
                {
                    OutMsg(pgType, "Backup database successfuly!" + Environment.NewLine);
                }
                else
                {
                    processFailed = true;
                    OutMsg(pgType, ret + Environment.NewLine);
                }
            }
            catch
            {
                processFailed = true;
            }
            finally
            {
                _dSqlTag.Close();
            }
        }

        private void btnDakrefRestoreBrowse_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;

            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            try
            {
                openFileDialog1.InitialDirectory = Path.GetDirectoryName(this.txtDakrefBack.Text);
                openFileDialog1.FileName = Path.GetFileName(this.txtDakrefBack.Text);
            }
            catch
            {
                openFileDialog1.InitialDirectory = @"C:\";
            }
            openFileDialog1.Filter = "Back up files (*.bak)|*.bak|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog(this) == DialogResult.OK)
            {
                this.txtDakrefBack.Text = openFileDialog1.FileName;

                SaveConfig("DakrefBakPath", openFileDialog1.FileName);

                //lblDelModuleMsg.Text = string.Empty;
            }
            else
            {
                //if (this.txtDelModName.Text.Trim() == string.Empty || !File.Exists(this.txtDelModName.Text))
                //{
                //    this.lblDelModuleMsg.Text = "Invalid File!";
                //}

            }

        }

        private void btnDakrefUnicode_Click(object sender, EventArgs e)
        {
            cancelPressed = false;
            processFailed = false;

            if (ValidateFormDakrefUnicode)
            {
                OutMsg(PageType.Dakref, "Process started at: " + DateTime.Now.ToShortTimeString() + ".\r\n");
                OutMsg(PageType.Dakref, "Unicoding DAKREF..." + Environment.NewLine, true);
                isProcessing = true;
                SetDakrefButtonStatus(false);

                Thread tr = new Thread(new ThreadStart(Unicode));
                tr.Start();

                while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
                {
                    if (cancelPressed)
                    {
                        //tr.Abort();

                        OutMsg(PageType.Dakref, "Cancelling");
                        while (tr.IsAlive)
                        {
                            Application.DoEvents();
                            OutMsg(PageType.Dakref, ".");
                            OutMsg();
                            Thread.Sleep(300);
                        }
                        OutMsg(PageType.Dakref, ".");
                    }
                    Application.DoEvents();
                    OutMsg();
                }

                DateTime dt = DateTime.Now;
                if (!cancelPressed)
                {
                    if (processFailed)
                    {
                        MessageBox.Show(this, "Unicode DAKREF failed", "Unicode DAKREF ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        OutMsg(PageType.Dakref, "Unicode DAKREF failed.\r\n", true);
                    }
                    else
                    {
                        MessageBox.Show(this, "Unicode DAKREF  done!", "Unicode DAKREF ");
                    }
                }
                else
                {
                    OutMsg(PageType.Dakref, "Unicode DAKREF cancelled.\r\n", true);
                    cancelPressed = false;
                }

                SetDakrefButtonStatus(true);
                isProcessing = false;
                OutMsg(PageType.Dakref, "Process ended at: " + dt.ToShortTimeString() + ".\r\n", true);
            }
            else
            {
                //MessageBox.Show(this, "Incorrect backup file name!", "Restore DAKREF", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //txtDakrefBack.Focus();
            }
        }

        internal bool IsCancel()
        {
            return cancelPressed;
        }

        private void Unicode()
        {
            try
            {
                if (_dSqlTag == null)
                {
                    _dSqlTag = new DataSql(txtDakrefTagServer.Text,
                            txtDakrefTagDB.Text, DakrefTagDBUser, DakrefTagDBPW);

                    _dSqlTag.checkCancel += new DataSql.IsCancel(IsCancel);
                }
                else
                {
                    _dSqlTag.SetServer(txtDakrefTagServer.Text,
                            txtDakrefTagDB.Text, DakrefTagDBUser, DakrefTagDBPW);
                }

                _dSqlTag.Open();

                string ret = _dSqlTag.RunSQL(Query.ConvertUnicodeTable);
                if (ret == "")
                {
                    //OutMsg(PageType.Dakref, "Convert to Unicode tables successfuly!" + Environment.NewLine);
                }
                else
                {
                    OutMsg(PageType.Dakref, ret + Environment.NewLine);
                }

            }
            catch (Exception e)
            {
                OutMsg(PageType.Dakref, e.Message + Environment.NewLine);
            }
            finally
            {
                _dSqlTag.Close();
            }
        }



        private void LaunchDTS()
        {
            OleDbConnection dbConn = null;
            OleDbCommand cmd = null;
            DataSet dsExcel = null;
            OleDbDataAdapter daExcel = null;
            string result = null;
            string[] FieldNames = null;
            SqlConnection srcConnection = null;

            //DataSql _db = null;
            string strExcelConn = ConfigurationManager.AppSettings["ExcelConnection"];
            string strSQL = null;

            try
            {
                _dSqlTag.Open();

                if (!chkDakrefVerTest.Checked)
                {
                    dbConn = new OleDbConnection(strExcelConn + txtDakrefMigration.Text);
                    strSQL = "SELECT * FROM [Sheet1$]";

                    OutMsg(PageType.Dakref, "Connecting to Sheet1....\r\n");
                    dbConn.Open();

                    cmd = new OleDbCommand(strSQL, dbConn);
                    dsExcel = new DataSet();
                    daExcel = new OleDbDataAdapter(cmd);

                    string ModuleVersionSN = null;
                    string ModuleSN = null;
                    string F3 = null;

                    OutMsg(PageType.Dakref, "Reading Sheet1....\r\n");
                    daExcel.Fill(dsExcel);

                    OutMsg(PageType.Dakref, "Processing Sheet1....\r\n");
                    foreach (DataRow row in dsExcel.Tables[0].Rows)
                    {
                        ModuleVersionSN = row["ModuleVersionSN"].ToString().Trim();
                        ModuleSN = row["ModuleSN"].ToString().Trim();
                        F3 = row["F3"].ToString().Trim();

                        if (ModuleVersionSN != "" && ModuleSN != "")
                        {
                            strSQL = "INSERT INTO [dbo].[AutoMigrate] ([ModuleVersionSn],[Modulesn],[F3]) VALUES(" +
                                    ModuleVersionSN + "," + ModuleSN + ",'" + F3 + "')";

                            result = _dSqlTag.RunSQL(strSQL);
                            if (result != "")
                            {
                                processFailed = true;
                                OutMsg(PageType.Dakref, result + Environment.NewLine);
                                break;
                            }
                        }
                    }

                    dbConn.Close();
                }
            }
            catch (Exception e)
            {
                processFailed = true;
                OutMsg(PageType.Dakref, e.Message + Environment.NewLine);
            }
            finally
            {
            }

            if (processFailed || cancelPressed)
            {
                _dSqlTag.Close();
                return;
            }

            try
            {

                OutMsg(PageType.Dakref, "Preparing Dakref For Load....\r\n");
                string[] arrQuery = Query.PrepareDakref;
                arrQuery[1] = "alter database " + txtDakrefTagDB.Text + " set recovery simple";
                result = _dSqlTag.RunSQL(arrQuery);
                if (result != "")
                {
                    processFailed = true;
                    OutMsg(PageType.Dakref, result + Environment.NewLine);
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                srcConnection = new SqlConnection(_dSqlSrc.ConnectionString);
                srcConnection.Open();

                OutMsg(PageType.Dakref, "Copying table RetiredQuestion....\r\n");
                _dSqlTag.RunSQL(Query.CreateRetiredQuestionTable);

                strSQL = "use "+txtDakrefSrcDB .Text+
                        " select ModuleVersionSN,NewQuestionSN,OldQuestionSN,KLIne as Comments from " +
                        " dbo.RetiredQuest where IsDeleted=0 and ModuleVersionSN in (select Max(ModuleVersionSN) from dbo.moduleversion)";

                FieldNames = new string[] { "ModuleVersionSN", "NewQuestionSN", "OldQuestionSN", "Comments"};
                result = UTIL.BulkCopy(srcConnection, _dSqlTag.Connection, "RetiredQuestion", FieldNames, strSQL, null);

                if (result != "")
                {
                    OutMsg(PageType.Dakref, result + "\r\n");
                    processFailed = true;
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Copying table Module....\r\n");
                result = UTIL.BulkCopy(srcConnection, _dSqlTag.Connection, "Module", null);
                if (result != "")
                {
                    OutMsg(PageType.Dakref, result + "\r\n");
                    processFailed = true;
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Copying table ModuleVersion....\r\n");
                result = UTIL.BulkCopy(srcConnection, _dSqlTag.Connection, "ModuleVersion", null);
                if (result != "")
                {
                    OutMsg(PageType.Dakref, result + "\r\n");
                    processFailed = true;
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Copying table QCountState....\r\n");
                result = UTIL.BulkCopy(srcConnection, _dSqlTag.Connection, "QCountState", null);
                if (result != "")
                {
                    OutMsg(PageType.Dakref, result + "\r\n");
                    processFailed = true;
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Copying table QDLink....\r\n");
                result = UTIL.BulkCopy(srcConnection, _dSqlTag.Connection, "QDLink", null);
                if (result != "")
                {
                    OutMsg(PageType.Dakref, result + "\r\n");
                    processFailed = true;
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Copying table QDStateLink....\r\n");
                result = UTIL.BulkCopy(srcConnection, _dSqlTag.Connection, "QDStateLink", null);
                if (result != "")
                {
                    OutMsg(PageType.Dakref, result + "\r\n");
                    processFailed = true;
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Copying table QRLink....\r\n");
                result = UTIL.BulkCopy(srcConnection, _dSqlTag.Connection, "QRLink", null);
                if (result != "")
                {
                    OutMsg(PageType.Dakref, result + "\r\n");
                    processFailed = true;
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Copying table QSLink....\r\n");
                result = UTIL.BulkCopy(srcConnection, _dSqlTag.Connection, "QSLink", null);
                if (result != "")
                {
                    OutMsg(PageType.Dakref, result + "\r\n");
                    processFailed = true;
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Copying table Question....\r\n");
                result = UTIL.BulkCopy(srcConnection, _dSqlTag.Connection, "Question", null);
                if (result != "")
                {
                    OutMsg(PageType.Dakref, result + "\r\n");
                    processFailed = true;
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Copying table QuestionBody....\r\n");
                FieldNames = new string[] { "QuestionBodySN", "StdText", "NoteText", "ListAnswer", "DataType", "Properties" };
                result = UTIL.BulkCopy(srcConnection, _dSqlTag.Connection, "QuestionBody", FieldNames, null);
                if (result != "")
                {
                    OutMsg(PageType.Dakref, result + "\r\n");
                    processFailed = true;
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Copying table RGKeyword....\r\n");
                result = UTIL.BulkCopy(srcConnection, _dSqlTag.Connection, "RGKeyword", null);
                if (result != "")
                {
                    OutMsg(PageType.Dakref, result + "\r\n");
                    processFailed = true;
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Copying table RGSection....\r\n");
                FieldNames = new string[] { "SectionSN", "ModuleSN", "Heading", "TextBlock", "Sequence", "TagDate" };
                result = UTIL.BulkCopy(srcConnection, _dSqlTag.Connection, "RGSection", FieldNames, null);
                if (result != "")
                {
                    OutMsg(PageType.Dakref, result + "\r\n");
                    processFailed = true;
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Copying table RGTOC....\r\n");
                result = UTIL.BulkCopy(srcConnection, _dSqlTag.Connection, "RGTOC", null);
                if (result != "")
                {
                    OutMsg(PageType.Dakref, result + "\r\n");
                    processFailed = true;
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Copying table SDVLink....\r\n");
                result = UTIL.BulkCopy(srcConnection, _dSqlTag.Connection, "SDVLink", null);
                if (result != "")
                {
                    OutMsg(PageType.Dakref, result + "\r\n");
                    processFailed = true;
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Copying table State....\r\n");
                result = UTIL.BulkCopy(srcConnection, _dSqlTag.Connection, "State", null);
                if (result != "")
                {
                    OutMsg(PageType.Dakref, result + "\r\n");
                    processFailed = true;
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Copying table StateDomainStructure....\r\n");
                result = UTIL.BulkCopy(srcConnection, _dSqlTag.Connection, "StateDomainStructure", null);
                if (result != "")
                {
                    OutMsg(PageType.Dakref, result + "\r\n");
                    processFailed = true;
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Copying table StateModule....\r\n");
                result = UTIL.BulkCopy(srcConnection, _dSqlTag.Connection, "StateModule", null);
                if (result != "")
                {
                    OutMsg(PageType.Dakref, result + "\r\n");
                    processFailed = true;
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Copying table StateSection....\r\n");
                result = UTIL.BulkCopy(srcConnection, _dSqlTag.Connection, "StateSection", null);
                if (result != "")
                {
                    OutMsg(PageType.Dakref, result + "\r\n");
                    processFailed = true;
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Copying table StateVersion....\r\n");
                result = UTIL.BulkCopy(srcConnection, _dSqlTag.Connection, "StateVersion", null);
                if (result != "")
                {
                    OutMsg(PageType.Dakref, result + "\r\n");
                    processFailed = true;
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Copying table TemplateRule....\r\n");
                //strSQL = "DECLARE @Temp INT SELECT @Temp = VersionID FROM Version SELECT * FROM TemplateRule WHERE ModuleVersionSN >= @Temp";
                strSQL = "SELECT * FROM TemplateRule WHERE ModuleVersionSN >= " + iModuleVersion;
                result = UTIL.BulkCopy(srcConnection, _dSqlTag.Connection, "TemplateRule", null, strSQL, null);
                if (result != "")
                {
                    OutMsg(PageType.Dakref, result + "\r\n");
                    processFailed = true;
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Copying table ApplicabilityVariable....\r\n");
                //strSQL = "DECLARE @Temp INT SELECT @Temp = VersionID FROM Version SELECT * FROM ApplicabilityVariable WHERE ModuleVersionSN >= @Temp";
                strSQL = "SELECT * FROM ApplicabilityVariable WHERE ModuleVersionSN >= " + iModuleVersion;
                result = UTIL.BulkCopy(srcConnection, _dSqlTag.Connection, "ApplicabilityVariable", null, strSQL, null);
                if (result != "")
                {
                    OutMsg(PageType.Dakref, result + "\r\n");
                    processFailed = true;
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Copying table DomainStructure....\r\n");
                //strSQL = "DECLARE @Temp INT SELECT @Temp = VersionID FROM Version SELECT * FROM DomainStructure WHERE ModuleVersionSN >= @Temp";
                strSQL = "SELECT * FROM DomainStructure WHERE ModuleVersionSN >= " + iModuleVersion;
                result = UTIL.BulkCopy(srcConnection, _dSqlTag.Connection, "DomainStructure", null, strSQL, null);
                if (result != "")
                {
                    OutMsg(PageType.Dakref, result + "\r\n");
                    processFailed = true;
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Copying table aw_Hyperlink....\r\n");
                result = UTIL.BulkCopy(srcConnection, _dSqlTag.Connection, "aw_Hyperlink", null);
                if (result != "")
                {
                    OutMsg(PageType.Dakref, result + "\r\n");
                    processFailed = true;
                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Copying table aw_InfoOnly....\r\n");
                result = UTIL.BulkCopy(srcConnection, _dSqlTag.Connection, "aw_InfoOnly", null);
                if (result != "")
                {
                    OutMsg(PageType.Dakref, result + "\r\n");
                    processFailed = true;
                    return;
                }

                srcConnection.Close();


                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Updatinging QuestionBody table....\r\n");
                result = _dSqlTag.RunSQL(Query.UpdateQuestionbody);
                if (result != "")
                {
                    processFailed = true;
                    OutMsg(PageType.Dakref, result + Environment.NewLine);

                    return;
                }

                OutMsg(PageType.Dakref, "Recreating Constraints and Indexes....\r\n");
                if (_dSqlTag.RunSQL(Query.ConstraintsIndexes) != "")
                {
                    processFailed = true;

                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Domain Path Update....\r\n");
                if (!DomainPathUpdate())
                {
                    processFailed = true;

                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                if (_dSqlTag.RunSQL("GRANT SELECT ON aw_InfoOnly TO PUBLIC") != "")
                {
                    processFailed = true;

                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                OutMsg(PageType.Dakref, "Updating Module Version....\r\n");
                if (_dSqlTag.RunSQL(Query.DakrefUpdate) != "")
                {
                    processFailed = true;

                    return;
                }

                if (processFailed || cancelPressed)
                {
                    return;
                }

                try
                {
                    if (chkDakrefVerTest.Checked)
                    {
                        //Copy ModuleOrder data from last version
                        _dSqlTag.RunSQL(Query.CopyModuleOrder);
                    }
                    else
                    {
                        _dSqlTag.RunSQL(Query.AddCountryIDField);
                        _dSqlTag.RunSQL(Query.AddChecklistApplicField);

                        dbConn = new OleDbConnection(strExcelConn + txtDakrefModuleOrder.Text);
                        strSQL = "SELECT * FROM [Sheet1$]";

                        dbConn.Open();

                        cmd = new OleDbCommand(strSQL, dbConn);
                        dsExcel = new DataSet();
                        daExcel = new OleDbDataAdapter(cmd);

                        string ModuleVersionSN = null;
                        string ModuleSN = null;
                        string ModuleOrder = null;
                        string ModuleType = null;
                        string ModuleName = null;
                        string CountryID = null;
                        string ChecklistApplic = null;

                        daExcel.Fill(dsExcel);

                        foreach (DataRow row in dsExcel.Tables[0].Rows)
                        {
                            ModuleVersionSN = row["ModuleVersionSN"].ToString().Trim();
                            ModuleSN = row["Module SN"].ToString().Trim();
                            ModuleOrder = row["ModuleOrder"].ToString().Trim();
                            ModuleType = row["Type"].ToString().Trim();
                            ModuleName = row["Module Name"].ToString().Trim();
                            CountryID = row["CountryID"].ToString().Trim();
                            ChecklistApplic = row["ChecklistApplic"].ToString().Trim().ToUpper();

                            if (ModuleVersionSN != "" && ModuleSN != "")
                            {
                                if (ModuleType.ToUpper() == "INTL" && (ChecklistApplic.ToUpper() == "Y" || ChecklistApplic == "1"))
                                {
                                    ChecklistApplic = "Y";
                                }
                                else
                                {
                                    ChecklistApplic = "";
                                }

                                strSQL = "INSERT INTO [dbo].[ModuleOrdering] ([ModuleVersionSN],[ModuleOrder],[ModuleSN],[Type],[CountryID],[ModuleName],[ChecklistApplic]) VALUES(" +
                                        ModuleVersionSN + "," + ModuleOrder + "," + ModuleSN + ",'" + ModuleType + "','" + CountryID + "','" + ModuleName + "','" + ChecklistApplic + "')";

                                if (_dSqlTag.RunSQL(strSQL) != "")
                                {
                                    processFailed = true;
                                    break;
                                }
                            }
                        }
                        dbConn.Close();
                    }
                }
                catch (Exception e)
                {
                    OutMsg(PageType.Dakref, e.Message); 
                    processFailed = true;
                }


                if (processFailed || cancelPressed)
                {
                    return;
                }


                if (_dSqlTag.RunSQL(Query.UpdateModuleOrder) != "")
                {
                    processFailed = true;

                    return;
                }
            }
            catch (Exception e)
            {
                OutMsg(PageType.Dakref, e.Message);

                processFailed = true;
            }
            finally
            {
                if (srcConnection != null)
                {
                    srcConnection.Close();
                }
                if (_dSqlSrc != null)
                {
                    _dSqlTag.Close();
                }
                //dbConn.Close();
            }


        }
        private bool ValidateFormDakref
        {
            get
            {
                if (txtDakrefSrcVer.Text == "")
                {
                    MessageBox.Show(this, "Make sure source DB is openning!", "Update Release Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtDakrefSrcVer.Focus();
                    return false;
                }
                else if (txtDakrefTagVer.Text == "")
                {
                    MessageBox.Show(this, "Make sure DAKREF DB is openning!", "Update Release Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtDakrefTagVer.Focus();
                    return false;
                }
                else if ((txtDakrefMigration.Text == "" || !File.Exists(txtDakrefMigration.Text)) && !chkDakrefVerTest.Checked)
                {
                    MessageBox.Show(this, "Make sure migration detection file existing!", "Update Release Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtDakrefMigration.Focus();
                    return false;
                }
                else if ((txtDakrefModuleOrder.Text == "" || !File.Exists(txtDakrefModuleOrder.Text)) && !chkDakrefVerTest.Checked)
                {
                    MessageBox.Show(this, "Make sure module ordering file existing!", "Update Release Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtDakrefModuleOrder.Focus();
                    return false;
                }
                else if (!blDakrefReleaseDone)
                {
                    MessageBox.Show(this, "Update Release Info first!", "Update Release Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    btnDakrefReleaseInfo.Focus();
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }
        private bool ValidateFormDakrefBackup
        {
            get
            {
                if (txtDakrefBack.Text != "" &&
                        File.Exists(txtDakrefBack.Text))
                {
                    return true;
                }
                else
                {
                    MessageBox.Show(this, "Make sure backup file existing!", "Restore Database", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtDakrefBack.Focus();
                    return false;
                }
            }
        }
        private bool ValidateFormDakrefUnicode
        {
            get
            {
                if (txtDakrefTagVer.Text == "")
                {
                    MessageBox.Show(this, "Make sure DAKREF DB is openning!", "Restore DAKREF", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtDakrefTagVer.Focus();
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }
        private bool ValidateFormDakrefReleaseInfo
        {
            get
            {
                if (txtDakrefTagVer.Text == "")
                {
                    MessageBox.Show(this, "Make sure DAKREF DB is openning!", "Update Release Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtDakrefTagVer.Focus();
                    return false;
                }
                else if (txtDakrefNewVer.Text == "")
                {
                    MessageBox.Show(this, "New version number is empty!", "Update Release Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtDakrefNewVer.Focus();
                    return false;
                }
                else if ((txtDakrefWhatNew.Text == "" || !File.Exists(txtDakrefWhatNew.Text)) && !chkDakrefVerTest.Checked)
                {
                    MessageBox.Show(this, "Make sure what's new file existing!", "Update Release Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtDakrefWhatNew.Focus();
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }

        private bool ValidateFormConfigBackup
        {
            get
            {
                string sPath = Path.GetDirectoryName(txtConfigBakPath.Text);

                if (Directory.Exists(sPath))
                {
                    return true;
                }
                else
                {
                    MessageBox.Show(this, "Make sure backup directory existing!", "Backup Database", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtConfigBakPath.Focus();
                    return false;
                }
            }
        }

        private bool ValidateFormConfigRestore
        {
            get
            {
                if (txtConfigResPath.Text != "" &&
                        File.Exists(txtConfigResPath.Text))
                {
                    return true;
                }
                else
                {
                    MessageBox.Show(this, "Make sure backup file existing!", "Restore Database", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtConfigResPath.Focus();
                    return false;
                }
            }
        }

        bool blDakrefReleaseDone = false;
        private void btnDakrefReleaseInfo_Click(object sender, EventArgs e)
        {
            StreamReader srFile = null;
            string sFileContent = null;
            StringBuilder sbSql = new StringBuilder();

            try
            {
                //'check to see if all fields are filled in

                if (_dSqlTag == null)
                {
                    _dSqlTag = new DataSql(txtDakrefTagServer.Text,
                            txtDakrefTagDB.Text, DakrefTagDBUser, DakrefTagDBPW);
                    _dSqlTag.checkCancel += new DataSql.IsCancel(IsCancel);
                }
                else
                {
                    _dSqlTag.SetServer(txtDakrefTagServer.Text,
                            txtDakrefTagDB.Text, DakrefTagDBUser, DakrefTagDBPW);
                }

                _dSqlTag.Open();

                if (!ValidateFormDakrefReleaseInfo)
                {
                    return;
                }
                string result = _dSqlTag.RunSQL(Query.DakRefFull_SP_Unicode);
                if (result != "")
                {
                    MessageBox.Show(this, result, "Update Release Info Update");
                    return;
                }

                //'open the read the entire contents
                if (!chkDakrefVerTest.Checked)
                {
                    srFile = new StreamReader(txtDakrefWhatNew.Text, Encoding.Default);
                    sFileContent = srFile.ReadToEnd();
                    srFile.Close();
                }
                else
                {
                    sFileContent = "";
                }

                //'update the release info in the database to be built
                sbSql.Append("usp_DakRefFullBuild_ReleaseInfo @VersionID = '");
                sbSql.Append(txtDakrefNewVer.Text);
                sbSql.Append("', @NewText = '");
                sbSql.Append(sFileContent.Replace("'", "''"));
                sbSql.Append("'");

                //'set the connect string and execute the sql statement
                result = _dSqlTag.RunSQL(sbSql.ToString());
                if (result != "")
                {
                    //'inform the user of an error if the sql statement failed.
                    MessageBox.Show(this, result, "Update Release Info");
                }

                //Cursor.Current = Cursors.Default
                MessageBox.Show(this, "Update release information done!" + Environment.NewLine, "Update Release Info");

                blDakrefReleaseDone = true;
                //btnDakrefProcess.Enabled = true;

            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message + Environment.NewLine + ex.StackTrace, "Release Info Update");
            }
            finally
            {
                _dSqlTag.Close();
            }
        }

        private void btnDakrefMigrationBrowse_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;

            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            try
            {
                openFileDialog1.InitialDirectory = Path.GetDirectoryName(this.txtDakrefMigration.Text);
                openFileDialog1.FileName = Path.GetFileName(this.txtDakrefMigration.Text);
            }
            catch
            {
                openFileDialog1.InitialDirectory = @"C:\";
            }

            openFileDialog1.Filter = "Excel files (*.xls;)|*.xls;|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog(this) == DialogResult.OK)
            {
                this.txtDakrefMigration.Text = openFileDialog1.FileName;

                SaveConfig("DakrefMigrationPath", openFileDialog1.FileName);
            }
            else
            {
                if (this.txtDakrefMigration.Text.Trim() == string.Empty || !File.Exists(this.txtDakrefMigration.Text))
                {
                }
            }
        }

        private void btnDakrefModuleOrderBrowse_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            try
            {
                openFileDialog1.InitialDirectory = Path.GetDirectoryName(this.txtDakrefModuleOrder.Text);
                openFileDialog1.FileName = Path.GetFileName(this.txtDakrefModuleOrder.Text);
            }
            catch
            {
                openFileDialog1.InitialDirectory = @"C:\";
            }

            openFileDialog1.Filter = "Excel files (*.xls;)|*.xls;|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog(this) == DialogResult.OK)
            {
                this.txtDakrefModuleOrder.Text = openFileDialog1.FileName;

                SaveConfig("DakrefModuleOrderPath", openFileDialog1.FileName);
            }
            else
            {
                if (this.txtDakrefModuleOrder.Text.Trim() == string.Empty || !File.Exists(this.txtDakrefModuleOrder.Text))
                {
                }
            }
        }

        private void btnDakrefWhatNewBrowse_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;

            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            try
            {
                openFileDialog1.InitialDirectory = Path.GetDirectoryName(this.txtDakrefWhatNew.Text);
                openFileDialog1.FileName = Path.GetFileName(this.txtDakrefWhatNew.Text);
            }
            catch
            {
                openFileDialog1.InitialDirectory = @"C:\";
            }

            openFileDialog1.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog(this) == DialogResult.OK)
            {
                this.txtDakrefWhatNew.Text = openFileDialog1.FileName;

                SaveConfig("DakrefWhatsnewPath", openFileDialog1.FileName);
            }
            else
            {
                if (this.txtDakrefWhatNew.Text.Trim() == string.Empty || !File.Exists(this.txtDakrefWhatNew.Text))
                {
                }
            }
        }

        private void txtDakrefNewVer_TextChanged(object sender, EventArgs e)
        {
            EnableDakrefButton();
        }

        private void btnConfigBakOpen_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;

            processError = false;

            SetServer(PageType.ConfigBackup);

            Thread tr = new Thread(new ParameterizedThreadStart(GetDbInfo));
            //invokingCount = 0;
            tr.Start(PageType.ConfigBackup);

            while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
            {
                Application.DoEvents();
                OutMsg();
            }

            if (!processError)
            {
            }
            else
            {
                processError = false;
            }
            OutMsg();
        }

        private void btnConfigResOpen_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;

            processError = false;

            SetServer(PageType.ConfigRestore);

            Thread tr = new Thread(new ParameterizedThreadStart(GetDbInfo));
            //invokingCount = 0;
            tr.Start(PageType.ConfigRestore);

            while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
            {
                Application.DoEvents();
                OutMsg();
                //Thread.Sleep(200);
            }

            if (!processError)
            {
                //btnBlobsProcess.Enabled = true;
            }
            else
            {
                processError = false;
            }

            //btnDakrefProcess.Enabled = true;
            OutMsg();
        }

        private void btnConfigBakBrowse_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;

            SaveFileDialog openFileDialog1 = new SaveFileDialog();

            try
            {
                openFileDialog1.InitialDirectory = Path.GetDirectoryName(this.txtConfigBakPath.Text);
                openFileDialog1.FileName = Path.GetFileName(this.txtConfigBakPath.Text);
            }
            catch
            {
                openFileDialog1.InitialDirectory = @"C:\";
            }
            openFileDialog1.Filter = "Back up files (*.bak)|*.bak|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog(this) == DialogResult.OK)
            {
                this.txtConfigBakPath.Text = openFileDialog1.FileName;

                SaveConfig("ConfigBakPath", openFileDialog1.FileName);
            }
            else
            {

            }
        }

        private void btnConfigResBrowse_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;

            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            try
            {
                openFileDialog1.InitialDirectory = Path.GetDirectoryName(this.txtConfigResPath.Text);
                openFileDialog1.FileName = Path.GetFileName(this.txtConfigResPath.Text);
            }
            catch
            {
                openFileDialog1.InitialDirectory = @"C:\";
            }
            openFileDialog1.Filter = "Back up files (*.bak)|*.bak|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog(this) == DialogResult.OK)
            {
                this.txtConfigResPath.Text = openFileDialog1.FileName;

                SaveConfig("ConfigResPath", openFileDialog1.FileName);
            }
            else
            {

            }
        }

        private void btnConfigBakConfig_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;

            frmDBConfig _frmDBCfig = new frmDBConfig();

            _frmDBCfig._parent = this;

            SetServer(PageType.ConfigBackup);

            _frmDBCfig.ShowDialog(this);

            if (SQLConfigSubmitted)
            {
                GetServer(PageType.ConfigBackup);
                EnableDakrefButton();
            }
        }

        private void btnConfigResConfig_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;

            frmDBConfig _frmDBCfig = new frmDBConfig();

            _frmDBCfig._parent = this;

            SetServer(PageType.ConfigRestore);

            _frmDBCfig.ShowDialog(this);

            if (SQLConfigSubmitted)
            {
                GetServer(PageType.ConfigRestore);
                EnableDakrefButton();
            }
        }

        private void btnConfigBackup_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;

            cancelPressed = false;
            processFailed = false;

            if (ValidateFormConfigBackup)
            {
                backPath = txtConfigBakPath.Text;
                SetServer(PageType.ConfigBackup);

                lblConfigBakMsg.Text = "Backup Database...";
                isProcessing = true;
                SetConfiButtonStatus(false);

                txtConfigBakPath.Focus();

                Thread tr = new Thread(new ThreadStart(BackupDb));
                tr.Start();

                while (tr.ThreadState != ThreadState.Stopped)
                {
                    Application.DoEvents();
                }

                DateTime dt = DateTime.Now;

                if (!cancelPressed)
                {
                    if (processFailed)
                    {
                        MessageBox.Show(this, "Backup DATABASE failed", "Restore DATABASE", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        lblConfigBakMsg.Text = "Backup DATABASE failed!";
                    }
                    else
                    {
                        MessageBox.Show(this, "Backup DATABASE  done!", "Restore DATABASE ");
                        lblConfigBakMsg.Text = "Backup DATABASE successfully!";
                    }
                }
                else
                {
                    lblConfigBakMsg.Text = "Backup DATABASE cancelled.";
                    cancelPressed = false;
                }

                SetConfiButtonStatus(true);

                isProcessing = false;
            }
            else
            {
                lblConfigBakMsg.Text = "Incorrect backup directory!";
            }
            OutMsg();
        }
        private void SetConfiButtonStatus(bool Status)
        {
            btnConfigBakConfig.Enabled = Status;
            btnConfigBakOpen.Visible = Status;
            btnConfigBackup.Enabled = Status;
            btnConfigResConfig.Enabled = Status;
            btnConfigResOpen.Enabled = Status;
            btnConfigRestore.Enabled = Status;
        }

        private void btnConfigRestore_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;

            cancelPressed = false;
            processFailed = false;

            if (ValidateFormConfigRestore)
            {
                backPath = txtConfigResPath.Text;
                SetServer(PageType.ConfigRestore);

                lblConfigResMsg.Text = "Restoring Database...";
                isProcessing = true;
                SetConfiButtonStatus(false);

                txtConfigResPath.Focus();

                Thread tr = new Thread(new ThreadStart(RestoreDb));
                tr.Start();

                while (tr.ThreadState != ThreadState.Stopped)
                {
                    Application.DoEvents();
                }

                DateTime dt = DateTime.Now;

                if (!cancelPressed)
                {
                    if (processFailed)
                    {
                        MessageBox.Show(this, "Restore database failed", "Restore DATABASE", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        lblConfigResMsg.Text = "Restore database failed!";
                    }
                    else
                    {
                        MessageBox.Show(this, "Restore database  done!", "Restore DATABASE ");
                        lblConfigResMsg.Text = "Restore database successfully!";
                    }
                }
                else
                {
                    lblConfigResMsg.Text = "Restore database cancelled.";
                    cancelPressed = false;
                }

                SetConfiButtonStatus(true);

                isProcessing = false;

                txtConfigResVer.Text = "";
            }
            else
            {
                lblConfigResMsg.Text = "Incorrect backup file name!";
            }

            OutMsg();
        }

        private bool allowSpace = false;
        private void txtDakrefNewVer_KeyPress(object sender, KeyPressEventArgs e)
        {
            NumberFormatInfo numberFormatInfo = System.Globalization.CultureInfo.CurrentCulture.NumberFormat;
            string decimalSeparator = numberFormatInfo.NumberDecimalSeparator;
            //string groupSeparator = numberFormatInfo.NumberGroupSeparator;
            //string negativeSign = numberFormatInfo.NegativeSign;

            string keyInput = e.KeyChar.ToString();

            if (Char.IsDigit(e.KeyChar))
            {
                // Digits are OK
            }
            else if (keyInput.Equals(decimalSeparator))
            {
                // Decimal separator is OK
                if (txtDakrefNewVer.Text.IndexOf(decimalSeparator) > -1)
                {
                    e.Handled = true;
                }

                if (txtDakrefNewVer.Text.Length == 0)
                {
                    e.Handled = true;
                }
            }
            else if (e.KeyChar == '\b')
            {
                // Backspace key is OK
            }
            //    else if ((ModifierKeys & (Keys.Control | Keys.Alt)) != 0)
            //    {
            //     // Let the edit control handle control and alt key combinations
            //    }
            else if (this.allowSpace && e.KeyChar == ' ')
            {
            }
            else
            {
                // Swallow this invalid key and beep
                e.Handled = true;
                //    MessageBeep();
            }
        }

        private void chkDakrefVerTest_CheckedChanged(object sender, EventArgs e)
        {
            //txtDakrefMigration.Enabled = chkDakrefVerTest.Checked;
            //txtDakrefModuleOrder.Enabled = chkDakrefVerTest.Checked;
            //txtDakrefWhatNew.Enabled = chkDakrefVerTest.Checked;

            btnDakrefMigrationBrowse.Enabled = !chkDakrefVerTest.Checked;
            btnDakrefModuleOrderBrowse.Enabled = !chkDakrefVerTest.Checked;
            btnDakrefWhatNewBrowse.Enabled = !chkDakrefVerTest.Checked;

            //btnDakrefReleaseInfo.Enabled = !chkDakrefVerTest.Checked;

            EnableDakrefButton();
        }

        private void cobStartStep_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cobStartStep.SelectedIndex == 0)
            {
                chkAutoFixAirREMS.Checked = true;
            }
        }

        private void frmMain_Resize(object sender, EventArgs e)
        {
            this.Height = 582;
            this.Width = 616;
        }

        private void btnExcelRetiredQuestBrowse_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;

            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            //try
            //{
            //    openFileDialog1.InitialDirectory = Path.GetDirectoryName(this.txtExcelRetiredQues.Text);
            //    openFileDialog1.FileName = Path.GetFileName(this.txtExcelRetiredQues.Text);
            //}
            //catch
            //{
            //    openFileDialog1.InitialDirectory = @"C:\";
            //}

            openFileDialog1.Filter = "Excel files (*.xls;*.xlsx)|*.xls;*.xlsx|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog(this) == DialogResult.OK)
            {
                //this.txtExcelRetiredQues.Text = openFileDialog1.FileName;

                SaveConfig("ExcelRequiredQuestPath", openFileDialog1.FileName);

                //if (this.txtExcelRetiredQues.Text.Trim() == string.Empty || !File.Exists(this.txtExcelRetiredQues.Text))
                //{
                //    this.btnExcelRetiredQuestUpload.Enabled = false;
                //    this.btnExcelRetiredQuestCheck.Enabled = true;
                //}
                //else
                //{
                //    if (this.txtExcelTagVer.Text != string.Empty)
                //    {
                //        this.btnExcelRetiredQuestUpload.Enabled = true;
                //        this.btnExcelRetiredQuestCheck.Enabled = true;
                //    }
                //    else
                //    {
                //        this.btnExcelRetiredQuestUpload.Enabled = false;
                //        this.btnExcelRetiredQuestCheck.Enabled = false;
                //    }
                //}
            }
            else
            {
                
            }
        }

        private void btnExcelRetiredQuestUpload_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;

            cancelPressed = false;
            processFailed = false;

            isProcessing = true;

            //if (File.Exists(this.txtExcelRetiredQues.Text) && this.txtExcelTagVer.Text != string.Empty)
            //{
            //    if (_dSqlTag == null)
            //    {
            //        _dSqlTag = new DataSql(txtExcelTagServer.Text,
            //                txtExcelTagDB.Text, ExcelTagDBUser, ExcelTagDBPW);
            //        _dSqlTag.checkCancel += new DataSql.IsCancel(IsCancel);
            //    }
            //    else
            //    {
            //        _dSqlTag.SetServer(txtExcelTagServer.Text,
            //                txtExcelTagDB.Text, ExcelTagDBUser, ExcelTagDBPW);
            //    }

            //    DisenableExcelButton();

            //    _dSqlTag.Open();

            //    OutMsg(PageType.Upload, "Process started at: " + DateTime.Now.ToString("hh:mm:ss") + ".\r\n");

            //    _dSqlTag.RunSQL(Query.CreateRetiredQuestionTable);

            //    _dSqlTag.Close();

            //    OutMsg(PageType.Upload, "Uploading data." + Environment.NewLine, true);

            //    Thread tr = new Thread(new ThreadStart(UploadRetiredQuetion));
            //    tr.Start();

            //    while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
            //    {
            //        if (cancelPressed)
            //        {
            //            OutMsg(PageType.Upload, "Cancelling");
            //            while (tr.IsAlive)
            //            {
            //                Application.DoEvents();
            //                OutMsg(PageType.Upload, ".");
            //                OutMsg();
            //                Thread.Sleep(300);
            //            }
            //            OutMsg(PageType.Upload, ".");
            //        }
            //        Application.DoEvents();
            //        OutMsg();
            //    }

            //    DateTime dt = DateTime.Now;

            //    if (processFailed)
            //    {
            //        MessageBox.Show(this, "Uploading Data failed", "Uploading Data", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //        OutMsg(PageType.Upload, "Uploading Data failed.\r\n", true);
            //    }
            //    else
            //    {
            //        OutMsg(PageType.Upload, "Uploading Data done.\r\n", true);
            //    }

            //    EnableExcelButton();

            //    isProcessing = false;
            //    cancelPressed = false;
            //    OutMsg(PageType.Upload, "Process ended at: " + dt.ToString("hh:mm:ss") + ".\r\n", true);
            //}
            //else
            //{
            //    MessageBox.Show("Excel File is not existing or DB is not opened.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //}

            isProcessing = false;
        }

        private void btnExcelRetiredQuestCheck_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;

            cancelPressed = false;
            processFailed = false;

            isProcessing = true;

            //if (File.Exists(this.txtExcelRetiredQues.Text) && this.txtExcelTagVer.Text != string.Empty)
            //{
            //    if (_dSqlTag == null)
            //    {
            //        _dSqlTag = new DataSql(txtExcelTagServer.Text,
            //                txtExcelTagDB.Text, ExcelTagDBUser, ExcelTagDBPW);
            //        _dSqlTag.checkCancel += new DataSql.IsCancel(IsCancel);
            //    }
            //    else
            //    {
            //        _dSqlTag.SetServer(txtExcelTagServer.Text,
            //                txtExcelTagDB.Text, ExcelTagDBUser, ExcelTagDBPW);
            //    }

            //    DisenableExcelButton();

            //    _dSqlTag.Open();

            //    OutMsg(PageType.Upload, "Process started at: " + DateTime.Now.ToString("hh:mm:ss") + ".\r\n");

            //    _dSqlTag.RunSQL(Query.CreateRetiredQuestionTable);

            //    _dSqlTag.Close();

            //    OutMsg(PageType.Upload, "Cheking data." + Environment.NewLine, true);

            //    Thread tr = new Thread(new ThreadStart(CheckRetiredQuetion));
            //    tr.Start();

            //    while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
            //    {
            //        if (cancelPressed)
            //        {
            //            OutMsg(PageType.Upload, "Cancelling");
            //            while (tr.IsAlive)
            //            {
            //                Application.DoEvents();
            //                OutMsg(PageType.Upload, ".");
            //                OutMsg();
            //                Thread.Sleep(300);
            //            }
            //            OutMsg(PageType.Upload, ".");
            //        }
            //        Application.DoEvents();
            //        OutMsg();
            //    }

            //    if (!bValidateRetiredQuetion)
            //    {
            //        MessageBox.Show(this, "Some Data are not valid", "Checking Data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //    }

            //    DateTime dt = DateTime.Now;

            //    if (processFailed)
            //    {
            //        MessageBox.Show(this, "Checking Data failed", "Checking Data", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //        OutMsg(PageType.Upload, "Checking Data failed.\r\n", true);
            //    }
            //    else
            //    {
            //        OutMsg(PageType.Upload, "Checking Data done.\r\n", true);
            //    }

            //    EnableExcelButton();

            //    isProcessing = false;
            //    cancelPressed = false;
            //    OutMsg(PageType.Upload, "Process ended at: " + dt.ToString("hh:mm:ss") + ".\r\n", true);
            //}
            //else
            //{
            //    MessageBox.Show("Excel File is not existing or DB is not opened.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //}

            isProcessing = false;
        }

        private void btnExcelTagConfig_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;

            frmDBConfig _frmDBCfig = new frmDBConfig();

            _frmDBCfig._parent = this;

            SetServer(PageType.Upload);

            _frmDBCfig.ShowDialog(this);

            //if (SQLConfigSubmitted)
            //{
            //    if (txtExcelTagDB.Text != SQLDB || txtExcelTagServer.Text != SQLServer
            //            || ExcelTagDBUser != SQLUser || ExcelTagDBPW != SQLPW)
            //    {
            //        GetServer(PageType.Upload);
            //        DisableUpload();
            //    }
            //}
        }

        private void DisableUpload()
        {
            //this.btnExcelRetiredQuestUpload.Enabled = false;
            //this.txtExcelTagVer.Text = string.Empty;
        }

        private void EnableExcelButton()
        {
        //    this.btnExcefTagOpen.Enabled = true;
        //    this.btnExcelRetiredQuestBrowse.Enabled = true;
        //    this.btnExcelTagConfig.Enabled = true;

        //    this.btnExcelRetiredQuestUpload.Enabled = false;
        //    this.btnExcelRetiredQuestCheck.Enabled = false;

        //    if (this.txtExcelRetiredQues.Text != string.Empty && File.Exists(this.txtExcelRetiredQues.Text))
        //    {
        //        if (this.txtExcelTagVer.Text != string.Empty)
        //        {
        //            this.btnExcelRetiredQuestUpload.Enabled = true;
        //            this.btnExcelRetiredQuestCheck.Enabled = true;
        //        }
        //    }            
        }

        private void DisenableExcelButton()
        {
            //this.btnExcefTagOpen.Enabled = false;
            //this.btnExcelRetiredQuestBrowse.Enabled = false;
            //this.btnExcelRetiredQuestCheck.Enabled = false;
            //this.btnExcelRetiredQuestUpload.Enabled = false;
            //this.btnExcelTagConfig.Enabled = false;
        }

        private void btnExcefTagOpen_Click(object sender, EventArgs e)
        {
            if (isProcessing) return;

            processError = false;
            DisenableExcelButton();
            SetServer(PageType.Upload);

            Thread tr = new Thread(new ParameterizedThreadStart(GetDbInfo));
            //invokingCount = 0;
            tr.Start(PageType.Upload);

            while (tr.ThreadState != ThreadState.Stopped || invokingCount != 0)
            {
                Application.DoEvents();
                OutMsg();
                //Thread.Sleep(200);
            }

            if (!processError)
            {
                //btnBlobsProcess.Enabled = true;
            }
            else
            {
                processError = false;
            }
            EnableExcelButton();
            //btnDakrefProcess.Enabled = true;
            OutMsg();
        }

        private void UploadRetiredQuetion()
        {
            string filePath = "";// this.txtExcelRetiredQues.Text;
 
            OleDbConnection dbConn = null;
            OleDbCommand cmd = null;
            DataSet dsExcel = null;
            OleDbDataAdapter daExcel = null;
            string result = null;

            //string strExcelConn = ConfigurationManager.AppSettings["ExcelConnection"];
            string strExcelConn = ConfigurationManager.AppSettings["ExcelConnection12"];
            string strSQL = null;

            try
            {
                _dSqlTag.Open();

                dbConn = new OleDbConnection(strExcelConn + filePath);
                strSQL = "SELECT * FROM [Sheet1$]";

                dbConn.Open();

                cmd = new OleDbCommand(strSQL, dbConn);
                dsExcel = new DataSet();
                daExcel = new OleDbDataAdapter(cmd);

                string ModuleVersionSN = null;
                string NewQuestionSN = null;
                string OldQuestionSN = null;
                string Comments = null;

                daExcel.Fill(dsExcel);

                foreach (DataRow row in dsExcel.Tables[0].Rows)
                {
                    ModuleVersionSN = row["ModuleVersionSN"].ToString().Trim();
                    NewQuestionSN = row["NewQuestionSN"].ToString().Trim();
                    OldQuestionSN = row["OldQuestionSN"].ToString().Trim();
                    Comments = row["Comments"].ToString().Trim();

                    if (ModuleVersionSN != "" && NewQuestionSN != "" && OldQuestionSN != "")
                    {
                        strSQL = "IF NOT EXISTS (select null from [RetiredQuestion] where ModuleVersionSN=" + ModuleVersionSN
                        + " and (NewQuestionSN=" + NewQuestionSN + " or OldQuestionSN=" + OldQuestionSN
                        + " )) BEGIN INSERT INTO [RetiredQuestion] ([ModuleVersionSN],[NewQuestionSN],[OldQuestionSN],[Comments])VALUES( "
                        + ModuleVersionSN + "," + NewQuestionSN + "," + OldQuestionSN + ",'" + Comments
                        + "') END ELSE BEGIN UPDATE [RetiredQuestion] SET [NewQuestionSN] = " + NewQuestionSN
                        + ",[OldQuestionSN] = " + OldQuestionSN + ",[Comments] = '" + Comments
                        + "' where ModuleVersionSN=" + ModuleVersionSN + " and (NewQuestionSN=" + NewQuestionSN + " or OldQuestionSN="
                        + OldQuestionSN + ")END";

                        result = _dSqlTag.RunSQL(strSQL);
                        if (result != "")
                        {
                            processFailed = true;
                            OutMsg(PageType.Upload, result + Environment.NewLine);
                            break;
                        }
                    }
                }
            }
            catch(Exception e)
            {
                OutMsg(PageType.Upload, e.Message + Environment.NewLine);
                processFailed = true;
            }
            finally
            {
                dbConn.Close();
                _dSqlTag.Close();
            }
        }

        // bool bValidateRetiredQuetion = false;
        private void CheckRetiredQuetion()
        {
            // bValidateRetiredQuetion = true;

            string filePath = "";// this.txtExcelRetiredQues.Text;
            OleDbConnection dbConn = null;
            OleDbCommand cmd = null;
            DataSet dsExcel = null;
            OleDbDataAdapter daExcel = null;

            //string strExcelConn = ConfigurationManager.AppSettings["ExcelConnection"];
            string strExcelConn = ConfigurationManager.AppSettings["ExcelConnection12"];
            string strSQL = null;

            try
            {
                _dSqlTag.Open();

                dbConn = new OleDbConnection(strExcelConn + filePath);
                strSQL = "SELECT * FROM [Sheet1$]";

                dbConn.Open();

                cmd = new OleDbCommand(strSQL, dbConn);
                dsExcel = new DataSet();
                daExcel = new OleDbDataAdapter(cmd);

                string ModuleVersionSN = null;
                string NewQuestionSN = null;
                string OldQuestionSN = null;
                string Comments = null;

                string MVN = null;
                string ASN = null;
                string STATUS = null;

                daExcel.Fill(dsExcel);
                bool bVaild = true;
                int iLine = 0;
                DataSet ds = null;

                foreach (DataRow row in dsExcel.Tables[0].Rows)
                {
                    iLine++;
                    bVaild = true;
                    ModuleVersionSN = row["ModuleVersionSN"].ToString().Trim();
                    NewQuestionSN = row["NewQuestionSN"].ToString().Trim();
                    OldQuestionSN = row["OldQuestionSN"].ToString().Trim();
                    Comments = row["Comments"].ToString().Trim();

                    try
                    {
                        int.Parse(ModuleVersionSN);
                    }
                    catch
                    {
                        OutMsg(PageType.Upload, "Invalid ModuleVersionSN in Line " + iLine.ToString() + Environment.NewLine);
                        bVaild = false;
                        // bValidateRetiredQuetion = false;
                    }

                    try
                    {
                        int.Parse(NewQuestionSN);
                    }
                    catch
                    {
                        OutMsg(PageType.Upload, "Invalid NewQuestionSN in Line " + iLine.ToString() + Environment.NewLine);
                        bVaild = false;
                        // bValidateRetiredQuetion = false;
                    }

                    try
                    {
                        int.Parse(OldQuestionSN);
                    }
                    catch
                    {
                        OutMsg(PageType.Upload, "Invalid OldQuestionSN in Line " + iLine.ToString() + Environment.NewLine);
                        bVaild = false;
                        // bValidateRetiredQuetion = false;
                    }

                    if (bVaild)
                    {
                        strSQL = "SELECT distinct IsNull(ver.ModuleVersionSN,-1) as ModuleVersionSN,ct.ASN "
                            + ",case when ct2.ModuleVersionSN IS null then 'QR' else '' end as Status FROM  ApplicabilityVariable  AS ct "
                            + " left join ApplicabilityVariable  AS ct2 on ct.AClass=ct2.AClass and ct.ASN=ct2.ASN and ct2.ModuleVersionSN="
                            + ModuleVersionSN + " left join Version ver on ct2.ModuleVersionSN=ver.ModuleVersionSN WHERE ct.ASN in ("
                            + NewQuestionSN + "," + OldQuestionSN + ") AND ct.ModuleVersionSN != " + ModuleVersionSN
                            + " AND ct.AClass = 'Q'";


                        ds = _dSqlTag.GetDataSet(strSQL);
                        if (ds == null)
                        {
                            OutMsg(PageType.Upload, "Invalid data in Line " + iLine.ToString() + Environment.NewLine);
                            continue;
                        }
                       
                        if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                        {
                            foreach (DataRow drow in ds.Tables[0].Rows)
                            {
                                MVN = drow["ModuleVersionSN"].ToString().Trim();
                                ASN = drow["ASN"].ToString().Trim();
                                STATUS = drow["STATUS"].ToString().Trim();

                                if (STATUS == "" && ASN == OldQuestionSN)
                                {
                                    OutMsg(PageType.Upload, OldQuestionSN + " is not a retired question in Line " + iLine.ToString() + Environment.NewLine);
                                    // bValidateRetiredQuetion = false;
                                }
                             
                                if (STATUS == "" && MVN == "-1" && ASN == NewQuestionSN)
                                {
                                    OutMsg(PageType.Upload, "ModuleVersionSN is not match with current ModuleVersionSN in Line " + iLine.ToString() + Environment.NewLine);
                                    // bValidateRetiredQuetion = false;
                                }

                                if (STATUS == "QR" && ASN == NewQuestionSN)
                                {
                                    OutMsg(PageType.Upload, NewQuestionSN + " is a retired question in Line " + iLine.ToString() + Environment.NewLine);
                                    // bValidateRetiredQuetion = false;
                                }
                            }
                        }
                        else
                        {
                            OutMsg(PageType.Upload, "Invalid data in Line " + iLine.ToString() + Environment.NewLine);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                OutMsg(PageType.Upload, e.Message + Environment.NewLine);
                processFailed = true;
            }
            finally
            {
                dbConn.Close();
                _dSqlTag.Close();
            }
        }      
    }

    class MsgInfo
    {
        public PageType pType;
        public string Msg;

        public MsgInfo(PageType type, string msg)
        {
            pType = type;
            Msg = msg;
        }
    }

}