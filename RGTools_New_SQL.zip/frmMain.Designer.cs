using System.Windows.Forms;

namespace RGTools_New
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.pbrProgress = new System.Windows.Forms.ProgressBar();
            this.splitContainer9 = new System.Windows.Forms.SplitContainer();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.tbPgAbout = new System.Windows.Forms.TabPage();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.lblPgAboutDate = new System.Windows.Forms.Label();
            this.lblPgAboutVer = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.tbPgDakref = new System.Windows.Forms.TabPage();
            this.txtDakrefOut = new System.Windows.Forms.TextBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label101 = new System.Windows.Forms.Label();
            this.chkDakrefVerTest = new System.Windows.Forms.CheckBox();
            this.btnDakrefWhatNewBrowse = new System.Windows.Forms.Button();
            this.txtDakrefWhatNew = new System.Windows.Forms.TextBox();
            this.label88 = new System.Windows.Forms.Label();
            this.btnDakrefReleaseInfo = new System.Windows.Forms.Button();
            this.btnDakrefModuleOrderBrowse = new System.Windows.Forms.Button();
            this.txtDakrefModuleOrder = new System.Windows.Forms.TextBox();
            this.label87 = new System.Windows.Forms.Label();
            this.btnDakrefMigrationBrowse = new System.Windows.Forms.Button();
            this.txtDakrefMigration = new System.Windows.Forms.TextBox();
            this.label86 = new System.Windows.Forms.Label();
            this.btnDakrefRestore = new System.Windows.Forms.Button();
            this.btnDakrefRestoreBrowse = new System.Windows.Forms.Button();
            this.txtDakrefBack = new System.Windows.Forms.TextBox();
            this.label85 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.txtDakrefNewVer = new System.Windows.Forms.TextBox();
            this.btnDakrefCancel = new System.Windows.Forms.Button();
            this.btnDakrefProcess = new System.Windows.Forms.Button();
            this.txtDakrefTagServer = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.btnDakrefTagConfig = new System.Windows.Forms.Button();
            this.txtDakrefTagDB = new System.Windows.Forms.TextBox();
            this.label67 = new System.Windows.Forms.Label();
            this.txtDakrefSrcServer = new System.Windows.Forms.TextBox();
            this.label76 = new System.Windows.Forms.Label();
            this.btnDakrefSrcConfig = new System.Windows.Forms.Button();
            this.txtDakrefSrcDB = new System.Windows.Forms.TextBox();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.txtDakrefSrcVer = new System.Windows.Forms.TextBox();
            this.label79 = new System.Windows.Forms.Label();
            this.btnDakrefTagOpen = new System.Windows.Forms.Button();
            this.txtDakrefTagVer = new System.Windows.Forms.TextBox();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.btnDakrefSrcOpen = new System.Windows.Forms.Button();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.btnDakrefUnicode = new System.Windows.Forms.Button();
            this.tbPgImEx = new System.Windows.Forms.TabPage();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.lblExMsg = new System.Windows.Forms.Label();
            this.txtExServer = new System.Windows.Forms.TextBox();
            this.btnExOpen = new System.Windows.Forms.Button();
            this.btnExConfig = new System.Windows.Forms.Button();
            this.btnExport = new System.Windows.Forms.Button();
            this.btnExCancel = new System.Windows.Forms.Button();
            this.txtExVersion = new System.Windows.Forms.TextBox();
            this.txtExDataPath = new System.Windows.Forms.TextBox();
            this.btnExBrowse = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.txtExDB = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.txtImExOut = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblImMsg = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.txtImServer = new System.Windows.Forms.TextBox();
            this.txtImDataPath = new System.Windows.Forms.TextBox();
            this.btnImCancel = new System.Windows.Forms.Button();
            this.label45 = new System.Windows.Forms.Label();
            this.btnImConfig = new System.Windows.Forms.Button();
            this.txtImVersion = new System.Windows.Forms.TextBox();
            this.btnImOpen = new System.Windows.Forms.Button();
            this.txtImNewDB = new System.Windows.Forms.TextBox();
            this.chkImCreateNewDB = new System.Windows.Forms.CheckBox();
            this.txtImDB = new System.Windows.Forms.TextBox();
            this.btnImport = new System.Windows.Forms.Button();
            this.btnImDataDirBrowse = new System.Windows.Forms.Button();
            this.label46 = new System.Windows.Forms.Label();
            this.tbPgIPhoneDB = new System.Windows.Forms.TabPage();
            this.label89 = new System.Windows.Forms.Label();
            this.txtIPhoneServer = new System.Windows.Forms.TextBox();
            this.txtIPhoneDB = new System.Windows.Forms.TextBox();
            this.txtIPhoneOut = new System.Windows.Forms.TextBox();
            this.txtSQLitePath = new System.Windows.Forms.TextBox();
            this.txtIPhoneREMDir = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.btnIPhoneConfig = new System.Windows.Forms.Button();
            this.lblIPhoneProcessMsg = new System.Windows.Forms.Label();
            this.btnIPhoneDefSel = new System.Windows.Forms.Button();
            this.btnIPhoneUnSel = new System.Windows.Forms.Button();
            this.btnIPhoneDeSel = new System.Windows.Forms.Button();
            this.btnIPhoneSelAll = new System.Windows.Forms.Button();
            this.chkLstBox = new System.Windows.Forms.CheckedListBox();
            this.btnIPhoneBrowseSQLitePath = new System.Windows.Forms.Button();
            this.label59 = new System.Windows.Forms.Label();
            this.btnIPhoneCancel = new System.Windows.Forms.Button();
            this.lblIPhoneMsg = new System.Windows.Forms.Label();
            this.btnIPhoneProcess = new System.Windows.Forms.Button();
            this.btnIPhoneBrowseTextPath = new System.Windows.Forms.Button();
            this.label57 = new System.Windows.Forms.Label();
            this.tbPgVewDB = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.txtVewDBResult = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.cboVewDBQuery = new System.Windows.Forms.ComboBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.txtVewDBSTVerSN = new System.Windows.Forms.TextBox();
            this.txtVewDBVerSN = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.lstVewDBModule = new System.Windows.Forms.ListBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtVewDBServer = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.btnViewDBConfig = new System.Windows.Forms.Button();
            this.txtVewDBDB = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.lblVewDBMsg = new System.Windows.Forms.Label();
            this.btnVewDBOpen = new System.Windows.Forms.Button();
            this.txtVewDBVer = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.tbPgConfig = new System.Windows.Forms.TabPage();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.btnConfigRestore = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnConfigResBrowse = new System.Windows.Forms.Button();
            this.txtConfigResPath = new System.Windows.Forms.TextBox();
            this.label99 = new System.Windows.Forms.Label();
            this.txtConfigResServerName = new System.Windows.Forms.TextBox();
            this.label95 = new System.Windows.Forms.Label();
            this.lblConfigResMsg = new System.Windows.Forms.Label();
            this.btnConfigResConfig = new System.Windows.Forms.Button();
            this.btnConfigResOpen = new System.Windows.Forms.Button();
            this.txtConfigResVer = new System.Windows.Forms.TextBox();
            this.label97 = new System.Windows.Forms.Label();
            this.txtConfigResDBName = new System.Windows.Forms.TextBox();
            this.label98 = new System.Windows.Forms.Label();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.btnConfigBackup = new System.Windows.Forms.Button();
            this.btnConfigBakBrowse = new System.Windows.Forms.Button();
            this.txtConfigBakPath = new System.Windows.Forms.TextBox();
            this.label100 = new System.Windows.Forms.Label();
            this.txtConfigBakServerName = new System.Windows.Forms.TextBox();
            this.label91 = new System.Windows.Forms.Label();
            this.lblConfigBakMsg = new System.Windows.Forms.Label();
            this.btnConfigBakConfig = new System.Windows.Forms.Button();
            this.btnConfigBakOpen = new System.Windows.Forms.Button();
            this.txtConfigBakVer = new System.Windows.Forms.TextBox();
            this.label93 = new System.Windows.Forms.Label();
            this.txtConfigBakDBName = new System.Windows.Forms.TextBox();
            this.label94 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.lblConfigSerDirMsg = new System.Windows.Forms.Label();
            this.btnConfigSerDirBrowse = new System.Windows.Forms.Button();
            this.txtConfigSerDir = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lblConfigTmpDirMsg = new System.Windows.Forms.Label();
            this.btnConfigTmpDirBrowse = new System.Windows.Forms.Button();
            this.txtConfigTempDir = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.tbPgAutoProcess = new System.Windows.Forms.TabPage();
            this.label102 = new System.Windows.Forms.Label();
            this.chkAutoFixAirREMS = new System.Windows.Forms.CheckBox();
            this.label96 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.cobStartStep = new System.Windows.Forms.ComboBox();
            this.label44 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.btnAutoCancel = new System.Windows.Forms.Button();
            this.btnAutoProcess = new System.Windows.Forms.Button();
            this.txtAutoOut = new System.Windows.Forms.TextBox();
            this.tbPgBlobsCreat = new System.Windows.Forms.TabPage();
            this.splitContainer6 = new System.Windows.Forms.SplitContainer();
            this.txtBlobsServer = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.lblBlobsMsg = new System.Windows.Forms.Label();
            this.btnBlobsDBConfig = new System.Windows.Forms.Button();
            this.btnBlobsOpen = new System.Windows.Forms.Button();
            this.txtBlobsVer = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtBlobsDB = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.btnBlobsProcess = new System.Windows.Forms.Button();
            this.btnBlobsCancel = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.optMissingBlobs = new System.Windows.Forms.RadioButton();
            this.optAllTheBlobs = new System.Windows.Forms.RadioButton();
            this.txtBlobsOut = new System.Windows.Forms.TextBox();
            this.tbPgMergFederal = new System.Windows.Forms.TabPage();
            this.splitContainer7 = new System.Windows.Forms.SplitContainer();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtMergeFMModuleServer = new System.Windows.Forms.TextBox();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.btnMergeFMModuleConfig = new System.Windows.Forms.Button();
            this.txtMergeFMModuleDB = new System.Windows.Forms.TextBox();
            this.label71 = new System.Windows.Forms.Label();
            this.txtMergeFMMasterServer = new System.Windows.Forms.TextBox();
            this.label66 = new System.Windows.Forms.Label();
            this.btnMergeFMMasterConfig = new System.Windows.Forms.Button();
            this.txtMergeFMMasterDB = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.lblMergeFModuleMsg = new System.Windows.Forms.Label();
            this.txtMergeFMasterVer = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.btnMergeFModuleOpen = new System.Windows.Forms.Button();
            this.txtMergeFModuleVer = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.btnMergeFMasterOpen = new System.Windows.Forms.Button();
            this.label32 = new System.Windows.Forms.Label();
            this.lblMergeFMasterMsg = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.btnMergeFProcess = new System.Windows.Forms.Button();
            this.btnMergeFCancel = new System.Windows.Forms.Button();
            this.txtDateSC = new System.Windows.Forms.TextBox();
            this.txtDateDA = new System.Windows.Forms.TextBox();
            this.txtVNameSC = new System.Windows.Forms.TextBox();
            this.txtVNameDA = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.txtMergeFdOut = new System.Windows.Forms.TextBox();
            this.tbPgMergSt = new System.Windows.Forms.TabPage();
            this.splitContainer8 = new System.Windows.Forms.SplitContainer();
            this.txtMergeSTServer = new System.Windows.Forms.TextBox();
            this.label72 = new System.Windows.Forms.Label();
            this.btnMergeSTConfig = new System.Windows.Forms.Button();
            this.txtMergeSTDB = new System.Windows.Forms.TextBox();
            this.label73 = new System.Windows.Forms.Label();
            this.lblMergeStMsg = new System.Windows.Forms.Label();
            this.btnMergeSTOpen = new System.Windows.Forms.Button();
            this.txtMergeSTVer = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.lblMergeSTModuleRoot = new System.Windows.Forms.Label();
            this.lblMergeSTSateRoot = new System.Windows.Forms.Label();
            this.btnMergeSTModuleRoot = new System.Windows.Forms.Button();
            this.btnMergeSTSateRoot = new System.Windows.Forms.Button();
            this.chkMergeSynCheck = new System.Windows.Forms.CheckBox();
            this.btnMergeSTCancel = new System.Windows.Forms.Button();
            this.txtMergeSTOut = new System.Windows.Forms.TextBox();
            this.btnMergeSTProcess = new System.Windows.Forms.Button();
            this.txtMergeSTVerName = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.txtMergeSTDate = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.btnMergeSTRemoveAll = new System.Windows.Forms.Button();
            this.btnMergeSTAddAll = new System.Windows.Forms.Button();
            this.lstMergeSTStates = new System.Windows.Forms.ListBox();
            this.lstMergeSTAvaiSt = new System.Windows.Forms.ListBox();
            this.btnMergeSTAdd = new System.Windows.Forms.Button();
            this.btnMergeSTRemove = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.txtMergeSTModuleRoot = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.txtMergeSTSateRoot = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.tbPgDelState = new System.Windows.Forms.TabPage();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.txtDelStServer = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnSelStConfig = new System.Windows.Forms.Button();
            this.txtDelStDB = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.lblDelStMsg = new System.Windows.Forms.Label();
            this.btnDelStOpen = new System.Windows.Forms.Button();
            this.txtDelStVer = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnDelStCancel = new System.Windows.Forms.Button();
            this.txtDelStOut = new System.Windows.Forms.TextBox();
            this.btnDelStProcess = new System.Windows.Forms.Button();
            this.tbPgModuleDel = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.txtDelModServer = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnDelModConfig = new System.Windows.Forms.Button();
            this.txtDelModDB = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.lblDelModuleMsg = new System.Windows.Forms.Label();
            this.btnDelModOpen = new System.Windows.Forms.Button();
            this.txtDelModVer = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnDelModCancel = new System.Windows.Forms.Button();
            this.btnDelModRemAll = new System.Windows.Forms.Button();
            this.btnDelModAddAll = new System.Windows.Forms.Button();
            this.lstDelModSel = new System.Windows.Forms.ListBox();
            this.lstDelModAvail = new System.Windows.Forms.ListBox();
            this.btnDelModProcess = new System.Windows.Forms.Button();
            this.btnDelModAdd = new System.Windows.Forms.Button();
            this.btnDelModRemove = new System.Windows.Forms.Button();
            this.txtDelModOut = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbPgBuildMODULE = new System.Windows.Forms.TabPage();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.btnModuleOpen = new System.Windows.Forms.Button();
            this.txtModuleVer = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtModuleServer = new System.Windows.Forms.TextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.btnModuleDBConfig = new System.Windows.Forms.Button();
            this.txtModuleDB = new System.Windows.Forms.TextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.cmdFixAirREM = new System.Windows.Forms.Button();
            this.btnModuleRemoveAll = new System.Windows.Forms.Button();
            this.btnModuleAddAll = new System.Windows.Forms.Button();
            this.btnModuleStart = new System.Windows.Forms.Button();
            this.btnModuleCancel = new System.Windows.Forms.Button();
            this.lblModuleMsg = new System.Windows.Forms.Label();
            this.lstModuleSel = new System.Windows.Forms.ListBox();
            this.lstModuleAval = new System.Windows.Forms.ListBox();
            this.btnModuleAdd = new System.Windows.Forms.Button();
            this.btnModuleRemove = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.btnModuleBrowse = new System.Windows.Forms.Button();
            this.txtModuleDir = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtModuleOut = new System.Windows.Forms.TextBox();
            this.tbPgBuildREM = new System.Windows.Forms.TabPage();
            this.btnBuildREMCancel = new System.Windows.Forms.Button();
            this.lblMsg = new System.Windows.Forms.Label();
            this.btnBuildREMSel = new System.Windows.Forms.Button();
            this.btnBuildREMProcess = new System.Windows.Forms.Button();
            this.txtBuildREMOutput = new System.Windows.Forms.TextBox();
            this.txtBuildREMDir = new System.Windows.Forms.TextBox();
            this.btnBuildREMBrowse = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.chkBuildREMCalculate = new System.Windows.Forms.CheckBox();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.splitContainer9.Panel1.SuspendLayout();
            this.splitContainer9.SuspendLayout();
            this.tbPgAbout.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.tbPgDakref.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.tbPgImEx.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tbPgIPhoneDB.SuspendLayout();
            this.tbPgVewDB.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tbPgConfig.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tbPgAutoProcess.SuspendLayout();
            this.tbPgBlobsCreat.SuspendLayout();
            this.splitContainer6.Panel1.SuspendLayout();
            this.splitContainer6.Panel2.SuspendLayout();
            this.splitContainer6.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tbPgMergFederal.SuspendLayout();
            this.splitContainer7.Panel1.SuspendLayout();
            this.splitContainer7.Panel2.SuspendLayout();
            this.splitContainer7.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tbPgMergSt.SuspendLayout();
            this.splitContainer8.Panel1.SuspendLayout();
            this.splitContainer8.Panel2.SuspendLayout();
            this.splitContainer8.SuspendLayout();
            this.tbPgDelState.SuspendLayout();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.tbPgModuleDel.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tbPgBuildMODULE.SuspendLayout();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            this.tbPgBuildREM.SuspendLayout();
            this.tabControl.SuspendLayout();
            this.SuspendLayout();
            // 
            // pbrProgress
            // 
            this.pbrProgress.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pbrProgress.Location = new System.Drawing.Point(28, 542);
            this.pbrProgress.Name = "pbrProgress";
            this.pbrProgress.Size = new System.Drawing.Size(549, 18);
            this.pbrProgress.TabIndex = 88;
            this.pbrProgress.Visible = false;
            // 
            // splitContainer9
            // 
            this.splitContainer9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer9.Location = new System.Drawing.Point(3, 3);
            this.splitContainer9.Name = "splitContainer9";
            this.splitContainer9.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer9.Panel1
            // 
            this.splitContainer9.Panel1.Controls.Add(this.label35);
            this.splitContainer9.Panel1.Controls.Add(this.label36);
            this.splitContainer9.Panel1.Controls.Add(this.label37);
            this.splitContainer9.Size = new System.Drawing.Size(574, 482);
            this.splitContainer9.SplitterDistance = 94;
            this.splitContainer9.TabIndex = 0;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.ForeColor = System.Drawing.Color.Red;
            this.label35.Location = new System.Drawing.Point(143, 11);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(0, 13);
            this.label35.TabIndex = 45;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(12, 63);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(45, 13);
            this.label36.TabIndex = 41;
            this.label36.Text = "Version:";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(12, 11);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(125, 13);
            this.label37.TabIndex = 39;
            this.label37.Text = "Module Database Name:";
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.DefaultExt = "db";
            this.saveFileDialog1.Filter = "SQLite Files|*.db|All Files|*.*";
            this.saveFileDialog1.RestoreDirectory = true;
            // 
            // tbPgAbout
            // 
            this.tbPgAbout.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tbPgAbout.Controls.Add(this.groupBox11);
            this.tbPgAbout.Location = new System.Drawing.Point(4, 40);
            this.tbPgAbout.Name = "tbPgAbout";
            this.tbPgAbout.Padding = new System.Windows.Forms.Padding(3);
            this.tbPgAbout.Size = new System.Drawing.Size(580, 488);
            this.tbPgAbout.TabIndex = 15;
            this.tbPgAbout.Text = "About";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.lblPgAboutDate);
            this.groupBox11.Controls.Add(this.lblPgAboutVer);
            this.groupBox11.Controls.Add(this.label90);
            this.groupBox11.Location = new System.Drawing.Point(18, 37);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(536, 149);
            this.groupBox11.TabIndex = 0;
            this.groupBox11.TabStop = false;
            // 
            // lblPgAboutDate
            // 
            this.lblPgAboutDate.AutoSize = true;
            this.lblPgAboutDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPgAboutDate.Location = new System.Drawing.Point(36, 110);
            this.lblPgAboutDate.Name = "lblPgAboutDate";
            this.lblPgAboutDate.Size = new System.Drawing.Size(87, 20);
            this.lblPgAboutDate.TabIndex = 2;
            this.lblPgAboutDate.Text = "Copy Right";
            // 
            // lblPgAboutVer
            // 
            this.lblPgAboutVer.AutoSize = true;
            this.lblPgAboutVer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPgAboutVer.Location = new System.Drawing.Point(36, 81);
            this.lblPgAboutVer.Name = "lblPgAboutVer";
            this.lblPgAboutVer.Size = new System.Drawing.Size(71, 20);
            this.lblPgAboutVer.TabIndex = 1;
            this.lblPgAboutVer.Text = "Version: ";
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label90.Location = new System.Drawing.Point(35, 37);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(294, 24);
            this.label90.TabIndex = 0;
            this.label90.Text = "Regulary Tools for SQL Server";
            // 
            // tbPgDakref
            // 
            this.tbPgDakref.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tbPgDakref.Controls.Add(this.txtDakrefOut);
            this.tbPgDakref.Controls.Add(this.groupBox9);
            this.tbPgDakref.Controls.Add(this.btnDakrefUnicode);
            this.tbPgDakref.Location = new System.Drawing.Point(4, 40);
            this.tbPgDakref.Name = "tbPgDakref";
            this.tbPgDakref.Padding = new System.Windows.Forms.Padding(3);
            this.tbPgDakref.Size = new System.Drawing.Size(580, 488);
            this.tbPgDakref.TabIndex = 14;
            this.tbPgDakref.Text = "Conv. DAKREF";
            // 
            // txtDakrefOut
            // 
            this.txtDakrefOut.Location = new System.Drawing.Point(10, 327);
            this.txtDakrefOut.Multiline = true;
            this.txtDakrefOut.Name = "txtDakrefOut";
            this.txtDakrefOut.ReadOnly = true;
            this.txtDakrefOut.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtDakrefOut.Size = new System.Drawing.Size(559, 153);
            this.txtDakrefOut.TabIndex = 62;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label101);
            this.groupBox9.Controls.Add(this.chkDakrefVerTest);
            this.groupBox9.Controls.Add(this.btnDakrefWhatNewBrowse);
            this.groupBox9.Controls.Add(this.txtDakrefWhatNew);
            this.groupBox9.Controls.Add(this.label88);
            this.groupBox9.Controls.Add(this.btnDakrefReleaseInfo);
            this.groupBox9.Controls.Add(this.btnDakrefModuleOrderBrowse);
            this.groupBox9.Controls.Add(this.txtDakrefModuleOrder);
            this.groupBox9.Controls.Add(this.label87);
            this.groupBox9.Controls.Add(this.btnDakrefMigrationBrowse);
            this.groupBox9.Controls.Add(this.txtDakrefMigration);
            this.groupBox9.Controls.Add(this.label86);
            this.groupBox9.Controls.Add(this.btnDakrefRestore);
            this.groupBox9.Controls.Add(this.btnDakrefRestoreBrowse);
            this.groupBox9.Controls.Add(this.txtDakrefBack);
            this.groupBox9.Controls.Add(this.label85);
            this.groupBox9.Controls.Add(this.label84);
            this.groupBox9.Controls.Add(this.txtDakrefNewVer);
            this.groupBox9.Controls.Add(this.btnDakrefCancel);
            this.groupBox9.Controls.Add(this.btnDakrefProcess);
            this.groupBox9.Controls.Add(this.txtDakrefTagServer);
            this.groupBox9.Controls.Add(this.label51);
            this.groupBox9.Controls.Add(this.label63);
            this.groupBox9.Controls.Add(this.btnDakrefTagConfig);
            this.groupBox9.Controls.Add(this.txtDakrefTagDB);
            this.groupBox9.Controls.Add(this.label67);
            this.groupBox9.Controls.Add(this.txtDakrefSrcServer);
            this.groupBox9.Controls.Add(this.label76);
            this.groupBox9.Controls.Add(this.btnDakrefSrcConfig);
            this.groupBox9.Controls.Add(this.txtDakrefSrcDB);
            this.groupBox9.Controls.Add(this.label77);
            this.groupBox9.Controls.Add(this.label78);
            this.groupBox9.Controls.Add(this.txtDakrefSrcVer);
            this.groupBox9.Controls.Add(this.label79);
            this.groupBox9.Controls.Add(this.btnDakrefTagOpen);
            this.groupBox9.Controls.Add(this.txtDakrefTagVer);
            this.groupBox9.Controls.Add(this.label80);
            this.groupBox9.Controls.Add(this.label81);
            this.groupBox9.Controls.Add(this.btnDakrefSrcOpen);
            this.groupBox9.Controls.Add(this.label82);
            this.groupBox9.Controls.Add(this.label83);
            this.groupBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox9.Location = new System.Drawing.Point(10, 8);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(559, 313);
            this.groupBox9.TabIndex = 61;
            this.groupBox9.TabStop = false;
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label101.ForeColor = System.Drawing.Color.Red;
            this.label101.Location = new System.Drawing.Point(111, 92);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(299, 15);
            this.label101.TabIndex = 90;
            this.label101.Text = "(Restore DAKREF database to its last release version)";
            // 
            // chkDakrefVerTest
            // 
            this.chkDakrefVerTest.AutoSize = true;
            this.chkDakrefVerTest.Location = new System.Drawing.Point(9, 288);
            this.chkDakrefVerTest.Name = "chkDakrefVerTest";
            this.chkDakrefVerTest.Size = new System.Drawing.Size(93, 19);
            this.chkDakrefVerTest.TabIndex = 89;
            this.chkDakrefVerTest.Text = "Test Version";
            this.chkDakrefVerTest.UseVisualStyleBackColor = true;
            this.chkDakrefVerTest.CheckedChanged += new System.EventHandler(this.chkDakrefVerTest_CheckedChanged);
            // 
            // btnDakrefWhatNewBrowse
            // 
            this.btnDakrefWhatNewBrowse.Location = new System.Drawing.Point(478, 225);
            this.btnDakrefWhatNewBrowse.Name = "btnDakrefWhatNewBrowse";
            this.btnDakrefWhatNewBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnDakrefWhatNewBrowse.TabIndex = 83;
            this.btnDakrefWhatNewBrowse.Text = "&Browse...";
            this.btnDakrefWhatNewBrowse.UseVisualStyleBackColor = true;
            this.btnDakrefWhatNewBrowse.Click += new System.EventHandler(this.btnDakrefWhatNewBrowse_Click);
            // 
            // txtDakrefWhatNew
            // 
            this.txtDakrefWhatNew.BackColor = System.Drawing.Color.White;
            this.txtDakrefWhatNew.Location = new System.Drawing.Point(127, 227);
            this.txtDakrefWhatNew.Name = "txtDakrefWhatNew";
            this.txtDakrefWhatNew.ReadOnly = true;
            this.txtDakrefWhatNew.Size = new System.Drawing.Size(338, 21);
            this.txtDakrefWhatNew.TabIndex = 82;
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(6, 230);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(103, 15);
            this.label88.TabIndex = 81;
            this.label88.Text = "What\'s New Path:";
            // 
            // btnDakrefReleaseInfo
            // 
            this.btnDakrefReleaseInfo.Location = new System.Drawing.Point(350, 284);
            this.btnDakrefReleaseInfo.Name = "btnDakrefReleaseInfo";
            this.btnDakrefReleaseInfo.Size = new System.Drawing.Size(114, 23);
            this.btnDakrefReleaseInfo.TabIndex = 80;
            this.btnDakrefReleaseInfo.Text = "&Update Release Info";
            this.btnDakrefReleaseInfo.UseVisualStyleBackColor = true;
            this.btnDakrefReleaseInfo.Click += new System.EventHandler(this.btnDakrefReleaseInfo_Click);
            // 
            // btnDakrefModuleOrderBrowse
            // 
            this.btnDakrefModuleOrderBrowse.Location = new System.Drawing.Point(478, 199);
            this.btnDakrefModuleOrderBrowse.Name = "btnDakrefModuleOrderBrowse";
            this.btnDakrefModuleOrderBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnDakrefModuleOrderBrowse.TabIndex = 79;
            this.btnDakrefModuleOrderBrowse.Text = "&Browse...";
            this.btnDakrefModuleOrderBrowse.UseVisualStyleBackColor = true;
            this.btnDakrefModuleOrderBrowse.Click += new System.EventHandler(this.btnDakrefModuleOrderBrowse_Click);
            // 
            // txtDakrefModuleOrder
            // 
            this.txtDakrefModuleOrder.BackColor = System.Drawing.Color.White;
            this.txtDakrefModuleOrder.Location = new System.Drawing.Point(127, 201);
            this.txtDakrefModuleOrder.Name = "txtDakrefModuleOrder";
            this.txtDakrefModuleOrder.ReadOnly = true;
            this.txtDakrefModuleOrder.Size = new System.Drawing.Size(338, 21);
            this.txtDakrefModuleOrder.TabIndex = 78;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(6, 204);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(114, 15);
            this.label87.TabIndex = 77;
            this.label87.Text = "Module Order Path:";
            // 
            // btnDakrefMigrationBrowse
            // 
            this.btnDakrefMigrationBrowse.Location = new System.Drawing.Point(478, 173);
            this.btnDakrefMigrationBrowse.Name = "btnDakrefMigrationBrowse";
            this.btnDakrefMigrationBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnDakrefMigrationBrowse.TabIndex = 76;
            this.btnDakrefMigrationBrowse.Text = "&Browse...";
            this.btnDakrefMigrationBrowse.UseVisualStyleBackColor = true;
            this.btnDakrefMigrationBrowse.Click += new System.EventHandler(this.btnDakrefMigrationBrowse_Click);
            // 
            // txtDakrefMigration
            // 
            this.txtDakrefMigration.BackColor = System.Drawing.Color.White;
            this.txtDakrefMigration.Location = new System.Drawing.Point(127, 175);
            this.txtDakrefMigration.Name = "txtDakrefMigration";
            this.txtDakrefMigration.ReadOnly = true;
            this.txtDakrefMigration.Size = new System.Drawing.Size(340, 21);
            this.txtDakrefMigration.TabIndex = 75;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(6, 178);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(90, 15);
            this.label86.TabIndex = 74;
            this.label86.Text = "Migration Path:";
            // 
            // btnDakrefRestore
            // 
            this.btnDakrefRestore.Location = new System.Drawing.Point(231, 284);
            this.btnDakrefRestore.Name = "btnDakrefRestore";
            this.btnDakrefRestore.Size = new System.Drawing.Size(114, 23);
            this.btnDakrefRestore.TabIndex = 72;
            this.btnDakrefRestore.Text = "&Restore DakRef";
            this.btnDakrefRestore.UseVisualStyleBackColor = true;
            this.btnDakrefRestore.Click += new System.EventHandler(this.btnDakrefRestore_Click);
            // 
            // btnDakrefRestoreBrowse
            // 
            this.btnDakrefRestoreBrowse.Location = new System.Drawing.Point(478, 250);
            this.btnDakrefRestoreBrowse.Name = "btnDakrefRestoreBrowse";
            this.btnDakrefRestoreBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnDakrefRestoreBrowse.TabIndex = 71;
            this.btnDakrefRestoreBrowse.Text = "&Browse...";
            this.btnDakrefRestoreBrowse.UseVisualStyleBackColor = true;
            this.btnDakrefRestoreBrowse.Click += new System.EventHandler(this.btnDakrefRestoreBrowse_Click);
            // 
            // txtDakrefBack
            // 
            this.txtDakrefBack.BackColor = System.Drawing.Color.White;
            this.txtDakrefBack.Location = new System.Drawing.Point(127, 253);
            this.txtDakrefBack.Name = "txtDakrefBack";
            this.txtDakrefBack.ReadOnly = true;
            this.txtDakrefBack.Size = new System.Drawing.Size(338, 21);
            this.txtDakrefBack.TabIndex = 70;
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(4, 256);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(103, 15);
            this.label85.TabIndex = 69;
            this.label85.Text = "DakRef Bak Path:";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(275, 144);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(127, 15);
            this.label84.TabIndex = 68;
            this.label84.Text = "New Version Number:";
            // 
            // txtDakrefNewVer
            // 
            this.txtDakrefNewVer.BackColor = System.Drawing.Color.White;
            this.txtDakrefNewVer.Location = new System.Drawing.Point(408, 141);
            this.txtDakrefNewVer.Name = "txtDakrefNewVer";
            this.txtDakrefNewVer.Size = new System.Drawing.Size(57, 21);
            this.txtDakrefNewVer.TabIndex = 67;
            this.txtDakrefNewVer.TextChanged += new System.EventHandler(this.txtDakrefNewVer_TextChanged);
            this.txtDakrefNewVer.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDakrefNewVer_KeyPress);
            // 
            // btnDakrefCancel
            // 
            this.btnDakrefCancel.Location = new System.Drawing.Point(468, 284);
            this.btnDakrefCancel.Name = "btnDakrefCancel";
            this.btnDakrefCancel.Size = new System.Drawing.Size(85, 23);
            this.btnDakrefCancel.TabIndex = 66;
            this.btnDakrefCancel.Text = "&Cancel";
            this.btnDakrefCancel.UseVisualStyleBackColor = true;
            this.btnDakrefCancel.Visible = false;
            this.btnDakrefCancel.Click += new System.EventHandler(this.btnDakrefCancel_Click);
            // 
            // btnDakrefProcess
            // 
            this.btnDakrefProcess.Enabled = false;
            this.btnDakrefProcess.Location = new System.Drawing.Point(468, 284);
            this.btnDakrefProcess.Name = "btnDakrefProcess";
            this.btnDakrefProcess.Size = new System.Drawing.Size(85, 23);
            this.btnDakrefProcess.TabIndex = 65;
            this.btnDakrefProcess.Text = "&Start Process";
            this.btnDakrefProcess.UseVisualStyleBackColor = true;
            this.btnDakrefProcess.Click += new System.EventHandler(this.btnDakrefProcess_Click);
            // 
            // txtDakrefTagServer
            // 
            this.txtDakrefTagServer.BackColor = System.Drawing.Color.White;
            this.txtDakrefTagServer.Location = new System.Drawing.Point(92, 110);
            this.txtDakrefTagServer.Name = "txtDakrefTagServer";
            this.txtDakrefTagServer.ReadOnly = true;
            this.txtDakrefTagServer.Size = new System.Drawing.Size(177, 21);
            this.txtDakrefTagServer.TabIndex = 64;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(275, 113);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(64, 15);
            this.label51.TabIndex = 63;
            this.label51.Text = "DB Name:";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.ForeColor = System.Drawing.Color.Red;
            this.label63.Location = new System.Drawing.Point(135, 94);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(0, 15);
            this.label63.TabIndex = 62;
            // 
            // btnDakrefTagConfig
            // 
            this.btnDakrefTagConfig.Location = new System.Drawing.Point(478, 106);
            this.btnDakrefTagConfig.Name = "btnDakrefTagConfig";
            this.btnDakrefTagConfig.Size = new System.Drawing.Size(75, 23);
            this.btnDakrefTagConfig.TabIndex = 61;
            this.btnDakrefTagConfig.Text = "&Config.";
            this.btnDakrefTagConfig.UseVisualStyleBackColor = true;
            this.btnDakrefTagConfig.Click += new System.EventHandler(this.btnDakrefTagConfig_Click);
            // 
            // txtDakrefTagDB
            // 
            this.txtDakrefTagDB.BackColor = System.Drawing.Color.White;
            this.txtDakrefTagDB.Location = new System.Drawing.Point(345, 109);
            this.txtDakrefTagDB.Name = "txtDakrefTagDB";
            this.txtDakrefTagDB.ReadOnly = true;
            this.txtDakrefTagDB.Size = new System.Drawing.Size(120, 21);
            this.txtDakrefTagDB.TabIndex = 60;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(4, 112);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(82, 15);
            this.label67.TabIndex = 59;
            this.label67.Text = "Server Name:";
            // 
            // txtDakrefSrcServer
            // 
            this.txtDakrefSrcServer.BackColor = System.Drawing.Color.White;
            this.txtDakrefSrcServer.Location = new System.Drawing.Point(92, 36);
            this.txtDakrefSrcServer.Name = "txtDakrefSrcServer";
            this.txtDakrefSrcServer.ReadOnly = true;
            this.txtDakrefSrcServer.Size = new System.Drawing.Size(177, 21);
            this.txtDakrefSrcServer.TabIndex = 58;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(275, 39);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(64, 15);
            this.label76.TabIndex = 57;
            this.label76.Text = "DB Name:";
            // 
            // btnDakrefSrcConfig
            // 
            this.btnDakrefSrcConfig.Location = new System.Drawing.Point(478, 32);
            this.btnDakrefSrcConfig.Name = "btnDakrefSrcConfig";
            this.btnDakrefSrcConfig.Size = new System.Drawing.Size(75, 23);
            this.btnDakrefSrcConfig.TabIndex = 55;
            this.btnDakrefSrcConfig.Text = "&Config.";
            this.btnDakrefSrcConfig.UseVisualStyleBackColor = true;
            this.btnDakrefSrcConfig.Click += new System.EventHandler(this.btnDakrefSrcConfig_Click);
            // 
            // txtDakrefSrcDB
            // 
            this.txtDakrefSrcDB.BackColor = System.Drawing.Color.White;
            this.txtDakrefSrcDB.Location = new System.Drawing.Point(345, 35);
            this.txtDakrefSrcDB.Name = "txtDakrefSrcDB";
            this.txtDakrefSrcDB.ReadOnly = true;
            this.txtDakrefSrcDB.Size = new System.Drawing.Size(120, 21);
            this.txtDakrefSrcDB.TabIndex = 54;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(4, 38);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(82, 15);
            this.label77.TabIndex = 53;
            this.label77.Text = "Server Name:";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.ForeColor = System.Drawing.Color.Red;
            this.label78.Location = new System.Drawing.Point(155, 92);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(0, 15);
            this.label78.TabIndex = 52;
            // 
            // txtDakrefSrcVer
            // 
            this.txtDakrefSrcVer.Location = new System.Drawing.Point(92, 62);
            this.txtDakrefSrcVer.Name = "txtDakrefSrcVer";
            this.txtDakrefSrcVer.ReadOnly = true;
            this.txtDakrefSrcVer.Size = new System.Drawing.Size(177, 21);
            this.txtDakrefSrcVer.TabIndex = 42;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(3, 13);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(105, 15);
            this.label79.TabIndex = 39;
            this.label79.Text = "Source Database:";
            // 
            // btnDakrefTagOpen
            // 
            this.btnDakrefTagOpen.Location = new System.Drawing.Point(478, 139);
            this.btnDakrefTagOpen.Name = "btnDakrefTagOpen";
            this.btnDakrefTagOpen.Size = new System.Drawing.Size(75, 23);
            this.btnDakrefTagOpen.TabIndex = 50;
            this.btnDakrefTagOpen.Text = "&Open";
            this.btnDakrefTagOpen.UseVisualStyleBackColor = true;
            this.btnDakrefTagOpen.Click += new System.EventHandler(this.btnDakrefTagOpen_Click);
            // 
            // txtDakrefTagVer
            // 
            this.txtDakrefTagVer.Location = new System.Drawing.Point(92, 141);
            this.txtDakrefTagVer.Name = "txtDakrefTagVer";
            this.txtDakrefTagVer.ReadOnly = true;
            this.txtDakrefTagVer.Size = new System.Drawing.Size(177, 21);
            this.txtDakrefTagVer.TabIndex = 49;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(3, 65);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(51, 15);
            this.label80.TabIndex = 41;
            this.label80.Text = "Version:";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(3, 144);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(51, 15);
            this.label81.TabIndex = 48;
            this.label81.Text = "Version:";
            // 
            // btnDakrefSrcOpen
            // 
            this.btnDakrefSrcOpen.Location = new System.Drawing.Point(478, 65);
            this.btnDakrefSrcOpen.Name = "btnDakrefSrcOpen";
            this.btnDakrefSrcOpen.Size = new System.Drawing.Size(75, 23);
            this.btnDakrefSrcOpen.TabIndex = 43;
            this.btnDakrefSrcOpen.Text = "&Open";
            this.btnDakrefSrcOpen.UseVisualStyleBackColor = true;
            this.btnDakrefSrcOpen.Click += new System.EventHandler(this.btnDakrefSrcOpen_Click);
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(3, 92);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(114, 15);
            this.label82.TabIndex = 46;
            this.label82.Text = "DAKREF Database:";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.ForeColor = System.Drawing.Color.Red;
            this.label83.Location = new System.Drawing.Point(153, 17);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(0, 15);
            this.label83.TabIndex = 45;
            // 
            // btnDakrefUnicode
            // 
            this.btnDakrefUnicode.Location = new System.Drawing.Point(506, 396);
            this.btnDakrefUnicode.Name = "btnDakrefUnicode";
            this.btnDakrefUnicode.Size = new System.Drawing.Size(114, 23);
            this.btnDakrefUnicode.TabIndex = 73;
            this.btnDakrefUnicode.Text = "&Unicode";
            this.btnDakrefUnicode.UseVisualStyleBackColor = true;
            this.btnDakrefUnicode.Visible = false;
            this.btnDakrefUnicode.Click += new System.EventHandler(this.btnDakrefUnicode_Click);
            // 
            // tbPgImEx
            // 
            this.tbPgImEx.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tbPgImEx.Controls.Add(this.groupBox10);
            this.tbPgImEx.Controls.Add(this.txtImExOut);
            this.tbPgImEx.Controls.Add(this.groupBox2);
            this.tbPgImEx.Location = new System.Drawing.Point(4, 40);
            this.tbPgImEx.Name = "tbPgImEx";
            this.tbPgImEx.Padding = new System.Windows.Forms.Padding(3);
            this.tbPgImEx.Size = new System.Drawing.Size(580, 488);
            this.tbPgImEx.TabIndex = 13;
            this.tbPgImEx.Text = "Import/Export";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.lblExMsg);
            this.groupBox10.Controls.Add(this.txtExServer);
            this.groupBox10.Controls.Add(this.btnExOpen);
            this.groupBox10.Controls.Add(this.btnExConfig);
            this.groupBox10.Controls.Add(this.btnExport);
            this.groupBox10.Controls.Add(this.btnExCancel);
            this.groupBox10.Controls.Add(this.txtExVersion);
            this.groupBox10.Controls.Add(this.txtExDataPath);
            this.groupBox10.Controls.Add(this.btnExBrowse);
            this.groupBox10.Controls.Add(this.label15);
            this.groupBox10.Controls.Add(this.txtExDB);
            this.groupBox10.Controls.Add(this.label47);
            this.groupBox10.Controls.Add(this.label48);
            this.groupBox10.Controls.Add(this.label61);
            this.groupBox10.Location = new System.Drawing.Point(18, 13);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(544, 153);
            this.groupBox10.TabIndex = 8;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Export SQL Server to SYBASE Data files";
            // 
            // lblExMsg
            // 
            this.lblExMsg.AutoSize = true;
            this.lblExMsg.ForeColor = System.Drawing.Color.Red;
            this.lblExMsg.Location = new System.Drawing.Point(149, 79);
            this.lblExMsg.Name = "lblExMsg";
            this.lblExMsg.Size = new System.Drawing.Size(0, 13);
            this.lblExMsg.TabIndex = 69;
            // 
            // txtExServer
            // 
            this.txtExServer.BackColor = System.Drawing.Color.White;
            this.txtExServer.Location = new System.Drawing.Point(99, 26);
            this.txtExServer.Name = "txtExServer";
            this.txtExServer.ReadOnly = true;
            this.txtExServer.Size = new System.Drawing.Size(127, 20);
            this.txtExServer.TabIndex = 68;
            // 
            // btnExOpen
            // 
            this.btnExOpen.Location = new System.Drawing.Point(454, 56);
            this.btnExOpen.Name = "btnExOpen";
            this.btnExOpen.Size = new System.Drawing.Size(75, 23);
            this.btnExOpen.TabIndex = 65;
            this.btnExOpen.Text = "&Open";
            this.btnExOpen.UseVisualStyleBackColor = true;
            this.btnExOpen.Click += new System.EventHandler(this.btnExOpen_Click);
            // 
            // btnExConfig
            // 
            this.btnExConfig.Location = new System.Drawing.Point(454, 25);
            this.btnExConfig.Name = "btnExConfig";
            this.btnExConfig.Size = new System.Drawing.Size(75, 23);
            this.btnExConfig.TabIndex = 66;
            this.btnExConfig.Text = "&Config.";
            this.btnExConfig.UseVisualStyleBackColor = true;
            this.btnExConfig.Click += new System.EventHandler(this.btnExConfig_Click);
            // 
            // btnExport
            // 
            this.btnExport.Enabled = false;
            this.btnExport.Location = new System.Drawing.Point(454, 124);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(75, 24);
            this.btnExport.TabIndex = 64;
            this.btnExport.Text = "&Export";
            this.btnExport.UseVisualStyleBackColor = true;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // btnExCancel
            // 
            this.btnExCancel.Location = new System.Drawing.Point(454, 123);
            this.btnExCancel.Name = "btnExCancel";
            this.btnExCancel.Size = new System.Drawing.Size(75, 24);
            this.btnExCancel.TabIndex = 63;
            this.btnExCancel.Text = "&Cancel";
            this.btnExCancel.UseVisualStyleBackColor = true;
            this.btnExCancel.Visible = false;
            this.btnExCancel.Click += new System.EventHandler(this.btnExCancel_Click);
            // 
            // txtExVersion
            // 
            this.txtExVersion.Location = new System.Drawing.Point(99, 53);
            this.txtExVersion.Name = "txtExVersion";
            this.txtExVersion.ReadOnly = true;
            this.txtExVersion.Size = new System.Drawing.Size(317, 20);
            this.txtExVersion.TabIndex = 64;
            // 
            // txtExDataPath
            // 
            this.txtExDataPath.Location = new System.Drawing.Point(22, 97);
            this.txtExDataPath.Name = "txtExDataPath";
            this.txtExDataPath.Size = new System.Drawing.Size(407, 20);
            this.txtExDataPath.TabIndex = 62;
            this.txtExDataPath.TextChanged += new System.EventHandler(this.txtExDataPath_TextChanged);
            // 
            // btnExBrowse
            // 
            this.btnExBrowse.Location = new System.Drawing.Point(454, 95);
            this.btnExBrowse.Name = "btnExBrowse";
            this.btnExBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnExBrowse.TabIndex = 61;
            this.btnExBrowse.Text = "&Browse";
            this.btnExBrowse.UseVisualStyleBackColor = true;
            this.btnExBrowse.Click += new System.EventHandler(this.btnExBrowse_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(19, 79);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(112, 13);
            this.label15.TabIndex = 60;
            this.label15.Text = "Target Data Directory:";
            // 
            // txtExDB
            // 
            this.txtExDB.BackColor = System.Drawing.Color.White;
            this.txtExDB.Location = new System.Drawing.Point(290, 27);
            this.txtExDB.Name = "txtExDB";
            this.txtExDB.ReadOnly = true;
            this.txtExDB.Size = new System.Drawing.Size(126, 20);
            this.txtExDB.TabIndex = 62;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(230, 30);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(56, 13);
            this.label47.TabIndex = 55;
            this.label47.Text = "DB Name:";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(19, 56);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(45, 13);
            this.label48.TabIndex = 50;
            this.label48.Text = "Version:";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(19, 30);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(72, 13);
            this.label61.TabIndex = 48;
            this.label61.Text = "Server Name:";
            // 
            // txtImExOut
            // 
            this.txtImExOut.Location = new System.Drawing.Point(17, 326);
            this.txtImExOut.Multiline = true;
            this.txtImExOut.Name = "txtImExOut";
            this.txtImExOut.ReadOnly = true;
            this.txtImExOut.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtImExOut.Size = new System.Drawing.Size(545, 156);
            this.txtImExOut.TabIndex = 7;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblImMsg);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this.label74);
            this.groupBox2.Controls.Add(this.label75);
            this.groupBox2.Controls.Add(this.txtImServer);
            this.groupBox2.Controls.Add(this.txtImDataPath);
            this.groupBox2.Controls.Add(this.btnImCancel);
            this.groupBox2.Controls.Add(this.label45);
            this.groupBox2.Controls.Add(this.btnImConfig);
            this.groupBox2.Controls.Add(this.txtImVersion);
            this.groupBox2.Controls.Add(this.btnImOpen);
            this.groupBox2.Controls.Add(this.txtImNewDB);
            this.groupBox2.Controls.Add(this.chkImCreateNewDB);
            this.groupBox2.Controls.Add(this.txtImDB);
            this.groupBox2.Controls.Add(this.btnImport);
            this.groupBox2.Controls.Add(this.btnImDataDirBrowse);
            this.groupBox2.Controls.Add(this.label46);
            this.groupBox2.Location = new System.Drawing.Point(18, 172);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(544, 148);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Import SYBASE Data files to SQL Server";
            // 
            // lblImMsg
            // 
            this.lblImMsg.AutoSize = true;
            this.lblImMsg.ForeColor = System.Drawing.Color.Red;
            this.lblImMsg.Location = new System.Drawing.Point(149, 73);
            this.lblImMsg.Name = "lblImMsg";
            this.lblImMsg.Size = new System.Drawing.Size(0, 13);
            this.lblImMsg.TabIndex = 68;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(228, 24);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(56, 13);
            this.label25.TabIndex = 67;
            this.label25.Text = "DB Name:";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(17, 50);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(45, 13);
            this.label74.TabIndex = 63;
            this.label74.Text = "Version:";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(17, 24);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(72, 13);
            this.label75.TabIndex = 61;
            this.label75.Text = "Server Name:";
            // 
            // txtImServer
            // 
            this.txtImServer.BackColor = System.Drawing.Color.White;
            this.txtImServer.Location = new System.Drawing.Point(95, 20);
            this.txtImServer.Name = "txtImServer";
            this.txtImServer.ReadOnly = true;
            this.txtImServer.Size = new System.Drawing.Size(127, 20);
            this.txtImServer.TabIndex = 56;
            // 
            // txtImDataPath
            // 
            this.txtImDataPath.Location = new System.Drawing.Point(22, 91);
            this.txtImDataPath.Name = "txtImDataPath";
            this.txtImDataPath.Size = new System.Drawing.Size(407, 20);
            this.txtImDataPath.TabIndex = 59;
            this.txtImDataPath.TextChanged += new System.EventHandler(this.txtImDataPath_TextChanged);
            // 
            // btnImCancel
            // 
            this.btnImCancel.Location = new System.Drawing.Point(454, 117);
            this.btnImCancel.Name = "btnImCancel";
            this.btnImCancel.Size = new System.Drawing.Size(75, 24);
            this.btnImCancel.TabIndex = 58;
            this.btnImCancel.Text = "&Cancel";
            this.btnImCancel.UseVisualStyleBackColor = true;
            this.btnImCancel.Visible = false;
            this.btnImCancel.Click += new System.EventHandler(this.btnImCancel_Click);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(164, 117);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(63, 13);
            this.label45.TabIndex = 57;
            this.label45.Text = "Imported to:";
            // 
            // btnImConfig
            // 
            this.btnImConfig.Location = new System.Drawing.Point(454, 18);
            this.btnImConfig.Name = "btnImConfig";
            this.btnImConfig.Size = new System.Drawing.Size(75, 23);
            this.btnImConfig.TabIndex = 53;
            this.btnImConfig.Text = "&Config.";
            this.btnImConfig.UseVisualStyleBackColor = true;
            this.btnImConfig.Click += new System.EventHandler(this.btnImExConfig_Click);
            // 
            // txtImVersion
            // 
            this.txtImVersion.Location = new System.Drawing.Point(69, 47);
            this.txtImVersion.Name = "txtImVersion";
            this.txtImVersion.ReadOnly = true;
            this.txtImVersion.Size = new System.Drawing.Size(153, 20);
            this.txtImVersion.TabIndex = 51;
            // 
            // btnImOpen
            // 
            this.btnImOpen.Location = new System.Drawing.Point(454, 50);
            this.btnImOpen.Name = "btnImOpen";
            this.btnImOpen.Size = new System.Drawing.Size(75, 23);
            this.btnImOpen.TabIndex = 52;
            this.btnImOpen.Text = "&Open";
            this.btnImOpen.UseVisualStyleBackColor = true;
            this.btnImOpen.Click += new System.EventHandler(this.btnImExOpen_Click);
            // 
            // txtImNewDB
            // 
            this.txtImNewDB.BackColor = System.Drawing.Color.White;
            this.txtImNewDB.Enabled = false;
            this.txtImNewDB.Location = new System.Drawing.Point(233, 115);
            this.txtImNewDB.Name = "txtImNewDB";
            this.txtImNewDB.Size = new System.Drawing.Size(196, 20);
            this.txtImNewDB.TabIndex = 56;
            this.txtImNewDB.Text = "Sybase";
            // 
            // chkImCreateNewDB
            // 
            this.chkImCreateNewDB.AutoSize = true;
            this.chkImCreateNewDB.Location = new System.Drawing.Point(22, 116);
            this.chkImCreateNewDB.Name = "chkImCreateNewDB";
            this.chkImCreateNewDB.Size = new System.Drawing.Size(127, 17);
            this.chkImCreateNewDB.TabIndex = 14;
            this.chkImCreateNewDB.Text = "Create new database";
            this.chkImCreateNewDB.UseVisualStyleBackColor = true;
            this.chkImCreateNewDB.CheckedChanged += new System.EventHandler(this.chkImCreateNewDB_CheckedChanged);
            // 
            // txtImDB
            // 
            this.txtImDB.BackColor = System.Drawing.Color.White;
            this.txtImDB.Location = new System.Drawing.Point(290, 21);
            this.txtImDB.Name = "txtImDB";
            this.txtImDB.ReadOnly = true;
            this.txtImDB.Size = new System.Drawing.Size(126, 20);
            this.txtImDB.TabIndex = 49;
            // 
            // btnImport
            // 
            this.btnImport.Enabled = false;
            this.btnImport.Location = new System.Drawing.Point(454, 118);
            this.btnImport.Name = "btnImport";
            this.btnImport.Size = new System.Drawing.Size(75, 24);
            this.btnImport.TabIndex = 12;
            this.btnImport.Text = "&Import";
            this.btnImport.UseVisualStyleBackColor = true;
            this.btnImport.Click += new System.EventHandler(this.btnImport_Click);
            // 
            // btnImDataDirBrowse
            // 
            this.btnImDataDirBrowse.Location = new System.Drawing.Point(454, 87);
            this.btnImDataDirBrowse.Name = "btnImDataDirBrowse";
            this.btnImDataDirBrowse.Size = new System.Drawing.Size(75, 24);
            this.btnImDataDirBrowse.TabIndex = 10;
            this.btnImDataDirBrowse.Text = "&Browse";
            this.btnImDataDirBrowse.UseVisualStyleBackColor = true;
            this.btnImDataDirBrowse.Click += new System.EventHandler(this.btnImDataDirBrowse_Click);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(19, 73);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(115, 13);
            this.label46.TabIndex = 8;
            this.label46.Text = "Source Data Directory:";
            // 
            // tbPgIPhoneDB
            // 
            this.tbPgIPhoneDB.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tbPgIPhoneDB.Controls.Add(this.label89);
            this.tbPgIPhoneDB.Controls.Add(this.txtIPhoneServer);
            this.tbPgIPhoneDB.Controls.Add(this.txtIPhoneDB);
            this.tbPgIPhoneDB.Controls.Add(this.txtIPhoneOut);
            this.tbPgIPhoneDB.Controls.Add(this.txtSQLitePath);
            this.tbPgIPhoneDB.Controls.Add(this.txtIPhoneREMDir);
            this.tbPgIPhoneDB.Controls.Add(this.label43);
            this.tbPgIPhoneDB.Controls.Add(this.label58);
            this.tbPgIPhoneDB.Controls.Add(this.btnIPhoneConfig);
            this.tbPgIPhoneDB.Controls.Add(this.lblIPhoneProcessMsg);
            this.tbPgIPhoneDB.Controls.Add(this.btnIPhoneDefSel);
            this.tbPgIPhoneDB.Controls.Add(this.btnIPhoneUnSel);
            this.tbPgIPhoneDB.Controls.Add(this.btnIPhoneDeSel);
            this.tbPgIPhoneDB.Controls.Add(this.btnIPhoneSelAll);
            this.tbPgIPhoneDB.Controls.Add(this.chkLstBox);
            this.tbPgIPhoneDB.Controls.Add(this.btnIPhoneBrowseSQLitePath);
            this.tbPgIPhoneDB.Controls.Add(this.label59);
            this.tbPgIPhoneDB.Controls.Add(this.btnIPhoneCancel);
            this.tbPgIPhoneDB.Controls.Add(this.lblIPhoneMsg);
            this.tbPgIPhoneDB.Controls.Add(this.btnIPhoneProcess);
            this.tbPgIPhoneDB.Controls.Add(this.btnIPhoneBrowseTextPath);
            this.tbPgIPhoneDB.Controls.Add(this.label57);
            this.tbPgIPhoneDB.Location = new System.Drawing.Point(4, 40);
            this.tbPgIPhoneDB.Name = "tbPgIPhoneDB";
            this.tbPgIPhoneDB.Padding = new System.Windows.Forms.Padding(3);
            this.tbPgIPhoneDB.Size = new System.Drawing.Size(580, 488);
            this.tbPgIPhoneDB.TabIndex = 12;
            this.tbPgIPhoneDB.Text = "IPhone";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(14, 171);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(96, 13);
            this.label89.TabIndex = 102;
            this.label89.Text = "Available Modules:";
            // 
            // txtIPhoneServer
            // 
            this.txtIPhoneServer.BackColor = System.Drawing.Color.White;
            this.txtIPhoneServer.Location = new System.Drawing.Point(17, 130);
            this.txtIPhoneServer.Name = "txtIPhoneServer";
            this.txtIPhoneServer.ReadOnly = true;
            this.txtIPhoneServer.Size = new System.Drawing.Size(207, 20);
            this.txtIPhoneServer.TabIndex = 101;
            // 
            // txtIPhoneDB
            // 
            this.txtIPhoneDB.BackColor = System.Drawing.Color.White;
            this.txtIPhoneDB.Location = new System.Drawing.Point(251, 130);
            this.txtIPhoneDB.Name = "txtIPhoneDB";
            this.txtIPhoneDB.ReadOnly = true;
            this.txtIPhoneDB.Size = new System.Drawing.Size(195, 20);
            this.txtIPhoneDB.TabIndex = 99;
            // 
            // txtIPhoneOut
            // 
            this.txtIPhoneOut.Location = new System.Drawing.Point(17, 317);
            this.txtIPhoneOut.Multiline = true;
            this.txtIPhoneOut.Name = "txtIPhoneOut";
            this.txtIPhoneOut.ReadOnly = true;
            this.txtIPhoneOut.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtIPhoneOut.Size = new System.Drawing.Size(429, 149);
            this.txtIPhoneOut.TabIndex = 95;
            // 
            // txtSQLitePath
            // 
            this.txtSQLitePath.Location = new System.Drawing.Point(17, 81);
            this.txtSQLitePath.Name = "txtSQLitePath";
            this.txtSQLitePath.Size = new System.Drawing.Size(430, 20);
            this.txtSQLitePath.TabIndex = 28;
            this.txtSQLitePath.TextChanged += new System.EventHandler(this.txtSQLitePath_TextChanged);
            // 
            // txtIPhoneREMDir
            // 
            this.txtIPhoneREMDir.Location = new System.Drawing.Point(17, 37);
            this.txtIPhoneREMDir.Name = "txtIPhoneREMDir";
            this.txtIPhoneREMDir.Size = new System.Drawing.Size(430, 20);
            this.txtIPhoneREMDir.TabIndex = 11;
            this.txtIPhoneREMDir.TextChanged += new System.EventHandler(this.txtIPhoneREMDir_TextChanged);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(248, 111);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(56, 13);
            this.label43.TabIndex = 100;
            this.label43.Text = "DB Name:";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(14, 111);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(72, 13);
            this.label58.TabIndex = 98;
            this.label58.Text = "Server Name:";
            // 
            // btnIPhoneConfig
            // 
            this.btnIPhoneConfig.Location = new System.Drawing.Point(481, 127);
            this.btnIPhoneConfig.Name = "btnIPhoneConfig";
            this.btnIPhoneConfig.Size = new System.Drawing.Size(85, 23);
            this.btnIPhoneConfig.TabIndex = 97;
            this.btnIPhoneConfig.Text = "&Config.";
            this.btnIPhoneConfig.UseVisualStyleBackColor = true;
            this.btnIPhoneConfig.Click += new System.EventHandler(this.btnIPhoneConfig_Click);
            // 
            // lblIPhoneProcessMsg
            // 
            this.lblIPhoneProcessMsg.AutoSize = true;
            this.lblIPhoneProcessMsg.Location = new System.Drawing.Point(27, 456);
            this.lblIPhoneProcessMsg.Name = "lblIPhoneProcessMsg";
            this.lblIPhoneProcessMsg.Size = new System.Drawing.Size(0, 13);
            this.lblIPhoneProcessMsg.TabIndex = 94;
            // 
            // btnIPhoneDefSel
            // 
            this.btnIPhoneDefSel.Location = new System.Drawing.Point(481, 258);
            this.btnIPhoneDefSel.Name = "btnIPhoneDefSel";
            this.btnIPhoneDefSel.Size = new System.Drawing.Size(75, 23);
            this.btnIPhoneDefSel.TabIndex = 93;
            this.btnIPhoneDefSel.Text = "De&fSelect";
            this.btnIPhoneDefSel.UseVisualStyleBackColor = true;
            this.btnIPhoneDefSel.Click += new System.EventHandler(this.btnIPhoneDefSel_Click);
            // 
            // btnIPhoneUnSel
            // 
            this.btnIPhoneUnSel.Location = new System.Drawing.Point(481, 200);
            this.btnIPhoneUnSel.Name = "btnIPhoneUnSel";
            this.btnIPhoneUnSel.Size = new System.Drawing.Size(75, 23);
            this.btnIPhoneUnSel.TabIndex = 92;
            this.btnIPhoneUnSel.Text = "&UnSelect";
            this.btnIPhoneUnSel.UseVisualStyleBackColor = true;
            this.btnIPhoneUnSel.Click += new System.EventHandler(this.btnIPhoneUnSel_Click);
            // 
            // btnIPhoneDeSel
            // 
            this.btnIPhoneDeSel.Location = new System.Drawing.Point(481, 229);
            this.btnIPhoneDeSel.Name = "btnIPhoneDeSel";
            this.btnIPhoneDeSel.Size = new System.Drawing.Size(75, 23);
            this.btnIPhoneDeSel.TabIndex = 91;
            this.btnIPhoneDeSel.Text = "&DeSelect";
            this.btnIPhoneDeSel.UseVisualStyleBackColor = true;
            this.btnIPhoneDeSel.Click += new System.EventHandler(this.btnIPhoneDeSel_Click);
            // 
            // btnIPhoneSelAll
            // 
            this.btnIPhoneSelAll.Location = new System.Drawing.Point(481, 171);
            this.btnIPhoneSelAll.Name = "btnIPhoneSelAll";
            this.btnIPhoneSelAll.Size = new System.Drawing.Size(75, 23);
            this.btnIPhoneSelAll.TabIndex = 90;
            this.btnIPhoneSelAll.Text = "Select &All";
            this.btnIPhoneSelAll.UseVisualStyleBackColor = true;
            this.btnIPhoneSelAll.Click += new System.EventHandler(this.btnIPhoneSelAll_Click);
            // 
            // chkLstBox
            // 
            this.chkLstBox.FormattingEnabled = true;
            this.chkLstBox.Location = new System.Drawing.Point(17, 187);
            this.chkLstBox.Name = "chkLstBox";
            this.chkLstBox.Size = new System.Drawing.Size(430, 124);
            this.chkLstBox.TabIndex = 89;
            this.chkLstBox.Click += new System.EventHandler(this.chkLstBox_Click);
            // 
            // btnIPhoneBrowseSQLitePath
            // 
            this.btnIPhoneBrowseSQLitePath.Location = new System.Drawing.Point(481, 78);
            this.btnIPhoneBrowseSQLitePath.Name = "btnIPhoneBrowseSQLitePath";
            this.btnIPhoneBrowseSQLitePath.Size = new System.Drawing.Size(85, 23);
            this.btnIPhoneBrowseSQLitePath.TabIndex = 29;
            this.btnIPhoneBrowseSQLitePath.Text = "&Browse...";
            this.btnIPhoneBrowseSQLitePath.UseVisualStyleBackColor = true;
            this.btnIPhoneBrowseSQLitePath.Click += new System.EventHandler(this.btnIPhoneBrowseSQLitePath_Click);
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(14, 65);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(135, 13);
            this.label59.TabIndex = 27;
            this.label59.Text = "SQLite Database File Path:";
            // 
            // btnIPhoneCancel
            // 
            this.btnIPhoneCancel.Location = new System.Drawing.Point(481, 345);
            this.btnIPhoneCancel.Name = "btnIPhoneCancel";
            this.btnIPhoneCancel.Size = new System.Drawing.Size(85, 23);
            this.btnIPhoneCancel.TabIndex = 16;
            this.btnIPhoneCancel.Text = "&Cancel";
            this.btnIPhoneCancel.UseVisualStyleBackColor = true;
            this.btnIPhoneCancel.Visible = false;
            this.btnIPhoneCancel.Click += new System.EventHandler(this.btnIPhoneCancel_Click);
            // 
            // lblIPhoneMsg
            // 
            this.lblIPhoneMsg.AutoSize = true;
            this.lblIPhoneMsg.ForeColor = System.Drawing.Color.Red;
            this.lblIPhoneMsg.Location = new System.Drawing.Point(130, 12);
            this.lblIPhoneMsg.Name = "lblIPhoneMsg";
            this.lblIPhoneMsg.Size = new System.Drawing.Size(0, 13);
            this.lblIPhoneMsg.TabIndex = 15;
            // 
            // btnIPhoneProcess
            // 
            this.btnIPhoneProcess.Location = new System.Drawing.Point(481, 345);
            this.btnIPhoneProcess.Name = "btnIPhoneProcess";
            this.btnIPhoneProcess.Size = new System.Drawing.Size(85, 23);
            this.btnIPhoneProcess.TabIndex = 13;
            this.btnIPhoneProcess.Text = "&Start Process";
            this.btnIPhoneProcess.UseVisualStyleBackColor = true;
            this.btnIPhoneProcess.Click += new System.EventHandler(this.btnIPhoneProcess_Click);
            // 
            // btnIPhoneBrowseTextPath
            // 
            this.btnIPhoneBrowseTextPath.Location = new System.Drawing.Point(481, 34);
            this.btnIPhoneBrowseTextPath.Name = "btnIPhoneBrowseTextPath";
            this.btnIPhoneBrowseTextPath.Size = new System.Drawing.Size(85, 23);
            this.btnIPhoneBrowseTextPath.TabIndex = 12;
            this.btnIPhoneBrowseTextPath.Text = "&Browse";
            this.btnIPhoneBrowseTextPath.UseVisualStyleBackColor = true;
            this.btnIPhoneBrowseTextPath.Click += new System.EventHandler(this.btnIPhoneBrowseTextPath_Click);
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(14, 21);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(110, 13);
            this.label57.TabIndex = 10;
            this.label57.Text = "Source Text Directory";
            // 
            // tbPgVewDB
            // 
            this.tbPgVewDB.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tbPgVewDB.Controls.Add(this.groupBox7);
            this.tbPgVewDB.Controls.Add(this.groupBox6);
            this.tbPgVewDB.Controls.Add(this.groupBox5);
            this.tbPgVewDB.Location = new System.Drawing.Point(4, 40);
            this.tbPgVewDB.Name = "tbPgVewDB";
            this.tbPgVewDB.Padding = new System.Windows.Forms.Padding(3);
            this.tbPgVewDB.Size = new System.Drawing.Size(580, 488);
            this.tbPgVewDB.TabIndex = 11;
            this.tbPgVewDB.Text = "DB Infor";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.txtVewDBResult);
            this.groupBox7.Controls.Add(this.label55);
            this.groupBox7.Controls.Add(this.cboVewDBQuery);
            this.groupBox7.Location = new System.Drawing.Point(278, 104);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(296, 378);
            this.groupBox7.TabIndex = 2;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Check DB";
            // 
            // txtVewDBResult
            // 
            this.txtVewDBResult.Location = new System.Drawing.Point(17, 72);
            this.txtVewDBResult.Multiline = true;
            this.txtVewDBResult.Name = "txtVewDBResult";
            this.txtVewDBResult.ReadOnly = true;
            this.txtVewDBResult.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtVewDBResult.Size = new System.Drawing.Size(264, 300);
            this.txtVewDBResult.TabIndex = 44;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(14, 22);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(61, 13);
            this.label55.TabIndex = 31;
            this.label55.Text = "Run Query:";
            // 
            // cboVewDBQuery
            // 
            this.cboVewDBQuery.FormattingEnabled = true;
            this.cboVewDBQuery.Items.AddRange(new object[] {
            "Applicability Range Map",
            "Duplicate Appsn(rev 2)",
            "Duplicate State Domain SN",
            "Fix AV Collision(rev 5, 4/5/2016)",
            "Look For Duplicate QuestionLink Text",
            "Missing Link"});
            this.cboVewDBQuery.Location = new System.Drawing.Point(17, 45);
            this.cboVewDBQuery.Name = "cboVewDBQuery";
            this.cboVewDBQuery.Size = new System.Drawing.Size(264, 21);
            this.cboVewDBQuery.TabIndex = 0;
            this.cboVewDBQuery.SelectedIndexChanged += new System.EventHandler(this.cboVewDBQuery_SelectedIndexChanged);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.txtVewDBSTVerSN);
            this.groupBox6.Controls.Add(this.txtVewDBVerSN);
            this.groupBox6.Controls.Add(this.label54);
            this.groupBox6.Controls.Add(this.label53);
            this.groupBox6.Controls.Add(this.label52);
            this.groupBox6.Controls.Add(this.lstVewDBModule);
            this.groupBox6.Location = new System.Drawing.Point(9, 104);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(266, 378);
            this.groupBox6.TabIndex = 1;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "DB Information";
            // 
            // txtVewDBSTVerSN
            // 
            this.txtVewDBSTVerSN.BackColor = System.Drawing.Color.White;
            this.txtVewDBSTVerSN.Location = new System.Drawing.Point(107, 346);
            this.txtVewDBSTVerSN.Name = "txtVewDBSTVerSN";
            this.txtVewDBSTVerSN.ReadOnly = true;
            this.txtVewDBSTVerSN.Size = new System.Drawing.Size(141, 20);
            this.txtVewDBSTVerSN.TabIndex = 34;
            // 
            // txtVewDBVerSN
            // 
            this.txtVewDBVerSN.BackColor = System.Drawing.Color.White;
            this.txtVewDBVerSN.Location = new System.Drawing.Point(107, 320);
            this.txtVewDBVerSN.Name = "txtVewDBVerSN";
            this.txtVewDBVerSN.ReadOnly = true;
            this.txtVewDBVerSN.Size = new System.Drawing.Size(141, 20);
            this.txtVewDBVerSN.TabIndex = 33;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(6, 349);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(91, 13);
            this.label54.TabIndex = 32;
            this.label54.Text = "State Version SN:";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(6, 327);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(60, 13);
            this.label53.TabIndex = 31;
            this.label53.Text = "Vesion SN:";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(6, 23);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(50, 13);
            this.label52.TabIndex = 30;
            this.label52.Text = "Modules:";
            // 
            // lstVewDBModule
            // 
            this.lstVewDBModule.FormattingEnabled = true;
            this.lstVewDBModule.Location = new System.Drawing.Point(6, 45);
            this.lstVewDBModule.Name = "lstVewDBModule";
            this.lstVewDBModule.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstVewDBModule.Size = new System.Drawing.Size(242, 264);
            this.lstVewDBModule.TabIndex = 29;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.txtVewDBServer);
            this.groupBox5.Controls.Add(this.label60);
            this.groupBox5.Controls.Add(this.btnViewDBConfig);
            this.groupBox5.Controls.Add(this.txtVewDBDB);
            this.groupBox5.Controls.Add(this.label62);
            this.groupBox5.Controls.Add(this.lblVewDBMsg);
            this.groupBox5.Controls.Add(this.btnVewDBOpen);
            this.groupBox5.Controls.Add(this.txtVewDBVer);
            this.groupBox5.Controls.Add(this.label50);
            this.groupBox5.Location = new System.Drawing.Point(6, 6);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(568, 92);
            this.groupBox5.TabIndex = 0;
            this.groupBox5.TabStop = false;
            // 
            // txtVewDBServer
            // 
            this.txtVewDBServer.BackColor = System.Drawing.Color.White;
            this.txtVewDBServer.Location = new System.Drawing.Point(82, 33);
            this.txtVewDBServer.Name = "txtVewDBServer";
            this.txtVewDBServer.ReadOnly = true;
            this.txtVewDBServer.Size = new System.Drawing.Size(187, 20);
            this.txtVewDBServer.TabIndex = 78;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(276, 36);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(56, 13);
            this.label60.TabIndex = 77;
            this.label60.Text = "DB Name:";
            // 
            // btnViewDBConfig
            // 
            this.btnViewDBConfig.Location = new System.Drawing.Point(483, 31);
            this.btnViewDBConfig.Name = "btnViewDBConfig";
            this.btnViewDBConfig.Size = new System.Drawing.Size(75, 23);
            this.btnViewDBConfig.TabIndex = 76;
            this.btnViewDBConfig.Text = "&Config.";
            this.btnViewDBConfig.UseVisualStyleBackColor = true;
            this.btnViewDBConfig.Click += new System.EventHandler(this.btnViewDBConfig_Click);
            // 
            // txtVewDBDB
            // 
            this.txtVewDBDB.BackColor = System.Drawing.Color.White;
            this.txtVewDBDB.Location = new System.Drawing.Point(339, 34);
            this.txtVewDBDB.Name = "txtVewDBDB";
            this.txtVewDBDB.ReadOnly = true;
            this.txtVewDBDB.Size = new System.Drawing.Size(128, 20);
            this.txtVewDBDB.TabIndex = 75;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(8, 36);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(72, 13);
            this.label62.TabIndex = 74;
            this.label62.Text = "Server Name:";
            // 
            // lblVewDBMsg
            // 
            this.lblVewDBMsg.AutoSize = true;
            this.lblVewDBMsg.ForeColor = System.Drawing.Color.Red;
            this.lblVewDBMsg.Location = new System.Drawing.Point(81, 15);
            this.lblVewDBMsg.Name = "lblVewDBMsg";
            this.lblVewDBMsg.Size = new System.Drawing.Size(0, 13);
            this.lblVewDBMsg.TabIndex = 19;
            // 
            // btnVewDBOpen
            // 
            this.btnVewDBOpen.Location = new System.Drawing.Point(483, 57);
            this.btnVewDBOpen.Name = "btnVewDBOpen";
            this.btnVewDBOpen.Size = new System.Drawing.Size(75, 23);
            this.btnVewDBOpen.TabIndex = 17;
            this.btnVewDBOpen.Text = "&Open";
            this.btnVewDBOpen.UseVisualStyleBackColor = true;
            this.btnVewDBOpen.Click += new System.EventHandler(this.btnVewDBOpen_Click);
            // 
            // txtVewDBVer
            // 
            this.txtVewDBVer.Location = new System.Drawing.Point(82, 59);
            this.txtVewDBVer.Name = "txtVewDBVer";
            this.txtVewDBVer.ReadOnly = true;
            this.txtVewDBVer.Size = new System.Drawing.Size(385, 20);
            this.txtVewDBVer.TabIndex = 16;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(8, 62);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(45, 13);
            this.label50.TabIndex = 15;
            this.label50.Text = "Version:";
            // 
            // tbPgConfig
            // 
            this.tbPgConfig.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tbPgConfig.Controls.Add(this.groupBox13);
            this.tbPgConfig.Controls.Add(this.groupBox12);
            this.tbPgConfig.Controls.Add(this.groupBox8);
            this.tbPgConfig.Controls.Add(this.groupBox3);
            this.tbPgConfig.Location = new System.Drawing.Point(4, 40);
            this.tbPgConfig.Name = "tbPgConfig";
            this.tbPgConfig.Padding = new System.Windows.Forms.Padding(3);
            this.tbPgConfig.Size = new System.Drawing.Size(580, 488);
            this.tbPgConfig.TabIndex = 10;
            this.tbPgConfig.Text = "Configuration";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.btnConfigRestore);
            this.groupBox13.Controls.Add(this.button1);
            this.groupBox13.Controls.Add(this.btnConfigResBrowse);
            this.groupBox13.Controls.Add(this.txtConfigResPath);
            this.groupBox13.Controls.Add(this.label99);
            this.groupBox13.Controls.Add(this.txtConfigResServerName);
            this.groupBox13.Controls.Add(this.label95);
            this.groupBox13.Controls.Add(this.lblConfigResMsg);
            this.groupBox13.Controls.Add(this.btnConfigResConfig);
            this.groupBox13.Controls.Add(this.btnConfigResOpen);
            this.groupBox13.Controls.Add(this.txtConfigResVer);
            this.groupBox13.Controls.Add(this.label97);
            this.groupBox13.Controls.Add(this.txtConfigResDBName);
            this.groupBox13.Controls.Add(this.label98);
            this.groupBox13.Location = new System.Drawing.Point(6, 330);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(568, 145);
            this.groupBox13.TabIndex = 5;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Restore Database";
            // 
            // btnConfigRestore
            // 
            this.btnConfigRestore.Location = new System.Drawing.Point(450, 114);
            this.btnConfigRestore.Name = "btnConfigRestore";
            this.btnConfigRestore.Size = new System.Drawing.Size(107, 23);
            this.btnConfigRestore.TabIndex = 80;
            this.btnConfigRestore.Text = "Restore";
            this.btnConfigRestore.UseVisualStyleBackColor = true;
            this.btnConfigRestore.Click += new System.EventHandler(this.btnConfigRestore_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(476, -78);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(107, 23);
            this.button1.TabIndex = 79;
            this.button1.Text = "Backup";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // btnConfigResBrowse
            // 
            this.btnConfigResBrowse.Location = new System.Drawing.Point(482, 83);
            this.btnConfigResBrowse.Name = "btnConfigResBrowse";
            this.btnConfigResBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnConfigResBrowse.TabIndex = 74;
            this.btnConfigResBrowse.Text = "&Browse...";
            this.btnConfigResBrowse.UseVisualStyleBackColor = true;
            this.btnConfigResBrowse.Click += new System.EventHandler(this.btnConfigResBrowse_Click);
            // 
            // txtConfigResPath
            // 
            this.txtConfigResPath.BackColor = System.Drawing.Color.White;
            this.txtConfigResPath.Location = new System.Drawing.Point(102, 83);
            this.txtConfigResPath.Name = "txtConfigResPath";
            this.txtConfigResPath.ReadOnly = true;
            this.txtConfigResPath.Size = new System.Drawing.Size(370, 20);
            this.txtConfigResPath.TabIndex = 73;
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(11, 86);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(85, 13);
            this.label99.TabIndex = 72;
            this.label99.Text = "Bakup File Path:";
            // 
            // txtConfigResServerName
            // 
            this.txtConfigResServerName.BackColor = System.Drawing.Color.White;
            this.txtConfigResServerName.Location = new System.Drawing.Point(89, 19);
            this.txtConfigResServerName.Name = "txtConfigResServerName";
            this.txtConfigResServerName.ReadOnly = true;
            this.txtConfigResServerName.Size = new System.Drawing.Size(187, 20);
            this.txtConfigResServerName.TabIndex = 56;
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(282, 22);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(56, 13);
            this.label95.TabIndex = 55;
            this.label95.Text = "DB Name:";
            // 
            // lblConfigResMsg
            // 
            this.lblConfigResMsg.AutoSize = true;
            this.lblConfigResMsg.ForeColor = System.Drawing.Color.Red;
            this.lblConfigResMsg.Location = new System.Drawing.Point(16, 113);
            this.lblConfigResMsg.Name = "lblConfigResMsg";
            this.lblConfigResMsg.Size = new System.Drawing.Size(29, 13);
            this.lblConfigResMsg.TabIndex = 54;
            this.lblConfigResMsg.Text = "Error";
            // 
            // btnConfigResConfig
            // 
            this.btnConfigResConfig.Location = new System.Drawing.Point(483, 16);
            this.btnConfigResConfig.Name = "btnConfigResConfig";
            this.btnConfigResConfig.Size = new System.Drawing.Size(75, 23);
            this.btnConfigResConfig.TabIndex = 53;
            this.btnConfigResConfig.Text = "&Config.";
            this.btnConfigResConfig.UseVisualStyleBackColor = true;
            this.btnConfigResConfig.Click += new System.EventHandler(this.btnConfigResConfig_Click);
            // 
            // btnConfigResOpen
            // 
            this.btnConfigResOpen.Location = new System.Drawing.Point(483, 50);
            this.btnConfigResOpen.Name = "btnConfigResOpen";
            this.btnConfigResOpen.Size = new System.Drawing.Size(75, 23);
            this.btnConfigResOpen.TabIndex = 52;
            this.btnConfigResOpen.Text = "&Open";
            this.btnConfigResOpen.UseVisualStyleBackColor = true;
            this.btnConfigResOpen.Click += new System.EventHandler(this.btnConfigResOpen_Click);
            // 
            // txtConfigResVer
            // 
            this.txtConfigResVer.Location = new System.Drawing.Point(89, 52);
            this.txtConfigResVer.Name = "txtConfigResVer";
            this.txtConfigResVer.ReadOnly = true;
            this.txtConfigResVer.Size = new System.Drawing.Size(381, 20);
            this.txtConfigResVer.TabIndex = 51;
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Location = new System.Drawing.Point(11, 54);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(45, 13);
            this.label97.TabIndex = 50;
            this.label97.Text = "Version:";
            // 
            // txtConfigResDBName
            // 
            this.txtConfigResDBName.BackColor = System.Drawing.Color.White;
            this.txtConfigResDBName.Location = new System.Drawing.Point(344, 18);
            this.txtConfigResDBName.Name = "txtConfigResDBName";
            this.txtConfigResDBName.ReadOnly = true;
            this.txtConfigResDBName.Size = new System.Drawing.Size(128, 20);
            this.txtConfigResDBName.TabIndex = 49;
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Location = new System.Drawing.Point(11, 21);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(72, 13);
            this.label98.TabIndex = 48;
            this.label98.Text = "Server Name:";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.btnConfigBackup);
            this.groupBox12.Controls.Add(this.btnConfigBakBrowse);
            this.groupBox12.Controls.Add(this.txtConfigBakPath);
            this.groupBox12.Controls.Add(this.label100);
            this.groupBox12.Controls.Add(this.txtConfigBakServerName);
            this.groupBox12.Controls.Add(this.label91);
            this.groupBox12.Controls.Add(this.lblConfigBakMsg);
            this.groupBox12.Controls.Add(this.btnConfigBakConfig);
            this.groupBox12.Controls.Add(this.btnConfigBakOpen);
            this.groupBox12.Controls.Add(this.txtConfigBakVer);
            this.groupBox12.Controls.Add(this.label93);
            this.groupBox12.Controls.Add(this.txtConfigBakDBName);
            this.groupBox12.Controls.Add(this.label94);
            this.groupBox12.Location = new System.Drawing.Point(9, 174);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(568, 148);
            this.groupBox12.TabIndex = 4;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Backup Database";
            // 
            // btnConfigBackup
            // 
            this.btnConfigBackup.Location = new System.Drawing.Point(447, 112);
            this.btnConfigBackup.Name = "btnConfigBackup";
            this.btnConfigBackup.Size = new System.Drawing.Size(107, 23);
            this.btnConfigBackup.TabIndex = 78;
            this.btnConfigBackup.Text = "Backup";
            this.btnConfigBackup.UseVisualStyleBackColor = true;
            this.btnConfigBackup.Click += new System.EventHandler(this.btnConfigBackup_Click);
            // 
            // btnConfigBakBrowse
            // 
            this.btnConfigBakBrowse.Location = new System.Drawing.Point(479, 79);
            this.btnConfigBakBrowse.Name = "btnConfigBakBrowse";
            this.btnConfigBakBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnConfigBakBrowse.TabIndex = 77;
            this.btnConfigBakBrowse.Text = "&Browse...";
            this.btnConfigBakBrowse.UseVisualStyleBackColor = true;
            this.btnConfigBakBrowse.Click += new System.EventHandler(this.btnConfigBakBrowse_Click);
            // 
            // txtConfigBakPath
            // 
            this.txtConfigBakPath.BackColor = System.Drawing.Color.White;
            this.txtConfigBakPath.Location = new System.Drawing.Point(97, 81);
            this.txtConfigBakPath.Name = "txtConfigBakPath";
            this.txtConfigBakPath.Size = new System.Drawing.Size(370, 20);
            this.txtConfigBakPath.TabIndex = 76;
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Location = new System.Drawing.Point(6, 84);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(85, 13);
            this.label100.TabIndex = 75;
            this.label100.Text = "Bakup File Path:";
            // 
            // txtConfigBakServerName
            // 
            this.txtConfigBakServerName.BackColor = System.Drawing.Color.White;
            this.txtConfigBakServerName.Location = new System.Drawing.Point(89, 19);
            this.txtConfigBakServerName.Name = "txtConfigBakServerName";
            this.txtConfigBakServerName.ReadOnly = true;
            this.txtConfigBakServerName.Size = new System.Drawing.Size(187, 20);
            this.txtConfigBakServerName.TabIndex = 56;
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(282, 22);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(56, 13);
            this.label91.TabIndex = 55;
            this.label91.Text = "DB Name:";
            // 
            // lblConfigBakMsg
            // 
            this.lblConfigBakMsg.AutoSize = true;
            this.lblConfigBakMsg.ForeColor = System.Drawing.Color.Red;
            this.lblConfigBakMsg.Location = new System.Drawing.Point(16, 112);
            this.lblConfigBakMsg.Name = "lblConfigBakMsg";
            this.lblConfigBakMsg.Size = new System.Drawing.Size(29, 13);
            this.lblConfigBakMsg.TabIndex = 54;
            this.lblConfigBakMsg.Text = "Error";
            // 
            // btnConfigBakConfig
            // 
            this.btnConfigBakConfig.Location = new System.Drawing.Point(480, 15);
            this.btnConfigBakConfig.Name = "btnConfigBakConfig";
            this.btnConfigBakConfig.Size = new System.Drawing.Size(75, 23);
            this.btnConfigBakConfig.TabIndex = 53;
            this.btnConfigBakConfig.Text = "&Config.";
            this.btnConfigBakConfig.UseVisualStyleBackColor = true;
            this.btnConfigBakConfig.Click += new System.EventHandler(this.btnConfigBakConfig_Click);
            // 
            // btnConfigBakOpen
            // 
            this.btnConfigBakOpen.Location = new System.Drawing.Point(479, 49);
            this.btnConfigBakOpen.Name = "btnConfigBakOpen";
            this.btnConfigBakOpen.Size = new System.Drawing.Size(75, 23);
            this.btnConfigBakOpen.TabIndex = 52;
            this.btnConfigBakOpen.Text = "&Open";
            this.btnConfigBakOpen.UseVisualStyleBackColor = true;
            this.btnConfigBakOpen.Click += new System.EventHandler(this.btnConfigBakOpen_Click);
            // 
            // txtConfigBakVer
            // 
            this.txtConfigBakVer.Location = new System.Drawing.Point(89, 51);
            this.txtConfigBakVer.Name = "txtConfigBakVer";
            this.txtConfigBakVer.ReadOnly = true;
            this.txtConfigBakVer.Size = new System.Drawing.Size(383, 20);
            this.txtConfigBakVer.TabIndex = 51;
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(11, 54);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(45, 13);
            this.label93.TabIndex = 50;
            this.label93.Text = "Version:";
            // 
            // txtConfigBakDBName
            // 
            this.txtConfigBakDBName.BackColor = System.Drawing.Color.White;
            this.txtConfigBakDBName.Location = new System.Drawing.Point(344, 18);
            this.txtConfigBakDBName.Name = "txtConfigBakDBName";
            this.txtConfigBakDBName.ReadOnly = true;
            this.txtConfigBakDBName.Size = new System.Drawing.Size(128, 20);
            this.txtConfigBakDBName.TabIndex = 49;
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(11, 21);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(72, 13);
            this.label94.TabIndex = 48;
            this.label94.Text = "Server Name:";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.lblConfigSerDirMsg);
            this.groupBox8.Controls.Add(this.btnConfigSerDirBrowse);
            this.groupBox8.Controls.Add(this.txtConfigSerDir);
            this.groupBox8.Controls.Add(this.label56);
            this.groupBox8.Location = new System.Drawing.Point(6, 82);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(568, 72);
            this.groupBox8.TabIndex = 3;
            this.groupBox8.TabStop = false;
            // 
            // lblConfigSerDirMsg
            // 
            this.lblConfigSerDirMsg.AutoSize = true;
            this.lblConfigSerDirMsg.ForeColor = System.Drawing.Color.Red;
            this.lblConfigSerDirMsg.Location = new System.Drawing.Point(159, 20);
            this.lblConfigSerDirMsg.Name = "lblConfigSerDirMsg";
            this.lblConfigSerDirMsg.Size = new System.Drawing.Size(0, 13);
            this.lblConfigSerDirMsg.TabIndex = 14;
            // 
            // btnConfigSerDirBrowse
            // 
            this.btnConfigSerDirBrowse.Location = new System.Drawing.Point(482, 37);
            this.btnConfigSerDirBrowse.Name = "btnConfigSerDirBrowse";
            this.btnConfigSerDirBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnConfigSerDirBrowse.TabIndex = 13;
            this.btnConfigSerDirBrowse.Text = "&Browse";
            this.btnConfigSerDirBrowse.UseVisualStyleBackColor = true;
            this.btnConfigSerDirBrowse.Click += new System.EventHandler(this.btnConfigSerDirBrowse_Click);
            // 
            // txtConfigSerDir
            // 
            this.txtConfigSerDir.Location = new System.Drawing.Point(22, 39);
            this.txtConfigSerDir.Name = "txtConfigSerDir";
            this.txtConfigSerDir.Size = new System.Drawing.Size(400, 20);
            this.txtConfigSerDir.TabIndex = 12;
            this.txtConfigSerDir.TextChanged += new System.EventHandler(this.txtConfigSerDir_TextChanged);
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(19, 20);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(81, 13);
            this.label56.TabIndex = 11;
            this.label56.Text = "Serial Directory:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lblConfigTmpDirMsg);
            this.groupBox3.Controls.Add(this.btnConfigTmpDirBrowse);
            this.groupBox3.Controls.Add(this.txtConfigTempDir);
            this.groupBox3.Controls.Add(this.label49);
            this.groupBox3.Location = new System.Drawing.Point(6, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(568, 70);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            // 
            // lblConfigTmpDirMsg
            // 
            this.lblConfigTmpDirMsg.AutoSize = true;
            this.lblConfigTmpDirMsg.ForeColor = System.Drawing.Color.Red;
            this.lblConfigTmpDirMsg.Location = new System.Drawing.Point(159, 16);
            this.lblConfigTmpDirMsg.Name = "lblConfigTmpDirMsg";
            this.lblConfigTmpDirMsg.Size = new System.Drawing.Size(0, 13);
            this.lblConfigTmpDirMsg.TabIndex = 14;
            // 
            // btnConfigTmpDirBrowse
            // 
            this.btnConfigTmpDirBrowse.Location = new System.Drawing.Point(482, 35);
            this.btnConfigTmpDirBrowse.Name = "btnConfigTmpDirBrowse";
            this.btnConfigTmpDirBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnConfigTmpDirBrowse.TabIndex = 13;
            this.btnConfigTmpDirBrowse.Text = "&Browse";
            this.btnConfigTmpDirBrowse.UseVisualStyleBackColor = true;
            this.btnConfigTmpDirBrowse.Click += new System.EventHandler(this.btnConfigTmpDirBrowse_Click);
            // 
            // txtConfigTempDir
            // 
            this.txtConfigTempDir.Location = new System.Drawing.Point(22, 35);
            this.txtConfigTempDir.Name = "txtConfigTempDir";
            this.txtConfigTempDir.Size = new System.Drawing.Size(400, 20);
            this.txtConfigTempDir.TabIndex = 12;
            this.txtConfigTempDir.TextChanged += new System.EventHandler(this.txtConfigTempDir_TextChanged);
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(19, 16);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(105, 13);
            this.label49.TabIndex = 11;
            this.label49.Text = "Temporary Directory:";
            // 
            // tbPgAutoProcess
            // 
            this.tbPgAutoProcess.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tbPgAutoProcess.Controls.Add(this.label102);
            this.tbPgAutoProcess.Controls.Add(this.chkAutoFixAirREMS);
            this.tbPgAutoProcess.Controls.Add(this.label96);
            this.tbPgAutoProcess.Controls.Add(this.label92);
            this.tbPgAutoProcess.Controls.Add(this.label39);
            this.tbPgAutoProcess.Controls.Add(this.cobStartStep);
            this.tbPgAutoProcess.Controls.Add(this.label44);
            this.tbPgAutoProcess.Controls.Add(this.label42);
            this.tbPgAutoProcess.Controls.Add(this.label41);
            this.tbPgAutoProcess.Controls.Add(this.label40);
            this.tbPgAutoProcess.Controls.Add(this.label38);
            this.tbPgAutoProcess.Controls.Add(this.label34);
            this.tbPgAutoProcess.Controls.Add(this.btnAutoCancel);
            this.tbPgAutoProcess.Controls.Add(this.btnAutoProcess);
            this.tbPgAutoProcess.Controls.Add(this.txtAutoOut);
            this.tbPgAutoProcess.Location = new System.Drawing.Point(4, 40);
            this.tbPgAutoProcess.Name = "tbPgAutoProcess";
            this.tbPgAutoProcess.Padding = new System.Windows.Forms.Padding(3);
            this.tbPgAutoProcess.Size = new System.Drawing.Size(580, 488);
            this.tbPgAutoProcess.TabIndex = 9;
            this.tbPgAutoProcess.Text = "Auto Process";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Location = new System.Drawing.Point(14, 99);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(123, 13);
            this.label102.TabIndex = 89;
            this.label102.Text = "    Check the option box:";
            // 
            // chkAutoFixAirREMS
            // 
            this.chkAutoFixAirREMS.AutoSize = true;
            this.chkAutoFixAirREMS.Location = new System.Drawing.Point(137, 100);
            this.chkAutoFixAirREMS.Name = "chkAutoFixAirREMS";
            this.chkAutoFixAirREMS.Size = new System.Drawing.Size(86, 17);
            this.chkAutoFixAirREMS.TabIndex = 88;
            this.chkAutoFixAirREMS.Text = "Fix Air REMs";
            this.chkAutoFixAirREMS.UseVisualStyleBackColor = true;
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(14, 41);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(386, 13);
            this.label96.TabIndex = 87;
            this.label96.Text = "1. Under Configuration tab, restore MasterRef database to its last release versio" +
    "n";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(14, 134);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(112, 13);
            this.label92.TabIndex = 86;
            this.label92.Text = "    and Research Date";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(14, 197);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(55, 13);
            this.label39.TabIndex = 85;
            this.label39.Text = "Start from:";
            // 
            // cobStartStep
            // 
            this.cobStartStep.FormattingEnabled = true;
            this.cobStartStep.Items.AddRange(new object[] {
            "Step 1: Building REM files",
            "Step 2: Building Module DB",
            "Step 3: Fix av collision",
            "Step 4: Blob DB",
            "Step 5: Dup appsn",
            "Step 6: Look For Duplicate Question Link Text",
            "Step 7: Missing Link",
            "Step 8: Merge Federal",
            "Step 9: Fix av collision",
            "Step 10: Blob DB",
            "Step 11: Dup appsn",
            "Step 12: Applicability Range Map",
            "Step 13: Merge State",
            "Step 14: Blob DB",
            "Step 15: Dup state domainsn"});
            this.cobStartStep.Location = new System.Drawing.Point(75, 194);
            this.cobStartStep.Name = "cobStartStep";
            this.cobStartStep.Size = new System.Drawing.Size(270, 21);
            this.cobStartStep.TabIndex = 84;
            this.cobStartStep.SelectedIndexChanged += new System.EventHandler(this.cobStartStep_SelectedIndexChanged);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(14, 82);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(443, 13);
            this.label44.TabIndex = 83;
            this.label44.Text = "3. Under Build MODULE.DB tab, select Modules to be build, set Server Name and DB " +
    "Name";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(14, 172);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(185, 13);
            this.label42.TabIndex = 81;
            this.label42.Text = "    Date for new and modified sections";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(14, 154);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(537, 13);
            this.label41.TabIndex = 80;
            this.label41.Text = "5. Under Merge State tab, add States that are to be merged to the list. Set Modul" +
    "e Root Directory and Research ";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(14, 117);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(548, 13);
            this.label40.TabIndex = 79;
            this.label40.Text = "4. Under Merge Federal tab, set Server Name and DB Name of Master Module database" +
    ", as well as Version Name ";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(14, 63);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(555, 13);
            this.label38.TabIndex = 77;
            this.label38.Text = "2. Under Build REM Files tab, set root path of the Source Text Directory and sele" +
    "ct the corresponding sub directories";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(14, 15);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(445, 16);
            this.label34.TabIndex = 76;
            this.label34.Text = "Before running Auto Process, please create the following RgTool settings: ";
            // 
            // btnAutoCancel
            // 
            this.btnAutoCancel.Enabled = false;
            this.btnAutoCancel.Location = new System.Drawing.Point(369, 192);
            this.btnAutoCancel.Name = "btnAutoCancel";
            this.btnAutoCancel.Size = new System.Drawing.Size(85, 23);
            this.btnAutoCancel.TabIndex = 47;
            this.btnAutoCancel.Text = "&Cancel";
            this.btnAutoCancel.UseVisualStyleBackColor = true;
            this.btnAutoCancel.Click += new System.EventHandler(this.btnAutoCancel_Click);
            // 
            // btnAutoProcess
            // 
            this.btnAutoProcess.Location = new System.Drawing.Point(460, 192);
            this.btnAutoProcess.Name = "btnAutoProcess";
            this.btnAutoProcess.Size = new System.Drawing.Size(85, 23);
            this.btnAutoProcess.TabIndex = 44;
            this.btnAutoProcess.Text = "&Start Process";
            this.btnAutoProcess.UseVisualStyleBackColor = true;
            this.btnAutoProcess.Click += new System.EventHandler(this.btnAutoProcess_Click);
            // 
            // txtAutoOut
            // 
            this.txtAutoOut.Location = new System.Drawing.Point(17, 232);
            this.txtAutoOut.Multiline = true;
            this.txtAutoOut.Name = "txtAutoOut";
            this.txtAutoOut.ReadOnly = true;
            this.txtAutoOut.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtAutoOut.Size = new System.Drawing.Size(545, 250);
            this.txtAutoOut.TabIndex = 43;
            // 
            // tbPgBlobsCreat
            // 
            this.tbPgBlobsCreat.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tbPgBlobsCreat.Controls.Add(this.splitContainer6);
            this.tbPgBlobsCreat.Location = new System.Drawing.Point(4, 40);
            this.tbPgBlobsCreat.Name = "tbPgBlobsCreat";
            this.tbPgBlobsCreat.Padding = new System.Windows.Forms.Padding(3);
            this.tbPgBlobsCreat.Size = new System.Drawing.Size(580, 488);
            this.tbPgBlobsCreat.TabIndex = 8;
            this.tbPgBlobsCreat.Text = "Blobs Creation";
            // 
            // splitContainer6
            // 
            this.splitContainer6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer6.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer6.Location = new System.Drawing.Point(3, 3);
            this.splitContainer6.Name = "splitContainer6";
            this.splitContainer6.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer6.Panel1
            // 
            this.splitContainer6.Panel1.Controls.Add(this.txtBlobsServer);
            this.splitContainer6.Panel1.Controls.Add(this.label10);
            this.splitContainer6.Panel1.Controls.Add(this.lblBlobsMsg);
            this.splitContainer6.Panel1.Controls.Add(this.btnBlobsDBConfig);
            this.splitContainer6.Panel1.Controls.Add(this.btnBlobsOpen);
            this.splitContainer6.Panel1.Controls.Add(this.txtBlobsVer);
            this.splitContainer6.Panel1.Controls.Add(this.label21);
            this.splitContainer6.Panel1.Controls.Add(this.txtBlobsDB);
            this.splitContainer6.Panel1.Controls.Add(this.label22);
            // 
            // splitContainer6.Panel2
            // 
            this.splitContainer6.Panel2.Controls.Add(this.btnBlobsProcess);
            this.splitContainer6.Panel2.Controls.Add(this.btnBlobsCancel);
            this.splitContainer6.Panel2.Controls.Add(this.groupBox1);
            this.splitContainer6.Panel2.Controls.Add(this.txtBlobsOut);
            this.splitContainer6.Size = new System.Drawing.Size(574, 482);
            this.splitContainer6.SplitterDistance = 92;
            this.splitContainer6.TabIndex = 0;
            // 
            // txtBlobsServer
            // 
            this.txtBlobsServer.BackColor = System.Drawing.Color.White;
            this.txtBlobsServer.Location = new System.Drawing.Point(90, 27);
            this.txtBlobsServer.Name = "txtBlobsServer";
            this.txtBlobsServer.ReadOnly = true;
            this.txtBlobsServer.Size = new System.Drawing.Size(187, 20);
            this.txtBlobsServer.TabIndex = 47;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(283, 30);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 13);
            this.label10.TabIndex = 46;
            this.label10.Text = "DB Name:";
            // 
            // lblBlobsMsg
            // 
            this.lblBlobsMsg.AutoSize = true;
            this.lblBlobsMsg.ForeColor = System.Drawing.Color.Red;
            this.lblBlobsMsg.Location = new System.Drawing.Point(143, 11);
            this.lblBlobsMsg.Name = "lblBlobsMsg";
            this.lblBlobsMsg.Size = new System.Drawing.Size(0, 13);
            this.lblBlobsMsg.TabIndex = 45;
            // 
            // btnBlobsDBConfig
            // 
            this.btnBlobsDBConfig.Location = new System.Drawing.Point(487, 25);
            this.btnBlobsDBConfig.Name = "btnBlobsDBConfig";
            this.btnBlobsDBConfig.Size = new System.Drawing.Size(75, 23);
            this.btnBlobsDBConfig.TabIndex = 44;
            this.btnBlobsDBConfig.Text = "&Config.";
            this.btnBlobsDBConfig.UseVisualStyleBackColor = true;
            this.btnBlobsDBConfig.Click += new System.EventHandler(this.btnBlobsDBConfig_Click);
            // 
            // btnBlobsOpen
            // 
            this.btnBlobsOpen.Location = new System.Drawing.Point(487, 58);
            this.btnBlobsOpen.Name = "btnBlobsOpen";
            this.btnBlobsOpen.Size = new System.Drawing.Size(75, 23);
            this.btnBlobsOpen.TabIndex = 43;
            this.btnBlobsOpen.Text = "&Open";
            this.btnBlobsOpen.UseVisualStyleBackColor = true;
            this.btnBlobsOpen.Click += new System.EventHandler(this.btnBlobsOpen_Click);
            // 
            // txtBlobsVer
            // 
            this.txtBlobsVer.Location = new System.Drawing.Point(90, 60);
            this.txtBlobsVer.Name = "txtBlobsVer";
            this.txtBlobsVer.ReadOnly = true;
            this.txtBlobsVer.Size = new System.Drawing.Size(383, 20);
            this.txtBlobsVer.TabIndex = 42;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(12, 63);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(45, 13);
            this.label21.TabIndex = 41;
            this.label21.Text = "Version:";
            // 
            // txtBlobsDB
            // 
            this.txtBlobsDB.BackColor = System.Drawing.Color.White;
            this.txtBlobsDB.Location = new System.Drawing.Point(345, 26);
            this.txtBlobsDB.Name = "txtBlobsDB";
            this.txtBlobsDB.ReadOnly = true;
            this.txtBlobsDB.Size = new System.Drawing.Size(128, 20);
            this.txtBlobsDB.TabIndex = 40;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(12, 29);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(72, 13);
            this.label22.TabIndex = 39;
            this.label22.Text = "Server Name:";
            // 
            // btnBlobsProcess
            // 
            this.btnBlobsProcess.Enabled = false;
            this.btnBlobsProcess.Location = new System.Drawing.Point(468, 67);
            this.btnBlobsProcess.Name = "btnBlobsProcess";
            this.btnBlobsProcess.Size = new System.Drawing.Size(94, 25);
            this.btnBlobsProcess.TabIndex = 73;
            this.btnBlobsProcess.Text = "&Start Process";
            this.btnBlobsProcess.UseVisualStyleBackColor = true;
            this.btnBlobsProcess.Click += new System.EventHandler(this.btnBlobsProcess_Click);
            // 
            // btnBlobsCancel
            // 
            this.btnBlobsCancel.Location = new System.Drawing.Point(468, 67);
            this.btnBlobsCancel.Name = "btnBlobsCancel";
            this.btnBlobsCancel.Size = new System.Drawing.Size(94, 25);
            this.btnBlobsCancel.TabIndex = 72;
            this.btnBlobsCancel.Text = "&Cancel";
            this.btnBlobsCancel.UseVisualStyleBackColor = true;
            this.btnBlobsCancel.Visible = false;
            this.btnBlobsCancel.Click += new System.EventHandler(this.btnBlobsCancel_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.optMissingBlobs);
            this.groupBox1.Controls.Add(this.optAllTheBlobs);
            this.groupBox1.Location = new System.Drawing.Point(15, 18);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(353, 83);
            this.groupBox1.TabIndex = 61;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Build";
            // 
            // optMissingBlobs
            // 
            this.optMissingBlobs.AutoSize = true;
            this.optMissingBlobs.Checked = true;
            this.optMissingBlobs.Location = new System.Drawing.Point(21, 28);
            this.optMissingBlobs.Name = "optMissingBlobs";
            this.optMissingBlobs.Size = new System.Drawing.Size(89, 17);
            this.optMissingBlobs.TabIndex = 1;
            this.optMissingBlobs.TabStop = true;
            this.optMissingBlobs.Text = "Missing Blobs";
            this.optMissingBlobs.UseVisualStyleBackColor = true;
            // 
            // optAllTheBlobs
            // 
            this.optAllTheBlobs.AutoSize = true;
            this.optAllTheBlobs.Location = new System.Drawing.Point(21, 51);
            this.optAllTheBlobs.Name = "optAllTheBlobs";
            this.optAllTheBlobs.Size = new System.Drawing.Size(87, 17);
            this.optAllTheBlobs.TabIndex = 0;
            this.optAllTheBlobs.TabStop = true;
            this.optAllTheBlobs.Text = "All The Blobs";
            this.optAllTheBlobs.UseVisualStyleBackColor = true;
            // 
            // txtBlobsOut
            // 
            this.txtBlobsOut.Location = new System.Drawing.Point(15, 116);
            this.txtBlobsOut.Multiline = true;
            this.txtBlobsOut.Name = "txtBlobsOut";
            this.txtBlobsOut.ReadOnly = true;
            this.txtBlobsOut.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtBlobsOut.Size = new System.Drawing.Size(547, 258);
            this.txtBlobsOut.TabIndex = 60;
            // 
            // tbPgMergFederal
            // 
            this.tbPgMergFederal.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tbPgMergFederal.Controls.Add(this.splitContainer7);
            this.tbPgMergFederal.Location = new System.Drawing.Point(4, 40);
            this.tbPgMergFederal.Name = "tbPgMergFederal";
            this.tbPgMergFederal.Padding = new System.Windows.Forms.Padding(3);
            this.tbPgMergFederal.Size = new System.Drawing.Size(580, 488);
            this.tbPgMergFederal.TabIndex = 7;
            this.tbPgMergFederal.Text = "Merge Federal";
            // 
            // splitContainer7
            // 
            this.splitContainer7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer7.Location = new System.Drawing.Point(3, 3);
            this.splitContainer7.Name = "splitContainer7";
            this.splitContainer7.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer7.Panel1
            // 
            this.splitContainer7.Panel1.Controls.Add(this.groupBox4);
            // 
            // splitContainer7.Panel2
            // 
            this.splitContainer7.Panel2.Controls.Add(this.label33);
            this.splitContainer7.Panel2.Controls.Add(this.label20);
            this.splitContainer7.Panel2.Controls.Add(this.label17);
            this.splitContainer7.Panel2.Controls.Add(this.label14);
            this.splitContainer7.Panel2.Controls.Add(this.btnMergeFProcess);
            this.splitContainer7.Panel2.Controls.Add(this.btnMergeFCancel);
            this.splitContainer7.Panel2.Controls.Add(this.txtDateSC);
            this.splitContainer7.Panel2.Controls.Add(this.txtDateDA);
            this.splitContainer7.Panel2.Controls.Add(this.txtVNameSC);
            this.splitContainer7.Panel2.Controls.Add(this.txtVNameDA);
            this.splitContainer7.Panel2.Controls.Add(this.textBox8);
            this.splitContainer7.Panel2.Controls.Add(this.textBox7);
            this.splitContainer7.Panel2.Controls.Add(this.txtMergeFdOut);
            this.splitContainer7.Size = new System.Drawing.Size(574, 482);
            this.splitContainer7.SplitterDistance = 170;
            this.splitContainer7.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtMergeFMModuleServer);
            this.groupBox4.Controls.Add(this.label69);
            this.groupBox4.Controls.Add(this.label70);
            this.groupBox4.Controls.Add(this.btnMergeFMModuleConfig);
            this.groupBox4.Controls.Add(this.txtMergeFMModuleDB);
            this.groupBox4.Controls.Add(this.label71);
            this.groupBox4.Controls.Add(this.txtMergeFMMasterServer);
            this.groupBox4.Controls.Add(this.label66);
            this.groupBox4.Controls.Add(this.btnMergeFMMasterConfig);
            this.groupBox4.Controls.Add(this.txtMergeFMMasterDB);
            this.groupBox4.Controls.Add(this.label68);
            this.groupBox4.Controls.Add(this.lblMergeFModuleMsg);
            this.groupBox4.Controls.Add(this.txtMergeFMasterVer);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.btnMergeFModuleOpen);
            this.groupBox4.Controls.Add(this.txtMergeFModuleVer);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Controls.Add(this.btnMergeFMasterOpen);
            this.groupBox4.Controls.Add(this.label32);
            this.groupBox4.Controls.Add(this.lblMergeFMasterMsg);
            this.groupBox4.Location = new System.Drawing.Point(9, 0);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(559, 168);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            // 
            // txtMergeFMModuleServer
            // 
            this.txtMergeFMModuleServer.BackColor = System.Drawing.Color.White;
            this.txtMergeFMModuleServer.Location = new System.Drawing.Point(82, 110);
            this.txtMergeFMModuleServer.Name = "txtMergeFMModuleServer";
            this.txtMergeFMModuleServer.ReadOnly = true;
            this.txtMergeFMModuleServer.Size = new System.Drawing.Size(187, 20);
            this.txtMergeFMModuleServer.TabIndex = 64;
            this.txtMergeFMModuleServer.VisibleChanged += new System.EventHandler(this.MergeFMMouduleServerDB_Changed);
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(275, 113);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(56, 13);
            this.label69.TabIndex = 63;
            this.label69.Text = "DB Name:";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.ForeColor = System.Drawing.Color.Red;
            this.label70.Location = new System.Drawing.Point(135, 94);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(0, 13);
            this.label70.TabIndex = 62;
            // 
            // btnMergeFMModuleConfig
            // 
            this.btnMergeFMModuleConfig.Location = new System.Drawing.Point(478, 106);
            this.btnMergeFMModuleConfig.Name = "btnMergeFMModuleConfig";
            this.btnMergeFMModuleConfig.Size = new System.Drawing.Size(75, 23);
            this.btnMergeFMModuleConfig.TabIndex = 61;
            this.btnMergeFMModuleConfig.Text = "&Config.";
            this.btnMergeFMModuleConfig.UseVisualStyleBackColor = true;
            this.btnMergeFMModuleConfig.Click += new System.EventHandler(this.btnMergeFMModuleConfig_Click);
            // 
            // txtMergeFMModuleDB
            // 
            this.txtMergeFMModuleDB.BackColor = System.Drawing.Color.White;
            this.txtMergeFMModuleDB.Location = new System.Drawing.Point(337, 109);
            this.txtMergeFMModuleDB.Name = "txtMergeFMModuleDB";
            this.txtMergeFMModuleDB.ReadOnly = true;
            this.txtMergeFMModuleDB.Size = new System.Drawing.Size(128, 20);
            this.txtMergeFMModuleDB.TabIndex = 60;
            this.txtMergeFMModuleDB.TextChanged += new System.EventHandler(this.MergeFMMouduleServerDB_Changed);
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(4, 112);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(72, 13);
            this.label71.TabIndex = 59;
            this.label71.Text = "Server Name:";
            // 
            // txtMergeFMMasterServer
            // 
            this.txtMergeFMMasterServer.BackColor = System.Drawing.Color.White;
            this.txtMergeFMMasterServer.Location = new System.Drawing.Point(82, 36);
            this.txtMergeFMMasterServer.Name = "txtMergeFMMasterServer";
            this.txtMergeFMMasterServer.ReadOnly = true;
            this.txtMergeFMMasterServer.Size = new System.Drawing.Size(187, 20);
            this.txtMergeFMMasterServer.TabIndex = 58;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(275, 39);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(56, 13);
            this.label66.TabIndex = 57;
            this.label66.Text = "DB Name:";
            // 
            // btnMergeFMMasterConfig
            // 
            this.btnMergeFMMasterConfig.Location = new System.Drawing.Point(478, 32);
            this.btnMergeFMMasterConfig.Name = "btnMergeFMMasterConfig";
            this.btnMergeFMMasterConfig.Size = new System.Drawing.Size(75, 23);
            this.btnMergeFMMasterConfig.TabIndex = 55;
            this.btnMergeFMMasterConfig.Text = "&Config.";
            this.btnMergeFMMasterConfig.UseVisualStyleBackColor = true;
            this.btnMergeFMMasterConfig.Click += new System.EventHandler(this.btnMergeFMMasterConfig_Click);
            // 
            // txtMergeFMMasterDB
            // 
            this.txtMergeFMMasterDB.BackColor = System.Drawing.Color.White;
            this.txtMergeFMMasterDB.Location = new System.Drawing.Point(337, 35);
            this.txtMergeFMMasterDB.Name = "txtMergeFMMasterDB";
            this.txtMergeFMMasterDB.ReadOnly = true;
            this.txtMergeFMMasterDB.Size = new System.Drawing.Size(128, 20);
            this.txtMergeFMMasterDB.TabIndex = 54;
            this.txtMergeFMMasterDB.TextChanged += new System.EventHandler(this.MergeFMMouduleServerDB_Changed);
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(4, 38);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(72, 13);
            this.label68.TabIndex = 53;
            this.label68.Text = "Server Name:";
            // 
            // lblMergeFModuleMsg
            // 
            this.lblMergeFModuleMsg.AutoSize = true;
            this.lblMergeFModuleMsg.ForeColor = System.Drawing.Color.Red;
            this.lblMergeFModuleMsg.Location = new System.Drawing.Point(155, 92);
            this.lblMergeFModuleMsg.Name = "lblMergeFModuleMsg";
            this.lblMergeFModuleMsg.Size = new System.Drawing.Size(0, 13);
            this.lblMergeFModuleMsg.TabIndex = 52;
            // 
            // txtMergeFMasterVer
            // 
            this.txtMergeFMasterVer.Location = new System.Drawing.Point(54, 62);
            this.txtMergeFMasterVer.Name = "txtMergeFMasterVer";
            this.txtMergeFMasterVer.ReadOnly = true;
            this.txtMergeFMasterVer.Size = new System.Drawing.Size(215, 20);
            this.txtMergeFMasterVer.TabIndex = 42;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(3, 13);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(129, 13);
            this.label19.TabIndex = 39;
            this.label19.Text = "Master Module Database:";
            // 
            // btnMergeFModuleOpen
            // 
            this.btnMergeFModuleOpen.Location = new System.Drawing.Point(478, 139);
            this.btnMergeFModuleOpen.Name = "btnMergeFModuleOpen";
            this.btnMergeFModuleOpen.Size = new System.Drawing.Size(75, 23);
            this.btnMergeFModuleOpen.TabIndex = 50;
            this.btnMergeFModuleOpen.Text = "&Open";
            this.btnMergeFModuleOpen.UseVisualStyleBackColor = true;
            this.btnMergeFModuleOpen.Click += new System.EventHandler(this.btnMergeFModuleOpen_Click);
            // 
            // txtMergeFModuleVer
            // 
            this.txtMergeFModuleVer.Location = new System.Drawing.Point(54, 141);
            this.txtMergeFModuleVer.Name = "txtMergeFModuleVer";
            this.txtMergeFModuleVer.ReadOnly = true;
            this.txtMergeFModuleVer.Size = new System.Drawing.Size(215, 20);
            this.txtMergeFModuleVer.TabIndex = 49;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(3, 65);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(45, 13);
            this.label18.TabIndex = 41;
            this.label18.Text = "Version:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(3, 144);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(45, 13);
            this.label23.TabIndex = 48;
            this.label23.Text = "Version:";
            // 
            // btnMergeFMasterOpen
            // 
            this.btnMergeFMasterOpen.Location = new System.Drawing.Point(478, 65);
            this.btnMergeFMasterOpen.Name = "btnMergeFMasterOpen";
            this.btnMergeFMasterOpen.Size = new System.Drawing.Size(75, 23);
            this.btnMergeFMasterOpen.TabIndex = 43;
            this.btnMergeFMasterOpen.Text = "&Open";
            this.btnMergeFMasterOpen.UseVisualStyleBackColor = true;
            this.btnMergeFMasterOpen.Click += new System.EventHandler(this.btnMergeFMasterOpen_Click);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(3, 92);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(143, 13);
            this.label32.TabIndex = 46;
            this.label32.Text = "To Merge Module Database:";
            // 
            // lblMergeFMasterMsg
            // 
            this.lblMergeFMasterMsg.AutoSize = true;
            this.lblMergeFMasterMsg.ForeColor = System.Drawing.Color.Red;
            this.lblMergeFMasterMsg.Location = new System.Drawing.Point(153, 17);
            this.lblMergeFMasterMsg.Name = "lblMergeFMasterMsg";
            this.lblMergeFMasterMsg.Size = new System.Drawing.Size(0, 13);
            this.lblMergeFMasterMsg.TabIndex = 45;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(12, 23);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(394, 13);
            this.label33.TabIndex = 75;
            this.label33.Text = "in the \\\"Select Reference Change Date\\\" dialog box in Dakota Audit / Smart Cite.";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(12, 10);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(504, 13);
            this.label20.TabIndex = 74;
            this.label20.Text = "Enter the Version Names and Research Dates. Enter a Research Date to make the ver" +
    "sion name appear ";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(129, 55);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(73, 13);
            this.label17.TabIndex = 73;
            this.label17.Text = "Version Name";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(297, 55);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(79, 13);
            this.label14.TabIndex = 72;
            this.label14.Text = "Research Date";
            // 
            // btnMergeFProcess
            // 
            this.btnMergeFProcess.Enabled = false;
            this.btnMergeFProcess.Location = new System.Drawing.Point(469, 94);
            this.btnMergeFProcess.Name = "btnMergeFProcess";
            this.btnMergeFProcess.Size = new System.Drawing.Size(94, 25);
            this.btnMergeFProcess.TabIndex = 70;
            this.btnMergeFProcess.Text = "&Start Process";
            this.btnMergeFProcess.UseVisualStyleBackColor = true;
            this.btnMergeFProcess.Click += new System.EventHandler(this.btnMergeFProcess_Click);
            // 
            // btnMergeFCancel
            // 
            this.btnMergeFCancel.Location = new System.Drawing.Point(469, 94);
            this.btnMergeFCancel.Name = "btnMergeFCancel";
            this.btnMergeFCancel.Size = new System.Drawing.Size(94, 25);
            this.btnMergeFCancel.TabIndex = 69;
            this.btnMergeFCancel.Text = "&Cancel";
            this.btnMergeFCancel.UseVisualStyleBackColor = true;
            this.btnMergeFCancel.Visible = false;
            this.btnMergeFCancel.Click += new System.EventHandler(this.btnMergeFCancel_Click);
            // 
            // txtDateSC
            // 
            this.txtDateSC.Location = new System.Drawing.Point(288, 97);
            this.txtDateSC.Name = "txtDateSC";
            this.txtDateSC.Size = new System.Drawing.Size(163, 20);
            this.txtDateSC.TabIndex = 67;
            this.txtDateSC.Leave += new System.EventHandler(this.txtDateSC_Leave);
            // 
            // txtDateDA
            // 
            this.txtDateDA.Location = new System.Drawing.Point(287, 71);
            this.txtDateDA.Name = "txtDateDA";
            this.txtDateDA.Size = new System.Drawing.Size(163, 20);
            this.txtDateDA.TabIndex = 65;
            this.txtDateDA.Leave += new System.EventHandler(this.txtDateDA_Leave);
            // 
            // txtVNameSC
            // 
            this.txtVNameSC.Location = new System.Drawing.Point(119, 97);
            this.txtVNameSC.Name = "txtVNameSC";
            this.txtVNameSC.Size = new System.Drawing.Size(163, 20);
            this.txtVNameSC.TabIndex = 66;
            this.txtVNameSC.Leave += new System.EventHandler(this.txtVNameSC_Leave);
            // 
            // txtVNameDA
            // 
            this.txtVNameDA.Location = new System.Drawing.Point(119, 71);
            this.txtVNameDA.Name = "txtVNameDA";
            this.txtVNameDA.Size = new System.Drawing.Size(163, 20);
            this.txtVNameDA.TabIndex = 64;
            this.txtVNameDA.Leave += new System.EventHandler(this.txtVNameDA_Leave);
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(30, 97);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(83, 20);
            this.textBox8.TabIndex = 63;
            this.textBox8.Text = "Smart Cite:";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(30, 71);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(83, 20);
            this.textBox7.TabIndex = 62;
            this.textBox7.Text = "Dakota Auditor:";
            // 
            // txtMergeFdOut
            // 
            this.txtMergeFdOut.Location = new System.Drawing.Point(15, 125);
            this.txtMergeFdOut.Multiline = true;
            this.txtMergeFdOut.Name = "txtMergeFdOut";
            this.txtMergeFdOut.ReadOnly = true;
            this.txtMergeFdOut.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtMergeFdOut.Size = new System.Drawing.Size(547, 174);
            this.txtMergeFdOut.TabIndex = 59;
            // 
            // tbPgMergSt
            // 
            this.tbPgMergSt.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tbPgMergSt.Controls.Add(this.splitContainer8);
            this.tbPgMergSt.Location = new System.Drawing.Point(4, 40);
            this.tbPgMergSt.Name = "tbPgMergSt";
            this.tbPgMergSt.Padding = new System.Windows.Forms.Padding(3);
            this.tbPgMergSt.Size = new System.Drawing.Size(580, 488);
            this.tbPgMergSt.TabIndex = 5;
            this.tbPgMergSt.Text = "Merge State";
            // 
            // splitContainer8
            // 
            this.splitContainer8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer8.Location = new System.Drawing.Point(3, 3);
            this.splitContainer8.Name = "splitContainer8";
            this.splitContainer8.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer8.Panel1
            // 
            this.splitContainer8.Panel1.Controls.Add(this.txtMergeSTServer);
            this.splitContainer8.Panel1.Controls.Add(this.label72);
            this.splitContainer8.Panel1.Controls.Add(this.btnMergeSTConfig);
            this.splitContainer8.Panel1.Controls.Add(this.txtMergeSTDB);
            this.splitContainer8.Panel1.Controls.Add(this.label73);
            this.splitContainer8.Panel1.Controls.Add(this.lblMergeStMsg);
            this.splitContainer8.Panel1.Controls.Add(this.btnMergeSTOpen);
            this.splitContainer8.Panel1.Controls.Add(this.txtMergeSTVer);
            this.splitContainer8.Panel1.Controls.Add(this.label24);
            // 
            // splitContainer8.Panel2
            // 
            this.splitContainer8.Panel2.Controls.Add(this.lblMergeSTModuleRoot);
            this.splitContainer8.Panel2.Controls.Add(this.lblMergeSTSateRoot);
            this.splitContainer8.Panel2.Controls.Add(this.btnMergeSTModuleRoot);
            this.splitContainer8.Panel2.Controls.Add(this.btnMergeSTSateRoot);
            this.splitContainer8.Panel2.Controls.Add(this.chkMergeSynCheck);
            this.splitContainer8.Panel2.Controls.Add(this.btnMergeSTCancel);
            this.splitContainer8.Panel2.Controls.Add(this.txtMergeSTOut);
            this.splitContainer8.Panel2.Controls.Add(this.btnMergeSTProcess);
            this.splitContainer8.Panel2.Controls.Add(this.txtMergeSTVerName);
            this.splitContainer8.Panel2.Controls.Add(this.label30);
            this.splitContainer8.Panel2.Controls.Add(this.txtMergeSTDate);
            this.splitContainer8.Panel2.Controls.Add(this.label31);
            this.splitContainer8.Panel2.Controls.Add(this.btnMergeSTRemoveAll);
            this.splitContainer8.Panel2.Controls.Add(this.btnMergeSTAddAll);
            this.splitContainer8.Panel2.Controls.Add(this.lstMergeSTStates);
            this.splitContainer8.Panel2.Controls.Add(this.lstMergeSTAvaiSt);
            this.splitContainer8.Panel2.Controls.Add(this.btnMergeSTAdd);
            this.splitContainer8.Panel2.Controls.Add(this.btnMergeSTRemove);
            this.splitContainer8.Panel2.Controls.Add(this.label28);
            this.splitContainer8.Panel2.Controls.Add(this.label29);
            this.splitContainer8.Panel2.Controls.Add(this.txtMergeSTModuleRoot);
            this.splitContainer8.Panel2.Controls.Add(this.label27);
            this.splitContainer8.Panel2.Controls.Add(this.txtMergeSTSateRoot);
            this.splitContainer8.Panel2.Controls.Add(this.label26);
            this.splitContainer8.Size = new System.Drawing.Size(574, 482);
            this.splitContainer8.SplitterDistance = 90;
            this.splitContainer8.TabIndex = 0;
            // 
            // txtMergeSTServer
            // 
            this.txtMergeSTServer.BackColor = System.Drawing.Color.White;
            this.txtMergeSTServer.Location = new System.Drawing.Point(88, 27);
            this.txtMergeSTServer.Name = "txtMergeSTServer";
            this.txtMergeSTServer.ReadOnly = true;
            this.txtMergeSTServer.Size = new System.Drawing.Size(187, 20);
            this.txtMergeSTServer.TabIndex = 63;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(281, 30);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(56, 13);
            this.label72.TabIndex = 62;
            this.label72.Text = "DB Name:";
            // 
            // btnMergeSTConfig
            // 
            this.btnMergeSTConfig.Location = new System.Drawing.Point(487, 23);
            this.btnMergeSTConfig.Name = "btnMergeSTConfig";
            this.btnMergeSTConfig.Size = new System.Drawing.Size(75, 23);
            this.btnMergeSTConfig.TabIndex = 61;
            this.btnMergeSTConfig.Text = "&Config.";
            this.btnMergeSTConfig.UseVisualStyleBackColor = true;
            this.btnMergeSTConfig.Click += new System.EventHandler(this.btnMergeSTConfig_Click);
            // 
            // txtMergeSTDB
            // 
            this.txtMergeSTDB.BackColor = System.Drawing.Color.White;
            this.txtMergeSTDB.Location = new System.Drawing.Point(343, 26);
            this.txtMergeSTDB.Name = "txtMergeSTDB";
            this.txtMergeSTDB.ReadOnly = true;
            this.txtMergeSTDB.Size = new System.Drawing.Size(128, 20);
            this.txtMergeSTDB.TabIndex = 60;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(10, 29);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(72, 13);
            this.label73.TabIndex = 59;
            this.label73.Text = "Server Name:";
            // 
            // lblMergeStMsg
            // 
            this.lblMergeStMsg.AutoSize = true;
            this.lblMergeStMsg.ForeColor = System.Drawing.Color.Red;
            this.lblMergeStMsg.Location = new System.Drawing.Point(60, 11);
            this.lblMergeStMsg.Name = "lblMergeStMsg";
            this.lblMergeStMsg.Size = new System.Drawing.Size(0, 13);
            this.lblMergeStMsg.TabIndex = 45;
            // 
            // btnMergeSTOpen
            // 
            this.btnMergeSTOpen.Location = new System.Drawing.Point(487, 53);
            this.btnMergeSTOpen.Name = "btnMergeSTOpen";
            this.btnMergeSTOpen.Size = new System.Drawing.Size(75, 23);
            this.btnMergeSTOpen.TabIndex = 43;
            this.btnMergeSTOpen.Text = "&Open";
            this.btnMergeSTOpen.UseVisualStyleBackColor = true;
            this.btnMergeSTOpen.Click += new System.EventHandler(this.btnMergeSTOpen_Click);
            // 
            // txtMergeSTVer
            // 
            this.txtMergeSTVer.Location = new System.Drawing.Point(63, 60);
            this.txtMergeSTVer.Name = "txtMergeSTVer";
            this.txtMergeSTVer.ReadOnly = true;
            this.txtMergeSTVer.Size = new System.Drawing.Size(212, 20);
            this.txtMergeSTVer.TabIndex = 42;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(12, 63);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(45, 13);
            this.label24.TabIndex = 41;
            this.label24.Text = "Version:";
            // 
            // lblMergeSTModuleRoot
            // 
            this.lblMergeSTModuleRoot.AutoSize = true;
            this.lblMergeSTModuleRoot.ForeColor = System.Drawing.Color.Red;
            this.lblMergeSTModuleRoot.Location = new System.Drawing.Point(424, 2);
            this.lblMergeSTModuleRoot.Name = "lblMergeSTModuleRoot";
            this.lblMergeSTModuleRoot.Size = new System.Drawing.Size(0, 13);
            this.lblMergeSTModuleRoot.TabIndex = 64;
            // 
            // lblMergeSTSateRoot
            // 
            this.lblMergeSTSateRoot.AutoSize = true;
            this.lblMergeSTSateRoot.ForeColor = System.Drawing.Color.Red;
            this.lblMergeSTSateRoot.Location = new System.Drawing.Point(124, 2);
            this.lblMergeSTSateRoot.Name = "lblMergeSTSateRoot";
            this.lblMergeSTSateRoot.Size = new System.Drawing.Size(0, 13);
            this.lblMergeSTSateRoot.TabIndex = 63;
            // 
            // btnMergeSTModuleRoot
            // 
            this.btnMergeSTModuleRoot.Location = new System.Drawing.Point(509, 18);
            this.btnMergeSTModuleRoot.Name = "btnMergeSTModuleRoot";
            this.btnMergeSTModuleRoot.Size = new System.Drawing.Size(53, 23);
            this.btnMergeSTModuleRoot.TabIndex = 62;
            this.btnMergeSTModuleRoot.Text = "&Browse";
            this.btnMergeSTModuleRoot.UseVisualStyleBackColor = true;
            this.btnMergeSTModuleRoot.Click += new System.EventHandler(this.btnMergeSTModuleRoot_Click);
            // 
            // btnMergeSTSateRoot
            // 
            this.btnMergeSTSateRoot.Location = new System.Drawing.Point(222, 15);
            this.btnMergeSTSateRoot.Name = "btnMergeSTSateRoot";
            this.btnMergeSTSateRoot.Size = new System.Drawing.Size(53, 23);
            this.btnMergeSTSateRoot.TabIndex = 61;
            this.btnMergeSTSateRoot.Text = "&Browse";
            this.btnMergeSTSateRoot.UseVisualStyleBackColor = true;
            this.btnMergeSTSateRoot.Click += new System.EventHandler(this.btnMergeSTSateRoot_Click);
            // 
            // chkMergeSynCheck
            // 
            this.chkMergeSynCheck.AutoSize = true;
            this.chkMergeSynCheck.Location = new System.Drawing.Point(15, 208);
            this.chkMergeSynCheck.Name = "chkMergeSynCheck";
            this.chkMergeSynCheck.Size = new System.Drawing.Size(130, 17);
            this.chkMergeSynCheck.TabIndex = 60;
            this.chkMergeSynCheck.Text = "Syntax Checking Only";
            this.chkMergeSynCheck.UseVisualStyleBackColor = true;
            // 
            // btnMergeSTCancel
            // 
            this.btnMergeSTCancel.Location = new System.Drawing.Point(468, 200);
            this.btnMergeSTCancel.Name = "btnMergeSTCancel";
            this.btnMergeSTCancel.Size = new System.Drawing.Size(94, 25);
            this.btnMergeSTCancel.TabIndex = 59;
            this.btnMergeSTCancel.Text = "&Cancel";
            this.btnMergeSTCancel.UseVisualStyleBackColor = true;
            this.btnMergeSTCancel.Visible = false;
            this.btnMergeSTCancel.Click += new System.EventHandler(this.btnMergeSTCancel_Click);
            // 
            // txtMergeSTOut
            // 
            this.txtMergeSTOut.Location = new System.Drawing.Point(15, 231);
            this.txtMergeSTOut.Multiline = true;
            this.txtMergeSTOut.Name = "txtMergeSTOut";
            this.txtMergeSTOut.ReadOnly = true;
            this.txtMergeSTOut.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtMergeSTOut.Size = new System.Drawing.Size(547, 145);
            this.txtMergeSTOut.TabIndex = 58;
            // 
            // btnMergeSTProcess
            // 
            this.btnMergeSTProcess.Enabled = false;
            this.btnMergeSTProcess.Location = new System.Drawing.Point(468, 200);
            this.btnMergeSTProcess.Name = "btnMergeSTProcess";
            this.btnMergeSTProcess.Size = new System.Drawing.Size(94, 25);
            this.btnMergeSTProcess.TabIndex = 57;
            this.btnMergeSTProcess.Text = "&Start Process";
            this.btnMergeSTProcess.UseVisualStyleBackColor = true;
            this.btnMergeSTProcess.Click += new System.EventHandler(this.btnMergeSTProcess_Click);
            // 
            // txtMergeSTVerName
            // 
            this.txtMergeSTVerName.Location = new System.Drawing.Point(302, 174);
            this.txtMergeSTVerName.Name = "txtMergeSTVerName";
            this.txtMergeSTVerName.Size = new System.Drawing.Size(260, 20);
            this.txtMergeSTVerName.TabIndex = 56;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(299, 158);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(152, 13);
            this.label30.TabIndex = 55;
            this.label30.Text = "State Version Name (Optional):";
            // 
            // txtMergeSTDate
            // 
            this.txtMergeSTDate.Location = new System.Drawing.Point(15, 174);
            this.txtMergeSTDate.Name = "txtMergeSTDate";
            this.txtMergeSTDate.Size = new System.Drawing.Size(260, 20);
            this.txtMergeSTDate.TabIndex = 54;
            this.txtMergeSTDate.TextChanged += new System.EventHandler(this.txtMergeSTDate_TextChanged);
            this.txtMergeSTDate.DoubleClick += new System.EventHandler(this.txtMergeSTDate_DoubleClick);
            this.txtMergeSTDate.Leave += new System.EventHandler(this.txtMergeSTDate_Leave);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(12, 158);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(225, 13);
            this.label31.TabIndex = 53;
            this.label31.Text = "Research Date for new and modified sections:";
            // 
            // btnMergeSTRemoveAll
            // 
            this.btnMergeSTRemoveAll.Location = new System.Drawing.Point(248, 133);
            this.btnMergeSTRemoveAll.Name = "btnMergeSTRemoveAll";
            this.btnMergeSTRemoveAll.Size = new System.Drawing.Size(80, 22);
            this.btnMergeSTRemoveAll.TabIndex = 52;
            this.btnMergeSTRemoveAll.Text = "<-R&emove All";
            this.btnMergeSTRemoveAll.UseVisualStyleBackColor = true;
            this.btnMergeSTRemoveAll.Click += new System.EventHandler(this.btnMergeSTRemoveAll_Click);
            // 
            // btnMergeSTAddAll
            // 
            this.btnMergeSTAddAll.Location = new System.Drawing.Point(248, 105);
            this.btnMergeSTAddAll.Name = "btnMergeSTAddAll";
            this.btnMergeSTAddAll.Size = new System.Drawing.Size(80, 22);
            this.btnMergeSTAddAll.TabIndex = 51;
            this.btnMergeSTAddAll.Text = "A&dd All ->";
            this.btnMergeSTAddAll.UseVisualStyleBackColor = true;
            this.btnMergeSTAddAll.Click += new System.EventHandler(this.btnMergeSTAddAll_Click);
            // 
            // lstMergeSTStates
            // 
            this.lstMergeSTStates.FormattingEnabled = true;
            this.lstMergeSTStates.Location = new System.Drawing.Point(362, 60);
            this.lstMergeSTStates.Name = "lstMergeSTStates";
            this.lstMergeSTStates.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstMergeSTStates.Size = new System.Drawing.Size(200, 95);
            this.lstMergeSTStates.TabIndex = 50;
            this.lstMergeSTStates.SelectedIndexChanged += new System.EventHandler(this.lstMergeSTStates_SelectedIndexChanged);
            this.lstMergeSTStates.DoubleClick += new System.EventHandler(this.lstMergeSTStates_DoubleClick);
            // 
            // lstMergeSTAvaiSt
            // 
            this.lstMergeSTAvaiSt.FormattingEnabled = true;
            this.lstMergeSTAvaiSt.Location = new System.Drawing.Point(15, 60);
            this.lstMergeSTAvaiSt.Name = "lstMergeSTAvaiSt";
            this.lstMergeSTAvaiSt.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstMergeSTAvaiSt.Size = new System.Drawing.Size(200, 95);
            this.lstMergeSTAvaiSt.TabIndex = 49;
            this.lstMergeSTAvaiSt.SelectedIndexChanged += new System.EventHandler(this.lstMergeSTAvaiSt_SelectedIndexChanged);
            this.lstMergeSTAvaiSt.DoubleClick += new System.EventHandler(this.lstMergeSTAvaiSt_DoubleClick);
            // 
            // btnMergeSTAdd
            // 
            this.btnMergeSTAdd.Enabled = false;
            this.btnMergeSTAdd.Location = new System.Drawing.Point(248, 49);
            this.btnMergeSTAdd.Name = "btnMergeSTAdd";
            this.btnMergeSTAdd.Size = new System.Drawing.Size(80, 22);
            this.btnMergeSTAdd.TabIndex = 48;
            this.btnMergeSTAdd.Text = "&Add ->";
            this.btnMergeSTAdd.UseVisualStyleBackColor = true;
            this.btnMergeSTAdd.Click += new System.EventHandler(this.btnMergeSTAdd_Click);
            // 
            // btnMergeSTRemove
            // 
            this.btnMergeSTRemove.Enabled = false;
            this.btnMergeSTRemove.Location = new System.Drawing.Point(248, 77);
            this.btnMergeSTRemove.Name = "btnMergeSTRemove";
            this.btnMergeSTRemove.Size = new System.Drawing.Size(80, 22);
            this.btnMergeSTRemove.TabIndex = 47;
            this.btnMergeSTRemove.Text = "<- &Remove";
            this.btnMergeSTRemove.UseVisualStyleBackColor = true;
            this.btnMergeSTRemove.Click += new System.EventHandler(this.btnMergeSTRemove_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(359, 44);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(85, 13);
            this.label28.TabIndex = 46;
            this.label28.Text = "States to Merge:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(12, 44);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(86, 13);
            this.label29.TabIndex = 45;
            this.label29.Text = "Available States:";
            // 
            // txtMergeSTModuleRoot
            // 
            this.txtMergeSTModuleRoot.Location = new System.Drawing.Point(302, 18);
            this.txtMergeSTModuleRoot.Name = "txtMergeSTModuleRoot";
            this.txtMergeSTModuleRoot.Size = new System.Drawing.Size(200, 20);
            this.txtMergeSTModuleRoot.TabIndex = 44;
            this.txtMergeSTModuleRoot.TextChanged += new System.EventHandler(this.txtMergeSTModuleRoot_TextChanged);
            this.txtMergeSTModuleRoot.Leave += new System.EventHandler(this.txtMergeSTModuleRoot_Leave);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(299, 2);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(116, 13);
            this.label27.TabIndex = 43;
            this.label27.Text = "Module Root Directory:";
            // 
            // txtMergeSTSateRoot
            // 
            this.txtMergeSTSateRoot.Location = new System.Drawing.Point(15, 18);
            this.txtMergeSTSateRoot.Name = "txtMergeSTSateRoot";
            this.txtMergeSTSateRoot.Size = new System.Drawing.Size(200, 20);
            this.txtMergeSTSateRoot.TabIndex = 42;
            this.txtMergeSTSateRoot.TextChanged += new System.EventHandler(this.txtMergeSTSateRoot_TextChanged);
            this.txtMergeSTSateRoot.Leave += new System.EventHandler(this.txtMergeSTSateRoot_Leave);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(12, 2);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(106, 13);
            this.label26.TabIndex = 41;
            this.label26.Text = "State Root Directory:";
            // 
            // tbPgDelState
            // 
            this.tbPgDelState.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tbPgDelState.Controls.Add(this.splitContainer3);
            this.tbPgDelState.Location = new System.Drawing.Point(4, 40);
            this.tbPgDelState.Name = "tbPgDelState";
            this.tbPgDelState.Padding = new System.Windows.Forms.Padding(3);
            this.tbPgDelState.Size = new System.Drawing.Size(580, 488);
            this.tbPgDelState.TabIndex = 3;
            this.tbPgDelState.Text = "Delete State";
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(3, 3);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.txtDelStServer);
            this.splitContainer3.Panel1.Controls.Add(this.label7);
            this.splitContainer3.Panel1.Controls.Add(this.btnSelStConfig);
            this.splitContainer3.Panel1.Controls.Add(this.txtDelStDB);
            this.splitContainer3.Panel1.Controls.Add(this.label9);
            this.splitContainer3.Panel1.Controls.Add(this.lblDelStMsg);
            this.splitContainer3.Panel1.Controls.Add(this.btnDelStOpen);
            this.splitContainer3.Panel1.Controls.Add(this.txtDelStVer);
            this.splitContainer3.Panel1.Controls.Add(this.label8);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.btnDelStCancel);
            this.splitContainer3.Panel2.Controls.Add(this.txtDelStOut);
            this.splitContainer3.Panel2.Controls.Add(this.btnDelStProcess);
            this.splitContainer3.Size = new System.Drawing.Size(574, 482);
            this.splitContainer3.SplitterDistance = 107;
            this.splitContainer3.TabIndex = 0;
            // 
            // txtDelStServer
            // 
            this.txtDelStServer.BackColor = System.Drawing.Color.White;
            this.txtDelStServer.Location = new System.Drawing.Point(85, 33);
            this.txtDelStServer.Name = "txtDelStServer";
            this.txtDelStServer.ReadOnly = true;
            this.txtDelStServer.Size = new System.Drawing.Size(187, 20);
            this.txtDelStServer.TabIndex = 73;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(279, 36);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 13);
            this.label7.TabIndex = 72;
            this.label7.Text = "DB Name:";
            // 
            // btnSelStConfig
            // 
            this.btnSelStConfig.Location = new System.Drawing.Point(486, 31);
            this.btnSelStConfig.Name = "btnSelStConfig";
            this.btnSelStConfig.Size = new System.Drawing.Size(75, 23);
            this.btnSelStConfig.TabIndex = 71;
            this.btnSelStConfig.Text = "&Config.";
            this.btnSelStConfig.UseVisualStyleBackColor = true;
            this.btnSelStConfig.Click += new System.EventHandler(this.btnDelStConfig_Click);
            // 
            // txtDelStDB
            // 
            this.txtDelStDB.BackColor = System.Drawing.Color.White;
            this.txtDelStDB.Location = new System.Drawing.Point(342, 34);
            this.txtDelStDB.Name = "txtDelStDB";
            this.txtDelStDB.ReadOnly = true;
            this.txtDelStDB.Size = new System.Drawing.Size(128, 20);
            this.txtDelStDB.TabIndex = 70;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(11, 36);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(72, 13);
            this.label9.TabIndex = 69;
            this.label9.Text = "Server Name:";
            // 
            // lblDelStMsg
            // 
            this.lblDelStMsg.AutoSize = true;
            this.lblDelStMsg.ForeColor = System.Drawing.Color.Red;
            this.lblDelStMsg.Location = new System.Drawing.Point(67, 11);
            this.lblDelStMsg.Name = "lblDelStMsg";
            this.lblDelStMsg.Size = new System.Drawing.Size(0, 13);
            this.lblDelStMsg.TabIndex = 31;
            // 
            // btnDelStOpen
            // 
            this.btnDelStOpen.Location = new System.Drawing.Point(487, 66);
            this.btnDelStOpen.Name = "btnDelStOpen";
            this.btnDelStOpen.Size = new System.Drawing.Size(75, 23);
            this.btnDelStOpen.TabIndex = 22;
            this.btnDelStOpen.Text = "&Open";
            this.btnDelStOpen.UseVisualStyleBackColor = true;
            this.btnDelStOpen.Click += new System.EventHandler(this.btnDelStOpen_Click);
            // 
            // txtDelStVer
            // 
            this.txtDelStVer.Location = new System.Drawing.Point(85, 68);
            this.txtDelStVer.Name = "txtDelStVer";
            this.txtDelStVer.ReadOnly = true;
            this.txtDelStVer.Size = new System.Drawing.Size(385, 20);
            this.txtDelStVer.TabIndex = 21;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 71);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(45, 13);
            this.label8.TabIndex = 20;
            this.label8.Text = "Version:";
            // 
            // btnDelStCancel
            // 
            this.btnDelStCancel.Location = new System.Drawing.Point(468, 3);
            this.btnDelStCancel.Name = "btnDelStCancel";
            this.btnDelStCancel.Size = new System.Drawing.Size(94, 30);
            this.btnDelStCancel.TabIndex = 44;
            this.btnDelStCancel.Text = "&Cancel";
            this.btnDelStCancel.UseVisualStyleBackColor = true;
            this.btnDelStCancel.Visible = false;
            this.btnDelStCancel.Click += new System.EventHandler(this.btnDelStCancel_Click);
            // 
            // txtDelStOut
            // 
            this.txtDelStOut.Location = new System.Drawing.Point(15, 39);
            this.txtDelStOut.Multiline = true;
            this.txtDelStOut.Name = "txtDelStOut";
            this.txtDelStOut.ReadOnly = true;
            this.txtDelStOut.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtDelStOut.Size = new System.Drawing.Size(547, 327);
            this.txtDelStOut.TabIndex = 43;
            // 
            // btnDelStProcess
            // 
            this.btnDelStProcess.Enabled = false;
            this.btnDelStProcess.Location = new System.Drawing.Point(468, 4);
            this.btnDelStProcess.Name = "btnDelStProcess";
            this.btnDelStProcess.Size = new System.Drawing.Size(94, 29);
            this.btnDelStProcess.TabIndex = 42;
            this.btnDelStProcess.Text = "&Start Process";
            this.btnDelStProcess.UseVisualStyleBackColor = true;
            this.btnDelStProcess.Click += new System.EventHandler(this.btnDelStProcess_Click);
            // 
            // tbPgModuleDel
            // 
            this.tbPgModuleDel.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tbPgModuleDel.Controls.Add(this.splitContainer1);
            this.tbPgModuleDel.Location = new System.Drawing.Point(4, 40);
            this.tbPgModuleDel.Name = "tbPgModuleDel";
            this.tbPgModuleDel.Padding = new System.Windows.Forms.Padding(3);
            this.tbPgModuleDel.Size = new System.Drawing.Size(580, 488);
            this.tbPgModuleDel.TabIndex = 1;
            this.tbPgModuleDel.Text = "Delete Module";
            // 
            // splitContainer1
            // 
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer1.Location = new System.Drawing.Point(3, 6);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.txtDelModServer);
            this.splitContainer1.Panel1.Controls.Add(this.label2);
            this.splitContainer1.Panel1.Controls.Add(this.btnDelModConfig);
            this.splitContainer1.Panel1.Controls.Add(this.txtDelModDB);
            this.splitContainer1.Panel1.Controls.Add(this.label6);
            this.splitContainer1.Panel1.Controls.Add(this.lblDelModuleMsg);
            this.splitContainer1.Panel1.Controls.Add(this.btnDelModOpen);
            this.splitContainer1.Panel1.Controls.Add(this.txtDelModVer);
            this.splitContainer1.Panel1.Controls.Add(this.label3);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.btnDelModCancel);
            this.splitContainer1.Panel2.Controls.Add(this.btnDelModRemAll);
            this.splitContainer1.Panel2.Controls.Add(this.btnDelModAddAll);
            this.splitContainer1.Panel2.Controls.Add(this.lstDelModSel);
            this.splitContainer1.Panel2.Controls.Add(this.lstDelModAvail);
            this.splitContainer1.Panel2.Controls.Add(this.btnDelModProcess);
            this.splitContainer1.Panel2.Controls.Add(this.btnDelModAdd);
            this.splitContainer1.Panel2.Controls.Add(this.btnDelModRemove);
            this.splitContainer1.Panel2.Controls.Add(this.txtDelModOut);
            this.splitContainer1.Panel2.Controls.Add(this.label5);
            this.splitContainer1.Panel2.Controls.Add(this.label4);
            this.splitContainer1.Size = new System.Drawing.Size(577, 486);
            this.splitContainer1.SplitterDistance = 101;
            this.splitContainer1.TabIndex = 6;
            // 
            // txtDelModServer
            // 
            this.txtDelModServer.BackColor = System.Drawing.Color.White;
            this.txtDelModServer.Location = new System.Drawing.Point(86, 26);
            this.txtDelModServer.Name = "txtDelModServer";
            this.txtDelModServer.ReadOnly = true;
            this.txtDelModServer.Size = new System.Drawing.Size(187, 20);
            this.txtDelModServer.TabIndex = 68;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(280, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 67;
            this.label2.Text = "DB Name:";
            // 
            // btnDelModConfig
            // 
            this.btnDelModConfig.Location = new System.Drawing.Point(487, 24);
            this.btnDelModConfig.Name = "btnDelModConfig";
            this.btnDelModConfig.Size = new System.Drawing.Size(75, 23);
            this.btnDelModConfig.TabIndex = 66;
            this.btnDelModConfig.Text = "&Config.";
            this.btnDelModConfig.UseVisualStyleBackColor = true;
            this.btnDelModConfig.Click += new System.EventHandler(this.btnDelModConfig_Click);
            // 
            // txtDelModDB
            // 
            this.txtDelModDB.BackColor = System.Drawing.Color.White;
            this.txtDelModDB.Location = new System.Drawing.Point(343, 27);
            this.txtDelModDB.Name = "txtDelModDB";
            this.txtDelModDB.ReadOnly = true;
            this.txtDelModDB.Size = new System.Drawing.Size(128, 20);
            this.txtDelModDB.TabIndex = 65;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 29);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 13);
            this.label6.TabIndex = 64;
            this.label6.Text = "Server Name:";
            // 
            // lblDelModuleMsg
            // 
            this.lblDelModuleMsg.AutoSize = true;
            this.lblDelModuleMsg.ForeColor = System.Drawing.Color.Red;
            this.lblDelModuleMsg.Location = new System.Drawing.Point(57, 7);
            this.lblDelModuleMsg.Name = "lblDelModuleMsg";
            this.lblDelModuleMsg.Size = new System.Drawing.Size(0, 13);
            this.lblDelModuleMsg.TabIndex = 12;
            // 
            // btnDelModOpen
            // 
            this.btnDelModOpen.Location = new System.Drawing.Point(487, 58);
            this.btnDelModOpen.Name = "btnDelModOpen";
            this.btnDelModOpen.Size = new System.Drawing.Size(75, 23);
            this.btnDelModOpen.TabIndex = 10;
            this.btnDelModOpen.Text = "&Open";
            this.btnDelModOpen.UseVisualStyleBackColor = true;
            this.btnDelModOpen.Click += new System.EventHandler(this.btnDelModOpen_Click);
            // 
            // txtDelModVer
            // 
            this.txtDelModVer.Location = new System.Drawing.Point(85, 61);
            this.txtDelModVer.Name = "txtDelModVer";
            this.txtDelModVer.ReadOnly = true;
            this.txtDelModVer.Size = new System.Drawing.Size(386, 20);
            this.txtDelModVer.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Version:";
            // 
            // btnDelModCancel
            // 
            this.btnDelModCancel.Location = new System.Drawing.Point(248, 23);
            this.btnDelModCancel.Name = "btnDelModCancel";
            this.btnDelModCancel.Size = new System.Drawing.Size(80, 30);
            this.btnDelModCancel.TabIndex = 40;
            this.btnDelModCancel.Text = "&Cancel";
            this.btnDelModCancel.UseVisualStyleBackColor = true;
            this.btnDelModCancel.Visible = false;
            this.btnDelModCancel.Click += new System.EventHandler(this.btnDelModCancel_Click);
            // 
            // btnDelModRemAll
            // 
            this.btnDelModRemAll.Location = new System.Drawing.Point(248, 192);
            this.btnDelModRemAll.Name = "btnDelModRemAll";
            this.btnDelModRemAll.Size = new System.Drawing.Size(80, 30);
            this.btnDelModRemAll.TabIndex = 39;
            this.btnDelModRemAll.Text = "<-R&emove All";
            this.btnDelModRemAll.UseVisualStyleBackColor = true;
            this.btnDelModRemAll.Click += new System.EventHandler(this.btnDelModRemAll_Click);
            // 
            // btnDelModAddAll
            // 
            this.btnDelModAddAll.Location = new System.Drawing.Point(248, 156);
            this.btnDelModAddAll.Name = "btnDelModAddAll";
            this.btnDelModAddAll.Size = new System.Drawing.Size(80, 30);
            this.btnDelModAddAll.TabIndex = 38;
            this.btnDelModAddAll.Text = "A&dd All ->";
            this.btnDelModAddAll.UseVisualStyleBackColor = true;
            this.btnDelModAddAll.Click += new System.EventHandler(this.btnDelModAddAll_Click);
            // 
            // lstDelModSel
            // 
            this.lstDelModSel.FormattingEnabled = true;
            this.lstDelModSel.Location = new System.Drawing.Point(334, 51);
            this.lstDelModSel.Name = "lstDelModSel";
            this.lstDelModSel.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstDelModSel.Size = new System.Drawing.Size(228, 173);
            this.lstDelModSel.TabIndex = 29;
            this.lstDelModSel.SelectedIndexChanged += new System.EventHandler(this.lstDelModSel_SelectedIndexChanged);
            this.lstDelModSel.DoubleClick += new System.EventHandler(this.lstDelModSel_DoubleClick);
            // 
            // lstDelModAvail
            // 
            this.lstDelModAvail.FormattingEnabled = true;
            this.lstDelModAvail.Location = new System.Drawing.Point(15, 51);
            this.lstDelModAvail.Name = "lstDelModAvail";
            this.lstDelModAvail.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstDelModAvail.Size = new System.Drawing.Size(228, 173);
            this.lstDelModAvail.TabIndex = 28;
            this.lstDelModAvail.SelectedIndexChanged += new System.EventHandler(this.lstDelModAvail_SelectedIndexChanged);
            this.lstDelModAvail.DoubleClick += new System.EventHandler(this.lstDelModAvail_DoubleClick);
            // 
            // btnDelModProcess
            // 
            this.btnDelModProcess.Location = new System.Drawing.Point(248, 23);
            this.btnDelModProcess.Name = "btnDelModProcess";
            this.btnDelModProcess.Size = new System.Drawing.Size(80, 30);
            this.btnDelModProcess.TabIndex = 14;
            this.btnDelModProcess.Text = "&Start Process";
            this.btnDelModProcess.UseVisualStyleBackColor = true;
            this.btnDelModProcess.Click += new System.EventHandler(this.btnDelModPro_Click);
            // 
            // btnDelModAdd
            // 
            this.btnDelModAdd.Enabled = false;
            this.btnDelModAdd.Location = new System.Drawing.Point(248, 84);
            this.btnDelModAdd.Name = "btnDelModAdd";
            this.btnDelModAdd.Size = new System.Drawing.Size(80, 30);
            this.btnDelModAdd.TabIndex = 13;
            this.btnDelModAdd.Text = "&Add ->";
            this.btnDelModAdd.UseVisualStyleBackColor = true;
            this.btnDelModAdd.Click += new System.EventHandler(this.btnDelModAdd_Click);
            // 
            // btnDelModRemove
            // 
            this.btnDelModRemove.Enabled = false;
            this.btnDelModRemove.Location = new System.Drawing.Point(248, 120);
            this.btnDelModRemove.Name = "btnDelModRemove";
            this.btnDelModRemove.Size = new System.Drawing.Size(80, 30);
            this.btnDelModRemove.TabIndex = 12;
            this.btnDelModRemove.Text = "<- &Remove";
            this.btnDelModRemove.UseVisualStyleBackColor = true;
            this.btnDelModRemove.Click += new System.EventHandler(this.btnDelModRemove_Click);
            // 
            // txtDelModOut
            // 
            this.txtDelModOut.Location = new System.Drawing.Point(15, 238);
            this.txtDelModOut.Multiline = true;
            this.txtDelModOut.Name = "txtDelModOut";
            this.txtDelModOut.ReadOnly = true;
            this.txtDelModOut.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtDelModOut.Size = new System.Drawing.Size(547, 132);
            this.txtDelModOut.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(371, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(96, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Modules to Delete:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Available Modules:";
            // 
            // tbPgBuildMODULE
            // 
            this.tbPgBuildMODULE.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tbPgBuildMODULE.Controls.Add(this.splitContainer4);
            this.tbPgBuildMODULE.Location = new System.Drawing.Point(4, 40);
            this.tbPgBuildMODULE.Name = "tbPgBuildMODULE";
            this.tbPgBuildMODULE.Padding = new System.Windows.Forms.Padding(3);
            this.tbPgBuildMODULE.Size = new System.Drawing.Size(580, 488);
            this.tbPgBuildMODULE.TabIndex = 6;
            this.tbPgBuildMODULE.Text = "Build MODULE.DB";
            // 
            // splitContainer4
            // 
            this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer4.Location = new System.Drawing.Point(3, 3);
            this.splitContainer4.Name = "splitContainer4";
            this.splitContainer4.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.btnModuleOpen);
            this.splitContainer4.Panel1.Controls.Add(this.txtModuleVer);
            this.splitContainer4.Panel1.Controls.Add(this.label16);
            this.splitContainer4.Panel1.Controls.Add(this.txtModuleServer);
            this.splitContainer4.Panel1.Controls.Add(this.label64);
            this.splitContainer4.Panel1.Controls.Add(this.btnModuleDBConfig);
            this.splitContainer4.Panel1.Controls.Add(this.txtModuleDB);
            this.splitContainer4.Panel1.Controls.Add(this.label65);
            this.splitContainer4.Panel1.Controls.Add(this.cmdFixAirREM);
            this.splitContainer4.Panel1.Controls.Add(this.btnModuleRemoveAll);
            this.splitContainer4.Panel1.Controls.Add(this.btnModuleAddAll);
            this.splitContainer4.Panel1.Controls.Add(this.btnModuleStart);
            this.splitContainer4.Panel1.Controls.Add(this.btnModuleCancel);
            this.splitContainer4.Panel1.Controls.Add(this.lblModuleMsg);
            this.splitContainer4.Panel1.Controls.Add(this.lstModuleSel);
            this.splitContainer4.Panel1.Controls.Add(this.lstModuleAval);
            this.splitContainer4.Panel1.Controls.Add(this.btnModuleAdd);
            this.splitContainer4.Panel1.Controls.Add(this.btnModuleRemove);
            this.splitContainer4.Panel1.Controls.Add(this.label12);
            this.splitContainer4.Panel1.Controls.Add(this.label13);
            this.splitContainer4.Panel1.Controls.Add(this.btnModuleBrowse);
            this.splitContainer4.Panel1.Controls.Add(this.txtModuleDir);
            this.splitContainer4.Panel1.Controls.Add(this.label11);
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.txtModuleOut);
            this.splitContainer4.Size = new System.Drawing.Size(574, 482);
            this.splitContainer4.SplitterDistance = 327;
            this.splitContainer4.TabIndex = 0;
            // 
            // btnModuleOpen
            // 
            this.btnModuleOpen.Location = new System.Drawing.Point(484, 89);
            this.btnModuleOpen.Name = "btnModuleOpen";
            this.btnModuleOpen.Size = new System.Drawing.Size(75, 23);
            this.btnModuleOpen.TabIndex = 55;
            this.btnModuleOpen.Text = "&Open";
            this.btnModuleOpen.UseVisualStyleBackColor = true;
            this.btnModuleOpen.Click += new System.EventHandler(this.btnModuleOpen_Click);
            // 
            // txtModuleVer
            // 
            this.txtModuleVer.Location = new System.Drawing.Point(91, 92);
            this.txtModuleVer.Name = "txtModuleVer";
            this.txtModuleVer.ReadOnly = true;
            this.txtModuleVer.Size = new System.Drawing.Size(373, 20);
            this.txtModuleVer.TabIndex = 54;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(13, 96);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(45, 13);
            this.label16.TabIndex = 53;
            this.label16.Text = "Version:";
            // 
            // txtModuleServer
            // 
            this.txtModuleServer.BackColor = System.Drawing.Color.White;
            this.txtModuleServer.Location = new System.Drawing.Point(91, 64);
            this.txtModuleServer.Name = "txtModuleServer";
            this.txtModuleServer.ReadOnly = true;
            this.txtModuleServer.Size = new System.Drawing.Size(173, 20);
            this.txtModuleServer.TabIndex = 52;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(274, 67);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(56, 13);
            this.label64.TabIndex = 51;
            this.label64.Text = "DB Name:";
            // 
            // btnModuleDBConfig
            // 
            this.btnModuleDBConfig.Location = new System.Drawing.Point(484, 62);
            this.btnModuleDBConfig.Name = "btnModuleDBConfig";
            this.btnModuleDBConfig.Size = new System.Drawing.Size(75, 23);
            this.btnModuleDBConfig.TabIndex = 50;
            this.btnModuleDBConfig.Text = "&Config.";
            this.btnModuleDBConfig.UseVisualStyleBackColor = true;
            this.btnModuleDBConfig.Click += new System.EventHandler(this.btnModuleDBConfig_Click);
            // 
            // txtModuleDB
            // 
            this.txtModuleDB.BackColor = System.Drawing.Color.White;
            this.txtModuleDB.Location = new System.Drawing.Point(336, 64);
            this.txtModuleDB.Name = "txtModuleDB";
            this.txtModuleDB.ReadOnly = true;
            this.txtModuleDB.Size = new System.Drawing.Size(128, 20);
            this.txtModuleDB.TabIndex = 49;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(13, 67);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(72, 13);
            this.label65.TabIndex = 48;
            this.label65.Text = "Server Name:";
            // 
            // cmdFixAirREM
            // 
            this.cmdFixAirREM.Enabled = false;
            this.cmdFixAirREM.Location = new System.Drawing.Point(471, 115);
            this.cmdFixAirREM.Name = "cmdFixAirREM";
            this.cmdFixAirREM.Size = new System.Drawing.Size(88, 23);
            this.cmdFixAirREM.TabIndex = 38;
            this.cmdFixAirREM.Text = "&Fix A/W REMs";
            this.cmdFixAirREM.UseVisualStyleBackColor = true;
            this.cmdFixAirREM.Click += new System.EventHandler(this.cmdFixAirREM_Click);
            // 
            // btnModuleRemoveAll
            // 
            this.btnModuleRemoveAll.Location = new System.Drawing.Point(247, 232);
            this.btnModuleRemoveAll.Name = "btnModuleRemoveAll";
            this.btnModuleRemoveAll.Size = new System.Drawing.Size(80, 30);
            this.btnModuleRemoveAll.TabIndex = 37;
            this.btnModuleRemoveAll.Text = "<-R&emove All";
            this.btnModuleRemoveAll.UseVisualStyleBackColor = true;
            this.btnModuleRemoveAll.Click += new System.EventHandler(this.btnModuleRemoveAll_Click);
            // 
            // btnModuleAddAll
            // 
            this.btnModuleAddAll.Location = new System.Drawing.Point(248, 267);
            this.btnModuleAddAll.Name = "btnModuleAddAll";
            this.btnModuleAddAll.Size = new System.Drawing.Size(80, 30);
            this.btnModuleAddAll.TabIndex = 36;
            this.btnModuleAddAll.Text = "A&dd All ->";
            this.btnModuleAddAll.UseVisualStyleBackColor = true;
            this.btnModuleAddAll.Click += new System.EventHandler(this.btnModuleAddAll_Click);
            // 
            // btnModuleStart
            // 
            this.btnModuleStart.Location = new System.Drawing.Point(484, 27);
            this.btnModuleStart.Name = "btnModuleStart";
            this.btnModuleStart.Size = new System.Drawing.Size(75, 23);
            this.btnModuleStart.TabIndex = 34;
            this.btnModuleStart.Text = "&Start Process";
            this.btnModuleStart.UseVisualStyleBackColor = true;
            this.btnModuleStart.Click += new System.EventHandler(this.btnModuleStart_Click);
            // 
            // btnModuleCancel
            // 
            this.btnModuleCancel.Location = new System.Drawing.Point(484, 27);
            this.btnModuleCancel.Name = "btnModuleCancel";
            this.btnModuleCancel.Size = new System.Drawing.Size(75, 23);
            this.btnModuleCancel.TabIndex = 33;
            this.btnModuleCancel.Text = "&Cancel";
            this.btnModuleCancel.UseVisualStyleBackColor = true;
            this.btnModuleCancel.Visible = false;
            this.btnModuleCancel.Click += new System.EventHandler(this.btnModuleCancel_Click);
            // 
            // lblModuleMsg
            // 
            this.lblModuleMsg.AutoSize = true;
            this.lblModuleMsg.ForeColor = System.Drawing.Color.Red;
            this.lblModuleMsg.Location = new System.Drawing.Point(141, 11);
            this.lblModuleMsg.Name = "lblModuleMsg";
            this.lblModuleMsg.Size = new System.Drawing.Size(0, 13);
            this.lblModuleMsg.TabIndex = 29;
            // 
            // lstModuleSel
            // 
            this.lstModuleSel.FormattingEnabled = true;
            this.lstModuleSel.Location = new System.Drawing.Point(335, 145);
            this.lstModuleSel.Name = "lstModuleSel";
            this.lstModuleSel.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstModuleSel.Size = new System.Drawing.Size(224, 173);
            this.lstModuleSel.TabIndex = 28;
            this.lstModuleSel.SelectedIndexChanged += new System.EventHandler(this.lstModuleSel_SelectedIndexChanged);
            this.lstModuleSel.DoubleClick += new System.EventHandler(this.lstModuleSel_DoubleClick);
            // 
            // lstModuleAval
            // 
            this.lstModuleAval.FormattingEnabled = true;
            this.lstModuleAval.Location = new System.Drawing.Point(16, 145);
            this.lstModuleAval.Name = "lstModuleAval";
            this.lstModuleAval.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstModuleAval.Size = new System.Drawing.Size(224, 173);
            this.lstModuleAval.TabIndex = 27;
            this.lstModuleAval.SelectedIndexChanged += new System.EventHandler(this.lstModuleAval_SelectedIndexChanged);
            this.lstModuleAval.DoubleClick += new System.EventHandler(this.lstModuleAval_DoubleClick);
            // 
            // btnModuleAdd
            // 
            this.btnModuleAdd.Enabled = false;
            this.btnModuleAdd.Location = new System.Drawing.Point(248, 160);
            this.btnModuleAdd.Name = "btnModuleAdd";
            this.btnModuleAdd.Size = new System.Drawing.Size(80, 30);
            this.btnModuleAdd.TabIndex = 26;
            this.btnModuleAdd.Text = "&Add ->";
            this.btnModuleAdd.UseVisualStyleBackColor = true;
            this.btnModuleAdd.Click += new System.EventHandler(this.btnModuleAdd_Click);
            // 
            // btnModuleRemove
            // 
            this.btnModuleRemove.Enabled = false;
            this.btnModuleRemove.Location = new System.Drawing.Point(248, 196);
            this.btnModuleRemove.Name = "btnModuleRemove";
            this.btnModuleRemove.Size = new System.Drawing.Size(80, 30);
            this.btnModuleRemove.TabIndex = 25;
            this.btnModuleRemove.Text = "<- &Remove";
            this.btnModuleRemove.UseVisualStyleBackColor = true;
            this.btnModuleRemove.Click += new System.EventHandler(this.btnModuleRemove_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(356, 125);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(88, 13);
            this.label12.TabIndex = 19;
            this.label12.Text = "Modules to Build:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(13, 125);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(96, 13);
            this.label13.TabIndex = 18;
            this.label13.Text = "Available Modules:";
            // 
            // btnModuleBrowse
            // 
            this.btnModuleBrowse.Location = new System.Drawing.Point(393, 28);
            this.btnModuleBrowse.Name = "btnModuleBrowse";
            this.btnModuleBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnModuleBrowse.TabIndex = 17;
            this.btnModuleBrowse.Text = "&Browse";
            this.btnModuleBrowse.UseVisualStyleBackColor = true;
            this.btnModuleBrowse.Click += new System.EventHandler(this.btnModuleBrowse_Click);
            // 
            // txtModuleDir
            // 
            this.txtModuleDir.Location = new System.Drawing.Point(16, 31);
            this.txtModuleDir.Name = "txtModuleDir";
            this.txtModuleDir.Size = new System.Drawing.Size(363, 20);
            this.txtModuleDir.TabIndex = 13;
            this.txtModuleDir.TextChanged += new System.EventHandler(this.txtModuleDir_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(13, 10);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(116, 13);
            this.label11.TabIndex = 12;
            this.label11.Text = "Module Root Directory:";
            // 
            // txtModuleOut
            // 
            this.txtModuleOut.Location = new System.Drawing.Point(16, 5);
            this.txtModuleOut.Multiline = true;
            this.txtModuleOut.Name = "txtModuleOut";
            this.txtModuleOut.ReadOnly = true;
            this.txtModuleOut.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtModuleOut.Size = new System.Drawing.Size(547, 139);
            this.txtModuleOut.TabIndex = 12;
            // 
            // tbPgBuildREM
            // 
            this.tbPgBuildREM.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tbPgBuildREM.Controls.Add(this.btnBuildREMCancel);
            this.tbPgBuildREM.Controls.Add(this.lblMsg);
            this.tbPgBuildREM.Controls.Add(this.btnBuildREMSel);
            this.tbPgBuildREM.Controls.Add(this.btnBuildREMProcess);
            this.tbPgBuildREM.Controls.Add(this.txtBuildREMOutput);
            this.tbPgBuildREM.Controls.Add(this.txtBuildREMDir);
            this.tbPgBuildREM.Controls.Add(this.btnBuildREMBrowse);
            this.tbPgBuildREM.Controls.Add(this.label1);
            this.tbPgBuildREM.Controls.Add(this.chkBuildREMCalculate);
            this.tbPgBuildREM.Location = new System.Drawing.Point(4, 40);
            this.tbPgBuildREM.Name = "tbPgBuildREM";
            this.tbPgBuildREM.Padding = new System.Windows.Forms.Padding(3);
            this.tbPgBuildREM.Size = new System.Drawing.Size(580, 488);
            this.tbPgBuildREM.TabIndex = 0;
            this.tbPgBuildREM.Text = "Build REM Files";
            // 
            // btnBuildREMCancel
            // 
            this.btnBuildREMCancel.Location = new System.Drawing.Point(479, 58);
            this.btnBuildREMCancel.Name = "btnBuildREMCancel";
            this.btnBuildREMCancel.Size = new System.Drawing.Size(85, 23);
            this.btnBuildREMCancel.TabIndex = 8;
            this.btnBuildREMCancel.Text = "&Cancel";
            this.btnBuildREMCancel.UseVisualStyleBackColor = true;
            this.btnBuildREMCancel.Visible = false;
            this.btnBuildREMCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // lblMsg
            // 
            this.lblMsg.AutoSize = true;
            this.lblMsg.ForeColor = System.Drawing.Color.Red;
            this.lblMsg.Location = new System.Drawing.Point(144, 10);
            this.lblMsg.Name = "lblMsg";
            this.lblMsg.Size = new System.Drawing.Size(0, 13);
            this.lblMsg.TabIndex = 7;
            // 
            // btnBuildREMSel
            // 
            this.btnBuildREMSel.Location = new System.Drawing.Point(351, 58);
            this.btnBuildREMSel.Name = "btnBuildREMSel";
            this.btnBuildREMSel.Size = new System.Drawing.Size(98, 23);
            this.btnBuildREMSel.TabIndex = 6;
            this.btnBuildREMSel.Text = "Select &Directories";
            this.btnBuildREMSel.UseVisualStyleBackColor = true;
            this.btnBuildREMSel.Click += new System.EventHandler(this.btnSel_Click);
            // 
            // btnBuildREMProcess
            // 
            this.btnBuildREMProcess.Location = new System.Drawing.Point(479, 58);
            this.btnBuildREMProcess.Name = "btnBuildREMProcess";
            this.btnBuildREMProcess.Size = new System.Drawing.Size(85, 23);
            this.btnBuildREMProcess.TabIndex = 5;
            this.btnBuildREMProcess.Text = "&Start Process";
            this.btnBuildREMProcess.UseVisualStyleBackColor = true;
            this.btnBuildREMProcess.Click += new System.EventHandler(this.btnProcess_Click);
            // 
            // txtBuildREMOutput
            // 
            this.txtBuildREMOutput.Location = new System.Drawing.Point(19, 103);
            this.txtBuildREMOutput.Multiline = true;
            this.txtBuildREMOutput.Name = "txtBuildREMOutput";
            this.txtBuildREMOutput.ReadOnly = true;
            this.txtBuildREMOutput.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtBuildREMOutput.Size = new System.Drawing.Size(545, 378);
            this.txtBuildREMOutput.TabIndex = 4;
            // 
            // txtBuildREMDir
            // 
            this.txtBuildREMDir.Location = new System.Drawing.Point(15, 27);
            this.txtBuildREMDir.Name = "txtBuildREMDir";
            this.txtBuildREMDir.Size = new System.Drawing.Size(430, 20);
            this.txtBuildREMDir.TabIndex = 2;
            this.txtBuildREMDir.TextChanged += new System.EventHandler(this.txtDir_TextChanged);
            // 
            // btnBuildREMBrowse
            // 
            this.btnBuildREMBrowse.Location = new System.Drawing.Point(479, 27);
            this.btnBuildREMBrowse.Name = "btnBuildREMBrowse";
            this.btnBuildREMBrowse.Size = new System.Drawing.Size(85, 23);
            this.btnBuildREMBrowse.TabIndex = 3;
            this.btnBuildREMBrowse.Text = "&Browse";
            this.btnBuildREMBrowse.UseVisualStyleBackColor = true;
            this.btnBuildREMBrowse.Click += new System.EventHandler(this.brnBrowse_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Source Text Directory";
            // 
            // chkBuildREMCalculate
            // 
            this.chkBuildREMCalculate.AutoSize = true;
            this.chkBuildREMCalculate.Location = new System.Drawing.Point(19, 58);
            this.chkBuildREMCalculate.Name = "chkBuildREMCalculate";
            this.chkBuildREMCalculate.Size = new System.Drawing.Size(201, 17);
            this.chkBuildREMCalculate.TabIndex = 0;
            this.chkBuildREMCalculate.Text = "Calculate Domain/Question Changes";
            this.chkBuildREMCalculate.UseVisualStyleBackColor = true;
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tbPgBuildREM);
            this.tabControl.Controls.Add(this.tbPgBuildMODULE);
            this.tabControl.Controls.Add(this.tbPgModuleDel);
            this.tabControl.Controls.Add(this.tbPgDelState);
            this.tabControl.Controls.Add(this.tbPgMergSt);
            this.tabControl.Controls.Add(this.tbPgMergFederal);
            this.tabControl.Controls.Add(this.tbPgBlobsCreat);
            this.tabControl.Controls.Add(this.tbPgAutoProcess);
            this.tabControl.Controls.Add(this.tbPgConfig);
            this.tabControl.Controls.Add(this.tbPgVewDB);
            this.tabControl.Controls.Add(this.tbPgIPhoneDB);
            this.tabControl.Controls.Add(this.tbPgImEx);
            this.tabControl.Controls.Add(this.tbPgDakref);
            this.tabControl.Controls.Add(this.tbPgAbout);
            this.tabControl.Location = new System.Drawing.Point(8, 12);
            this.tabControl.Multiline = true;
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(588, 532);
            this.tabControl.TabIndex = 0;
            this.tabControl.SelectedIndexChanged += new System.EventHandler(this.tabControl_SelectedIndexChanged);
            this.tabControl.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControl_Selecting);
            this.tabControl.Deselecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControl_Deselecting);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 543);
            this.Controls.Add(this.tabControl);
            this.Controls.Add(this.pbrProgress);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.Text = "Regulatory Tools (Version for SQL Server)";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmMain_FormClosed);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.Resize += new System.EventHandler(this.frmMain_Resize);
            this.splitContainer9.Panel1.ResumeLayout(false);
            this.splitContainer9.Panel1.PerformLayout();
            this.splitContainer9.ResumeLayout(false);
            this.tbPgAbout.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.tbPgDakref.ResumeLayout(false);
            this.tbPgDakref.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.tbPgImEx.ResumeLayout(false);
            this.tbPgImEx.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tbPgIPhoneDB.ResumeLayout(false);
            this.tbPgIPhoneDB.PerformLayout();
            this.tbPgVewDB.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tbPgConfig.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tbPgAutoProcess.ResumeLayout(false);
            this.tbPgAutoProcess.PerformLayout();
            this.tbPgBlobsCreat.ResumeLayout(false);
            this.splitContainer6.Panel1.ResumeLayout(false);
            this.splitContainer6.Panel1.PerformLayout();
            this.splitContainer6.Panel2.ResumeLayout(false);
            this.splitContainer6.Panel2.PerformLayout();
            this.splitContainer6.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tbPgMergFederal.ResumeLayout(false);
            this.splitContainer7.Panel1.ResumeLayout(false);
            this.splitContainer7.Panel2.ResumeLayout(false);
            this.splitContainer7.Panel2.PerformLayout();
            this.splitContainer7.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tbPgMergSt.ResumeLayout(false);
            this.splitContainer8.Panel1.ResumeLayout(false);
            this.splitContainer8.Panel1.PerformLayout();
            this.splitContainer8.Panel2.ResumeLayout(false);
            this.splitContainer8.Panel2.PerformLayout();
            this.splitContainer8.ResumeLayout(false);
            this.tbPgDelState.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel1.PerformLayout();
            this.splitContainer3.Panel2.ResumeLayout(false);
            this.splitContainer3.Panel2.PerformLayout();
            this.splitContainer3.ResumeLayout(false);
            this.tbPgModuleDel.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            this.splitContainer1.ResumeLayout(false);
            this.tbPgBuildMODULE.ResumeLayout(false);
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel1.PerformLayout();
            this.splitContainer4.Panel2.ResumeLayout(false);
            this.splitContainer4.Panel2.PerformLayout();
            this.splitContainer4.ResumeLayout(false);
            this.tbPgBuildREM.ResumeLayout(false);
            this.tbPgBuildREM.PerformLayout();
            this.tabControl.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        //internal TextBox textBox1;
        //private Button button4;
        //private Button button3;
        private SplitContainer splitContainer9;
        private Label label35;
        //private Button button8;
        //private Button button9;
        //private TextBox textBox9;
        private Label label36;
        //internal TextBox textBox10;
        private Label label37;
        //private Button button10;
        //private Button button11;
        //private Button button12;
        //private GroupBox groupBox3;
        //internal RadioButton radioButton1;
        //internal RadioButton radioButton2;
        private ProgressBar pbrProgress;
        private SaveFileDialog saveFileDialog1;
        private TabPage tbPgAbout;
        private GroupBox groupBox11;
        private Label lblPgAboutDate;
        private Label lblPgAboutVer;
        private Label label90;
        private TabPage tbPgDakref;
        private TextBox txtDakrefOut;
        private GroupBox groupBox9;
        private Label label101;
        private CheckBox chkDakrefVerTest;
        private Button btnDakrefWhatNewBrowse;
        private TextBox txtDakrefWhatNew;
        private Label label88;
        private Button btnDakrefReleaseInfo;
        private Button btnDakrefModuleOrderBrowse;
        private TextBox txtDakrefModuleOrder;
        private Label label87;
        private Button btnDakrefMigrationBrowse;
        private TextBox txtDakrefMigration;
        private Label label86;
        private Button btnDakrefRestore;
        private Button btnDakrefRestoreBrowse;
        private TextBox txtDakrefBack;
        private Label label85;
        private Label label84;
        internal TextBox txtDakrefNewVer;
        private Button btnDakrefCancel;
        private Button btnDakrefProcess;
        internal TextBox txtDakrefTagServer;
        private Label label51;
        private Label label63;
        private Button btnDakrefTagConfig;
        internal TextBox txtDakrefTagDB;
        private Label label67;
        internal TextBox txtDakrefSrcServer;
        private Label label76;
        private Button btnDakrefSrcConfig;
        internal TextBox txtDakrefSrcDB;
        private Label label77;
        private Label label78;
        private TextBox txtDakrefSrcVer;
        private Label label79;
        private Button btnDakrefTagOpen;
        private TextBox txtDakrefTagVer;
        private Label label80;
        private Label label81;
        private Button btnDakrefSrcOpen;
        private Label label82;
        private Label label83;
        private Button btnDakrefUnicode;
        private TabPage tbPgImEx;
        private GroupBox groupBox10;
        internal Label lblExMsg;
        internal TextBox txtExServer;
        private Button btnExOpen;
        private Button btnExConfig;
        private Button btnExport;
        private Button btnExCancel;
        private TextBox txtExVersion;
        internal TextBox txtExDataPath;
        private Button btnExBrowse;
        private Label label15;
        internal TextBox txtExDB;
        private Label label47;
        private Label label48;
        private Label label61;
        private TextBox txtImExOut;
        private GroupBox groupBox2;
        internal Label lblImMsg;
        private Label label25;
        private Label label74;
        private Label label75;
        internal TextBox txtImServer;
        internal TextBox txtImDataPath;
        private Button btnImCancel;
        private Label label45;
        private Button btnImConfig;
        private TextBox txtImVersion;
        private Button btnImOpen;
        internal TextBox txtImNewDB;
        internal CheckBox chkImCreateNewDB;
        internal TextBox txtImDB;
        private Button btnImport;
        private Button btnImDataDirBrowse;
        private Label label46;
        private TabPage tbPgIPhoneDB;
        private Label label89;
        internal TextBox txtIPhoneServer;
        internal TextBox txtIPhoneDB;
        private TextBox txtIPhoneOut;
        private TextBox txtSQLitePath;
        private TextBox txtIPhoneREMDir;
        private Label label43;
        private Label label58;
        private Button btnIPhoneConfig;
        private Label lblIPhoneProcessMsg;
        private Button btnIPhoneDefSel;
        private Button btnIPhoneUnSel;
        private Button btnIPhoneDeSel;
        private Button btnIPhoneSelAll;
        private CheckedListBox chkLstBox;
        private Button btnIPhoneBrowseSQLitePath;
        private Label label59;
        private Button btnIPhoneCancel;
        private Label lblIPhoneMsg;
        private Button btnIPhoneProcess;
        private Button btnIPhoneBrowseTextPath;
        private Label label57;
        private TabPage tbPgVewDB;
        private GroupBox groupBox7;
        private TextBox txtVewDBResult;
        private Label label55;
        private ComboBox cboVewDBQuery;
        private GroupBox groupBox6;
        private TextBox txtVewDBSTVerSN;
        private TextBox txtVewDBVerSN;
        private Label label54;
        private Label label53;
        private Label label52;
        internal ListBox lstVewDBModule;
        private GroupBox groupBox5;
        internal TextBox txtVewDBServer;
        private Label label60;
        private Button btnViewDBConfig;
        internal TextBox txtVewDBDB;
        private Label label62;
        private Label lblVewDBMsg;
        private Button btnVewDBOpen;
        private TextBox txtVewDBVer;
        private Label label50;
        private TabPage tbPgConfig;
        private GroupBox groupBox13;
        private Button btnConfigRestore;
        private Button button1;
        private Button btnConfigResBrowse;
        private TextBox txtConfigResPath;
        private Label label99;
        private Label label95;
        private Button btnConfigResConfig;
        private TextBox txtConfigResVer;
        private Label label97;
        private Label label98;
        private GroupBox groupBox12;
        private Button btnConfigBackup;
        private Button btnConfigBakBrowse;
        private Label label100;
        private TextBox txtConfigBakServerName;
        private Label label91;
        private Button btnConfigBakConfig;
        private Button btnConfigBakOpen;
        private Label label93;
        private Label label94;
        private GroupBox groupBox8;
        private Label lblConfigSerDirMsg;
        private Button btnConfigSerDirBrowse;
        private TextBox txtConfigSerDir;
        private Label label56;
        private GroupBox groupBox3;
        private Label lblConfigTmpDirMsg;
        private Button btnConfigTmpDirBrowse;
        private TextBox txtConfigTempDir;
        private Label label49;
        private TabPage tbPgAutoProcess;
        private Label label102;
        private CheckBox chkAutoFixAirREMS;
        private Label label96;
        private Label label92;
        private Label label39;
        private ComboBox cobStartStep;
        private Label label44;
        private Label label42;
        private Label label41;
        private Label label40;
        private Label label38;
        private Label label34;
        private Button btnAutoCancel;
        private Button btnAutoProcess;
        private TextBox txtAutoOut;
        private TabPage tbPgBlobsCreat;
        private SplitContainer splitContainer6;
        internal TextBox txtBlobsServer;
        private Label label10;
        private Label lblBlobsMsg;
        private Button btnBlobsDBConfig;
        private Button btnBlobsOpen;
        private TextBox txtBlobsVer;
        private Label label21;
        internal TextBox txtBlobsDB;
        private Label label22;
        private Button btnBlobsProcess;
        private Button btnBlobsCancel;
        private GroupBox groupBox1;
        internal RadioButton optMissingBlobs;
        internal RadioButton optAllTheBlobs;
        private TextBox txtBlobsOut;
        private TabPage tbPgMergFederal;
        private SplitContainer splitContainer7;
        private GroupBox groupBox4;
        internal TextBox txtMergeFMModuleServer;
        private Label label69;
        private Label label70;
        private Button btnMergeFMModuleConfig;
        internal TextBox txtMergeFMModuleDB;
        private Label label71;
        internal TextBox txtMergeFMMasterServer;
        private Label label66;
        private Button btnMergeFMMasterConfig;
        internal TextBox txtMergeFMMasterDB;
        private Label label68;
        private Label lblMergeFModuleMsg;
        private TextBox txtMergeFMasterVer;
        private Label label19;
        private Button btnMergeFModuleOpen;
        private TextBox txtMergeFModuleVer;
        private Label label18;
        private Label label23;
        private Button btnMergeFMasterOpen;
        private Label label32;
        private Label lblMergeFMasterMsg;
        private Label label33;
        private Label label20;
        private Label label17;
        private Label label14;
        private Button btnMergeFProcess;
        private Button btnMergeFCancel;
        internal TextBox txtDateSC;
        internal TextBox txtDateDA;
        internal TextBox txtVNameSC;
        internal TextBox txtVNameDA;
        private TextBox textBox8;
        private TextBox textBox7;
        private TextBox txtMergeFdOut;
        private TabPage tbPgMergSt;
        private SplitContainer splitContainer8;
        internal TextBox txtMergeSTServer;
        private Label label72;
        private Button btnMergeSTConfig;
        internal TextBox txtMergeSTDB;
        private Label label73;
        private Label lblMergeStMsg;
        private Button btnMergeSTOpen;
        internal TextBox txtMergeSTVer;
        private Label label24;
        private Label lblMergeSTModuleRoot;
        private Label lblMergeSTSateRoot;
        private Button btnMergeSTModuleRoot;
        private Button btnMergeSTSateRoot;
        internal CheckBox chkMergeSynCheck;
        private Button btnMergeSTCancel;
        private TextBox txtMergeSTOut;
        private Button btnMergeSTProcess;
        internal TextBox txtMergeSTVerName;
        private Label label30;
        internal TextBox txtMergeSTDate;
        private Label label31;
        private Button btnMergeSTRemoveAll;
        private Button btnMergeSTAddAll;
        internal ListBox lstMergeSTStates;
        internal ListBox lstMergeSTAvaiSt;
        private Button btnMergeSTAdd;
        private Button btnMergeSTRemove;
        private Label label28;
        private Label label29;
        internal TextBox txtMergeSTModuleRoot;
        private Label label27;
        internal TextBox txtMergeSTSateRoot;
        private Label label26;
        private TabPage tbPgDelState;
        private SplitContainer splitContainer3;
        internal TextBox txtDelStServer;
        private Label label7;
        private Button btnSelStConfig;
        internal TextBox txtDelStDB;
        private Label label9;
        private Label lblDelStMsg;
        private Button btnDelStOpen;
        private TextBox txtDelStVer;
        private Label label8;
        private Button btnDelStCancel;
        private TextBox txtDelStOut;
        private Button btnDelStProcess;
        private TabPage tbPgModuleDel;
        private SplitContainer splitContainer1;
        internal TextBox txtDelModServer;
        private Label label2;
        private Button btnDelModConfig;
        internal TextBox txtDelModDB;
        private Label label6;
        private Label lblDelModuleMsg;
        private Button btnDelModOpen;
        private TextBox txtDelModVer;
        private Label label3;
        private Button btnDelModCancel;
        private Button btnDelModRemAll;
        private Button btnDelModAddAll;
        internal ListBox lstDelModSel;
        internal ListBox lstDelModAvail;
        private Button btnDelModProcess;
        private Button btnDelModAdd;
        private Button btnDelModRemove;
        private TextBox txtDelModOut;
        private Label label5;
        private Label label4;
        private TabPage tbPgBuildMODULE;
        private SplitContainer splitContainer4;
        private Button btnModuleOpen;
        private TextBox txtModuleVer;
        private Label label16;
        internal TextBox txtModuleServer;
        private Label label64;
        private Button btnModuleDBConfig;
        internal TextBox txtModuleDB;
        private Label label65;
        private Button cmdFixAirREM;
        private Button btnModuleRemoveAll;
        private Button btnModuleAddAll;
        private Button btnModuleStart;
        private Button btnModuleCancel;
        private Label lblModuleMsg;
        internal ListBox lstModuleSel;
        internal ListBox lstModuleAval;
        private Button btnModuleAdd;
        private Button btnModuleRemove;
        private Label label12;
        private Label label13;
        private Button btnModuleBrowse;
        internal TextBox txtModuleDir;
        private Label label11;
        private TextBox txtModuleOut;
        private TabPage tbPgBuildREM;
        private Button btnBuildREMCancel;
        private Label lblMsg;
        private Button btnBuildREMSel;
        private Button btnBuildREMProcess;
        private TextBox txtBuildREMOutput;
        private TextBox txtBuildREMDir;
        private Button btnBuildREMBrowse;
        private Label label1;
        private CheckBox chkBuildREMCalculate;
        private TabControl tabControl;
        private TextBox txtConfigBakPath;
        private TextBox txtConfigResServerName;
        private TextBox txtConfigResDBName;
        private TextBox txtConfigBakDBName;
        private TextBox txtConfigBakVer;
        private Label lblConfigResMsg;
        private Label lblConfigBakMsg;
        private Button btnConfigResOpen;

        //private TextBox textBox1;
    }
}

